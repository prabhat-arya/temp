
package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.LeaveTypeDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.LeaveTypeService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_LEAVETYPE)
public class LeaveTypeController {

	private static final Logger logger = LoggerFactory.getLogger(LeaveTypeController.class);

	@Autowired
	private LeaveTypeService service;

	/**
	 * Returns status code when new leave is created
	 * 
	 * @param model - new leave data
	 * @return - ResponseEntity
	 */

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody LeaveTypeDTO model) {
		try {
			boolean isExists2 = service.validate(model, true);
			if (isExists2) {
				logger.info("LeaveType record is Already is exist");

				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> save = service.save(model);
				if (save.isEmpty()) {
					logger.info("LeaveType failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("LeaveType record is inserted:{}", model.getLeaveType());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding  LeaveType:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.LEAVETYPE);

		}

	}

	/**
	 * Returns All Leave data when Leave data is available
	 * 
	 * @return - List of LeaveResponseModel
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllLeaves(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);
			if (data.isEmpty()) {
				logger.info("LeaveTypes record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("LeaveTypes found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting LeaveTypes:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVETYPE);

		}

	}

	/**
	 * Returns leave and status code when leave data is available by id
	 * 
	 * @param id - Leave Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId=AES.decryptUrl(companyId);
		try {
			LeaveTypeDTO leaveById = service.getById(data,companyId);
			if (leaveById != null) {
				List<LeaveTypeDTO> list = new ArrayList<>();
				list.add(leaveById);
				logger.info("Leave found with ID:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Not found Leave by Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Leave by Id:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVE);
		}
	}

	/**
	 * Returns status code when existing leave data is updated
	 * 
	 * @param model - new leave data
	 * @param id    - leave Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody LeaveTypeDTO model) {

		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("LeaveType  record is Already is exist");

				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> updateLeave = service.updateLeave(model, model.getId());
				if (updateLeave.isEmpty()) {
					logger.info("LeaveType failed to update");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("LeaveType  record is updated with Id:{}", model.getId());
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateLeave),
							HttpStatus.OK);
				}
			}
		} catch (Exception e) {

			logger.error("Error while updating  LeaveType");
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.LEAVETYPE);

		}
	}

	/**
	 * Returns All LeaveType when LeaveType data is available
	 * 
	 * @return - List of LeaveType
	 */

	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> leaveTypes(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {

			List<LeaveTypeDTO> allleaveTypes = service.AllLeavesTypes(companyId);

			if (!allleaveTypes.isEmpty()) {
				logger.info("Found:{}  {}", allleaveTypes.size(), Constants.LEAVETYPE);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allleaveTypes),
						HttpStatus.OK);
			} else {
				logger.info("LeaveTypes Records are not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVETYPE);
		}
	}

	/**
	 * Update Assets by status
	 * 
	 * @param id  - LeaveType Id
	 * @param Map object
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/leaveTypeStatus", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateAssetsByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateLeaveTypeByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("LeaveType updated With Id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Error while updating LeaveType by Id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating LeaveType Status by Id:{}", status.getId());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.LEAVETYPE);
		}
	}

	/**
	 * Soft delete method
	 * 
	 * @param id - LeaveType Id
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteLeaveType(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> leaveTypeList = service.softDeleteLeaveType(dto.getId());
			if (!leaveTypeList.isEmpty()) {
				logger.info("LeaveType Deleted With id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, leaveTypeList),
						HttpStatus.OK);
			} else {
				logger.info("LeaveType Not Deleted With Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Deleting LeaveType  by Id:{}", dto.getId());
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.LEAVETYPE);

		}
	}

}