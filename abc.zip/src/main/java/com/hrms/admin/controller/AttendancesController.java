package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.AttendanceDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.AttendanceService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Attendance Record
 * 
 * @author {Chandu}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_ATTENDANCE)
public class AttendancesController {
	private static final Logger logger = LoggerFactory.getLogger(AttendancesController.class);

	@Autowired
	private AttendanceService service;

	/**
	 * Returns status code when new attendance is created
	 * 
	 * @param model - new attendance data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody AttendanceDTO model) {

		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Attendance already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> save = service.save(model);
				if (save.isEmpty()) {
					logger.info("Attendance failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Attendance Added successfully");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save),
							HttpStatus.CREATED);
				}

			}
		} catch (Exception e) {
			logger.error("Error while adding Attendance:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.ATTENDANCE);
		}
	}

	/**
	 * Returns status code when existing attendance data is updated
	 * 
	 * @param model - new attendance data
	 * @param id    - attendance Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody AttendanceDTO model) {

		try {
			List<EntityDTO> updateAttendnace = service.updateAttendnace(model);
			if (updateAttendnace.isEmpty()) {
				logger.info("Attendance failed to Updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("Attendance Updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateAttendnace),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while updating Attendance:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.ATTENDANCE);

		}
	}

	/**
	 * Returns attendance and status code when attendance data is available by id
	 * 
	 * @param id - attendance Id
	 * @return - ResponseEntity
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllAttendnace(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);
			if (data.isEmpty()) {
				logger.info("Attendance is not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Attendance found:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Attendance:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE);
		}

	}

	/**
	 * Returns attendance and status code when attendance data is available by id
	 * 
	 * @param id - attendance Id
	 * @return - ResponseEntity
	 */

	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			AttendanceDTO findById = service.getById(data);
			if (findById != null) {
				logger.info("Attendance found by Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, findById), HttpStatus.OK);
			} else {
				logger.info("Attendance not found by Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Attendance:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE);
		}
	}

	/**
	 * Returns All attendance data when attendance data is available
	 * 
	 * @return - List of attendanceModel
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> findByCompanyId(@PathVariable String id) {
		String data = AES.decryptUrl(id);
		try {
			List<AttendanceDTO> allAttendance = service.getCompanyId(data);
			if (!allAttendance.isEmpty()) {
				logger.info("Attendance found by companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allAttendance),
						HttpStatus.OK);
			} else {
				logger.info("Attendance not found by companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while adding attendance:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE);
		}

	}

	/**
	 * Soft Delete
	 * @param id - attendance Id
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteAttendance(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> attendanceList = service.softDeleteAttendance(dto.getId());
			if (!attendanceList.isEmpty()) {
				logger.info("Attendance soft deleted with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, attendanceList),
						HttpStatus.OK);
			} else {
				logger.info("Attendance not soft deleted With Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while soft deleting Attendance by Id:{}", dto.getId() + "  " + e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + "Attendance");
		}
	}

	/**
	 * Update Attendance by status
	 * @param id  - status
	 * @param Map object
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateAttendanceByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateAttendanceByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("Attendance updated with Id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Attendance not updating with Id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Attendance Status by Id:{}", status.getId() + " : " + e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + "Attendance");
		}
	}
}
