package com.hrms.admin.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PasswordDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.service.EmployeeLoginService;
import com.hrms.admin.util.Base64ForgotPasswordUtility;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;

@Controller
//@RequestMapping("/test")
public class ForgetPasswordContoller {
	private static final Logger logger = LoggerFactory.getLogger(ForgetPasswordContoller.class);
	@Autowired
	private EmployeeLoginService loginService;

	@Value("${reset.url.link}")
	private String resetPwdLink;

	@Autowired
	private EmailServiceUtil mailService;

	@Value("${page.redirect.link}")
	private String redirectLink;

	@PostMapping(path = "/generateforgotPasswordToken")
	public ResponseEntity<ResponseDTO> forgotPassword(HttpServletRequest request, @RequestBody PasswordDTO passwordDTO)
			throws MailException, MessagingException {
		logger.info("*************forgotPassword Starting***************");
		Employee userByUserEmail = loginService.getUserByUserEmail(passwordDTO.getEmail());
		if (userByUserEmail == null) {
			logger.info("User not found in the record.");
			return new ResponseEntity<>(new ResponseDTO("User not found in the record", Constants.FALSE),
					HttpStatus.OK);
		}
		Employee createFogotPasswordResetToken = loginService.createForgotPasswordResetToken(passwordDTO.getEmail());
		String token = createFogotPasswordResetToken.getToken();
		mailService.sendForgotMail(passwordDTO.getEmail(), token,
				userByUserEmail.getFirstName() + " " + userByUserEmail.getLastName(),userByUserEmail.getCompany().getId());
		logger.info("*************Reset Password mail sent***************");
		return new ResponseEntity<>(new ResponseDTO("Email Sent Successfully", Constants.TRUE), HttpStatus.OK);
	}

	@GetMapping(value = "/tokenValidate/{token}")
	public String tokenValidate(@PathVariable("token") String token, Model model, HttpServletResponse resp) {
		PasswordDTO passwordDTO = new PasswordDTO();
		passwordDTO.setToken(token);
		model.addAttribute("passwordDTO", passwordDTO);
		String result = loginService.findtoken(token);
		EntityDTO validatetTokenAndSavePassword = null;
		if (result != null) {
			logger.info("*************Token Validate done ***************");
			try {
				validatetTokenAndSavePassword = loginService.validatetTokenAndSavePassword(token);
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		resp.setStatus(HttpStatus.TEMPORARY_REDIRECT.value());
		return "reset-password";
	}

	// From Mail user will get link and temp password and if temp password available
	/**
	 * @param id - token
	 * @throws IOException
	 */

	@SuppressWarnings("unchecked")
	@PostMapping("/validateforgotPasswordToken")
	public ResponseEntity<ResponseDTO> showChangePasswordPage(@RequestParam Map<String, String> data,
			HttpServletResponse resp) throws IOException {

		String token1 = data.get("token");
		String result = loginService.findtoken(token1);
		String newPassword = Base64ForgotPasswordUtility.decodePassword(data.get("newPassword"));
		String confirmPassword = Base64ForgotPasswordUtility.decodePassword(data.get("confirmPassword"));
		try {
			if (result != null) {
				List<EntityDTO> list = loginService.validatetTokenAndSavePassword(newPassword, confirmPassword, token1);
				if (list.get(0).getName().equals("enter valid password")) {
					return new ResponseEntity<>(new ResponseDTO("Provide proper password", Constants.FALSE),
							HttpStatus.OK);
				}
				if (list.get(0).getName().equals("Password mismatched")) {
					return new ResponseEntity<>(new ResponseDTO("Password doesn't match. Please enter it correctly.",
							Constants.FALSE, list), HttpStatus.OK);
				}

			}
		} catch (Exception e) {

			return new ResponseEntity<>(new ResponseDTO("password reset  failed.", Constants.FALSE),
					HttpStatus.BAD_REQUEST);

		}
		resp.sendRedirect(redirectLink);
		return null;
	}
}
