package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PayrollCaluclateDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.payroll.dto.DeductionsDTO;
import com.hrms.admin.payroll.dto.EarningsDTO;
import com.hrms.admin.payroll.dto.PayCalculateViewDTO;
import com.hrms.admin.payroll.dto.PayScheduleDTO;
import com.hrms.admin.payroll.dto.PayrollRequestDTO;
import com.hrms.admin.payroll.dto.PayslipGenerationDTO1;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.role.dto.EmployeeIdsDTO;
import com.hrms.admin.service.PayrollService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.FieldsValidation;
import com.hrms.admin.util.URLConstants;

@CrossOrigin
@RestController
@RequestMapping(URLConstants.ADMIN_PAYROLL)
public class PayrollController {

	@Autowired
	private PayrollService payrollService;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private FieldsValidation validation;
	private static final Logger logger = LoggerFactory.getLogger(PayrollController.class);

	/**
	 * @param payrollDto -empId,branchId,empCtc
	 * 
	 * @return ResponseEntity
	 */
	@SuppressWarnings("unused")
	@PostMapping(value = "/calculate", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> payRollCalculation(@RequestBody PayrollCaluclateDTO payrollDto,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			double num = 0.0;
			if (payrollDto.getEmpCTC() != num) {
				boolean isflag = validation.validateDecimalValue(payrollDto.getEmpCTC().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Bank record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			if (!Objects.isNull(payrollDto.getBranchId())) {
				PayCalculateViewDTO payCalculateViewDTO = payrollService.payRollCalculation(payrollDto,
						payrollDto.getBranchId(),companyId);
				logger.info("payroll calculated successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, payCalculateViewDTO),
						HttpStatus.OK);
			} else {
				logger.info("payroll not calculated");
				return new ResponseEntity<>(new ResponseDTO(Constants.BAD_REQUEST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			logger.error("Error while calculating payroll");
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while calculating payroll");
			return new ResponseEntity<>(new ResponseDTO(Constants.NOT_EXECUTED, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * @param payrollDto- date,empId,ctc
	 * 
	 * @return ResponseEntity
	 */
	@PostMapping(value = "/generate", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> payRollGeneration(@RequestBody PayrollRequestDTO payrollDto) {

		try {
			PayslipGenerationDTO1 payslipGenerationDTO1 = null;

			if (payrollDto != null && payrollDto.getEmployeeId() != 0) {
				Optional<Employee> employee = employeeRepository.findById(payrollDto.getEmployeeId());
				if (employee.isPresent()) {
					Employee emp = employee.get();
					String date = payrollDto.getDate();
					if (date.length() == 6) {
						payrollDto.setDate("0" + date);
					}
					payslipGenerationDTO1 = payrollService.payrollGeneration1(payrollDto, emp.getBranch().getId());
				}
				return new ResponseEntity<>(
						new ResponseDTO("PaySlip Generated successfully", Constants.TRUE, payslipGenerationDTO1),
						HttpStatus.OK);
			} else {
				logger.info("payRoll is not Generated");
				return new ResponseEntity<>(new ResponseDTO(Constants.BAD_REQUEST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			logger.info("payroll not Generated");
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.info("payroll not Generated");
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * @return ResponseEntity
	 */
	@GetMapping("/getallemps")
	public ResponseEntity<ResponseDTO> getAllEmployeeIds(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			return new ResponseEntity<>(
					new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, payrollService.getEmployeeIds(companyId)),
					HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while geting all EmployeeId record:{}", e);
			return new ResponseEntity<>(new ResponseDTO(Constants.BAD_REQUEST, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Returns status code when new Earnings is created
	 * 
	 * @param earningsDTO -new object
	 * @return ResponseEntity
	 */
	@PostMapping(value = "/earnings", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> createEarningType(@RequestBody EarningsDTO earningsDTO,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			double num = 0.0;
			if (earningsDTO.getFlatAmount() != num) {
				boolean isflag = validation.validateDecimalValue(earningsDTO.getFlatAmount().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			if (earningsDTO.getPercentage() != num) {
				boolean isflag1 = validation.validateDecimalValuePercentage(earningsDTO.getPercentage().toString());
				if (Boolean.FALSE.equals(isflag1)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			boolean isExists = payrollService.validate(earningsDTO, true,companyId);
			if (isExists) {
				logger.info("Earnings record is already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {

				List<EntityDTO> earningsLIst = payrollService.save(earningsDTO, earningsDTO.getBranchId(),companyId);
				if (earningsLIst.isEmpty()) {
					logger.info("Eearnings fail to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Earnings record is inserted:{}", earningsDTO.getEarningName());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, earningsLIst),
							HttpStatus.CREATED);
				}
			}

		} catch (Exception e) {
			logger.error("Error while storing Earnings record:{}", e);
			throw new NotCreatedException(e + " " + Constants.EARNINGS);
		}

	}

	/**
	 * @return all the earnings data
	 */
	@GetMapping("/earningsList")
	public ResponseEntity<ResponseDTO> getAllEarnings(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			List<EarningsDTO> allEarnings = payrollService.allEarnings(companyId);
			if (!allEarnings.isEmpty()) {
				logger.info("Found Earnings with size:{}", allEarnings.size());
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allEarnings),
						HttpStatus.OK);
			} else {
				logger.info("Earnings Records are not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting all Records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EARNINGS);
		}
	}

	/**
	 * Returns status code when new Deductions is created
	 * 
	 * @param deductionsDTO- new DeductionsDTO data
	 * @return
	 */
	@PostMapping(value = "/deductions", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> createDeductionsType(@RequestBody DeductionsDTO deductionsDTO,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			double num = 0.0;
			if (deductionsDTO.getFlatAmount() != num) {
				boolean isflag = validation.validateDecimalValue(deductionsDTO.getFlatAmount().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			if (deductionsDTO.getPercentage() != num) {
				boolean isflag1 = validation.validateDecimalValuePercentage(deductionsDTO.getPercentage().toString());
				if (Boolean.FALSE.equals(isflag1)) {
					logger.info("Earnings record contains Invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			boolean isExists = payrollService.validate(deductionsDTO, true,companyId);
			if (isExists) {
				logger.info("Deductions record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> deductionsLIst = payrollService.save(deductionsDTO, deductionsDTO.getBranchId(),companyId);
				if (deductionsLIst.isEmpty()) {
					logger.info("Deductions fail to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Deductions record is inserted:{}", deductionsDTO.getDeductionName());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, deductionsLIst),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while storing Deductions record:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.DEDUCTIONS);
		}

	}

	/**
	 * @return all the Deductions data
	 */
	@GetMapping("/deductionsList")
	public ResponseEntity<ResponseDTO> getAllDeductions(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			List<DeductionsDTO> allDeductions = payrollService.allDeductions(companyId);
			if (!allDeductions.isEmpty()) {
				logger.info("Found Deductions with size:{}", allDeductions.size());
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allDeductions),
						HttpStatus.OK);
			} else {
				logger.info("Deductions Records are not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting all Records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEDUCTIONS);
		}

	}

	/**
	 * Returns status code when existing Earnings data is updated
	 * 
	 * @param model - new Earnings data
	 * @param id    - earnings Id
	 * @return ResponseEntity
	 */
	@PutMapping(value = "/earningsUpdate", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> earningsUpdate(@Valid @RequestBody EarningsDTO model) {

		try {
			double num = 0.0;
			if (model.getFlatAmount() != num) {
				boolean isflag = validation.validateDecimalValue(model.getFlatAmount().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Earnings record contains invalid data ");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			if (model.getPercentage() != num) {
				boolean isflag1 = validation.validateDecimalValuePercentage(model.getPercentage().toString());
				if (Boolean.FALSE.equals(isflag1)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			List<EntityDTO> updateEarning = payrollService.updateEarning(model, model.getId());
			if (!updateEarning.isEmpty()) {
				logger.info("Earnings Updation Successfull");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEarning),
						HttpStatus.OK);
			} else {
				logger.info("Earnings Updation failed");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating Earnings:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EARNINGS);
		}
	}

	/**
	 * Returns status code with all the existing earnings data
	 * 
	 * @param id - earnings Id
	 * @return - ResponseEntity
	 */

	@PutMapping(value = "/earningDelete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteEarning(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> earningsList = payrollService.softDeleteEarnings(dto.getId());
			if (!earningsList.isEmpty()) {
				logger.info("Earnings Soft Deleted With id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, earningsList),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Soft Deleting Earnings with Id:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.EARNINGS);
		}
	}

	/**
	 * Returns status code when existing deductions data is updated
	 * 
	 * @param model - new deductions data
	 * @param id    - deductions Id
	 * @return ResponseEntity
	 */

	@PutMapping(value = "/deductionsUpdate")
	public ResponseEntity<ResponseDTO> deductionsUpdate(@Valid @RequestBody DeductionsDTO model) {

		try {
			double num = 0.0;
			if (model.getFlatAmount() != num) {
				boolean isflag = validation.validateDecimalValue(model.getFlatAmount().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			if (model.getPercentage() != num) {
				boolean isflag1 = validation.validateDecimalValuePercentage(model.getPercentage().toString());
				if (Boolean.FALSE.equals(isflag1)) {
					logger.info("Earnings record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			List<EntityDTO> updateDeduction = payrollService.updateDeduction(model, model.getId());
			if (!updateDeduction.isEmpty()) {
				logger.info("Deductions Updation Successfull");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateDeduction),
						HttpStatus.OK);
			} else {
				logger.info("Deductions Updation failed");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating Deductions:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.DEDUCTIONS);
		}
	}

	/**
	 * Returns status code with all the existing deductions data
	 * 
	 * @param id - deductions Id
	 * @return - ResponseEntity
	 */

	@PutMapping(value = "/deductionDelete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteDeduction(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> deductionsList = payrollService.softDeleteDeduction(dto.getId());
			if (!deductionsList.isEmpty()) {
				logger.info("Deductions Soft Deleted With Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, deductionsList),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Soft Deleting Deductions with Id:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.DEDUCTIONS);
		}
	}

	/**
	 * @param pagingDto
	 * @return earnings list with pagination
	 */
	@PostMapping(value = "/earningPage", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllEarningsByPage(@RequestBody PaginationDTO pagingDto,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = payrollService.getAllEarningsByPage(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStatus(),companyId);
			if (data.isEmpty()) {
				logger.info("Earning record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("Earning  record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Earning:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EARNING);
		}
	}

	/**
	 * @param pagingDto
	 * @return deductions list with pagination
	 */
	@PostMapping(value = "/deductionPage", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllDeductionsByPage(@RequestBody PaginationDTO pagingDto,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = payrollService.getAllDeductionsByPage(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStatus(),companyId);
			if (data.isEmpty()) {
				logger.info("Deduction record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("Deduction record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Deduction:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEDUCTION);
		}
	}

	/**
	 * @param employeeIdsDTO-list of empIds
	 * 
	 * @return send payslips to employees
	 */
	@PostMapping(value = "/employeePayslip", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void employeePayslip(@RequestBody EmployeeIdsDTO employeeIdsDTO) {
		payrollService.employeePayslip(employeeIdsDTO);
	}

	/**
	 * Returns status code when new PaySchedule is created
	 * 
	 * @param payScheduleDTO
	 * @return ResponseEntity
	 */
	@PostMapping(value = "/paySchedule", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> createPaySchedule(@RequestBody PayScheduleDTO payScheduleDTO,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			boolean isExists = payrollService.validate(payScheduleDTO, true,companyId);
			if (isExists) {
				logger.info("PaySchedule record is Already exist :: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> deductionsLIst = payrollService.createPaySchedule(payScheduleDTO,companyId);
				if (deductionsLIst.isEmpty()) {
					logger.info("PaySchedule fail to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("PaySchedule record is inserted:{}", payScheduleDTO.getBranchId());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, deductionsLIst),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while storing paySchedule record:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.PAY_SCHEDULE);
		}

	}

	/**
	 * Returns status code and PaySchedule record
	 * 
	 * @param branchId
	 * @return ResponseEntity
	 */
	@GetMapping("/getPaySchedule/{branchId}")
	public ResponseEntity<ResponseDTO> getPayScheduleByBranchId(@PathVariable("branchId") String branchId) {
		Long data = Long.parseLong(AES.decryptUrl(branchId));
		try {
			PayScheduleDTO payScheduleDTO = payrollService.getPayScheduleByBranchId(data);
			if (payScheduleDTO != null) {
				List<PayScheduleDTO> list = new ArrayList<>();
				list.add(payScheduleDTO);
				logger.info("Found PaySchedule with branchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("PaySchedule Records are not available with branchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			logger.error("Error while getting Records:{}", e);
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PAY_SCHEDULE);
		}
	}

	/**
	 * Returns status code when existing PaySchedule data is updated
	 * 
	 * @param model -new PaySchedule data
	 * @param id    -payscheduleId
	 * @return ResponseEntity
	 */
	@PutMapping(value = "/payScheduleUpdate")
	public ResponseEntity<ResponseDTO> payScheduleUpdate(@Valid @RequestBody PayScheduleDTO model) {
		try {
			List<EntityDTO> updatePaySchedule = payrollService.payScheduleUpdate(model, model.getId());
			if (!updatePaySchedule.isEmpty()) {
				logger.info("PaySchedule Updation Successfull");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updatePaySchedule), HttpStatus.OK);
			} else {
				logger.info("PaySchedule updation failed");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating PaySchedule:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EARNINGS);
		}
	}

	/**
	 * @param empId
	 * 
	 * @return download the payslip
	 */
	@GetMapping("/pdf/{empId}")
	public void downloadPdf(@PathVariable("empId") String empId, @RequestParam("date") String date) {
		Long empData = Long.parseLong(AES.decryptUrl(empId));
		payrollService.downloadPdf(empData, date);

	}

	/**
	 * Returns earnings and status code when earnings data is available by id
	 * 
	 * @param id - earnings id
	 * @return ResponseEntity
	 */
	@GetMapping("/getEarnings/{id}")
	public ResponseEntity<ResponseDTO> getEarningsById(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			EarningsDTO earningsDTO = payrollService.getById(data);
			if (earningsDTO != null) {
				List<EarningsDTO> list = new ArrayList<>();
				list.add(earningsDTO);
				logger.info("Earnings found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Earnings Not Found by Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Earnings with Id:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EARNING);
		}
	}

	/**
	 * Returns deductions and status code when deductions data is available by i
	 * 
	 * @param id -deductionsId
	 * @return ResponseEntity
	 */
	@GetMapping("/getDeductions/{id}")
	public ResponseEntity<ResponseDTO> getDeductionsById(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			DeductionsDTO deductionsDTO = payrollService.getDeductionsById(data);
			if (deductionsDTO != null) {
				List<DeductionsDTO> list = new ArrayList<>();
				list.add(deductionsDTO);
				logger.info("Deduction found with deductionsId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Deduction Not Found by deductionsId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			logger.error("Error while getting Deduction with deductionsId:{}", e);
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Deduction:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEDUCTION);
		}
	}

	/**
	 * update the status if record is available by deductionsId
	 * 
	 * @param id - dedctuionsId
	 * @return ResponseEntity
	 */
	@PutMapping(value = "/deductionStatusUpdate", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> deductionStatusUpdate(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> deductionsList = payrollService.deductionStatusUpdate(dto.getId());
			if (!deductionsList.isEmpty()) {
				logger.info("Deductions status updated With Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, deductionsList),
						HttpStatus.OK);
			} else {
				logger.info("Deductions status failed to updated with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating Deductions Status by Id:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.UPDATING_ERROR + " " + Constants.DEDUCTION);
		}
	}

	/**
	 * update the status if record is available by earningsId
	 * 
	 * @param id - earningsId
	 * @return ResponseEntity
	 */
	@PutMapping(value = "/earningsStatusUpdate", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> earningsStatusUpdate(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> deductionsList = payrollService.earningsStatusUpdate(dto.getId());
			if (!deductionsList.isEmpty()) {
				logger.info("Earnings status updated With Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, deductionsList),
						HttpStatus.OK);
			} else {
				logger.info("Earnings status failed to updated with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (NullPointerException e) {
			logger.error("Error while updating Earnings Status with Id:{} : {}", dto.getId(), e);
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating Earnings Status with Id:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.UPDATING_ERROR + " " + Constants.EARNING);
		}
	}

	/**
	 * @param salaryComponentId
	 * 
	 * @return download the payslip
	 */
	@GetMapping("/payslip/{salaryComponentId}")
	public void downloadPaySlip(@PathVariable String salaryComponentId) {
		 Long data = Long.parseLong(AES.decryptUrl(salaryComponentId));
		payrollService.downloadPaySlip(data);
	}
	
	@GetMapping("/payslip-gen")
	public ResponseEntity<ResponseDTO> generatePaySlip(@RequestHeader String companyId) {

		try {
			Map<Long, String> generatePayslipByCompany = payrollService.generatePayslipByCompany(companyId);
			
			if (!generatePayslipByCompany.isEmpty()) {
				logger.info("Controller--PaySlip generated");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, generatePayslipByCompany), HttpStatus.OK);
			} else {
				logger.info("Controller--PaySlip Not generated");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}
}
