package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.BranchService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_BRANCH)
public class BranchController {

	private static final Logger logger = LoggerFactory.getLogger(BranchController.class);

	@Autowired
	private BranchService service;

	/**
	 * Returns status code when new branch is created
	 * 
	 * @param model - new branch data
	 * @return - ResponseEntity
	 */

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody BranchDTO model) {
		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Branch already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> branchList = service.save(model);
				if (branchList.isEmpty()) {
					logger.info("Branch failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {

					logger.info("Branch added successfully");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, branchList),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding branch:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.BRANCH);
		}
	}

	/**
	 * Returns All Branch data when branch data is available
	 * 
	 * @return - List of BranchResponse
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto,@RequestHeader String companyId) {
		try {
			Map<String, Object> data = service.getAllBranch(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),AES.decryptUrl(companyId));
			if (data.isEmpty()) {
				logger.info("Branch not founded:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Branch founded:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Branch:{}",e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.BRANCH);
		}

	}

	/**
	 * Returns branch and status code when branch data is available by id
	 * 
	 * @param id - branch Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		String cmpId = AES.decryptUrl(companyId);
		try {
			BranchDTO branchById = service.getById(data,cmpId);
			if (branchById != null) {
				List<BranchDTO> list = new ArrayList<>();
				list.add(branchById);
				logger.info("Branch found with branchId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Branch not found by branchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting branch by branchId:{}",data + " : "+ e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " +Constants.BRANCH);
		}
	}

	/**
	 * Returns status code when existing branch data is updated
	 * 
	 * @param model - new branch data
	 * @param id    - branch Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody BranchDTO model) {
		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.error("Branch Already existed");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> branchList = service.updateBranch(model);
				if (branchList.isEmpty()) {
					logger.info("Branch failed to updated");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Branch updated successfully");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, branchList),
							HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating branch by branchId:{}", model.getId() +" : "+e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.BRANCH);
		}
	}

	/**
	 * Returns status code with all the existing branch data
	 * 
	 * @param id - branch Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allBranch(@PathVariable String id) {
		String data = AES.decryptUrl(id);
		try {
			List<BranchDTO> allBranchs = service.listOfBranch(data);
			if (!allBranchs.isEmpty()) {
				logger.info("Branch found by companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allBranchs),
						HttpStatus.OK);
			} else {
				logger.info("Branch not found by CompanyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding branch by companyId:{}",data+" : "+ e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.BRANCH);
		}
	}

	/**
	 * Returns status code with all the existing branch data
	 * 
	 * @param id - branch Id
	 * @return - ResponseEntity
	 */

	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteBranch(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> branchList = service.softDeleteBranch(dto.getId());

			if (branchList.isEmpty()) {
				logger.info("Branch not deleted with branchId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("Branch deleted with branchId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, branchList),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting branch with branchId:{}",dto.getId()+" : "+e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.BRANCH);
		}
	}

	/**
	 * Returns status code when existing branch data is updateAssetsByStatus
	 * 
	 * @param id  - branch Id
	 * @param Map object
	 * @return - ResponseEntity
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateBranchByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateBranchByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("Branch updated with branchId:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Branch not updated with branchId:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Branch status by bracnchId:{}" ,status.getId() +" : "+e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.BRANCH);
		}
	}
}