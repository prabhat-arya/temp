package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ResultDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.PolicyService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Policy Record
 * 
 * @author {Suresh}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_POLICY)
public class PolicyController {

	private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);

	@Autowired
	PolicyService policyService;

	/**
	 * Returns status code when new Policy is created
	 * 
	 * @param model - new policy data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> add(@RequestPart String policy, @RequestPart MultipartFile file) {

		try {

			ObjectMapper mapper = new ObjectMapper();
			PolicyDTO policydto = mapper.readValue(policy, PolicyDTO.class);
			// validation checking
			List<ResultDTO> resultlist = new ArrayList<>();
			if (policydto.getName() == null || policydto.getName().isEmpty()
					|| policydto.getName().trim().length() == 0) {
				ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE, "Name should not be Empty");
				resultlist.add(result);
				return new ResponseEntity<>(new ResponseDTO("Name should not be Empty", Constants.FALSE, resultlist),
						HttpStatus.OK);
			} else if (!(policydto.getName().trim().length() >= 2) || !(policydto.getName().trim().length() <= 25)) {
				ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE,
						"Name should contain 2 to 25 characters");
				resultlist.add(result);
				return new ResponseEntity<>(
						new ResponseDTO("Name should contain 2 to 25 characters", Constants.FALSE, resultlist),
						HttpStatus.OK);
			}

			if (policydto.getCompanyId() == null) {
				ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE, "company Id should not be empty");
				resultlist.add(result);
				return new ResponseEntity<>(
						new ResponseDTO("company Id should not be empty", Constants.FALSE, resultlist), HttpStatus.OK);
			}
			// here call validation method
			boolean isExists = policyService.validate(policydto, true);
			if (isExists) {
				logger.info("Policy already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> savePolicy = policyService.save(policydto, file);
				if (!savePolicy.isEmpty()) {
					logger.info("Policy added successfully");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, savePolicy),
							HttpStatus.CREATED);
				} else {
					logger.info("Policy failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Policy:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.POLICY);
		}
	}

	/**
	 * Returns Policy and status code when policy data is available by id
	 * 
	 * @param id - Policy Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId=AES.decryptUrl(companyId);
		try {
			PolicyDTO policyById = policyService.getPolicyById(data, companyId);
			if (policyById != null) {
				List<PolicyDTO> list = new ArrayList<>();
				list.add(policyById);
				logger.info("Policy found with policyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Policy not found with policyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Policy with policyId:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.POLICY);
		}
	}

	/**
	 * Returns status code when existing Policy data is updated
	 * 
	 * @param model - new Policy data
	 * @param id    - Policy Id
	 * @return - ResponseEntity
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 *//*
		 * @PutMapping(path = "/{id}") public ResponseEntity<ResponseDTO>
		 * update(@PathVariable Long id, @RequestPart String policy,
		 * 
		 * @RequestPart MultipartFile file) throws JsonMappingException,
		 * JsonProcessingException {
		 * 
		 * try {
		 * 
		 * ObjectMapper mapper = new ObjectMapper(); PolicyDTO policydto =
		 * mapper.readValue(policy, PolicyDTO.class); // validation checking
		 * List<ResultDTO> resultlist = new ArrayList<>(); if (policydto.getName() ==
		 * null || policydto.getName().isEmpty() || policydto.getName().trim().length()
		 * == 0) { ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE,
		 * "Name should not be Empty"); resultlist.add(result); return new
		 * ResponseEntity<>(new ResponseDTO("Name should not be Empty", Constants.FALSE,
		 * resultlist), HttpStatus.OK); } else if (!(policydto.getName().trim().length()
		 * >= 2) || !(policydto.getName().trim().length() <= 25)) { ResultDTO result =
		 * new ResultDTO(new Date(), Constants.VALIDATE,
		 * "Name should contain 2 to 25 characters"); resultlist.add(result); return new
		 * ResponseEntity<>(new ResponseDTO("Name should contain 2 to 25 characters",
		 * Constants.FALSE, resultlist), HttpStatus.OK); }
		 * 
		 * if (policydto.getCompanyId() == null) { ResultDTO result = new ResultDTO(new
		 * Date(), Constants.VALIDATE, "company Id should not be empty");
		 * resultlist.add(result); return new ResponseEntity<>(new ResponseDTO(
		 * "company Id should not be empty", Constants.FALSE, resultlist),
		 * HttpStatus.OK); } // here call validation method boolean isExists =
		 * policyService.validate(policydto, false); if (isExists) {
		 * logger.info("Policy already exist"); return new ResponseEntity<>(new
		 * ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK); } else
		 * { List<EntityDTO> updatePolicy = policyService.update(id, policydto, file);
		 * if (!updatePolicy.isEmpty()) { logger.info("Policy added successfully");
		 * return new ResponseEntity<>( new ResponseDTO(Constants.UPDATE_SUCCESS,
		 * Constants.TRUE, updatePolicy), HttpStatus.OK); } else {
		 * logger.info("Policy failed to add"); return new ResponseEntity<>(new
		 * ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK); } } }
		 * catch (Exception e) { logger.error("Error while adding Policy"+ "",e); throw
		 * new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.POLICY); }
		 * }
		 * 
		 */

	/**
	 * Get all pagination
	 * 
	 * @param pagingDto
	 * @return pagination method
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = policyService.getAllPolicy(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					companyId);

			if (data.isEmpty()) {
				logger.info("Policys record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("policys record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting policy:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.POLICY);

		}
	}

	/**
	 * Getting all policy based on companyId
	 * 
	 * @param companyid
	 * @return getting all policy based on companyId
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allPolicyBasedOnCompanyId(@PathVariable String id) {
		String data = AES.decryptUrl(id);
		try {
			List<PolicyDTO> allPolicys = policyService.getAllPolicy(data);
			if (!allPolicys.isEmpty()) {
				logger.info("Found: {}  {} ", allPolicys.size(), Constants.POLICY);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allPolicys), HttpStatus.OK);
			} else {
				logger.info("Policies record not found with companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all policies record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.POLICY);
		}
	}

	/**
	 * Update policy based on status
	 * 
	 * @param dto
	 * @return update policy based on status
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updatePolicyByStatus(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> policyList = policyService.updatePolicyByStatus(dto.getId(), dto.getStatus());
			if (!policyList.isEmpty()) {
				logger.info("Policy updated with policyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Failed to deactivate policy with policyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Policy Status with policyId:{} : {}", dto.getId(), e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.POLICY);
		}
	}

	/**
	 * Soft delete method
	 * 
	 * @param dto
	 * @return soft delete method
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeletePolicy(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> policyList = policyService.softDeletePolicy(dto.getId());
			if (!policyList.isEmpty()) {
				logger.info("Policy deleted with policyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, policyList),
						HttpStatus.OK);
			} else {
				logger.info("Policy Not deleted with policyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting policy with policyId:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.POLICY);
		}
	}

	/**
	 * File date in input stream resource format
	 * 
	 * @author manikanta
	 * @param document id
	 * @return file date in input stream resource format
	 * @throws IllegalStateException
	 * @throws IOException
	 *//*
		 * @GetMapping("/document/{id}") public ResponseEntity<InputStreamResource>
		 * getDocument(@PathVariable String id) throws IllegalStateException,
		 * IOException { String data = AES.decryptUrl(id);
		 * logger.info("GetDocument Method Startd with Id:{}",data); DocumentDetails
		 * document= policyService.getDocument(data); InputStream in =
		 * document.getStream(); HttpHeaders headers = new HttpHeaders();
		 * headers.add("Content-Disposition", "attachment; filename=" +
		 * document.getTitle()); return ResponseEntity.ok().headers(headers).body(new
		 * InputStreamResource(in)); }
		 */
	/**
	 * List of all policies
	 * 
	 * @author manikanta
	 * @param policy name
	 * @return list of all policies
	 */
	@PostMapping(value = "/allpolicies/{name}")
	public ResponseEntity<ResponseDTO> getByPolicyName(@PathVariable String name,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			PolicyDTO policyById = policyService.getPolicyByName(name.toLowerCase(),companyId);
			if (!Objects.isNull(policyById)) {
				logger.info("Policy found with Name:{}", name);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, policyById), HttpStatus.OK);
			} else {
				logger.info("Policy not found with Name:{}", name);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Policy with Name:{} : {}", name, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.POLICY);
		}
	}
}
