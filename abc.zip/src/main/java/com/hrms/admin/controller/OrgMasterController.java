/*
 * package com.hrms.admin.controller;
 * 
 * import java.util.Map;
 * 
 * import javax.validation.Valid;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.MediaType; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.web.bind.annotation.CrossOrigin; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.hrms.admin.dto.OrgMasterDTO; import
 * com.hrms.admin.dto.ResponseDTO; import
 * com.hrms.admin.exceptions.NotCreatedException; import
 * com.hrms.admin.service.OrgMasterService; import
 * com.hrms.admin.util.Constants; import com.hrms.admin.util.URLConstants;
 * 
 * @RestController
 * 
 * @CrossOrigin
 * 
 * @RequestMapping(URLConstants.ADMIN_USER) public class OrgMasterController {
 * private static final Logger logger =
 * LoggerFactory.getLogger(OrgMasterController.class);
 * 
 * @Autowired private OrgMasterService service;
 * 
 * @PostMapping(path = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
 * public ResponseEntity<ResponseDTO> add(@Valid @RequestBody OrgMasterDTO
 * model) {
 * 
 * try {
 * 
 * boolean isExists = service.validate(model, true); if (isExists) {
 * logger.info("User record is Already exist"); return new ResponseEntity<>(new
 * ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK); }
 * 
 * boolean isExists1 = service.validateEmail(model, true); if (isExists1) {
 * logger.info("User Email record is Already exist"); return new
 * ResponseEntity<>(new ResponseDTO(Constants.EMAIL_ALREADY_EXIST,
 * Constants.FALSE), HttpStatus.OK); }
 * 
 * Map<String, String> saveUser = service.save(model); if (!saveUser.isEmpty())
 * { logger.info("user record is inserted"); return new ResponseEntity<>(new
 * ResponseDTO(Constants.PAGE_LIST, Constants.TRUE, saveUser),
 * HttpStatus.CREATED); } else { logger.info("user failed to insert"); return
 * new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
 * HttpStatus.OK); } } catch (Exception e) {
 * logger.error("Error while adding USer:{}", e.getMessage()); throw new
 * NotCreatedException(Constants.INSERTION_ERROR + " " + "User"); } }
 * 
 * 
 * // this method is use for only test purpose
 * 
 * @GetMapping("/list") public ResponseEntity<ResponseDTO> getusers() {
 * List<OrgMaster> allUser = service.getAll(); if (!allUser.isEmpty()) {
 * logger.info("user record is found"); return new ResponseEntity<>(new
 * ResponseDTO(Constants.LIST, Constants.TRUE, allUser), HttpStatus.OK); } else
 * { logger.info("user record is not found"); return new ResponseEntity<>(new
 * ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK); } }
 * 
 * }
 */