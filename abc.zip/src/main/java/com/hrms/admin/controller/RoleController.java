package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.role.dto.EmpRoleDTO;
import com.hrms.admin.role.dto.EmployeeRoleDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.service.impl.RoleTestJsonService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_ROLE)
public class RoleController {

	//	@Autowired
	//	private RoleService roleService;

	@Autowired
	private RolesRepository roleRepo;

	@Autowired
	private RoleTestJsonService roleTestJsonService;
	
//	@Autowired
//	private RoleJsonRepo roleJsonRepo;

	private static final Logger logger = LoggerFactory.getLogger(RoleController.class);

	// -- Creating New Role
	/**
	 * @param empRoleDto
	 * @return Creating New Role
	 */
	@PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> createNewRole(@RequestBody EmployeeRoleDTO empRoleDto, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			EmployeeRoles findByName = roleRepo.findRoleByCompany(empRoleDto.getRoleName(), companyId);
			if (findByName != null) {
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.TRUE),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE,
						roleTestJsonService.createRole(empRoleDto, companyId)), HttpStatus.OK);
			}
		} catch (Exception e) {

			e.printStackTrace();
			logger.error(e.getMessage());
			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.TRUE),
					HttpStatus.OK);
		}
	}

	// -- Adding User to Role
	/**
	 * @param empRoleDto
	 * @return Adding User to Role
	 */
	/*
	 * @SuppressWarnings("unused")
	 * 
	 * @PutMapping(value = "/assign") public ResponseEntity<ResponseDTO>
	 * addUserToRole(@RequestBody EmpRoleDTO empRoleDto){
	 * 
	 * EmployeeRoleDTO addUserListToRole =
	 * roleService.addUserListToRole(empRoleDto);
	 * 
	 * if(addUserListToRole != null) {
	 * 
	 * return new ResponseEntity<ResponseDTO>( new
	 * ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, addUserListToRole),
	 * HttpStatus.OK); }else { logger.info("Users failed to add to role"); return
	 * new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.INSERT_FAIL,
	 * Constants.FALSE), HttpStatus.OK); } }
	 */

	/*
	 * @PutMapping("/update") public ResponseEntity<ResponseDTO>
	 * updateRole(@RequestBody Long roleId, @RequestBody Long empId) {
	 * 
	 * }
	 */
	// -- Deleting User From Role
	/**
	 * @param empRoleDto
	 * @return Deleting User From Role
	 */

	/*
	 * @DeleteMapping(value = "/assign/delete") public ResponseEntity<ResponseDTO>
	 * deleteUserFromRole(@RequestBody EmployeeRoleDTO empRoleDto) {
	 * 
	 * try {
	 * 
	 * boolean deletedUser = roleService.deleteUserFromRole(empRoleDto);
	 * if(deletedUser == true) {
	 * 
	 * return new ResponseEntity<ResponseDTO>(new
	 * ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE,deletedUser ),
	 * HttpStatus.CREATED); }else { logger.info("User failed to Delete"); return new
	 * ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.DELETE_FAIL,
	 * Constants.FALSE), HttpStatus.OK); } }catch (Exception e) {
	 * 
	 * logger.error("Error while getting Roles: "+e); throw new
	 * NotDeletedException(Constants.DELETING_ERROR + " " + "Role"); } }
	 */
	// -- Role Pagination
	/**
	 * @param pagingDto
	 * @return Role Pagination
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllRoles(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = roleTestJsonService.getAllRoles(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStatus(), companyId);
			if (data.isEmpty()) {
				logger.info("Roles record is not avaliable");
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			} else {
				logger.info("Roles found: " + data);
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.LIST, Constants.TRUE, data),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Roles: " + e);
			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	// --AllMenusList
	/**
	 * @return All Menus List
	 */
	@GetMapping("/getmenus")
	public ResponseEntity<ResponseDTO> getAllMenus() {
		try {
			List<MenuSortingDTO> allMenus = roleTestJsonService.getAllMenus();
			if (allMenus.isEmpty()) {

				logger.info("Menu record is not avaliable");
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);

			} else {

				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.LIST, Constants.TRUE, allMenus),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Roles: " + e);
			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	// --AllRolesList
	/**
	 * @return All Roles List
	 */
	@GetMapping("/getroles")
	public ResponseEntity<ResponseDTO> getAllRoles(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			List<EmpRoleDTO> allRoles = roleTestJsonService.getAllRoles(companyId);
			if (allRoles.isEmpty()) {

				logger.info("Roles record is not avaliable");
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);

			} else {

				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.LIST, Constants.TRUE, allRoles),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Roles: " + e);
			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	// -- Getting Role By Id
	/**
	 * @param roleId
	 * @return Getting Role By Id
	 */
	@GetMapping("/{roleId}")
	public ResponseEntity<ResponseDTO> getRoleById(@PathVariable String roleId) {
		Long data = Long.parseLong(AES.decryptUrl(roleId));
		System.out.println(AES.encryptUrl("10000"));
		try {
			EmployeeRoleDTO getRoleById = roleTestJsonService.getRoleById(data);// roleGetById(roleId);

			if (getRoleById != null) {

				logger.debug("Role fond with ID = " + data + " " + getRoleById);
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.LIST, Constants.TRUE, getRoleById),
						HttpStatus.OK);
			} else {
				logger.error("Role Not Found by Id :: " + data);
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Role by Id: " + data + " " + e);

			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	// -- Updating Role
	/**
	 * @param empRoleDTO
	 * @return Updating Role
	 */
	@PutMapping("/update")
	public ResponseEntity<ResponseDTO> update(@RequestBody EmployeeRoleDTO empRoleDTO, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			EmployeeRoleDTO update = roleTestJsonService.updateRole(empRoleDTO, companyId);
			if (update == null) {
				logger.info("Role record not found");
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("Role Updation Successfull");
				return new ResponseEntity<ResponseDTO>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, update), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Role: " + e);
			e.printStackTrace();
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + "Role");
		}
	}

	@PutMapping(value = "/roleDeactive")
	public ResponseEntity<ResponseDTO> deactivateRole(@RequestBody EmployeeRoleDTO empRoleId) {
		try {

			if (roleTestJsonService.dependencyCheck(empRoleId.getRoleId()) == true) {
				roleTestJsonService.deactiveRole(empRoleId);
				if (empRoleId.getIsActive().equals(Boolean.TRUE)) {
					logger.info("Role Activated With id:{} ", empRoleId.getRoleId());
					return new ResponseEntity<>(new ResponseDTO(Constants.ROLE_ACTIVE_SUCCESS, Constants.TRUE),
							HttpStatus.OK);
				} else {
					logger.info("Role Deactivated With id:{} ", empRoleId.getRoleId());
					return new ResponseEntity<>(new ResponseDTO(Constants.ROLE_DEACTIVE_SUCCESS, Constants.TRUE),
							HttpStatus.OK);
				}

			} else {
				logger.info("Role Not deactived with Id:{} ", empRoleId.getRoleId());
				return new ResponseEntity<>(new ResponseDTO(Constants.ROLE_DEACTIVE_FAILURE, Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Role Status by Id:{} ", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.ROLE);
		}
	}

	//GetRoleBy Response as boolean

	@GetMapping("boolean/{roleId}")
	public ResponseEntity<ResponseDTO> getRoleByAsBoolean(@PathVariable String roleId, @RequestHeader String companyId) {
		//Long data = Long.parseLong(AES.decryptUrl(roleId));
		System.out.println(AES.encryptUrl("mani0002"));
		try {
			EmployeeRoles getRoleById = roleRepo.findRoleByCompany(AES.decryptUrl(roleId), AES.decryptUrl(companyId));
			if(getRoleById !=null) {
				logger.debug("Role fond with ID :{}" ,roleId );
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.LIST, Constants.TRUE, true),
						HttpStatus.OK);
			}else {
				logger.error("Role Not Found by Id :: " + roleId);
				return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, false),
						HttpStatus.OK);
			}
		}catch (Exception e) {
			logger.error("Role Not Found by Id :: " + roleId);
			e.printStackTrace();
			return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, false),
					HttpStatus.OK);
		}
	}
}