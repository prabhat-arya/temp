package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ExitFeedbackDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.entity.ExitFeedback;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.service.ExitFeedbackService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@CrossOrigin
@RestController
@RequestMapping(URLConstants.ADMIN_EXITFEEDBACK)
public class ExitFeedbackController {

	@Autowired
	private ExitFeedbackService exitFeedbackService;

	private static final Logger logger = LoggerFactory.getLogger(ExitFeedbackController.class);

	/**
	 * This method is used to save exit feedback and upload files based on the
	 * exitId
	 * 
	 * @param model
	 * @return this method is used to save exit feedback and upload files based on
	 *         the exitId
	 */
	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> addFeedback(@RequestParam(required = false) MultipartFile[] files,
			@RequestParam("data") String data) {
		try {

			List<EntityDTO> feedbackList = exitFeedbackService.saveExitFeedback(files, data);
			if (feedbackList.isEmpty()) {
				logger.info("Feedback failed to add");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("Feedback added successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, feedbackList),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding feedback:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.FEEDBACK);
		}
	}

	/**
	 * Returns feedback based on exitId
	 * 
	 * @param exitId
	 * @return returns feedback based on exitId
	 */
	@GetMapping("/{exitId}")
	public ResponseEntity<ResponseDTO> getFeedbackByExitId(@PathVariable String exitId) {

		Long exitData = Long.parseLong(AES.decryptUrl(exitId));
		try {
			List<ExitFeedbackDTO> result = exitFeedbackService.getExitFeedbackBasedOnExitId(exitData);
			if (result != null) {
				List<ExitFeedbackDTO> list = new ArrayList<>();
				list.addAll(result);
				logger.info("ExitFeedback found with exitId:{}", exitData);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("ExitFeedback not found with exitId:{}", exitData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting ExitFeedback with exitId:{} : {}", exitData, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EXIT_FEEDBACK);
		}
	}

	/**
	 * Returns feedback based on feedbackId
	 * 
	 * @param feedbackId
	 * @return returns feedback based on feedbackId
	 */
	@GetMapping("/feedback/{feedbackId}")
	public ResponseEntity<ResponseDTO> getFeedbackByFeedbackId(@PathVariable String feedbackId) {

		Long feedbackData = Long.parseLong(AES.decryptUrl(feedbackId));
		try {
			ExitFeedbackDTO result = exitFeedbackService.getExitFeedbackBasedOnFeedbackId(feedbackData);
			if (result != null) {
				List<ExitFeedbackDTO> list = new ArrayList<>();
				list.add(result);
				logger.info("ExitFeedback found with feedbackId:{}", feedbackData);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("ExitFeedback not found by feedbackId:{}", feedbackData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting ExitFeedback with feedbackId:{} : {}", feedbackData, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EXIT_FEEDBACK);
		}
	}

	/**
	 * Returns exit feedback based on empId
	 * 
	 * @param employeeId
	 * @return returns exit feedback based on empId
	 */

	@GetMapping("/employeeId/{employeeId}")
	public ResponseEntity<ResponseDTO> getExitFeedbackBasedOnEmployeeId(@PathVariable String employeeId) {

		Long employeeData = Long.parseLong(AES.decryptUrl(employeeId));
		try {
			List<ExitFeedbackDTO> result = exitFeedbackService.getExitFeedbackBasedOnEmployeeId(employeeData);
			if (!result.isEmpty()) {
				logger.info("ExitFeedback found with employeeId:{}", employeeData);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, result), HttpStatus.OK);
			} else {
				logger.info("ExitFeedback not found with employeeId:{}", employeeData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting ExitFeedback with employeeId:{} : {}", employeeData, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EXIT_FEEDBACK);
		}
	}

	/**
	 * It will delete the feed back from related file
	 * 
	 * @author manikanta
	 * @param fileId
	 * @return it will delete the feed back from related file
	 */
	@PutMapping(value = "/delete")
	public ResponseEntity<ResponseDTO> deleteFeedBackFile(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> feedBackFile = exitFeedbackService.deleteFeedBackFile(dto.getId());
			if (!feedBackFile.isEmpty()) {
				logger.info("File Deleted with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, feedBackFile),
						HttpStatus.OK);
			} else {
				logger.info("File not exist with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting feedBack file:{}", e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.FEEDBACK_FILE);
		}
	}

	// delete the feedback by feedbackId
	@PutMapping("/deleteFeedback")
	public ResponseEntity<ResponseDTO> deleteFeedbackByFeedbackId(@RequestBody StatusDTO dto) {
		try {
			ExitFeedbackDTO deleted = exitFeedbackService.deleteExitFeedbackBasedOnFeedbackId(dto.getId());
			if (deleted != null) {
				logger.info("ExitFeedback deleted with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, null),
						HttpStatus.OK);
			} else {
				logger.info("ExitFeedback not deleted by Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting ExitFeedback by Id:{} : {}", dto.getId(), e);
			throw new NotFoundException(Constants.DEACTIVE_FAIL + " " + Constants.EXIT_FEEDBACK);
		}
	}

	/**
	 * File document for preview purpose
	 * 
	 * @author manikanta
	 * @param fileId
	 * @return file document for preview purpose
	 *//*
		 * @PostMapping(value = "/preview/{fileId}", consumes =
		 * MediaType.APPLICATION_JSON_VALUE) public ResponseEntity<ResponseDTO>
		 * previewFeedBackDocument(@PathVariable String fileId) { try { DocumentDetails
		 * previewFeedBackDocument =
		 * exitFeedbackService.previewFeedBackDocument(fileId); if
		 * (!Objects.isNull(previewFeedBackDocument)) {
		 * logger.info("ExitFeedbackdocnment avaliable with fileId:{}", fileId); return
		 * new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE,
		 * previewFeedBackDocument), HttpStatus.OK); } else {
		 * logger.info("ExitFeedbackdocnment not avaliable with fileId:{}", fileId);
		 * return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE),
		 * HttpStatus.OK); } } catch (Exception e) {
		 * logger.error("Error while getting ExitFeedback document with fileId:{} : {}",
		 * fileId, e); throw new NotFoundException(Constants.NO_LIST + " " +
		 * Constants.EXIT_FEEDBACK_DOCUMNET); } }
		 */

	/**
	 * All exit feedback records
	 */
	@GetMapping("/findAllExitFeedBack")
	public ResponseEntity<ResponseDTO> getAllExitFeedBackRecords(@RequestHeader(value = "companyId") String companyId) {

		try {
			List<ExitFeedback> allExitFeedBackRecords = exitFeedbackService.findAllExitFeedBacks(AES.decryptUrl(companyId));
			if (allExitFeedBackRecords.isEmpty()) {
				logger.info("ExitFeedback not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("All ExitFeedback found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allExitFeedBackRecords),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all exit feedbacks:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EXIT_FEEDBACK);
		}
	}

}
