
package com.hrms.admin.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.CancelLeaveDTO;
import com.hrms.admin.dto.EmpLeaveCountDTO;
import com.hrms.admin.dto.EmpLeaveDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ManagerDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.EmpLeaveService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Employee Leave Record
 * 
 * @author {Sandeep}
 *
 */
@RestController
@RequestMapping(URLConstants.EMPLOYEE_LEAVE)
@CrossOrigin
public class EmpLeaveController {

	private static final Logger logger = LoggerFactory.getLogger(EmpLeaveController.class);

	@Autowired
	private EmpLeaveService service;

	/**
	 * Returns status code when new EmpLeave is created
	 * 
	 * @param model - new empLeave data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> applyLeave(@RequestPart String applyLeave,
			@RequestPart(required = false) MultipartFile file, @RequestHeader String companyId) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			EmpLeaveDTO empLeavedto = mapper.readValue(applyLeave, EmpLeaveDTO.class);
			boolean isExists = service.validate(empLeavedto, true);
			if (isExists) {
				logger.info("EmpLeave record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.LEAVE_APPLIED, Constants.FALSE), HttpStatus.OK);
			}
			List<EntityDTO> addEmpLeave = service.addEmpLeave(empLeavedto, file, AES.decryptUrl(companyId));
			if (addEmpLeave.get(0).getName().equals("nodata")) {
				logger.info("Leave type data not found in AnnualLeaves table");
				return new ResponseEntity<>(
						new ResponseDTO("Leave type is not Applicable for Employee", Constants.TRUE), HttpStatus.OK);

			}
			if (!addEmpLeave.isEmpty()) {
				logger.info("EmpLeave applied successfuly");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, addEmpLeave),
						HttpStatus.CREATED);
			} else {
				logger.info("EmpLeave fail to appliedLeave");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while storing EmpLeave:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + Constants.EMP_LEAVE + e);
		}
	}

	/**
	 * Returns status code when existing empLeave data is updated
	 * 
	 * @param model - new empLeave data
	 * @param id    - Id
	 * @return - ResponseEntity
	 */
	@PutMapping
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody EmpLeaveDTO model) {

		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("EmpLeave record is Already exist");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EMP_LEAVE + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.OK);
			} else {
				List<EntityDTO> updateEmpLeave2 = service.updateEmpLeave(model, model.getId());
				if (!updateEmpLeave2.isEmpty()) {
					logger.info("EmpLeave record is updated with Id:{}", model.getId());
					return new ResponseEntity<>(new ResponseDTO("Company" + " " + Constants.UPDATE_SUCCESS,
							Constants.TRUE, updateEmpLeave2), HttpStatus.OK);
				} else {
					logger.info("EmpLeave failed to update with Id:{}", model.getId());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EMP_LEAVE + " " + Constants.UPDATE_FAIL, Constants.FALSE),
							HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating EmpLeave:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + Constants.EMP_LEAVE + e);
		}
	}

	/**
	 * Returns EmpLeave and status code when empLeave data is available by id
	 * 
	 * @param id - Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			EmpLeaveDTO empLeaveById = service.getEmpLeaveByid(data);
			if (empLeaveById != null) {
				List<EmpLeaveDTO> list = new ArrayList<>();
				list.add(empLeaveById);
				logger.info("EmpLeave found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("No Data found while getting EmpLeave by Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting EmpLeave:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns EmpLeave for given Date
	 * 
	 * @param date1 - Date
	 * @return - list of employee leaves
	 */
	@GetMapping("/date/{date}")
	public ResponseEntity<ResponseDTO> getByDate(
			@PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") String date, @RequestHeader String companyId)
			throws ParseException {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date data = dateFormat.parse(AES.decryptUrl(date));
		try {
			List<EmpLeaveDTO> findLeavesbyDate = service.findLeavesbyDate(data, AES.decryptUrl(companyId));
			if (!findLeavesbyDate.isEmpty()) {
				logger.info("EmployeeLeave found with Date:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, findLeavesbyDate),
						HttpStatus.OK);
			} else {
				logger.info("No EmployeeLeave with Date found:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting EmployeeLeave with Date:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns All Leaves data when empLeave data is available
	 * 
	 * @return - List of empLeaveModel
	 */
	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> getEmpLeavelist(@RequestHeader String companyId) {

		try {
			List<EmpLeaveDTO> allEmpLeaves = service.getAllEmpLeave(AES.decryptUrl(companyId));
			if (!allEmpLeaves.isEmpty()) {
				logger.info("Empleave list Found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allEmpLeaves),
						HttpStatus.OK);
			} else {
				logger.info("EmpLeave record list is not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all EmpLeave Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns EmpLeave for given time period
	 * 
	 * @param date1 - startDate
	 * @param date2 - endDate
	 * @return - list of employee leaves
	 */
	@GetMapping("id/{id}/{date1}/{date2}")
	public ResponseEntity<ResponseDTO> getEmpLeavesByDate(@PathVariable("id") String id,
			@PathVariable("date1") @DateTimeFormat(pattern = "yyyy-MM-dd") String date1,
			@PathVariable("date2") @DateTimeFormat(pattern = "yyyy-MM-dd") String date2,
			@RequestHeader String companyId) throws ParseException {

		Long id1 = Long.parseLong(AES.decryptUrl(id));

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date data11 = dateFormat.parse(AES.decryptUrl(date1));
		Date data22 = dateFormat.parse(AES.decryptUrl(date2));

		try {
			List<EmpLeaveDTO> list = service.getEmpLeavesByDate(id1, data11, data22);

			if (!list.isEmpty()) {
				logger.info("EmpLeave records is found with Id:{}", id1);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("No EmplLeave record found with Id:{}", id1);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all AllEmplLeave Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}

	}

	/**
	 * Returns EmpLeave for given employee
	 * 
	 * @param id - empId
	 * @return - list of employee leaves
	 */
	@GetMapping("/empId/{id}")
	public ResponseEntity<ResponseDTO> getEmpLeavesByDate(@PathVariable() String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			List<EmpLeaveDTO> list = service.findLeavesbyEmpId(data);
			if (!list.isEmpty()) {
				logger.info("EmpLeave found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("No EmplLeave with given empyeeId found:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting AllEmplLeave with given employeeId:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Getting all employee leaves in Database
	 * 
	 * @param empId
	 * @param pagingDto
	 * @param type
	 * @return ResponseEntity
	 */
	@PostMapping(value = "emp/page/{empId}/{type}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllEmpLeaves(@PathVariable Long empId, @RequestBody PaginationDTO pagingDto,
			@PathVariable Boolean type, @RequestHeader String companyId) {
		try {
			if (type.equals(Boolean.TRUE)) {
				return null;
			} else {
				Map<String, Object> data = service.getAllEmpLeaves(empId, pagingDto.getPageIndex(),
						pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(),
						pagingDto.getOrderBy(), pagingDto.getStatus(), AES.decryptUrl(companyId));
				if (data.isEmpty()) {

					logger.info("EmpLeave record is not avaliable");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
							HttpStatus.OK);
				} else {
					logger.info("EmpLeave found");
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while getting all EmpLeave record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * @param mngrId
	 * @param pagingDto
	 * @param type
	 * @return pagination
	 */
	@PostMapping(value = "team/page/{mngrId}/{type}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllTeamLeaves(@PathVariable Long mngrId, @RequestBody PaginationDTO pagingDto,
			@PathVariable Boolean type, @RequestHeader String companyId) {
		try {
			Map<String, Object> data;
			if (type.equals(Boolean.TRUE)) {
				data = service.getAllTeamLeaves(mngrId, pagingDto.getPageIndex(), pagingDto.getPageSize(),
						pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
						AES.decryptUrl(companyId));
			}
			data = service.getAllTeamLeaves(mngrId, pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					AES.decryptUrl(companyId));

			if (data.isEmpty()) {
				logger.info("Error while getting AllTeamLeaves");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("AllTeamLeaves founded: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting AllTeamLeaves: ", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Getting all manager list
	 * 
	 * @param id
	 * @return getting managers
	 */
	@GetMapping("/mngr/{id}")
	public ResponseEntity<ResponseDTO> getManagers(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));

		try {
			List<ManagerDTO> managers = service.findManager(data, AES.decryptUrl(companyId));
			if (!managers.isEmpty()) {
				logger.info("Found Manager List with id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, managers), HttpStatus.OK);
			} else {
				logger.info("Manager List Not found with id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding mnager list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	@GetMapping("/mngrs")
	public ResponseEntity<ResponseDTO> getAllManagers(@RequestHeader String companyId) {

		try {
			List<ManagerDTO> managers = service.allmangerList(AES.decryptUrl(companyId));
			if (!managers.isEmpty()) {
				logger.info("Found Manager List with id:{}");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, managers), HttpStatus.OK);
			} else {
				logger.info("Manager List Not found with id:{}");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding mnager list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Soft Delete
	 * 
	 * @param dto
	 * @return soft delete method
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteEmpLeave(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> empLeaveList = service.softDeleteEmpLeave(dto.getId());
			if (!empLeaveList.isEmpty()) {
				logger.info("EmpLeave deleted successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, empLeaveList),
						HttpStatus.OK);
			} else {
				logger.info("EmpLeave not deleted");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while  deleting empLeave:{}", e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Update employee leave by status
	 * 
	 * @param status
	 * @return update emp leave by status
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmpLeaveByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateEmpLeaveByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("EmpLeave upadated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("EmpLeave not upadated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating EmpLeave:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns status code when existing empLeave data is updated
	 * 
	 * @param model - new empLeave data
	 * @param id    - Id
	 * @return - ResponseEntity
	 */
	@PutMapping(value = "/approval", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> approval(@RequestBody EmpLeaveDTO model) {
		try {
			List<EntityDTO> list = service.approveOrReject(model, model.getId());
			if (!list.isEmpty()) {
				logger.info("EmpLeave approved");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.LEAVE_APROVAL + model.getStatus(), Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("EmpLeave not approved");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while approving EmpLeave:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns employee's leaves(available,pending,approved,rejected) count based on
	 * employeeId
	 * 
	 * @param id - employeeId
	 * @return - ResponseEntity
	 */
	@GetMapping("/leavesCount/{employeeId}")
	public ResponseEntity<ResponseDTO> getEmployeeLeavesCountById(@PathVariable String employeeId) {
		Long data = Long.parseLong(AES.decryptUrl(employeeId));
		try {
			EmpLeaveCountDTO empLeaveCount = service.getEmployeeLeavesCountById(data);
			if (empLeaveCount != null) {
				logger.info("Employee Leaves count found by employeeId:{}", data);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, empLeaveCount), HttpStatus.OK);
			} else {
				logger.info("No Employees leaves count found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NOT_EXECUTED, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting leaves count with employeeId:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	/**
	 * Returns employee's cancelled leaves count based on employeeId
	 * 
	 * @param id - employeeId
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/canceled/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> canceledLeaves(@PathVariable Long id, @RequestBody CancelLeaveDTO dto) {
		try {
			List<EntityDTO> list = service.cancelLeaves(dto, id);
			if (list != null) {
				logger.info("EmpLeave cancel leaves added and approvedleaves updated with id:{}", id);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("EmpLeave cancel leaves not added and approvedleaves not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while EmpLeave cancel leaves not added and approvedleaves not updated:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}
	}

	@PostMapping(value = "/cancellationofApprovedLeaves", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> cancellationofApprovedLeaves(@RequestBody EmpLeaveDTO dto) {
		try {
			List<EntityDTO> empCancellationofApprovedLeaves = service.getEmployeeCancellationofApprovedLeaves(dto);

			if (empCancellationofApprovedLeaves != null) {
				logger.info("Empployee Cancellation of ApprovedLeaves  updated with id:{}", dto.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, empCancellationofApprovedLeaves),
						HttpStatus.OK);
			} else {
				logger.info("Empployee Cancellation of ApprovedLeaves  not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while EmpLeave Cancellation of ApprovedLeaves not updated:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}

	}

	@PostMapping("/cancelApplied")
	public ResponseEntity<ResponseDTO> cancelApplied(@RequestBody EmpLeaveDTO dto) {
		try {
			List<EntityDTO> empCancellationofAppliedRejectLeaves = service.getEmployeeCancelAppliedRejectLeaves(dto);
			if (empCancellationofAppliedRejectLeaves != null) {
				logger.info("Empployee Cancellation of AppliedRejectLeaves  updated with id:{}", dto.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, empCancellationofAppliedRejectLeaves),
						HttpStatus.OK);
			} else {
				logger.info("Empployee Cancellation of AppliedRejectLeaves  not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while EmpLeave Cancellation of AppliedRejectLeaves not updated:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}

	}
	@PutMapping("/cancelApproved")
	public ResponseEntity<ResponseDTO> cancelApproved(@RequestBody EmpLeaveDTO dto) {
		try {
			List<EntityDTO> empCancelApprovedLeaves = service.getEmployeeCancelApprovedLeaves(dto);
			if (empCancelApprovedLeaves != null) {
				logger.info("Empployee Cancel Approved  updated with id:{}", dto.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, empCancelApprovedLeaves),
						HttpStatus.OK);
			} else {
				logger.info("Empployee Cancel Approved not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while EmpLeave Cancel Approved not updated:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMP_LEAVE);
		}

	}
}
