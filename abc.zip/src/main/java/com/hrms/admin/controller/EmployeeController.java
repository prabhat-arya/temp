package com.hrms.admin.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hrms.admin.dto.BankDTO;
import com.hrms.admin.dto.EmployeeBranchDTO;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeOccasionDTO;
import com.hrms.admin.dto.EmployeeProfileDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmployeeRolesDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.FileNamesListDTO;
import com.hrms.admin.dto.ManagerDTO;
import com.hrms.admin.dto.OfficeUseOnlyDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ResultDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.exceptions.FileUploadException;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.fileuploaddownload.property.ExcelGenerator;
import com.hrms.admin.fileuploaddownload.property.PdfReportGenerator;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.service.OccasionNotificationService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.ExcelHeaderCheckUtil;
import com.hrms.admin.util.ExcelHeaders;
import com.hrms.admin.util.FieldsValidation;
import com.hrms.admin.util.URLConstants;
import com.itextpdf.text.DocumentException;

@RestController
@RequestMapping(URLConstants.ONBOARD_EMPLOYEE)
@CrossOrigin
public class EmployeeController {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private OccasionNotificationService occasionNotification;

	@Autowired
	private FieldsValidation validateUtil;

	@Autowired
	private PdfReportGenerator pdfReportGenerator;

	@Autowired
	private ExcelGenerator excelGenerator;

	@Autowired
	private ExcelHeaderCheckUtil excelHeaderCheckUtil;

	/**
	 * Save employee info success/failure massage
	 * 
	 * @param employee Object
	 * @return save employee info success/failure massage
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> saveempinfo(@Valid @RequestBody EmployeeInfoDTO employee) {
		try {
//			boolean isDuplicate = employeeService.validateacadimicYear(employee);
//			if (isDuplicate) {
//				logger.info("Employee Academic year is Duplicate");
//				return new ResponseEntity<>(new ResponseDTO(Constants.DUPLICATE_YEAR, Constants.FALSE), HttpStatus.OK);
//			}

			boolean isExists = employeeService.validate(employee, true);
			if (isExists) {
				logger.info("Employee record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else if (employeeService.validateEmployeeEmail(employee.getEmail()) != 0L) {
				logger.info("Email already registered with other employee");
				return new ResponseEntity<>(
						new ResponseDTO("Email already registered with other employee", Constants.FALSE),
						HttpStatus.OK);
			} else if (employeeService.validateEmployeeContact(employee.getContactNo()) != 0L) {
				logger.info("Mobile already registered with other employee");
				return new ResponseEntity<>(
						new ResponseDTO("Mobile already registered with other employee", Constants.FALSE),
						HttpStatus.OK);
			} else if (employeeService.validateEmployeeUserNmae(employee.getUserName()) != 0L) {
				logger.info("User Name already registered with other employee");
				return new ResponseEntity<>(
						new ResponseDTO("UserName already registered with other employee", Constants.FALSE),
						HttpStatus.OK);
			} else {
				List<EntityDTO> saveEmployee = employeeService.saveEmployeeInfo(employee);
				if (!saveEmployee.isEmpty()) {
					logger.info("Employee record is inserted:{}", employee.getFirstName());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, saveEmployee),
							HttpStatus.CREATED);
				} else {
					logger.info("Employee failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Employee:{}", e.getMessage());
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Update employee info success/failure massage
	 * 
	 * @param employee    id
	 * @param employeedto
	 * @return update employee info success/failure massage
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE) // update employee
	public ResponseEntity<ResponseDTO> updateEmployeeinfo(@Valid @RequestBody EmployeeInfoDTO employeedto) {
		try {
			boolean isExists = employeeService.validate(employeedto, true);
			if (isExists) {
				logger.info("Employee record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				Boolean validateEmail = validateUtil.validateEmail(employeedto.getOfficalMail());
				if (Boolean.FALSE.equals(validateEmail)) {
					List<ResultDTO> resultlist = new ArrayList<>();
					ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE, Constants.VALID_OFFICE_MAIL);
					resultlist.add(result);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.VALID_OFFICE_MAIL, Constants.FALSE, resultlist), HttpStatus.OK);
				}

				List<EntityDTO> updateEmployee = employeeService.updateEmplyeeInfo(employeedto.getId(), employeedto);
				if (!updateEmployee.isEmpty()) {
					logger.info("Employee info is updated");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployee), HttpStatus.OK);
				} else {
					logger.info("Employee failed to update");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating employee:{}", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Getting Employee entity based on id
	 * 
	 * @param id
	 * @return employee entity based on id
	 */
	// get employee
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getEmployee(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			List<EmployeeDTO> employee = employeeService.getEmployeeById(data);
			if (!employee.isEmpty()) {
				logger.info("Employee found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employee), HttpStatus.OK);
			} else {
				logger.info("Employee Not found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating employee with employeeId:{}{}", data, e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Employee active/inactive status update success/failure
	 * 
	 * @param id
	 * @param status
	 * @return employee active/inactive status update success/failure
	 */
	@PutMapping(value = "/empStatus", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmployeeByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> updateEmployeeByStatus = employeeService.updateEmployeeByStatus(status.getId(),
					status.getStatus());
			if (!updateEmployeeByStatus.isEmpty()) {
				logger.info("Employee deactivated with employeeId:{}", status.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployeeByStatus),
						HttpStatus.OK);
			} else {
				logger.info("Employee not deactived with employeeId:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating employee status with employeeId:{}", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Employee is approved or not
	 * 
	 * @author sandeep
	 * @param employee id
	 * @return employee is approved or not
	 */
	@PutMapping(value = "/approve", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> approveById(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> approveById = employeeService.approveById(dto.getId());
			if (approveById.get(0).getName().equals(Constants.APPROVED)) {
				logger.info("Employee already Actived with employeeId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_APPROVE, Constants.TRUE, approveById),
						HttpStatus.OK);
			} else if (!approveById.isEmpty()) {
				logger.info("Employee actived with employeeId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.APPROVE_SUCCESS, Constants.TRUE, approveById),
						HttpStatus.OK);
			} else {
				logger.info("Employee not activated with employeeId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.APPROVE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while activating employee with employeeId:{} : {}", dto.getId(), e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);

		}
	}

	/**
	 * Success/failure massage
	 * 
	 * @author manikanta
	 * @param employee id
	 * @param projects list
	 * @return success/failure massage
	 */
	// Assigning Project to Employee by EmployeeId(Many to Many with project)
	@PutMapping(value = "/empproject", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmployeeProject(@RequestBody EmployeeDTO model) {
		try {
			List<EntityDTO> updateEmployeeProject = employeeService.updateEmployeeProject(model, model.getId());
			if (!updateEmployeeProject.isEmpty()) {
				logger.info("Employee is updated");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployeeProject),
						HttpStatus.OK);
			} else {
				logger.info("Employee with project not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating employee:{}", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);

		}
	}

	/**
	 * Employee list with pagination
	 * 
	 * @param pagingDto
	 * @return employee list with pagination
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllEmp(@RequestBody PaginationDTO pagingDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			String key = pagingDto.getSearchKey().replaceAll("\\s", "");
			Map<String, Object> data = employeeService.getAllEmployeePage(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), key, pagingDto.getOrderBy(), pagingDto.getStatus(),pagingDto.getEmploymentTypeId(),
					companyId);
			if (data.isEmpty()) {
				logger.info("No Employees found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employees found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Employee related document deleted or not deleted
	 * 
	 * @author manikanta
	 * @param employeeid
	 * @param fileId
	 * @return employee related document deleted or not deleted
	 */
	@DeleteMapping(value = "/{id}/{fileId}")
	public ResponseEntity<ResponseDTO> deleteEmployeeFile(@PathVariable String id, @PathVariable String fileId) {
		Long empId = Long.parseLong(AES.decryptUrl(id));
		Long file = Long.parseLong(AES.decryptUrl(fileId));
		try {
			List<EntityDTO> emp = employeeService.deleteEmployeeFile(empId, file);
			if (!emp.isEmpty()) {
				logger.info("File deleted with employeeId:{}", empId);
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, emp),
						HttpStatus.OK);
			} else {
				logger.info("Employe file file does not exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting employee:{}", e.getMessage());
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Assets assign to employee or not
	 * 
	 * @author manikanta
	 * @param assets   list model
	 * @param employee id
	 * @return assets assign to employee or not massage
	 */
	// adding or updating resource to employee
	@PutMapping(value = "/resources", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addOrUpdateResource(@RequestBody EmployeeDTO model) {

		try {
			List<EntityDTO> resourcetoemp = employeeService.addResourceToEmployee(model, model.getId());
			if (!resourcetoemp.isEmpty()) {
				logger.info("Resource add to employee with Id:{} ", model.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, resourcetoemp),
						HttpStatus.OK);
			} else {
				logger.info("Resource not add to employee with Id:{} ", model.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Resource adding to employee:{} ", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}

	}

	/**
	 * Policies assigned or not for the employee
	 * 
	 * @author manikanta
	 * @param employee id
	 * @param policy   list model
	 * @return policies assigned or not for the employee
	 */
	// Employee updated with Policies
	@PutMapping(value = "/emppolicy", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmployeePolicies(@RequestBody EmployeeDTO model) {
		try {
			List<EntityDTO> updateEmployeePolicies = employeeService.updateEmployeePolicies(model, model.getId());
			if (!updateEmployeePolicies.isEmpty()) {
				logger.info("Employee is updated");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployeePolicies),
						HttpStatus.OK);
			} else {
				logger.info("Employee not upadated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Employee:{}", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Number of employees in particular branch
	 * 
	 * @author ramesh
	 * @param branchId
	 * @return no of employee in particular branch
	 *//*
		 * @GetMapping("/basedOnBranch/{branchId}") public ResponseEntity<ResponseDTO>
		 * getEmployeesBranchId(@PathVariable String branchId) { Long data =
		 * Long.parseLong(AES.decryptUrl(branchId)); try { List<EmployeeBranchDTO>
		 * employeeDetails = employeeService.getEmployeeByBranchId(data); if
		 * (employeeDetails.isEmpty()) { logger.info("Employee Details Not found");
		 * return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST,
		 * Constants.TRUE), HttpStatus.OK); } else {
		 * logger.info("Employee Details found"); return new ResponseEntity<>(new
		 * ResponseDTO(Constants.LIST, Constants.TRUE, employeeDetails), HttpStatus.OK);
		 * } } catch (Exception e) { logger.error("Error while getting Employee:{} ",
		 * e.getMessage()); throw new NotFoundException(Constants.FINDING_ERROR + " " +
		 * Constants.EMPLOYEE); }
		 * 
		 * }
		 */

	/**
	 * List of all employees who are is active only
	 * 
	 * @author manikanta
	 * @return list of all employees who are is active only
	 */
	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> allEmployees(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeInfoDTO> allemp = employeeService.listOfEmployee(companyId);
			if (!allemp.isEmpty()) {
				logger.info("All Employees found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allemp), HttpStatus.OK);
			} else {
				logger.info("All Employees not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Employees in perticular branch
	 * 
	 * @ @param branchid
	 * @return employees in branch
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allEmployeesByBranch(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeBranchDTO> allemp = employeeService.getEmployeeByBranchId(data, companyId);
			if (!allemp.isEmpty()) {
				logger.info("All Employees found by BranchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allemp), HttpStatus.OK);
			} else {
				logger.info("Employees not found with branchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employees with branchId:{} : {}", data, e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Soft Delete
	 * 
	 * @param dto
	 * @return
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteEmployee(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> employeeList = employeeService.softDeleteEmployee(dto.getId());
			if (!employeeList.isEmpty()) {
				logger.info("Employees deleted with employeeId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, employeeList),
						HttpStatus.OK);
			} else {
				logger.info("Employees not deleted with employeeId::{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting Employee with employeeId:{} : {}", dto.getId(), e.getMessage());
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Files uploaded or not with particular employee
	 * 
	 * @param employeeid
	 * @param list       of files
	 * @param profile    image
	 * @return files uploaded or not with particular employee
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	@PutMapping(value = "/files/{id}", consumes = { "multipart/form-data" }) // files adding to employee on onboarding
	public ResponseEntity<ResponseDTO> updateEmployee(@PathVariable Long id,
			@RequestPart(required = false) MultipartFile[] files, @RequestPart(required = false) MultipartFile image,
			@RequestPart(required = false) List<FileNamesListDTO> properties) {
		try {
//			ObjectMapper mapper = new ObjectMapper();
//			List<FileNamesListDTO> fileJsonList = new ArrayList<>();
//			if (!properties.isEmpty()) {
//				fileJsonList = mapper.readValue(properties, new TypeReference<List<FileNamesListDTO>>() {
//				});
//			}
			List<FileNamesListDTO> fileJsonList = properties;
			System.out.println(properties);
			List<EntityDTO> updateEmployee = employeeService.updateEmployeeFiles(id, files, image, fileJsonList);
			if (!updateEmployee.isEmpty()) {
				logger.info("Employee files updated with employeeId:{} ", id);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployee),
						HttpStatus.OK);
			} else {
				logger.info("Employee files Not updated with employeeId:{} ", id);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Employee files:{} ", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * count of employees based on branch Id
	 * 
	 * @author ramesh
	 * @param branchId
	 * @return count of employees in employee
	 */
	@GetMapping("/branch/{branchId}")
	public ResponseEntity<ResponseDTO> getAllEmployeeCountBasedOnBranch(@PathVariable String branchId,
			@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(branchId));
		companyId = AES.decryptUrl(companyId);
		try {
			Long employeeCount = employeeService.getAllEmpCountBasedOnBranch(data, companyId);
			if (employeeCount != 0) {
				logger.info("Found employees with branchId:{}", data);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, employeeCount), HttpStatus.OK);
			} else {
				logger.info("employee count based on Branch Not found with branchId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees count based on BranchId:{} : {}", data, e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Current day occasions will give as list
	 * 
	 * @author prabath
	 * @return current day occasions will give as list
	 */
	@GetMapping("/occasion-notification")
	public ResponseEntity<List<EmployeeOccasionDTO>> employeeOccasionon(String companyId) {
		companyId = AES.decryptUrl(companyId);
		List<EmployeeOccasionDTO> allempOccasionon = occasionNotification.getOccasionNotification(companyId);
		if (!allempOccasionon.isEmpty()) {
			logger.info("Found list of all employees occasion");
			return new ResponseEntity<List<EmployeeOccasionDTO>>(allempOccasionon, HttpStatus.OK);
		} else {
			logger.info("No occasion for today found");
			return null;
		}
	}

	/**
	 * csv report file will generate for all employees
	 * 
	 * @author suresh
	 * @return csv report file will generate for all employees
	 */
	@GetMapping("/export/csv")
	public void exportToCSV(HttpServletResponse response, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			response.setHeader(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employees_" + currentDateTime + ".csv");
			employeeService.createEmployeeDataCSVFIle(response, companyId);
			logger.info("Employee export data csv format::");
		} catch (Exception e) {
			logger.info("Employee export data csv format::{}", e.getMessage());
			throw new FileUploadException("Error while generating CSV file");
		}
	}

	/**
	 * excel report file will generate for all employees
	 * 
	 * @author suresh
	 * @return excel report file will generate for all employees
	 * @throws Exception
	 */
	@GetMapping("/presentEmpExcelreport")
	public ResponseEntity<InputStreamResource> excelReportAllEmployee(@RequestHeader String companyId)
			throws Exception {
		companyId = AES.decryptUrl(companyId);
		List<EmployeeInfoDTO> allEmployeeDetails = employeeService.listOfEmployee(companyId);
		ByteArrayInputStream in = excelGenerator.EmployeeToExcel(allEmployeeDetails);
		logger.info("Employee Excel report data format");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_DISPOSITION, "attachment; filename=Employees_List.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * pdf report file will generate for all employees
	 * 
	 * @author suresh
	 * @return pdf report file will generate for all employees
	 * @throws IOException
	 * @throws DocumentException
	 * @throws MalformedURLException
	 */
	@GetMapping(value = "/pdfreport", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> employeeReport(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeInfoDTO> employees = employeeService.listOfEmployee(companyId);
			logger.info("Employee pdfreport data format::");
			ByteArrayInputStream bis = pdfReportGenerator.EmpReport(employees, companyId);
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			HttpHeaders headers = new HttpHeaders();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=employeereport" + currentDateTime + ".pdf");
			return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
					.body(new InputStreamResource(bis));
		} catch (Exception e) {
			logger.error("Error while generating employee pdf report:{}", e.getMessage());
			throw new NotFoundException(Constants.FILE_GENERATE);
		}
	}

	/**
	 * Details will added employee
	 * 
	 * @author Manikanta
	 * @param employee id
	 * @param Office   Use only details
	 * @return details will added employee
	 */
	@PutMapping(value = "/officeUse", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmpInfoWithOfficeUseData(@RequestBody OfficeUseOnlyDTO dto) {
		try {
			double num = 0.0;
			if (dto.getCtc() != num) {
				boolean isflag = validateUtil.validateDecimalValue(dto.getCtc().toString());
				if (Boolean.FALSE.equals(isflag)) {
					logger.info("Bank record contains invalid data");
					return new ResponseEntity<>(new ResponseDTO(Constants.VALIDATE_MSG, Constants.FALSE),
							HttpStatus.OK);
				}
			}
			List<EntityDTO> list = employeeService.updateEmplyeeOfficeUseDetails(dto.getEmpId(), dto);
			if (!list.isEmpty()) {
				logger.info("Updated Employee Office Use Only Details with employeeId:{}", dto.getEmpId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Update failed Employee Office Use Only Details with employeeId:{}", dto.getEmpId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Update failed Employee Office Use Only Details:{}", e.getMessage());
			throw new NotFoundException(Constants.UPDATING_ERROR + " " + "employee Office details");
		}
	}

	/**
	 * Success/failure message
	 * 
	 * @author manikanta
	 * @param employee id
	 * @param employee profile dto
	 * @return Success/failure message
	 */
	@PutMapping(value = "/updateProfile", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmployeeProfileDetails(@RequestBody EmployeeProfileDTO dto) {
		try {
			List<EntityDTO> updateEmployeeProfileDetails = employeeService.updateEmployeeProfileDetails(dto.getId(),
					dto);
			if (!updateEmployeeProfileDetails.isEmpty()) {
				logger.info("Employee profile updated with Id:{} ", dto.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateEmployeeProfileDetails),
						HttpStatus.OK);
			} else {
				logger.info("Employee profile not updated with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating employee profile details with Id:{}", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Employee profile details
	 * 
	 * @author manikanta
	 * @param employeeid
	 * @return employee profile details
	 */
	@GetMapping("/profile/{id}")
	public ResponseEntity<ResponseDTO> getEmployeeProfileDetails(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			EmployeeProfileDTO employee = employeeService.getEmployeeProfileDetails(data);
			if (employee != null) {
				logger.info("Employee profile found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employee), HttpStatus.OK);
			} else {
				logger.info("Employee profile details not found with employeeId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee Profile Details:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}

	}

	/**
	 * Excel file with employee basic info bulk upload employees basic info from
	 * excel sheet
	 * 
	 * @param excel file with employee basic info bulk upload employees basic info
	 *              from excel sheet
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/empinfo", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeInfoFile(@RequestParam MultipartFile file) {
		try {
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file, ExcelHeaders.BASIC_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpDatafromUploadedfile(file);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception while employee details not uploading from excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Excel file with employee ProfessionalDetails bulk upload employees
	 * professionalDetails from excel sheet
	 * 
	 * @param excel file with employee ProfessionalDetails bulk upload employees
	 *              professionalDetails from excel sheet
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/experience", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeProfessionalDetailsFile(@RequestParam MultipartFile file,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file, ExcelHeaders.EXPERIANCE_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees experiance details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpProfessionalDetailsDatafromUploadedfile(file,
					companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Employee details not uploaded sucessfully from excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Excel file with employee BankDetails bulk upload employees BankDetails from
	 * excel sheet
	 * 
	 * @param excel file with employee BankDetails bulk upload employees BankDetails
	 *              from excel sheet
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/bankDetails", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeBankDetailsFile(@RequestParam MultipartFile file,@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file, ExcelHeaders.BANK_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees bank details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpOfficeUseDataDatafromUploadedfile(file,companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Employee details not uploaded sucessfully from excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Employee bank details pagnation
	 * 
	 * @param pagination dto employee bank details pagnation
	 * @author manikanta
	 * @return page wise data will return
	 */
	@PostMapping(value = "/bank/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllEmpBankDetails(@RequestBody PaginationDTO pagingDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			String key = pagingDto.getSearchKey().replaceAll("\\s", "");
			Map<String, Object> data = employeeService.getAllEmployeeBankDetailsPage(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), key, pagingDto.getOrderBy(), companyId);
			if (data.isEmpty()) {
				logger.info("No Employee bank details found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee  bank details found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee bank details:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Excel file with employee OFfical mail id's bulk upload employees official
	 * mail id from excel sheet
	 * 
	 * @param excel file with employee OFfical mail id's bulk upload employees
	 *              official mail id from excel sheet
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/empMailIds", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeOfficeMailIDs(@RequestParam MultipartFile file,@RequestHeader String companyId) {
		try {
			companyId = AES.decryptUrl(companyId);
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file, ExcelHeaders.EMPLOYEE_MAIL_IDS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees mail ids file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpMailIdsfromUploadedfile(file,companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while uploading excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * List projects assigned to employee
	 * 
	 * @param employee ID
	 * @return list projects assigned to employee
	 * @author manikanta
	 */
	@GetMapping("/project/{id}")
	public ResponseEntity<ResponseDTO> getEmployeeprojects(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			List<EmployeeProjectsDTO> employee = employeeService.getEmployeeProjects(data);
			if (!employee.isEmpty()) {
				logger.info("Employee projects found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employee), HttpStatus.OK);
			} else {
				logger.info("Employee projects not found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee projects details:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * list of managers in department
	 * 
	 * @param department Id & designation Id
	 * @return list managers in department
	 * @author manikanta
	 */
	@GetMapping("/manager/{departmentId}/{designationId}")
	public ResponseEntity<ResponseDTO> getManagersBasedOnBDeapartment(@PathVariable String departmentId,
			@PathVariable String designationId, @RequestHeader String companyId) {
		Long departmentIdData = Long.parseLong(AES.decryptUrl(departmentId));
		Long designationIdData = Long.parseLong(AES.decryptUrl(designationId));
		companyId = AES.decryptUrl(companyId);
		try {
			List<ManagerDTO> employee = employeeService.getManagers(departmentIdData, designationIdData, companyId);
			if (!employee.isEmpty()) {
				logger.info("Managers found with DepartmentId:{} ", departmentIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employee), HttpStatus.OK);
			} else {
				logger.info("Managers not found with DepartmentId:{}", departmentIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting managers list:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.MANAGER_LIST);
		}
	}

	/**
	 * Get all roles in company
	 * 
	 * @return get all roles in company
	 */
	@GetMapping("/getroles")
	public ResponseEntity<ResponseDTO> getAllRoles(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeRolesDTO> allRoles = employeeService.getAllRoles(companyId);
			if (allRoles.isEmpty()) {
				logger.info("Roles record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Roles record is avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allRoles), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting roles:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	/**
	 * Get all active users in company
	 * 
	 * @return get all active users in company
	 */
	@GetMapping("/getusers")
	public ResponseEntity<ResponseDTO> getAllUsers(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<String> allUsers = employeeService.getAllUsers(companyId);
			if (allUsers.isEmpty()) {
				logger.info("Users record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Users record is avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allUsers), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Users:{} ", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	/**
	 * Employee bank details if available
	 * 
	 * @param empId
	 * @return employee bank details if available
	 */
	@GetMapping("/bankDeatils/{empId}")
	public ResponseEntity<ResponseDTO> getEmployeeBankDeatils(@PathVariable String empId) {
		Long empData = Long.parseLong(AES.decryptUrl(empId));
		try {
			List<BankDTO> bank = employeeService.getBankDeatils(empData);
			if (bank.isEmpty()) {
				logger.info("Bank record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Bank record is avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, bank), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Bankdatails:{} ", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
		}
	}

	/**
	 * Excel file with employee Educational details bulk upload
	 * 
	 * @param excel file with employee Educational details bulk upload
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/education", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeEducationalDetails(@RequestParam MultipartFile file,@RequestHeader String companyId) {
		try {
			companyId = AES.decryptUrl(companyId);
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file,
					ExcelHeaders.EDUCATIONAL_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees educational details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpEducationalDetailsfromUploadedfile(file,companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while uploading excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	/**
	 * Excel file with employee Emergency Contact details bulk upload
	 * 
	 * @param excel file with employee Emergency Contact details bulk upload
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/emergency", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeeEmergencyContactDetails(@RequestParam MultipartFile file,@RequestHeader String companyId) {
		try {
			companyId = AES.decryptUrl(companyId);
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file,
					ExcelHeaders.EMERGENCY_CONTACT_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees emergency contact details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpEmergencyContactDetailsfromUploadedfile(file,companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while uploading excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}
	
	
	/**
	 * Excel file with employee Personal details bulk upload
	 * 
	 * @param excel file with employee Personal details bulk upload
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/personalDetails", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadEmployeePersonalDetails(@RequestParam MultipartFile file,@RequestHeader String companyId) {
		try {
			companyId = AES.decryptUrl(companyId);
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeader(file,
					ExcelHeaders.PERSONAL_DETAILS);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees personal details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveEmpPersonalDetailsfromUploadedfile(file,companyId);
			if (!isFlag.isEmpty()) {
				logger.info("Employee Personal details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employee Personal details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while uploading excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}


	@PutMapping(value = "/updateAllToApprove")
	public ResponseEntity<ResponseDTO> updateAllEmpStatusToApprove(@RequestHeader String companyId,@RequestBody(required = false) List<Employee> empIds) {
		try {
			List<EntityDTO> updateAllEmpStatusToApprove = new ArrayList<>();
//			if(empIds.isEmpty()) {
//				updateAllEmpStatusToApprove = employeeService.updateAllEmpStatusToApprove(AES.decryptUrl(companyId));
//			}else {
			
				updateAllEmpStatusToApprove = employeeService.updateAllEmpStatusToApproveWithEmpIds(empIds);	
//			}
			if (!updateAllEmpStatusToApprove.isEmpty()) {
				logger.info("Employees statuses updated ");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateAllEmpStatusToApprove),
						HttpStatus.OK);
			} else {
				logger.info("Employees statuses not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating employees statuses", e.getMessage());
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * Excel file with employee basic info bulk upload employees basic info from
	 * excel sheet
	 * 
	 * @param excel file with employee basic info bulk upload employees basic info
	 *              from excel sheet
	 * @author manikanta
	 * @return success/failure massage
	 */
	@PostMapping(value = "/upload/allempinfo", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> uploadAllEmployeeInfoFile(@RequestParam MultipartFile file) {
		try {
			Boolean compareExcelHeader = excelHeaderCheckUtil.compareExcelHeaderForMultipleSheets(file);
			if (compareExcelHeader.equals(Boolean.FALSE)) {
				logger.info("Employees all details file header names mismatched");
				return new ResponseEntity<>(new ResponseDTO("File header names mismatched", Constants.FALSE),
						HttpStatus.OK);
			}
			Boolean compareExcelSheetNames = excelHeaderCheckUtil.compareExcelSheetNames(file);
			if (compareExcelSheetNames.equals(Boolean.FALSE)) {
				logger.info("Employees all details file Sheets names mismatched");
				return new ResponseEntity<>(
						new ResponseDTO("File sheet name or sheet position mismatched", Constants.FALSE),
						HttpStatus.OK);
			}
			List<Map<String, Integer>> isFlag = employeeService.saveAllEmpDatafromUploadedfile(file);
			if (!isFlag.isEmpty()) {
				logger.info("Employees details uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded successfully", Constants.TRUE, isFlag),
						HttpStatus.OK);
			} else {
				logger.info("Employees details not uploaded sucessfully from excel file");
				return new ResponseEntity<>(new ResponseDTO("File uploaded not done,please try again", Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception while employees details not uploading from excel file:{}", e.getMessage());
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/empAssets/{id}")
	public ResponseEntity<ResponseDTO> getEmployeAssets(@PathVariable String id) {
		try {
			Long data = Long.parseLong(AES.decryptUrl(id));
//			Long data = Long.parseLong(id);
			List<ResourceItemsDTO> employeAssets = employeeService.getEmployeAssets(data);
			if (!employeAssets.isEmpty()) {
				logger.info("Employees assets found ");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employeAssets),
						HttpStatus.OK);
			} else {
				logger.info("Employees assets not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting employees assets", e.getMessage());
			throw new NotUpdatedException(Constants.NO_LIST + " " + Constants.EMPLOYEE);
		}
	}
}
