package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ShiftDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.ShiftService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Shifts
 * 
 * @author {Sandeep}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_SHIFT)
public class ShiftController {
	private static final Logger logger = LoggerFactory.getLogger(ShiftController.class);

	@Autowired
	private ShiftService service;

	/**
	 * @param model
	 * @return Shift save method
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody ShiftDTO model) {
		try {
			// here call validation method
			boolean isExists1 = service.validate(model, true);
			if (isExists1) {
				logger.info("Shift already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);

			} else {
				List<EntityDTO> save1 = service.save(model);
				if (save1.isEmpty()) {
					logger.info("Shift failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				} else if (save1.get(0).getName().equals("is not Exist")) {
					logger.info("Shift failed to add");
					return new ResponseEntity<>(new ResponseDTO("Company is not Exist", Constants.FALSE),
							HttpStatus.OK);
				} else if (save1.get(0).getName().equals("Allowance Amount")) {
					logger.info("Allowance Amount must be greater than Zero");
					return new ResponseEntity<>(
							new ResponseDTO("Allowance Amount must be greater than Zero", Constants.FALSE),
							HttpStatus.OK);
				} else {
					logger.info("Shift Added successfully");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save1),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Shift:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param model
	 * @return Shift update method
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody ShiftDTO model) {

		try {
			List<EntityDTO> updateShift = service.updateShift(model, model.getId());
			if (updateShift.isEmpty()) {
				logger.info("Shift failed to updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			} else if (updateShift.get(0).getName().equals("Allowance Amount")) {
				logger.info("Allowance Amount must be greater than Zero");
				return new ResponseEntity<>(
						new ResponseDTO("Allowance Amount must be greater than Zero", Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("Shift Updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateShift),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Shift:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param id
	 * @return getting shifts based in id
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId = AES.decryptUrl(companyId);
		try {
			ShiftDTO findById = service.getById(data, companyId);
			if (findById != null) {
				List<ShiftDTO> list = new ArrayList<>();
				list.add(findById);
				logger.info("Shift found by shiftId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Error while getting Shift with  shiftId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Shift:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param dto
	 * @return soft delete method
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteShift(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> shiftList = service.softDeleteShift(dto.getId());
			if (!shiftList.isEmpty()) {
				logger.info("Shift deleted with shiftId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, shiftList),
						HttpStatus.OK);
			} else {
				logger.info("Shift not deleted with shiftId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting shift with  shiftId:{}", e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param dto
	 * @return update shift method
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateShiftByStatus(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> list = service.updateShiftByStatus(dto.getId(), dto.getStatus());
			if (!list.isEmpty()) {
				logger.info("Shift updated with shiftId{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Shift failed to updated with shiftId{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Shift Status with shiftId:{} : {}", dto.getId(), e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param company id
	 * @return getting all shifts
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> getAll(@PathVariable String id) {
		String data = AES.decryptUrl(id);
		try {
			List<ShiftDTO> list = service.findAll(data);
			if (list.isEmpty()) {
				logger.info("Shift not found with shiftId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Shift record is found with shiftId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting shifts with shiftid:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param pagingDto
	 * @return
	 */
	@PostMapping(value = "/page")
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllShift(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					companyId);
			if (data.isEmpty()) {
				logger.info("Shift not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Shift record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Shift:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.SHIFT);
		}
	}
}
