package com.hrms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.OrgStructureParent;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.service.impl.OrgStructureServiceImpl;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@CrossOrigin
@RestController
@RequestMapping(URLConstants.ADMIN_ORG)
public class OrgStructureController {
	private static final Logger log = LoggerFactory.getLogger(OrgStructureController.class);

	@Autowired
	OrgStructureServiceImpl orgStructureServiceImpl;

	/**
	 * Organization structure 
	 */
	@GetMapping("/all-structure")
	public ResponseEntity<ResponseDTO> getOrgStructure() {
		try {

			List<OrgStructureParent> orgs = orgStructureServiceImpl.getOrg();
			if (!orgs.isEmpty()) {
				log.info("Found Org_Structure");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, orgs),
						HttpStatus.OK);
			} else {
				log.info("Org_Structure Not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Error while getting all Org_Structure Record:{}",e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ORG_STRUCTURE);
		}
	}

}
