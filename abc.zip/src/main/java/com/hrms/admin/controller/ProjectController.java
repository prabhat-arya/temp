package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PieChartRequestDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ProjectPieChartDTO;
import com.hrms.admin.dto.ProjectReleaseDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.ProjectService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Project Record
 * 
 * @author {MD Atif}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_PROJECT)
public class ProjectController {

	private static final Logger logger = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	private ProjectService service;

	/**
	 * Returns status code when new project is created
	 * 
	 * @param model - new project data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody ProjectDTO model) {
		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Project record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE, null),
						HttpStatus.OK);
			} else {
				List<EntityDTO> projectList = service.save(model);
				if (!projectList.isEmpty()) {
					logger.info("Project record is inserted");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, projectList),
							HttpStatus.CREATED);
				} else {
					logger.info("Project failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Project:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * Returns Project and status code when project data is available by id
	 * 
	 * @param id - project Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId = AES.decryptUrl(companyId);
		try {
			ProjectDTO projectById = service.getById(data, companyId);
			if (projectById != null) {
				List<ProjectDTO> list = new ArrayList<>();
				list.add(projectById);
				logger.info("project find with projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Project not found with projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Project with projectId:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * Returns status code when existing project data is updated
	 * 
	 * @param model - new project data
	 * @param id    - project Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody ProjectDTO model) {
		try {

			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("Project record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE, null),
						HttpStatus.OK);
			} else {
				List<EntityDTO> projectList = service.updateProject(model, model.getId());
				if (!projectList.isEmpty()) {
					logger.info("Project is updated with projcetId:{}", model.getId());

					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, projectList),
							HttpStatus.OK);
				} else {
					logger.info("Project failed to update with projectId:{}", model.getId());
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Project:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * Returns Project and status code when project data is available by id
	 * 
	 * @param id - projectId
	 * @return - ResponseEntity
	 */
	@GetMapping("/totalemp/{id}")
	public ResponseEntity<ResponseDTO> getEmployeesByProjId(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId = AES.decryptUrl(companyId);
		try {
			ProjectDTO findAllEmpByProjId = service.findAllEmployeeByProjId(data, companyId);
			if (findAllEmpByProjId != null) {
				List<ProjectDTO> list = new ArrayList<>();
				list.add(findAllEmpByProjId);
				logger.info("Employees found with projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Employees not found with projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding employees with projectId:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * Returns Project and status code when Project data is available by id
	 * 
	 * @param id - ProjectId
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllProject(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					companyId);
			if (data.isEmpty()) {
				logger.info("Projects record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Projects records are found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Projects:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * Returns All Project data when Project data is available
	 * 
	 * @return - List of ProjectModel
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> getAllProjects(@PathVariable String id) {
		String data = (AES.decryptUrl(id));
		try {
			List<ProjectDTO> allProjects = service.getAllProject(data);
			if (!allProjects.isEmpty()) {
				logger.info("Found:{} : {}", allProjects.size(), Constants.PROJECT);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allProjects),
						HttpStatus.OK);
			} else {
				logger.info("Project Records are not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Project Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * @param id - ProjectId return ProjectId is change in the status isDelete is
	 *           true
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteProject(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> projectList = service.softDeleteProject(dto.getId());
			if (!projectList.isEmpty()) {
				logger.info("Project deleted with projectId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, projectList),
						HttpStatus.OK);
			} else {
				logger.info("Project not deleted with projectId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting Project with projectId:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * @param id  - ProjectId
	 * @param Map object
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateprojectByStatus(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> projectList = service.updateProjectByStatus(dto.getId(), dto.getStatus());
			if (!projectList.isEmpty()) {
				logger.info("Project upadted with ProjectId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, projectList),
						HttpStatus.OK);
			} else {
				logger.info("Project is not available with projectId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Project status with projetcId:{} : {}", dto.getId(), e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.PROJECT);
		}
	}

	/**
	 * @param id -branchId return Project details based on branchId
	 * @return - ResposeEntity
	 *//*
		 * @GetMapping("/branch/{branchId}") public ResponseEntity<ResponseDTO>
		 * getAllProjectCountBasedOnBranch(@PathVariable String branchId) { Long data =
		 * Long.parseLong(AES.decryptUrl(branchId)); try { Long projectCount =
		 * service.getAllProjectCountBasedOnBranch(data); if (projectCount != 0) {
		 * logger.info("Found :{}  projects with BranchId:{}",projectCount,data); return
		 * new ResponseEntity<>( new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY,
		 * Constants.TRUE, projectCount), HttpStatus.OK); } else {
		 * logger.info("Branch Not found with branchId:{}", data); return new
		 * ResponseEntity<>(new ResponseDTO(Constants.NOT_EXECUTED, Constants.TRUE),
		 * HttpStatus.OK); } } catch (Exception e) {
		 * logger.error("Error while finding Project with branchId:{} : {}",data,e);
		 * throw new NotFoundException(Constants.FINDING_ERROR + " " +
		 * Constants.PROJECT);
		 * 
		 * } }
		 */
	/**
	 * @param ProjectReleaseDTO return project ReleaseAnnounce
	 * @return - ResposeEntity
	 */
	@PostMapping(value = "/projectReleaseAnnounce", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> projectReleaseAnnounce(@RequestBody ProjectReleaseDTO model) {
		try {
			Boolean response = service.projectReleaseAnnounce(model);
			if (Boolean.TRUE.equals(response)) {
				logger.info("Project Release Announce send succesfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Project Release Announce failed to send");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending Project Release Announce:{}", e);
			return new ResponseEntity<>(new ResponseDTO(e.getMessage(), Constants.FALSE), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @return Contains method to provide APIs for Project Record
	 * 
	 * @author {RAMESH RENDLA}
	 *
	 */
	@PostMapping("/projectPiechartList")
	public ResponseEntity<ResponseDTO> getProjectsListInDonatChartInDashBoard(@RequestBody PieChartRequestDTO reqDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			if (reqDto.getManagerId() == null) {
				Set<ProjectPieChartDTO> allProjectsPieChart = service.getAllProjectPieChart(companyId,
						reqDto.getProjectId());
				if (!allProjectsPieChart.isEmpty()) {
					logger.info("Project List found based on Company");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allProjectsPieChart),
							HttpStatus.OK);
				} else {
					logger.info("All projects not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
				}
			} else if (reqDto.getManagerId() != null) {
				Set<ProjectPieChartDTO> allProjectsPieChart = service
						.getProjectsListDonatChartUnderManager(reqDto.getManagerId(), reqDto.getProjectId(), companyId);
				if (!allProjectsPieChart.isEmpty()) {
					logger.info("Project List found based on Manager");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allProjectsPieChart),
							HttpStatus.OK);
				} else {
					logger.info("All projects not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
				}
			} else {
				logger.info("Projects list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("error while getting all projects:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}
}
