package com.hrms.admin.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.dto.AttendPaginationDTO;
import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.AttendancePaginationDto;
import com.hrms.admin.dto.BarChartDateWiseCountDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PieChartRequestDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.SampleCsvFile;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.service.AttendanceInfoService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for AttendanceInfoLoadController
 * 
 * @author {Sai Chandu & Ramesh Rendla}
 *
 */
@RestController
@RequestMapping("/admin/attendanceinfo")
@CrossOrigin
public class AttendanceInfoLoadController {

	private static final Logger logger = LoggerFactory.getLogger(AttendanceInfoLoadController.class);

	@Autowired
	AttendanceInfoService attendanceservice;

	/**
	 * Returns status code when new Attendance is created
	 * 
	 * @param model - new Attendance data
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addEmployeeManualAttendance(@RequestBody AttendanceInfoDTO model) {
		try {
			boolean isExists = attendanceservice.validate(model);
			if (isExists) {
				logger.info("Attendance already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> attendanceList = attendanceservice.save(model);
				if (!attendanceList.isEmpty()) {
					logger.info("Employee Manual Attendance Added:{}", model);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, attendanceList),
							HttpStatus.CREATED);
				} else {
					logger.info("Employee Manual Attendance failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while employee Manual Attendance:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + "Attendancee Info");
		}
	}

	/**
	 * Mulitple Services called in this API Returns All Attendance data when
	 * Attendance data is available Return attendance list based on EMPID Return
	 * attendance list based on EMPID and FromDate to ToDate Return attendance list
	 * based on SHIFTID and FromDate to ToDate Return attendance list based on
	 * FromDate to ToDate
	 * 
	 * @param-pagination applied
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody AttendancePaginationDto paginations,
			@RequestHeader String companyId) {
		try {
			if (paginations.getEmpId() == null && paginations.getShiftId() == null && paginations.getFromDate() == null
					&& paginations.getToDate() == null) {
				Map<String, Object> data = attendanceservice.getAllAttendnace(paginations.getPageIndex(),
						paginations.getPageSize(), paginations.getSortBy(), paginations.getSearchKey(),
						paginations.getOrderBy(), AES.decryptUrl(companyId));
				if (!data.isEmpty()) {
					logger.info("Attendance list found");
					return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, data),
							HttpStatus.OK);
				} else {
					logger.info("Attendance list not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, data),
							HttpStatus.OK);
				}
			} else if (paginations.getEmpId() != null && paginations.getShiftId() == null
					&& paginations.getFromDate() == null && paginations.getToDate() == null) {
				Map<String, Object> list = attendanceservice.getAllAttendenceByEmpId(paginations.getEmpId(),
						paginations.getPageIndex(), paginations.getPageSize(), paginations.getSortBy(),
						paginations.getSearchKey(), paginations.getOrderBy(), AES.decryptUrl(companyId));
				if (!list.isEmpty()) {
					logger.info("Employee attendance list not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, list),
							HttpStatus.OK);
				}
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else if (paginations.getEmpId() != null && paginations.getFromDate() != null
					&& paginations.getToDate() != null && paginations.getShiftId() == null) {
				Map<String, Object> betweenList = attendanceservice.getAttendanceListBetweenDatesPaging(
						paginations.getEmpId(), paginations.getFromDate(), paginations.getToDate(),
						paginations.getPageIndex(), paginations.getPageSize(), paginations.getSortBy(),
						paginations.getSearchKey(), paginations.getOrderBy(), AES.decryptUrl(companyId));
				if (betweenList.isEmpty()) {
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
				}
				logger.info(" Employees attendance list:{}", betweenList);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, betweenList),
						HttpStatus.OK);

			} else if (paginations.getShiftId() != null && paginations.getFromDate() != null
					&& paginations.getToDate() != null && paginations.getEmpId() == null) {
				logger.info("Employee attendance list not found");
				Map<String, Object> betweenListvthShift = attendanceservice.getAllAttendanceListDateShiftPaging(
						paginations.getFromDate(), paginations.getToDate(), paginations.getShiftId(),
						paginations.getPageIndex(), paginations.getPageSize(), paginations.getSortBy(),
						paginations.getSearchKey(), paginations.getOrderBy(), AES.decryptUrl(companyId));
				if (betweenListvthShift.isEmpty()) {
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
				}
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, betweenListvthShift),
						HttpStatus.OK);
			} else if (paginations.getFromDate() != null && paginations.getToDate() != null
					&& paginations.getEmpId() == null && paginations.getShiftId() == null) {
				logger.info("Employees attendance list is not found");
				Map<String, Object> empAttDetailsbetweenDates = attendanceservice.getEmpAttDetailsbetweenDatesPaging(
						paginations.getFromDate(), paginations.getToDate(), paginations.getPageIndex(),
						paginations.getPageSize(), paginations.getSortBy(), paginations.getSearchKey(),
						paginations.getOrderBy(), AES.decryptUrl(companyId));
				if (empAttDetailsbetweenDates.isEmpty()) {
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
				}
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, empAttDetailsbetweenDates),
						HttpStatus.OK);
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Attendance list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns Employee Attendance based on employeeId
	 * 
	 * @param id - employeeId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/byEmployeeId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getEmployeeAttendance(@RequestBody AttendanceInfoDTO model) {
		try {
			AttendanceInfoDTO employeeAttendance = attendanceservice.getEmployeeAttendance(model.getEmpId(),
					model.getDate());
			if (employeeAttendance == null) {
				logger.info("Employee attendance Record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee attendance Record found based on employee:{}", employeeAttendance);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, employeeAttendance),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee attendance  Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}

	}

	/**
	 * Update Employee Attendance based on employeeId
	 * 
	 * @param id - employeeId
	 * 
	 * @return - ResponseEntity
	 */
	@PutMapping(value = "/updateEmployeeId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateEmployeeAttendanceById(@RequestBody AttendanceInfoDTO model) {
		try {
			List<EntityDTO> attendance = attendanceservice.updateEmployeeAttendance(model);
			if (attendance == null) {
				logger.info("Employee attendance Record failed to update");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE, null),
						HttpStatus.OK);
			} else {
				logger.info("Employee attendance Record updated based on employee:{}", attendance);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, attendance),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee attendance  Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}

	}

	/**
	 * Delete Employee Attendance based on employeeId
	 * 
	 * @param id - employeeId
	 * 
	 * @return - ResponseEntity
	 */
	@PutMapping(value = "/deleteEmployeeId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> deleteEmployeeAttendanceById(@RequestBody AttendanceInfoDTO model) {
		try {
			boolean deleteAttendance = attendanceservice.deleteEmployeeAttendance(model);
			if (!deleteAttendance) {
				logger.info("Employee attendance Record failed to delete");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.TRUE, null),
						HttpStatus.OK);
			} else {
				logger.info("Employee attendance Record deleted succesfull :{}", deleteAttendance);
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, deleteAttendance),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee attendance  Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}

	}

	/**
	 * Returns employees present and absent attendance percentage in pie chart
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping("/pieChart")
	public ResponseEntity<ResponseDTO> attendancePercentagePieCharts(@RequestBody PieChartRequestDTO dto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			if (dto.getEmpid() == null && dto.getProjectId() == null) {
				AttPercentagePieChartDto attendancePercentagePieChart = attendanceservice
						.attendancePercentagePieChart(AES.decryptUrl(companyId));
				if (attendancePercentagePieChart == null) {
					logger.info("Employee attendance percentage Record is not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
							HttpStatus.OK);
				} else {
					logger.info("Employees attendance percentage Record found:{}", attendancePercentagePieChart);
					return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE,
							attendancePercentagePieChart), HttpStatus.OK);
				}
			} else if (dto.getEmpid() != null && dto.getProjectId() == null) {
				AttPercentagePieChartDto attendancePercentagePieChart = attendanceservice
						.attendancePercentagePieChartByEmpid(dto.getEmpid(), AES.decryptUrl(companyId));
				if (attendancePercentagePieChart == null) {
					logger.info("Employees attendance percentage Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
							HttpStatus.OK);
				} else {
					logger.info("Employee attendance percentage Record found:{}", attendancePercentagePieChart);
					return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE,
							attendancePercentagePieChart), HttpStatus.OK);
				}
			} else if (dto.getEmpid() == null && dto.getProjectId() != null) {
				AttPercentagePieChartDto attendancePercentagePieChart = attendanceservice
						.getAllEmpAttPercentagePieChartByProjectId(dto.getProjectId(), AES.decryptUrl(companyId));
				if (attendancePercentagePieChart == null) {
					logger.info("Employees attendance percentage Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
							HttpStatus.OK);
				} else {
					logger.info("Employee's attendance percentage based on ProjectId:{}", attendancePercentagePieChart);
					return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE,
							attendancePercentagePieChart), HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees attendance percentage Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns Attendance count shown in bargraph when Attendance data is available
	 * last seven days
	 * 
	 * @return -ResponseEntity
	 */
	@PostMapping("/barChart")
	public ResponseEntity<ResponseDTO> employeeAttendanceCountBarChart(@RequestBody PieChartRequestDTO dto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			if (dto.getEmpid() == null && dto.getProjectId() == null) {
				BarChartDateWiseCountDTO employeeAttCountBarChart = attendanceservice
						.employeeAttCountBarChart(dto,AES.decryptUrl(companyId));
				if (employeeAttCountBarChart == null) {
					logger.info("Employee attendance percentage Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.GET_FAIL, Constants.FALSE, null),
							HttpStatus.OK);
				} else {
					logger.info("Employee attendance count Record found:{}", employeeAttCountBarChart);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, employeeAttCountBarChart),
							HttpStatus.OK);
				}
			} else if (dto.getEmpid() == null && dto.getProjectId() != null) {
				BarChartDateWiseCountDTO attendanceList = attendanceservice.allEmpAttCountProjectBarChart(dto,
						AES.decryptUrl(companyId));
				if (attendanceList == null) {
					logger.info("Employee's count not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Employee's count based on ProjectId:{}", attendanceList);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceList),
							HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting attendances percentage Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns present employees list in piechart and status code when Attendance
	 * data is available based on projectId
	 * 
	 * @param id - projectId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/projectPiechart/present/projectId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> presentAttListPieChartByProjectId(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> attendanceListPieChart = attendanceservice.empPresentAttListByProjectPieChart(pagingDto,
					AES.decryptUrl(companyId));
			if (attendanceListPieChart.isEmpty()) {
				logger.info("Employee's present Record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),

						HttpStatus.OK);
			} else {
				logger.info("Present Employee's attendance List based on ProjectId:{}", attendanceListPieChart);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceListPieChart),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee's present list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns Absent employees list in piechart and status code when Attendance
	 * data is available based on projectId
	 * 
	 * @param id - projectId
	 * 
	 * @return - ResponseEntity
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/projectPiechart/absent/projectId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> absentAttListPieChartByProjectId(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> attendanceListPieChart = attendanceservice.empAbsentAttListByProjectPieChart(pagingDto,
					AES.decryptUrl(companyId));
			List<AttendanceInfoDTO> absentList = (List<AttendanceInfoDTO>) attendanceListPieChart.get("data");
			if (absentList.isEmpty()) {
				logger.info("Employee's absent Record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Absent Employee's attendance List based on ProjectId:{}", attendanceListPieChart);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceListPieChart),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee's absent list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns present employees list in barGraph and status code when Attendance
	 * data is available based on projectId
	 * 
	 * @param id - projectId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/projectBarchart/present/projectId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> presentAttListBarChartByProjectId(@RequestBody AttendPaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			if (pagingDto.getDate().isEmpty()) {
				Map<String, Object> attendanceList = attendanceservice.empPresentAttListByProjectBarChart(pagingDto,
						AES.decryptUrl(companyId));
				if (attendanceList.isEmpty()) {
					logger.info("Present Employee's attendance list Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Present Employee's attendance List based on projectId:{}", attendanceList);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceList),
							HttpStatus.OK);
				}
			} else if (!pagingDto.getDate().isEmpty()) {
				Map<String, Object> attendanceList = attendanceservice
						.presentEmployeeAttListByProjectBarChartOnDate(pagingDto, AES.decryptUrl(companyId));
				if (attendanceList.isEmpty()) {
					logger.info("Present Employee's attendance list Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Present Employee's attendance List based on projectId:{}", attendanceList);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceList),
							HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns absent employees list in barGraph and status code when Attendance
	 * data is available based on projectId
	 * 
	 * @param id - projectId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/projectBarchart/absent/projectId", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> absentAttListBarChartByProjectId(@RequestBody AttendPaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {

		try {
			if (pagingDto.getDate().isEmpty()) {
				Map<String, Object> attendanceListPieChart = attendanceservice
						.empabsentAttListByProjectBarChart(pagingDto, AES.decryptUrl(companyId));
				@SuppressWarnings("unchecked")
				List<AttendanceInfoDTO> absentList = (List<AttendanceInfoDTO>) attendanceListPieChart.get("data");
				if (absentList.isEmpty()) {
					logger.info("Absent Employee's attendance list Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Absent Employee's attendance List based on projectId:{}", attendanceListPieChart);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceListPieChart),
							HttpStatus.OK);
				}
			} else if (!pagingDto.getDate().isEmpty()) {
				Map<String, Object> attendanceListPieChart = attendanceservice
						.empabsentAttListByProjectBarChartOnDate(pagingDto, AES.decryptUrl(companyId));
				@SuppressWarnings("unchecked")
				List<AttendanceInfoDTO> absentList = (List<AttendanceInfoDTO>) attendanceListPieChart.get("data");
				if (absentList.isEmpty()) {
					logger.info("Absent Employee's attendance list Record not found");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Absent Employee's attendance List based on projectId:{}", attendanceListPieChart);
					return new ResponseEntity<>(
							new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, attendanceListPieChart),
							HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees list:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns present employee list in pie chart based on employeeId
	 * 
	 * @param id - employeeId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/Piechart/presentListByEmpid", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getPresetAttendanceListPieChartByEmpID(
			@RequestBody AttendancePaginationDto reqstDto, @RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> presentListByEmpId = attendanceservice.getPresentAttendenceListByEmpIdInPieChart(
					reqstDto.getEmpId(), reqstDto.getPageIndex(), reqstDto.getPageSize(), reqstDto.getSortBy(),
					reqstDto.getSearchKey(), reqstDto.getOrderBy(), AES.decryptUrl(companyId));
			if (presentListByEmpId.isEmpty()) {
				logger.info("Employees attendance percentage Record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee attendance percentage Record found based on employee:{}", presentListByEmpId);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, presentListByEmpId),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting attendance percentage Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}

	}

	/**
	 * Returns absent employee list in pie chart based on employeeId
	 * 
	 * @param id - employeeId
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/Piechart/absentListByEmpid", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAbsetAttendanceListPieChartByEmpID(
			@RequestBody AttendancePaginationDto reqstDto, @RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> absentListByEmpId = attendanceservice.getAbsentAttendenceListByEmpIdInPieChart(
					reqstDto.getEmpId(), reqstDto.getPageIndex(), reqstDto.getPageSize(), reqstDto.getSortBy(),
					reqstDto.getSearchKey(), reqstDto.getOrderBy(), AES.decryptUrl(companyId));
			if (absentListByEmpId.isEmpty()) {
				logger.info("Employee attendance percentage Record not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee attendance percentage Record found:{}", absentListByEmpId);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, absentListByEmpId),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting attendance percentage Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}

	}

	/**
	 * Returns Present Attendance List shown in pieChart when Attendance data is
	 * available based on empid
	 * 
	 * @param id-empid
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/presentListPieChart", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllPresentEmployeesListPieChart(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> attensList = attendanceservice.getAllPresentListPieChart(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					AES.decryptUrl(companyId));
			if (attensList.isEmpty()) {
				logger.error("Employees Present attendance list is empty");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, attensList),
						HttpStatus.OK);

			} else {
				logger.info("Employees attendance percentage List size:{}", attensList.size());
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting present employees Record:{} ", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns Absent Attendance List shown in pieChart when Attendance data is
	 * available based on empid
	 * 
	 * @param id-empid
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/absentListPieChart", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllAbsentEmployeesListPieChart(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			Map<String, Object> attensList = attendanceservice.getAllAbesntListPieChart(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					AES.decryptUrl(companyId));
			if (attensList.isEmpty()) {
				logger.error("Employee's Present attendance list is empty");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, attensList),
						HttpStatus.OK);
			} else {
				logger.error("Employee absent attendance percentage List size:{}", attensList.size());
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting absent employee Records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns Present Attendance list shown in barGraph when Attendance data is
	 * available
	 * 
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/presentListBarChart", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllPresentEmployeesListBarChart(@RequestBody AttendPaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			if (pagingDto.getDate().isEmpty()) {
				Map<String, Object> attensList = attendanceservice.getAllPresentListBarChart(pagingDto.getPageIndex(),
						pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(),
						pagingDto.getOrderBy(), AES.decryptUrl(companyId));
				if (attensList.isEmpty()) {
					logger.error("Employees Present attendance list is empty");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, attensList),
							HttpStatus.OK);
				} else {
					logger.info("Employee Present attendance List size:{}", attensList.size());
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				}
			} else if (!pagingDto.getDate().isEmpty()) {
				Map<String, Object> attensList = attendanceservice.getPresentListBarChartOnDate(
						pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),
						pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getDate(),
						AES.decryptUrl(companyId));
				if (attensList.isEmpty()) {
					logger.error("Employee Present attendance list is empty");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				} else {
					logger.info("Employee present attendance List size:{}", attensList.size());
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting present employees record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns absent Attendance list shown in barGraph when Attendance data is
	 * available
	 * 
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/absentListBarChart", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllAbsentEmployeesListBarChart(@RequestBody AttendPaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			if (pagingDto.getDate().isEmpty()) {
				Map<String, Object> attensList = attendanceservice.getAllAbsentListBarChart(pagingDto.getPageIndex(),
						pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(),
						pagingDto.getOrderBy(), AES.decryptUrl(companyId));
				if (attensList.isEmpty()) {
					logger.info("Employee Present attendance list is empty");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				} else {
					logger.info("Employee attendance percentage List size:{}", attensList.size());
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				}
			} else if (!pagingDto.getDate().isEmpty()) {
				Map<String, Object> attensList = attendanceservice.getAbsentListBarChartOnDate(pagingDto.getPageIndex(),
						pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(),
						pagingDto.getOrderBy(), pagingDto.getDate(), AES.decryptUrl(companyId));
				if (attensList.isEmpty()) {
					logger.info("Employee Present attendance list is empty");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, attensList),
							HttpStatus.OK);
				} else {
					logger.info("Employee attendance percentage List size:{}", attensList.size());
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, attensList),
							HttpStatus.OK);
				}
			} else {
				logger.info("Employees attendance list not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting present employees Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns Attendance list generated in excel report when Attendance data is
	 * available
	 * 
	 * @return -ResponseEntity
	 */
	@GetMapping("/download/excelreport")
	public ResponseEntity<InputStreamResource> excelReportAllAttendances(
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		try {
			InputStreamResource in = attendanceservice.getAllExcelReportAttendances(AES.decryptUrl(companyId));
			HttpHeaders headers = new HttpHeaders();
			String currentDate = attendanceservice.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					Constants.EXCEL_FILEPATH + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Generated Excel Report employees Attendance");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Excel Report employee's Attendance:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns Attendance list generated in PDF report when Attendance data is
	 * available
	 * 
	 * @return -ResponseEntity
	 */
	@GetMapping(value = "/download/pdfreport", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAttendances(
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		try {
			InputStreamResource in = attendanceservice.getAllpdfReportAttendances(AES.decryptUrl(companyId));
			HttpHeaders headers = new HttpHeaders();
			String currentDate = attendanceservice.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, Constants.PDF_FILEPATH + currentDate + ".pdf");
			logger.info("Pdf Report for employees Attendance are generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting pdf Report employees Attendance:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ATTENDANCE_INFO);
		}
	}

	/**
	 * Returns Present Attendance list generated in CSV report when Attendance data
	 * is available
	 * 
	 * @return -ResponseEntity
	 */
	@GetMapping("/download/attErrorCSVreport")
	public void csvReportAttendancesError(HttpServletResponse response) throws IOException {
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = Constants.ATTACHMENT_FILEPATH + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		logger.info("csv Report for Present employees Attendance are generated");
		attendanceservice.getErrorAttRecordsListCsv(response);

	}

	/**
	 * Returns Attendance list generated in CSV report when Attendance data is
	 * available
	 * 
	 * @return -ResponseEntity
	 * @throws Exception
	 */
	@GetMapping("/download/csvreport")
	public void csvReportAttendances(HttpServletResponse response, @RequestHeader(value = "companyId") String companyId)
			throws Exception {
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = Constants.ATTACHMENT_FILEPATH + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		logger.info("csv Report for employees Attendance are generated");
		attendanceservice.getAllAttendenceDetailsCsv(response, AES.decryptUrl(companyId));

	}

	/**
	 * Returns upload Employee's Attendance break history records in CSV format when
	 * Attendance break history data is available s
	 * 
	 * @return -ResponseEntity
	 */
	@PostMapping(value = "/upload", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> attendanceBreakHistory(@RequestParam("file") MultipartFile file,
			@RequestHeader(value = "companyId") String companyId) {
		try {

			List<Map<String, Integer>> list = attendanceservice.attendanceBreakHistoryCsv(file,
					AES.decryptUrl(companyId));
			if (!list.isEmpty()) {
				logger.info("Attendance details uploaded sucessfully from Csv file");
				return new ResponseEntity<>(new ResponseDTO("file uploaded successfully", Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Attendance details failed to upload from Csv file");
				return new ResponseEntity<>(new ResponseDTO("file upload failed, Please try again..", Constants.FALSE),
						HttpStatus.OK);
			}

		} catch (RuntimeException e) {
			logger.error("Attendance details failure to upload from Csv file:{}", e);
			return new ResponseEntity<>(new ResponseDTO(Constants.UPLOAD_ERROR, Constants.FALSE, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			logger.error("Attendance details failure to upload from Csv file:{}", e);
			throw new NotFoundException(Constants.UPLOAD_ERROR + " " + "Attendance " + e.getMessage());
		}
	}

	/**
	 * Returns Download sample file in CSV formate
	 * 
	 */
	@GetMapping("/download/csvSample")
	public void csvHeaderGenerator(HttpServletResponse response) throws IOException {
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = Constants.ATTACHMENT_FILEPATH + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "EMPID", "INTIME", "OUTTIME", "DATE" };
		String[] nameMapping = { "empId", "inTime", "outTime", "date" };

		SampleCsvFile sample = new SampleCsvFile();
		sample.setEmpId("id");
		sample.setDate("yyyy-mm-dd");
		sample.setInTime("yyyy-mm-dd hh:mm:ss");
		sample.setOutTime("yyyy-mm-dd hh:mm:ss");
		csvWriter.writeHeader(csvHeader);
		csvWriter.write(sample, nameMapping);
		logger.info("Sample csv file  generated");
		csvWriter.close();
	}

	/**
	 * Returns Attendance Error Records list generated in CSV report when Attendance
	 * data is available
	 * 
	 * @return -ResponseEntity
	 */
	@GetMapping("/attErrorRecordcsvReport")
	public void csvReportAttendanceErrorRecord(HttpServletResponse response) throws IOException {
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = HttpHeaders.CONTENT_DISPOSITION + "attachment; filename=AttendanceError_" + currentDateTime
				+ ".csv";
		response.setHeader(headerKey, headerValue);

		logger.info("csv Report for employees Attendance errror records are generated");
		attendanceservice.getAllAttendanceErrorRecordListCsv(response);
	}
}
