package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.GoalCreationDTO;
import com.hrms.admin.dto.GoalCreationEmployeeDTO;
import com.hrms.admin.dto.PaginationPerformanceDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.service.GoalCreationService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/*
 * @author Atif Ansari
 */
/**
 * @author Chandu
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_GOAL)
public class GoalCreationController {

	private static final Logger logger = LoggerFactory.getLogger(GoalCreationController.class);

	@Autowired
	private GoalCreationService service;

	/**
	 * This method is used to Create the Goals based on the employeeId
	 * 
	 * @param model
	 * @return this method is used to Create the Goals based on the employeeId
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addGoal(@Valid @RequestBody GoalCreationDTO model) {
		try {

			List<EntityDTO> goalList = service.save(model);
			if (goalList.isEmpty()) {
				logger.info("Goal Already Exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("Goal Added successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, goalList),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding Goal:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.GOAL);
		}
	}

	/**
	 * This method is used to show all Goals based on pagination
	 * 
	 * @param pagingDto
	 * @return This method is used to show all Goals based on pagination
	 */
	@PostMapping("/page")
	public ResponseEntity<ResponseDTO> showAllGoals(@RequestBody PaginationPerformanceDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.findAllGoals(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					pagingDto.getManagerName(), companyId);
			if (data.isEmpty()) {
				logger.info("Goal record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Goal record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding Goal:{}", e);
			throw new NotCreatedException(Constants.GET_FAIL + " " + Constants.GOAL);
		}
	}

	/**
	 * This method is used to find the department based on EmployeeId
	 * 
	 * @param employeeId
	 * @return This method is used to find the department based on EmployeeId
	 */
	@GetMapping("/employeeId/{employeeId}")
	public ResponseEntity<ResponseDTO> findDepartmentByEmployeeId(@PathVariable String employeeId) {

		Long employeeIdData = Long.parseLong(AES.decryptUrl(employeeId));
		try {
			List<GoalCreationEmployeeDTO> employeeDepartment = service.findDepartmentByEmployeeId(employeeIdData);
			if (employeeDepartment.isEmpty()) {
				logger.info("Employee details not found with employeeId:{}", employeeIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Employee details record found with employeeId:{}", employeeIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, employeeDepartment),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding Employee details with employeeId:{} : {}", employeeIdData, e);
			throw new NotCreatedException(Constants.GET_FAIL + " " + Constants.GOAL);
		}
	}

	/**
	 * This method is used to find the one goal on an employee based on EmployeeId
	 * 
	 * @param employeeId
	 * @return This method is used to find the one goal on an employee based on
	 *         EmployeeId
	 */
	@GetMapping("/oneEmployee/{employeeId}")
	public ResponseEntity<ResponseDTO> findOneGoalOfEmployeeByEmployeeId(@PathVariable String employeeId) {
		Long employeeIdData = Long.parseLong(AES.decryptUrl(employeeId));
		try {
			GoalCreationDTO oneEmployee = service.findOneGoalByEmployeeId(employeeIdData);
			if (oneEmployee == null) {
				logger.info("Goal not found with employeeId:{}", employeeIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Goal rocord is found with employeeId:{}", employeeIdData);
				List<GoalCreationDTO> list = new ArrayList<>();
				list.add(oneEmployee);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding goal with employeeId:{} : {}", employeeIdData, e);
			throw new NotCreatedException(Constants.GET_FAIL + " " + Constants.GOAL);
		}
	}
	
	@GetMapping("/getallemps/{managerId}")
	public ResponseEntity<ResponseDTO> getAllEmployeeIds(@PathVariable String managerId) {
		Long employeeIdData = Long.parseLong(AES.decryptUrl(managerId));
		try {
			return new ResponseEntity<>(
					new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, service.getEmployeeIds(employeeIdData)),
					HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while geting all EmployeeId record:{}", e);
			return new ResponseEntity<>(new ResponseDTO(Constants.BAD_REQUEST, Constants.FALSE), HttpStatus.OK);
		}
	}

}
