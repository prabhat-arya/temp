package com.hrms.admin.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.AssignShiftDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ReportPageDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ShiftAssignDTO;
import com.hrms.admin.dto.ShiftRequestDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.AssignShiftService;
import com.hrms.admin.service.ReportService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@RequestMapping(URLConstants.SHIFT_ASSIGN)
@CrossOrigin
public class AssignShiftController {

	private static final Logger logger = LoggerFactory.getLogger(AssignShiftController.class);
	@Autowired
	public AssignShiftService service;

	@Autowired
	private ReportService reportService;

	/**
	 * Save assigned shift to employee
	 * 
	 * @author Sandeep
	 * @param model
	 * @return save assigned shift to employee
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@RequestBody ShiftAssignDTO model) {
		try {
			ShiftAssignDTO list = service.assignShift(model);
			if (list != null) {
				logger.info("AssignShift created");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, list),
						HttpStatus.CREATED);
			} else {
				logger.info("AssignShift not created");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while creating AssignShift:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + "AssigningShift");
		}
	}

	/**
	 * List of employee with assigned shifts
	 * 
	 * @author Manikanta
	 * @param pagingDto
	 * @return list of employee with assigned shifts
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllAssignShifts(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),companyId);
			if (data.isEmpty()) {
				logger.info("AssignShift not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
			} else {
				logger.info("AssignShift found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting AssignShift:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + "Shift Assigned");
		}
	}

	/**
	 * Shifts assigned to employee based on employeeId
	 * 
	 * @author Manikanta
	 * @param Employee id
	 * @return Shifts assigned to employee based on employeeId
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getAssignShiftByEmpId(@PathVariable String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId=AES.decryptUrl(companyId);
		try {
			List<AssignShiftDTO> list = service.getAssignShiftByEmpId(data,companyId);
			if (!list.isEmpty()) {
				logger.info("AssignShift found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("AssignShift not found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting AssignShift:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGNING_SHIFT);
		}
	}

	/**
	 * Shift change request
	 * 
	 * @author Sandeep
	 * @param model
	 * @return response message
	 */
	@PostMapping(value = "/changeShiftRequest", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> changeShiftRequest(@RequestBody ShiftRequestDTO model) {
		try {
			String s = service.changeShiftRequest(model);
			if (s != null) {
				logger.info("Change Shift Request record is updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, s),
						HttpStatus.OK);
			} else {
				logger.info("Change Shift Request record is not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while updating Change Shift Request record:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + e);
		}
	}

	/**
	 * Status for changeshift request
	 * 
	 * @author Sandeep
	 * @param model
	 * @return status for changeshift request
	 */
	@PutMapping(value = "/updateRequestedShift", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateReuestedShift(@RequestBody ShiftRequestDTO model) {
		try {
			String response = service.updateRequestedShift(model);
			if (response != null) {
				logger.info("Request Shift updated successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, response),
						HttpStatus.OK);
			} else {
				logger.info("Request Shift failed to update");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Request Shift:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + e);
		}
	}

	/**
	 * Status for changing shift request based on shiftId
	 * 
	 * @author Sandeep
	 * @param model
	 * @return status for changing shift request based on shiftId
	 */
	@PutMapping(value = "/updateChangeShiftRequest/{id}")
	public ResponseEntity<ResponseDTO> updateChangeShiftRequest(@RequestBody ShiftRequestDTO model,
			@PathVariable Long id) {
		try {
			String s = service.updateChangeShiftRequest(model, id);
			if (s != null) {
				logger.info("Change Shift Request updated successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, s),
						HttpStatus.OK);
			} else {
				logger.info("Change Shift Request not updated");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while updating Change Shift Request:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + e);
		}
	}

	/**
	 * Employee shift Request pagination
	 * 
	 * @param empId
	 * @param pagingDto
	 * @param type
	 * @return
	 */
	@PostMapping("/emp/page/{empId}/{type}")
	public ResponseEntity<ResponseDTO> getAllEmployeeShift(@PathVariable Long empId,
			@RequestBody PaginationDTO pagingDto, @PathVariable Boolean type,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data;
			if (type.equals(Boolean.TRUE)) {
				return null;
			} else {
				data = service.getAllEmployeeShift(empId, pagingDto.getPageIndex(), pagingDto.getPageSize(),
						pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);

				if (data.isEmpty()) {

					logger.info("Shift record is not avaliable");
					return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
							HttpStatus.OK);
				} else {
					logger.info("Shift record found");
					return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while getting all Shift record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + "Shift");
		}

	}

	/**
	 * Manager Shift Request Pagination
	 * 
	 * @param pagingDto
	 * @param mngrId
	 * @param type
	 * @return
	 */
	@PostMapping(value = "/mgr/page/{mngrId}/{type}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllManager(@RequestBody PaginationDTO pagingDto, @PathVariable Long mngrId,
			@PathVariable Boolean type,@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data;
			if (type.equals(Boolean.TRUE)) {
				data = service.getAllManagerShift(pagingDto.getPageIndex(), pagingDto.getPageSize(),
						pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);
			} else {
				data = service.getAllEmployeeShift(mngrId, pagingDto.getPageIndex(), pagingDto.getPageSize(),
						pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);
			}

			if (data.isEmpty()) {

				logger.info("Shift records is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Shift rocords is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Shift records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + "Shift");
		}
	}

	/**
	 * Getting all the shifts present in database
	 * 
	 * @author Sandeep
	 * @param model
	 * @return Getting all the shifts present in database
	 */
	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> getAll(@RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			List<AssignShiftDTO> list = service.findAll(companyId);
			if (list.isEmpty()) {
				logger.info("Assign Shifts not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Assign Shifts found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Assign Shifts:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + "shift");
		}
	}

	/**
	 * @author Manikanta
	 * @param pagingDto
	 * @return Excel generation for AssignShift
	 * @throws IOException
	 */
	@PostMapping(value = "/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportAllShift(@RequestBody ReportPageDTO pagingDto,@RequestHeader String companyId)
			throws IOException {
		companyId=AES.decryptUrl(companyId);
		try {
			String searchKey = "";
			InputStreamResource in = reportService.getShiftExcelReportShifts(pagingDto.getProjectId(),
					pagingDto.getShiftId(), pagingDto.getStartDate(), pagingDto.getEndDate(), searchKey,companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employee_Shift_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report employees shifts is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report for employees shifts:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGN_SHIFT);
		}
	}

	/**
	 * @author Manikanta
	 * @param pagingDto
	 * @return Pdf generation for AssignShift
	 * @throws IOException
	 */
	@PostMapping(value = "/pdfreport", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAllShift(@RequestBody ReportPageDTO pagingDto ,@RequestHeader String companyId)
			throws IOException {
		companyId=AES.decryptUrl(companyId);
		try {
			String searchKey = "";
			InputStreamResource in = reportService.getAllpdfReportShifts(pagingDto.getProjectId(),
					pagingDto.getShiftId(), pagingDto.getStartDate(), pagingDto.getEndDate(), searchKey,companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Employee_Shift_" + currentDate + ".pdf");
			logger.info("Pdf Report for employees shifts is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employee shifts:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGN_SHIFT);
		}
	}

	/**
	 * @author Manikanta
	 * @return CSV generation for AssignShift
	 * @param response
	 * @param pagingDto
	 * @throws IOException
	 */
	@PostMapping(value = "/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportShifts(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,@RequestHeader String companyId) throws IOException {
		companyId=AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);

		String headerKey = Constants.CONTENT_DISPOSITION;
		String currentDate = reportService.currentDateandTime();
		String headerValue = "attachment; filename=shift_" + currentDate + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("csv Report for Present employees shifts is generated");
		pagingDto.setSearchKey("");
		reportService.getAllshiftListCsv(response, pagingDto,companyId);
	}

}
