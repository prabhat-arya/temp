package com.hrms.admin.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.PayrollReportPaginationDTO;
import com.hrms.admin.dto.ReportPageDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.service.ReportService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for generating reports
 * 
 * @author {Sandeep}
 *
 */
@RestController
@RequestMapping(URLConstants.ADMIN_REPORTS)
@CrossOrigin
public class ReportController {

	private static Logger logger = LoggerFactory.getLogger(ReportController.class);

	@Autowired
	private ReportService reportService;

	/**
	 * Pagination method for Onboarding Reports
	 * 
	 * @param pagingDto
	 * 
	 * @return paging data
	 */
	@PostMapping(value = "/onboardReports", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getOnboardingReports(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = reportService.getOnboardingReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStatus(), pagingDto.getStartDate(), pagingDto.getEndDate(), pagingDto.getGender(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);
			if (data.isEmpty()) {
				logger.info("Onboarning Employee record is not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Onboarning Employee record found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting onboarning Employee:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @return CSV generation for Onboarding Reports
	 * 
	 * @param response
	 * @param pagingDto
	 * @throws Exception
	 */
	@PostMapping(value = "/onboardReports/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void exportToCSV(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws Exception {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=Employees_Onboard_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		reportService.getAllonboardListCsv(response, pagingDto, companyId);
		logger.info("Onboard Employee export data csv format");

	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for Onboarding Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/onboardReports/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAllEmployee(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAllEmployeepdfReports(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getStatus(), pagingDto.getSearchKey(), pagingDto.getGender(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Employees_Onboard_" + currentDate + ".pdf");
			logger.info("Pdf Report for onboard employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report on onboard employees:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for Onboarding Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/onboardReports/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportAllEmployee(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getEmployeeExcelReports(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getStatus(), pagingDto.getSearchKey(), pagingDto.getGender(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employees_Onboard_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report onboard employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report on onboard employees:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pagination method AssignShift
	 */
	@PostMapping(value = "/shiftReport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllShifts(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data1 = reportService.getAllShiftReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getProjectId(), pagingDto.getShiftId(), pagingDto.getStartDate(), pagingDto.getEndDate(),
					companyId);
			if (data1.isEmpty()) {
				logger.info("Shift data not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Shift data found:{}", data1);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data1), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Shift data;{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.SHIFT);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for AssignShift
	 * @throws IOException
	 */
	@PostMapping(value = "/shiftReport/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportAllShift(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getShiftExcelReportShifts(pagingDto.getProjectId(),
					pagingDto.getShiftId(), pagingDto.getStartDate(), pagingDto.getEndDate(), pagingDto.getSearchKey(),
					companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employee_Shift_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report employees shifts is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report for employees shifts:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGN_SHIFT);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for AssignShift
	 * @throws IOException
	 */
	@PostMapping(value = "/shiftReport/pdfreport", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAllShift(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAllpdfReportShifts(pagingDto.getProjectId(),
					pagingDto.getShiftId(), pagingDto.getStartDate(), pagingDto.getEndDate(), pagingDto.getSearchKey(),
					companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Employee_Shift_" + currentDate + ".pdf");
			logger.info("Pdf Report for employees shifts is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employee shifts:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGN_SHIFT);
		}
	}

	/**
	 * @return CSV generation for AssignShift
	 * @param response
	 * @param pagingDto
	 * @throws IOException
	 */
	@PostMapping(value = "/shiftReport/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportShifts(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);

		String headerKey = Constants.CONTENT_DISPOSITION;
		String currentDate = reportService.currentDateandTime();
		String headerValue = "attachment; filename=shift_" + currentDate + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("csv Report for Present employees shifts is generated");
		reportService.getAllshiftListCsv(response, pagingDto, companyId);
	}

	/**
	 * @param pagingDto
	 * 
	 * @return Pagination method for EmpLeave Reports
	 */
	@PostMapping(value = "/leaveReport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllLeaves(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = reportService.getAllLeaveReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStartDate(), pagingDto.getEndDate(), companyId);
			if (data.isEmpty()) {
				logger.info("Employee leave data not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee leave data found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employee leave data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVE);
		}

	}

	/**
	 * @param pagingDto
	 * @return Excel generation for EmpLeave Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/leaveReport/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportAllLeave(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getLeaveExcelReport(pagingDto.getStartDate(), pagingDto.getEndDate(),
					pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employee_Leave_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report employees  leave is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees leave data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for EmpLeave Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/leaveReport/pdfreport", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAllLeave(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getLeavepdfReport(pagingDto.getStartDate(), pagingDto.getEndDate(),
					pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Employee_Leave_" + currentDate + ".pdf");
			logger.info("Pdf Report for employees leave data is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees leave data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVE);
		}
	}

	/**
	 * @return CSV generation EmpLeave Reports
	 * 
	 * @param response
	 * @param pagingDto
	 * @throws Exception
	 */
	@PostMapping(value = "/leaveReport/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportLeave(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws Exception {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);

		String headerKey = Constants.CONTENT_DISPOSITION;
		String currentDate = reportService.currentDateandTime();
		String headerValue = "attachment; filename=leave_" + currentDate + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("csv Report for employees leave data is generated");
		reportService.getAllleaveListCsv(response, pagingDto, companyId);
	}

	/**
	 * @param pagingDto
	 * 
	 * @return Pagination method for Employee Attendance Reports
	 */
	@PostMapping(value = "/attendanceReport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllAttendance(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = reportService.getAttendanceReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStartDate(), pagingDto.getEndDate(), companyId);
			if (data.isEmpty()) {
				logger.info("Employee Attendance not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee Attendance found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee Attendance:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE_ATTENDANCE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for Employee Attendance Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/attendanceReport/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportAttendnce(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAttendanceExcelReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Attendance_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report employees attendance is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees attendance data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSIGN_SHIFT);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for Employee Attendance Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/attendanceReport/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAttendance(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAttendancepdfReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Attendance_" + currentDate + ".pdf");
			logger.info("PDF Report employees attendance data is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees attendance:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.LEAVE);
		}
	}

	/**
	 * @return CSV generation for Employee Attendance Reports
	 * @param response
	 * @param pagingDto
	 * @throws Exception
	 */
	@PostMapping(value = "/attendanceReport/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportAttendance(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws Exception {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=Attendance_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("CSV Report employees  attendance data is generated");
		reportService.getAllAttendanceListCsv(response, pagingDto, companyId);
	}

	/**
	 * @param pagingDto
	 * 
	 * @return Pagination method for Employee Perfomance Reports
	 */
	@PostMapping(value = "/perfomanceReport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllPerfomance(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data2 = reportService.getPerfomannceReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStartDate(), pagingDto.getEndDate(), companyId);
			if (data2.isEmpty()) {
				logger.info("Employee perfomance data not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee perfomance data found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data2), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting employees perfomance data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PERFORMANCE_DATA);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for Employee Perfomance Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/perfomanceReport/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportPerfomance(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getPerfomanceExcelReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Perfomance_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report employees  Perfomance data");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees Perfomance data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PERFORMANCE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for Employee Perfomance Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/perfomanceReport/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportPerfomance(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getPerfomancepdfReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=Perfomance_" + currentDate + ".pdf");
			logger.info("PDF Report employees Perfomance is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees Perfomance:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PERFORMANCE);
		}
	}

	/**
	 * @return CSV genration for Employee Perfomance Reports
	 * 
	 * @param response
	 * @param pagingDto
	 * @throws IOException
	 * @throws ParseException
	 */
	@PostMapping(value = "/perfomanceReport/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportPerfomance(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) throws IOException, ParseException {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=Perfomance_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("CSV Report employees  Perfomance is generated");
		reportService.getAllPerfomanceListCsv(response, pagingDto, companyId);
	}

	// for payroll reports added-------------------------
	/**
	 * This method is used to show the reports based on salary range
	 * 
	 * @param pagingDto
	 * @return
	 */

	@PostMapping(value = "/salary/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getEmpReportBasedOnSalaryRange(@RequestBody PayrollReportPaginationDTO pagingDto,
			@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			String key = pagingDto.getSearchKey().replaceAll("\\s", "");
			Map<String, Object> data = reportService.getAllEmployeeReportBasedOnSalaryRange(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), key, pagingDto.getOrderBy(), pagingDto.getStatus(),
					pagingDto.getSalaryRange(), pagingDto.getFromDate(), pagingDto.getToDate(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);
			if (data.isEmpty()) {
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Employee Reports details:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * This method is used to print the excel for Payroll report
	 */
	@PostMapping(value = "/payrollReport/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> excelReportPayroll(@RequestBody PayrollReportPaginationDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			String key = pagingDto.getSearchKey().replaceAll("\\s", "");
			InputStreamResource in = reportService.getPayrollExcelReport(key, pagingDto.getStatus(),
					pagingDto.getSalaryRange(), pagingDto.getFromDate(), pagingDto.getToDate(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);

			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Payroll_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel payroll report is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees payroll data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.NOT_EXECUTED);
		}
	}

	/**
	 * This method is used to print print the payroll pdf report
	 * 
	 * @param pagingDto
	 * @return
	 * @throws IOException
	 */
	@PostMapping(value = "/payrollReport/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> payRollPdfReport(@RequestBody PayrollReportPaginationDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		String key = pagingDto.getSearchKey().replaceAll("\\s", "");
		try {
			InputStreamResource in = reportService.getPayrollPdfReport(key, pagingDto.getStatus(),
					pagingDto.getSalaryRange(), pagingDto.getFromDate(), pagingDto.getToDate(),
					pagingDto.getDepartmentId(), pagingDto.getDesignationId(), companyId);
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION, "inline; filename=PayrollReport_" + currentDate + ".pdf");
			logger.info("PDF Report for payroll data is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report employees Payroll:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.NOT_EXECUTED);
		}
	}

	@PostMapping(value = "/payroll/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void csvReportPayroll(HttpServletResponse response, @RequestBody PayrollReportPaginationDTO pagingDto,
			@RequestHeader String companyId) throws IOException, ParseException {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=PayrollReport_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		logger.info("CSV Report employees  Payroll data is generated");
		reportService.csvFileForPayrollReport(response, pagingDto, companyId);
	}

	/**
	 * @param pagingDto
	 * 
	 * @return Pagination method for Employee Promotional(Employement type) Reports
	 */
	@PostMapping(value = "/promotionalReport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllEmploymentTypes(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data2 = reportService.getEmploymentTypeReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStartDate(), pagingDto.getEndDate(), pagingDto.getEmploymentTypeId(), companyId);
			if (data2.isEmpty()) {
				logger.info("Employee promotional data not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee promotional data found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data2), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting employees promotional data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROMOTIONAL_DATA);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for Promotional employee Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/promotionalReports/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> employeePromotionalExcelReport(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getPromotionalExcelReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getEmploymentTypeId(), companyId, pagingDto.getSearchKey());
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employees_Promotional_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report promotional employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report on promotional employees:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for Promotional Reports
	 * @throws IOException
	 */
	@PostMapping(value = "/promotionalReports/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> promotionalpdfReportAllEmployee(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getPromotionalPdfReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), pagingDto.getEmploymentTypeId(), companyId, pagingDto.getSearchKey());
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"inline; filename=Employees_Promotional_" + currentDate + ".pdf");
			logger.info("Pdf Report for Promotional employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting Report on promotional employees:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @return CSV generation for Promotional Reports
	 * 
	 * @param response
	 * @param pagingDto
	 * @throws Exception
	 */
	@PostMapping(value = "/promotionalReports/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void employeePromotionalExportToCSV(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,
			@RequestHeader String companyId) throws Exception {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=Employees_Promotional_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		reportService.getEmployeesPromotionalListCsv(response, pagingDto, companyId);
		logger.info("Promotional Employee export data csv format");

	}

	/**
	 * @param pagingDto
	 * 
	 * @return Pagination method for Employee Exit Reports
	 */
	@PostMapping(value = "/exitReports", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAllExitEmployeePage(@RequestBody ReportPageDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data2 = reportService.getAllExitEmployeeReports(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStartDate(), pagingDto.getEndDate(), companyId);
			if (data2.isEmpty()) {
				logger.info("Employee Exit Records data not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Employee Exit Records data found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data2), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting employees Exit Records data:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.PROMOTIONAL_DATA);
		}
	}

	/**
	 * @param pagingDto
	 * @return Excel generation for Promotional employee Reports
	 * @throws IOException
	 */

	@PostMapping(value = "/exitReports/excelreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> getAllExitEmployeeExcelReport(@RequestBody ReportPageDTO pagingDto,

			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAllExitEmployeeExcelReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), companyId, pagingDto.getSearchKey());
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"attachment; filename=Employees_Exit_" + currentDate + Constants.EXCEL_EXTENTION);
			logger.info("Excel Report Exit employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			logger.error("Error while getting Report on Exit employees:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @param pagingDto
	 * @return Pdf generation for Promotional Reports
	 * @throws IOException
	 */

	@PostMapping(value = "/exitReports/pdfreport", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> getAllExitEmployeepdfReport(@RequestBody ReportPageDTO pagingDto,

			@RequestHeader String companyId) throws IOException {
		companyId = AES.decryptUrl(companyId);
		try {
			InputStreamResource in = reportService.getAllExitEmployeepdfReport(pagingDto.getStartDate(),
					pagingDto.getEndDate(), companyId, pagingDto.getSearchKey());
			HttpHeaders headers = new HttpHeaders();
			String currentDate = reportService.currentDateandTime();
			headers.add(Constants.CONTENT_DISPOSITION,
					"inline; filename=Employees_Promotional_" + currentDate + ".pdf");
			logger.info("Pdf Report for Exit employees is generated");
			return ResponseEntity.ok().headers(headers).body(in);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting Report on Exit employees:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMPLOYEE);
		}
	}

	/**
	 * @return CSV generation for Promotional Reports
	 * 
	 * @param response
	 * @param pagingDto
	 * @throws Exception
	 */
	@PostMapping(value = "/exitReports/csvreport", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void getAllExitEmployeeExportToCSV(HttpServletResponse response, @RequestBody ReportPageDTO pagingDto,

			@RequestHeader String companyId) throws Exception {
		companyId = AES.decryptUrl(companyId);
		response.setContentType(Constants.FILEFORMATE);
		DateFormat dateFormatter = new SimpleDateFormat(Constants.DATEFORMAT);
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = Constants.CONTENT_DISPOSITION;
		String headerValue = "attachment; filename=Employees_Exit_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		reportService.getAllExitEmployeeExportToCSV(response, pagingDto, companyId);
		logger.info("Exit Employee export data csv format");

	}

}
