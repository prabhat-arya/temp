package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.BellIconNotificationsDTO;
import com.hrms.admin.dto.EmployeeOccasionDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.NotificationDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.dto.WishesDTO;
import com.hrms.admin.entity.BellIconNotifications;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.service.NotificationService;
import com.hrms.admin.service.OccasionNotificationService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@RequestMapping(URLConstants.ADMIN_NOTIFICATION)
@CrossOrigin
public class NotificationController {

	private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);

	@Autowired
	private NotificationService service;

	@Autowired
	private OccasionNotificationService occasionNotification;

	@Autowired
	private EmployeeRepository employeeRepo;

	/**
	 * Returns status code when new notification is created
	 * 
	 * @param model - new notification data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody NotificationDTO model) {
		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Notification record is already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> save = service.save(model);
				if (!save.isEmpty()) {
					service.sendNotifications(save.get(0).getId(), model.getFromMail());
					logger.info("Notification record is inserted:{}", model.getSubject());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save),
							HttpStatus.CREATED);

				} else {
					logger.info("Notification failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Notification:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.NOTIFICATION);
		}
	}

	/**
	 * Returns status code when existing notification data is updated
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@RequestBody NotificationDTO model) {
		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("Notification  record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> updateNotification = service.updateNotification(model, model.getId());
				if (updateNotification.isEmpty()) {
					logger.info("Notification failed to update");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				} else {
					logger.info("Notification  record is updated with Id:{}", model.getId());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateNotification),
							HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Notification:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.NOTIFICATION);
		}
	}

	/**
	 * Returns Department and status code when notification data is available by id
	 * 
	 * @param id - notification Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/id/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId = AES.decryptUrl(companyId);
		try {
			NotificationDTO notificationById = service.getById(data, companyId);
			if (notificationById != null) {
				List<NotificationDTO> list = new ArrayList<>();
				list.add(notificationById);
				logger.info("Notification found with notificationId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Notification not found with notificationId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Notification with NotificationId:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.NOTIFICATION);
		}

	}

	/**
	 * Returns All Notifications data when department data is available
	 * 
	 * @return - List of DepartmentModel
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllNotification(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					companyId);
			if (data.isEmpty()) {
				logger.info("Notification record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("Notifications record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Notifications:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.NOTIFICATION);
		}
	}

	/**
	 * Update notification by status
	 * 
	 * @param id  - NotificationId
	 * @param Map object
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/notificationStatus", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateNotificationByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateNotificationByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("Notification updated with Id:", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Notification is not available:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Notification Status with Id:{} : {}", status.getId(), e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.NOTIFICATION);
		}
	}

	/**
	 * Soft Delete method
	 * 
	 * @param id - NotificationId
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteNotification(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> projectList = service.softDeleteNotification(dto.getId());
			if (!projectList.isEmpty()) {
				logger.info("Notification soft deleted with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, projectList),
						HttpStatus.OK);
			} else {
				logger.info("Notification not soft deleted with Id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while soft deleting Notification  with Id:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.NOTIFICATION);
		}
	}

	/**
	 * Returns status code when new Notification is created
	 * 
	 * @param model - new Notification send data
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/wishesMail", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> wishesMail(@RequestBody WishesDTO w, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EntityDTO> wishesList = service.wishesList(w, companyId);
			if (!wishesList.isEmpty()) {
				logger.info("Wishes mail sent successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.error("Wishes mail not sent");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending wishes mail:{} : {}", w.getType(), e);
			return new ResponseEntity<>(new ResponseDTO(e.getMessage(), Constants.FALSE), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Returns status code when new Notification is created
	 * 
	 * @param model - new Notification send data
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/welcomeMail/{empId}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> welcomeMail(@PathVariable Long empId, @RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			Boolean welcomeMail = service.welcomeMail(empId, companyId);
			if (Boolean.TRUE.equals(welcomeMail)) {
				logger.info("WelcomeMail sent successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("welcomeMail not sent");
				return new ResponseEntity<>(new ResponseDTO(Constants.SEND_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending welcomeMail mail:{}", e);
			return new ResponseEntity<>(new ResponseDTO(e.getMessage(), Constants.FALSE), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Returns status code when Notification
	 * 
	 * @param model - new Notification data
	 * @return - ResponseEntity
	 */
	@GetMapping("/birthday")
	public ResponseEntity<ResponseDTO> getBirthDayNotification(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeOccasionDTO> birthDayNotification = occasionNotification.getBirthDayNotification(companyId);
			if (!birthDayNotification.isEmpty()) {
				logger.info("Employee birthday notification sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, birthDayNotification),
						HttpStatus.OK);
			} else {
				logger.info("Employee birthday notification not sent");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending employee birthday notification:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " : " + e.getMessage());
		}
	}

	/**
	 * Returns all notifications when notifications data is available on current
	 * date
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/allAnnouncements")
	public ResponseEntity<ResponseDTO> getAllNotifications(@RequestHeader String companyId) {
		companyId = AES.decryptUrl(companyId);
		try {
			List<EmployeeOccasionDTO> allNotification = occasionNotification.getAllNotification(companyId);
			if (!allNotification.isEmpty()) {
				logger.info("all announcements sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allNotification),
						HttpStatus.OK);
			} else {
				logger.info("Announcements not available for today");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending all announcements:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns all notifications when notifications data is available on current
	 * date
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/bellIconAnnouncements/{approverId}")
	public ResponseEntity<ResponseDTO> getBellIconNotificationsForManager(@PathVariable String approverId,
			@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(approverId));
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> allNotification = service.getBellIconNotificationsTomanager(data, companyId);
			if (allNotification != null) {
				logger.info("all announcements sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allNotification),
						HttpStatus.OK);
			} else {
				logger.info("Announcements not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending all announcements:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns all notifications when notifications data is available on current
	 * date
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/bellIconAnnouncements/employee/{empId}")
	public ResponseEntity<ResponseDTO> getBellIconNotificationsForEmployee(@PathVariable String empId,
			@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(empId));
		companyId = AES.decryptUrl(companyId);
		try {
			Map<String, Object> allNotification = service.getBellIconNotificationsToemployee(data, companyId);
			if (allNotification != null) {
				logger.info("all announcements sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allNotification),
						HttpStatus.OK);
			} else {
				logger.info("Announcements not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending all announcements:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns notification when notifications data is available
	 * 
	 * @return - ResponseEntity
	 */
	@PostMapping("/bellIconById")
	public ResponseEntity<ResponseDTO> getBellIconByNotificationId(@RequestBody BellIconNotificationsDTO notification) {
		try {
			BellIconNotifications bellIconNotificationById = service.getBellIconNotificationById(notification);
			if (bellIconNotificationById != null) {
				logger.info("announcement sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, bellIconNotificationById),
						HttpStatus.OK);
			} else {
				logger.info("Announcement not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending announcement:{}", e.getMessage());
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Delete Bell icon notification based on notificationId
	 * 
	 * @param id - notificationId
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping(value = "/deleteBellNotificationId/{notificationId}")
	public ResponseEntity<ResponseDTO> deleteBellIconNotificationById(@PathVariable String notificationId) {
		Long notification = Long.parseLong(AES.decryptUrl(notificationId));
		try {
			boolean deleteNotification = service.deleteBellIconNotificationById(notification);
			if (!deleteNotification) {
				logger.info("Bell Icon notification Record failed to delete");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.TRUE, null),
						HttpStatus.OK);
			} else {
				logger.info("Bell Icon notification deleted succesfull :{}", deleteNotification);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, deleteNotification), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error when delete Bell Icon notification Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns all notifications List when notifications data is available
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/bellIconListOfManager/{approverId}")
	public ResponseEntity<ResponseDTO> getBellIconNotificationsListForManager(@PathVariable String approverId,
			@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(approverId));
		companyId = AES.decryptUrl(companyId);
		try {
			List<BellIconNotifications> allNotification = service.getBellNotificationsListTomanager(data, companyId);
			if (allNotification != null) {
				logger.info("all announcements sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allNotification),
						HttpStatus.OK);
			} else {
				logger.info("Announcements not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending all announcements:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns all notifications List when notifications data is available
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/bellIconListOfEmployee/{empId}")
	public ResponseEntity<ResponseDTO> getBellIconNotificationsListForEmployee(@PathVariable String empId,
			@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(empId));
		companyId = AES.decryptUrl(companyId);
		try {
			List<BellIconNotifications> allNotification = service.getBellNotificationsListToemployee(data, companyId);
			if (allNotification != null) {
				logger.info("all announcements sent successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allNotification),
						HttpStatus.OK);
			} else {
				logger.info("Announcements not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while sending all announcements:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}
}