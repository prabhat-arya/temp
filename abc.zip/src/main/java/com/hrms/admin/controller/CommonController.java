package com.hrms.admin.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.CertificateTypeDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmploymentTypeDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.BankDetailsErrorRecords;
import com.hrms.admin.entity.CertificateType;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.fileuploaddownload.property.ErrorRecordEmployeeUploadExcel;
import com.hrms.admin.fileuploaddownload.property.ErrorRecordsExcel;
import com.hrms.admin.service.AttendanceInfoService;
import com.hrms.admin.service.CommonService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@RequestMapping(URLConstants.COMMON_OPERATIONS)
@CrossOrigin
public class CommonController {

	private static final Logger logger = LoggerFactory.getLogger(CommonController.class);

	@Autowired
	private CommonService service;

	@Autowired
	AttendanceInfoService attendanceservice;

	/**
	 * Getting all employees under project based on managerId
	 * 
	 * @author {Manikanta}
	 * @param id
	 * @return getting all employees under project based on managerId
	 */
	@GetMapping("/manager/{id}")
	public ResponseEntity<ResponseDTO> getAllEmployeesUnderProject(@PathVariable String id) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		try {
			List<ProjectDTO> list = service.managerHierarchy(data);
			if (!list.isEmpty()) {
				logger.info("All Employee's list based on projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("employees not found with projectId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Employees found with projectId:{}", data);
			throw new NotFoundException("Employees not found with project");
		}
	}

	/**
	 * Returns all projects list and status code when Projects data is available
	 * based on companyId
	 * 
	 * @author {RAMESH RENDLA}
	 *
	 */
	@GetMapping("/admin/{companyId}")
	public ResponseEntity<ResponseDTO> getProjectsListForDashBoardAdmin(@PathVariable String companyId) {
		String data = AES.decryptUrl(companyId);
		try {
			List<EmployeeProjectsDTO> projects = service.projectsBasedOnCompany(data);
			if (!projects.isEmpty()) {
				logger.info("Project List found based on CompanyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, projects),
						HttpStatus.OK);
			} else {
				logger.info("Projects not found with companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Project:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Returns all projects list and status code when Projects data is available
	 * based on managerId
	 * 
	 * @author {RAMESH RENDLA}
	 *
	 */
	@GetMapping("/managers/{managerId}")
	public ResponseEntity<ResponseDTO> getProjectsListForDashBoardManager(@PathVariable String managerId,
			@RequestHeader(value = "companyId") String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(managerId));
		try {
			List<EmployeeProjectsDTO> projects = service.projectsListBasedOnManger(data, AES.decryptUrl(companyId));
			if (!projects.isEmpty()) {
				logger.info("Project List found based on ManagerId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, projects),
						HttpStatus.OK);
			} else {
				logger.info(" all projects not found:{} ", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all project:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR);
		}
	}

	/**
	 * Employee bank info error records
	 * 
	 * @return employee bank info error records
	 * @throws IOException
	 */
	@GetMapping("/export/BankErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorBankDetails() throws IOException {
		List<BankDetailsErrorRecords> bankDetailsError = service.excelReportAllErrorBankDetails();
		ByteArrayInputStream in = ErrorRecordsExcel.bankDetailsErrorRecordsExcel(bankDetailsError);
		logger.info("Bank error records in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=bankErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Employee experience error records excel file
	 * 
	 * @return employee experience error records excel file
	 * @throws IOException
	 */
	@GetMapping("/export/ProfErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorProfessionalDetailsError() throws IOException {
		List<ProfessionalDetailsErrorRecords> professionalDetailsError = service
				.excelReportAllErrorProfessionalDetailsError();
		ByteArrayInputStream in = ErrorRecordsExcel.professionalDetailsErrorRecordsExcel(professionalDetailsError);
		logger.info("Professional error records in  excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=professionalErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Employee error record excel sheet
	 * 
	 * @return employee error record excel sheet
	 * @throws IOException
	 */
	@GetMapping("/export/EmployeeErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorEmployeeDetailsError() throws IOException {
		List<EmployeeErrorRecords> empDetailsError = service.excelReportAllErrorEmployeeDetailsError();

		ByteArrayInputStream in = ErrorRecordsExcel.employeeDetailsErrorRecordsExcel(empDetailsError);
		logger.info("Employee error records in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Success employee records excel file
	 * 
	 * @return success employee records excel file
	 * @throws IOException
	 */
	@GetMapping("/export/EmployeeSuccessRecords")
	public ResponseEntity<InputStreamResource> excelReportAllSuccessEmployeeDetails(@RequestHeader String companyId)
			throws IOException {
		List<Employee> empDetailsSuccess = service.excelReportAllSuccessEmployeeDetails(AES.decryptUrl(companyId));
		ByteArrayInputStream in = ErrorRecordsExcel.empDetailsSuccessRecordsExcel(empDetailsSuccess);
		logger.info("Success employee records in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpSuccessRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Mail id error records
	 * 
	 * @return mail id error records
	 * @throws Exception
	 */
	@GetMapping("/export/mailErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorEmployeeMailIdError() throws Exception {
		List<EmployeeMailErrorRecords> empDetailsError = service.excelReportAllErrorEmployeeMailIdError();
		ByteArrayInputStream in = ErrorRecordsExcel.employeeMialIdErrorRecordsExcel(empDetailsError);
		logger.info("Mail error records in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpMailIdErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for Bank error records details
	 * 
	 * @return Sample file
	 * @throws IOException
	 */
	@GetMapping("/export/BankErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorSampleBankDetails() throws IOException {
		ByteArrayInputStream in = ErrorRecordsExcel.bankDetailsErrorRecordsExcelSampleFile();
		logger.info("Banke Error record sample file  excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpoloyeeBankDetails" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for professional error records details
	 * 
	 * @return Sample file
	 * @throws IOException
	 */
	@GetMapping("/export/ProfErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorProfessionalSampleDetailsError() throws IOException {
		ByteArrayInputStream in = ErrorRecordsExcel.professionalDetailsErrorRecordsExcelSampleFile();
		logger.info("Professional error records sample in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpoloyeeProfessionalDetails" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for employee error records details
	 * 
	 * @return Sample file
	 * @throws IOException
	 */
	@GetMapping("/export/EmployeeErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorSampleEmployeeDetailsError() throws IOException {
		ByteArrayInputStream in = ErrorRecordsExcel.empDetailsErrorRecordsExcelSampleFile();
		logger.info("Employee excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmployeebasicInfo" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for mail error records details
	 * 
	 * @return Sample file
	 * @throws Exception
	 */
	@GetMapping("/export/mailErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorSampleEmployeeMailIdError() throws Exception {
		ByteArrayInputStream in = ErrorRecordsExcel.employeeMialIdErrorRecordsExcelSampleFile();
		logger.info("Mail error records sample excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmployeeMailId" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for educational error records details
	 * 
	 * @return Sample file
	 * @throws Exception
	 */
	@GetMapping("/export/educationalErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorSampleEmployeeEducationalDetailsError()
			throws Exception {
		ByteArrayInputStream in = ErrorRecordsExcel.employeeEducationalDetailsErrorRecordsExcelSampleFile();
		logger.info("Educational details records sample excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=Employeeeducationaldetails" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Employee Educational error records excel file
	 * 
	 * @return employee experience error records excel file
	 * @throws IOException
	 */
	@GetMapping("/export/educationalErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorEducationalDetailsError() throws IOException {
		List<AcadmicDetailsErrorRecords> educationalDetailsError = service.excelReportAllErrorEducationalDetailsError();
		ByteArrayInputStream in = ErrorRecordsExcel.educationalDetailsErrorRecordsExcel(educationalDetailsError);
		logger.info("Educational error records in  excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EducatioanlErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for emergency contact details error records details
	 * 
	 * @return Sample file
	 * @throws Exception
	 */
	@GetMapping("/export/emergencyErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportAllErrorSampleEmployeeEmergencyDetailsError()
			throws Exception {
		ByteArrayInputStream in = ErrorRecordsExcel.employeeEmergencyDetailsErrorRecordsExcelSampleFile();
		logger.info("Emergency contact details records sample excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=Employeeemergencycontactdetails" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Employee Educational error records excel file
	 * 
	 * @return employee experience error records excel file
	 * @throws IOException
	 */
	@GetMapping("/export/emergencyErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorEmergencyContactDetailsError() throws IOException {
		List<EmergencyContactDetailErrorRecords> educationalDetailsError = service
				.excelReportAllErrorEmergencyContactDetailsError();
		ByteArrayInputStream in = ErrorRecordsExcel.emergencyContactDetailsErrorRecordsExcel(educationalDetailsError);
		logger.info("Educational error records in  excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmergencyErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Employee error record excel sheet
	 * 
	 * @return employee error record excel sheet
	 * @throws IOException
	 */
	@GetMapping("/export/allEmployeeErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportBulkAllErrorEmployeeDetailsError() throws IOException {
		List<EmployeeErrorRecords> empDetailsError = service.excelReportAllErrorEmployeeDetailsError();
		List<EmployeeMailErrorRecords> empeMailError = service.excelReportAllErrorEmployeeMailIdError();
		List<AcadmicDetailsErrorRecords> educationalDetailsError = service.excelReportAllErrorEducationalDetailsError();
		List<EmergencyContactDetailErrorRecords> emergencyContactDetailError = service
				.excelReportAllErrorEmergencyContactDetailsError();
		List<ProfessionalDetailsErrorRecords> professionalDetailsError = service
				.excelReportAllErrorProfessionalDetailsError();
		List<PersonalDetailsErrorRecords> personalContactDetailsError = service.excelReportAllErrorPersonalContactDetailsError();
		ByteArrayInputStream in = ErrorRecordEmployeeUploadExcel.allEmployeeDetailsErrorRecordsExcel(empDetailsError,
				educationalDetailsError, emergencyContactDetailError, professionalDetailsError, empeMailError,personalContactDetailsError);
		logger.info("Employee error records in excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmpErrorRecord_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Sample file for employee error records details
	 * 
	 * @return Sample file
	 * @throws IOException
	 */
	@GetMapping("/export/allEmployeeErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> excelReportBulkAllErrorEmployeeDetailsErrorSampleFile()
			throws IOException {
		ByteArrayInputStream in = ErrorRecordsExcel.allEmpDetailsErrorRecordsExcelSampleFile();
		logger.info("Employee excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=EmployeebasicInfo" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(value = "/certificatesType")
	public ResponseEntity<ResponseDTO> getAllCertificatesList() {
		try {
			List<CertificateTypeDTO> certificateTypeList = service.getCertificateTypeList();
			if (!certificateTypeList.isEmpty()) {
				logger.info("Certificates List found ");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, certificateTypeList),
						HttpStatus.OK);
			} else {
				logger.info("Certificates List not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting Certificates List", e.getMessage());
			throw new NotUpdatedException(Constants.NO_LIST);
		}
	}

	@PostMapping(value = "/saveCertificateType")
	public ResponseEntity<ResponseDTO> saveCertificateType(@RequestBody CertificateTypeDTO model) {
		try {
			boolean isExists = service.validateCertificateType(model);
			if (isExists) {
				logger.info("Certificate Type already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				CertificateType certificateTypeList = service.saveCertificateType(model);
				if (certificateTypeList != null) {
					logger.info("Certificates List saved ");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, certificateTypeList),
							HttpStatus.OK);
				} else {
					logger.info("Certificates List not save");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while saving Certificates List", e.getMessage());
			throw new NotUpdatedException(Constants.NO_LIST);
		}
	}
/*
 * 
 */
	@GetMapping(value = "/employmentTypeList")
	public ResponseEntity<ResponseDTO> getAllEmploymentTypeList() {
		try {
			List<EmploymentTypeDTO> certificateTypeList = service.getEmploymentTypeList();
			if (!certificateTypeList.isEmpty()) {
				logger.info("EmploymentType List found ");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, certificateTypeList),
						HttpStatus.OK);
			} else {
				logger.info("EmploymentType List not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting EmploymentType List", e.getMessage());
			throw new NotUpdatedException(Constants.NO_LIST);
		}
	}
	
	/**
	 * Sample file for personal contact details sample file
	 * 
	 * @return Sample file
	 * @throws Exception
	 */
	@GetMapping("/export/personalErrorRecords/samplefile")
	public ResponseEntity<InputStreamResource> EmployeePesrsonalDetailsSampleFile()
			throws Exception {
		ByteArrayInputStream in = ErrorRecordsExcel.employeePersonalDetailsExcelSampleFile();
		logger.info("Personal details records sample excel report data format");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=Employee_Personal_contact_details" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
	/**
	 *   personal contact details error records file
	 * 
	 * @return Sample file
	 * @throws Exception
	 */
	@GetMapping("/export/personalErrorRecords")
	public ResponseEntity<InputStreamResource> excelReportAllErrorPersonalContactDetailsError() throws IOException {
		List<PersonalDetailsErrorRecords> personalDetailsError = service
				.excelReportAllErrorPersonalContactDetailsError();
		ByteArrayInputStream in = ErrorRecordsExcel.personalContactDetailsErrorRecordsExcel(personalDetailsError);
		logger.info("personal error records in  excel report");
		HttpHeaders headers = new HttpHeaders();
		String currentDate = attendanceservice.currentDateandTime();
		headers.add(Constants.CONTENT_DISPOSITION,
				"attachment; filename=PersonalErrorRecords_" + currentDate + Constants.EXCEL_EXTENTION);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}