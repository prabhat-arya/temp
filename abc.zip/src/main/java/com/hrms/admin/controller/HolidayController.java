package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.HolidayDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.HolidayService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Holiday Record
 * 
 * @author {Praveen Kumar}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_HOLIDAY)
public class HolidayController {

	private static final Logger logger = LoggerFactory.getLogger(HolidayController.class);

	@Autowired
	private HolidayService service;

	/**
	 * Returns status code when new Holiday is created
	 * 
	 * @param model - New Holiday data
	 * @return - ResponseEntity
	 */

	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> add(@RequestPart String model,@RequestPart(required = false) MultipartFile file) {

		try {
			// here call validation method
			ObjectMapper mapper = new ObjectMapper();
			HolidayDTO dto = mapper.readValue(model, HolidayDTO.class);
			boolean isExists = service.validate(dto, true);
			if (isExists) {
				logger.info("Holiday record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> save = service.save(dto,file);
				if (save.isEmpty()) {
					logger.info("Holiday failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.TRUE), HttpStatus.OK);
				} else {
					logger.info("Holiday record is inserted:{}", dto.getName());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save), HttpStatus.CREATED);
				}
			}

		} catch (Exception e) {
			logger.error("Error while storing holiday record:{}",e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + ":"+ Constants.HOLIDAY );
		}

	}

	/**
	 * Returns status code when existing Holiday data is updated
	 * 
	 * @param model - new Holiday data
	 * @param id    - Holiday Id
	 * @return - ResponseEntity
	 */

	@PutMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> update(@RequestPart String model,@RequestPart(required = false) MultipartFile file) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			HolidayDTO dto = mapper.readValue(model, HolidayDTO.class);
			boolean isExists = service.validate(dto, false);
			if (isExists) {
				logger.info("Holiday record is Already is exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.OK);
			} else {
				List<EntityDTO> updateHoliday = service.updateHoliday(dto,file);
				if (updateHoliday.isEmpty()) {
					logger.info("Holiday failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE),
							HttpStatus.OK);
				} else {
					logger.info("Holiday record is updated with Id:{}", dto.getId());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateHoliday), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
				logger.error("Error while updating holiday:{}", e);
				throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.HOLIDAY);
		}
	}

	/**
	 * Returns Holiday and status code when Holiday data is available by id
	 * @param id - Holiday Id
	 * @return Returns Holiday and status code when Holiday data is available by id
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId=AES.decryptUrl(companyId);
		try {
			HolidayDTO holidayId = service.getById(data , companyId);

			if (holidayId != null) {
				List<HolidayDTO> list = new ArrayList<>();
				list.add(holidayId);
				logger.info("Holiday fond with holidayId:{}",data );
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("No data while getting Holiday with holidayId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Holiday:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.HOLIDAY);
		}
	}

	/**
	 * Returns status code when Holiday data is deleted
	 * @param id - Holiday id
	 * @return Returns status code when Holiday data is deleted
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto , @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = service.getAllHoliday(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),companyId);
			if (data.isEmpty()) {
				logger.info("Holiday record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null),
						HttpStatus.OK);
			} else {
				logger.info("Holiday record is found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Holiday record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.HOLIDAY);
		}
	}

	/**
	 * update assets by status
	 * @param status
	 * @return update assets by status
	 */
	@PutMapping(value = "/holidayStatus",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateAssetsByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> assetsList = service.updateHolidayByStatus(status.getId(),status.getStatus());
			if (!assetsList.isEmpty()) {
				logger.info("Holiday upadated with Id:{}", status.getId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, assetsList), HttpStatus.OK);
			} else {
				logger.info("Holiday is not available:{}",status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Holiday Status with Id:{} : {}",status.getId(), e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " +Constants.HOLIDAY);
		}
	}

	/**
	 * soft delete method
	 * @param dto
	 * @return soft delete method
	 */
	
	@PutMapping(value = "/delete",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteHoliday(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> holidayList = service.softDeleteHoliday(dto.getId());
			logger.info("Holiday soft deleted with Id:{}", dto.getId());
			return new ResponseEntity<>(
					new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, holidayList), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while Soft Deleting Holiday with Id:{} : {}",dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.HOLIDAY);
		}
	}

	/**
	 * This method is used to find all holiday's list based on branchId
	 * @param branchId
	 * @return This method is used to find all holiday's list based on branchId
	 */
	@GetMapping("/branch/{branchId}")
	public ResponseEntity<ResponseDTO> getAllHolidayListBasedOnBranch(@PathVariable String branchId, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(branchId));
		try {
			List<HolidayDTO> projectCount = service.getAllHolidayListBasedOnBranch(data, AES.decryptUrl(companyId));
			if (!projectCount.isEmpty()) {
				logger.info("Found: {}  {}", projectCount.size(),Constants.HOLIDAY);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, projectCount), HttpStatus.OK);
			} else {
				logger.info("Holiday Record is not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while getting all holiday record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.HOLIDAY);

		}
	}
}