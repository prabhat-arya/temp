package com.hrms.admin.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PerformanceDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.service.PerformanceService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/*
 * @author Atif Ansari
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_PERFORMANCE)
public class PerformanceController {

	
	private static final Logger logger = LoggerFactory.getLogger(PerformanceController.class);
	
	@Autowired
	private PerformanceService service;
	
	/**
	 * This method is saving the performance in the Data base for the employee
	 * 
	 * @param model
	 * @return This method is saving the performance in the Data base for the employee
	 */
	@PostMapping(value = "/byEmployee",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addPerformanceByEmployee(@Valid @RequestBody PerformanceDTO model) {
		try {

			List<EntityDTO> save = service.saveAndUpdatePerformanceByEmployee(model);
			if (save.isEmpty()) {
				logger.info("Performance is failed to added for the employee");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("Performance is added for the employee");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save), HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding performance for employee");
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.PERFORMANCE);
		}
	}
	
	
	
	/**
	 * This method is saving the performance in the Data base for the Manager 
	 * 
	 * @param model
	 * @return This method is saving the performance in the Data base for the Manager
	 */
	@PostMapping(value = "/byManager",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addPerformanceByManager(@Valid @RequestBody PerformanceDTO model) {
		try {

			List<EntityDTO> save = service.saveAndUpdatePerformanceByManager(model);
			if (save.isEmpty()) {
				logger.info("Manager added or updated the performance for the employee");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("failed to add  or updated the performance for employee");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save), HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while manager adding or updating the performance for employee");
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.PERFORMANCE);
		}
	}
	
	
	
	/**
	 * This method is used to show the Performance by EmployeeId
	 * 
	 * @param employeeId
	 * @return This method is used to show the Performance by EmployeeId
	 */
	@GetMapping("/employee/{employeeId}")
	public ResponseEntity<ResponseDTO> showPerformanceByEmployeeId(@PathVariable String employeeId) {
		
		Long employeeIdData = Long.parseLong(AES.decryptUrl(employeeId));
		try {

			List<PerformanceDTO> list = service.findPerformanceByEmployeeId(employeeIdData);
			if (list.isEmpty()) {
				logger.info("Found Performance with employeeId:{}",employeeIdData);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE),
						HttpStatus.OK);
			} else {
				logger.info("Performance  not found with employeeId:{}",employeeIdData);
				return new ResponseEntity<>(
						new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding Performance with employeeId:{} : {}",employeeIdData,e);
			throw new NotCreatedException(Constants.NOT_EXECUTED + " " + Constants.PERFORMANCE);
		}
	}
	
	/**
	 * This method is used to  add the Final Performance By Employee like agree or Disagree
	 * 
	 * @param model
	 * @return This method is used to  add the Final Performance By Employee like agree or Disagree
	 */
	@PostMapping(value = "/byEmployeeFinal",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addPerformanceByEmployeeFinal(@Valid @RequestBody PerformanceDTO model) {
		try {

			List<EntityDTO> save = service.saveAndUpdatePerformanceByEmployeeFinalSubmit(model);
			if (save.isEmpty()) {
				logger.info("Employee final submit the Performance");
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("Employee failed to final submit Performance");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, save), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Employee final submiting the Performance:{}",e);
			throw new NotCreatedException(Constants.UPDATE_FAIL + " " + Constants.PERFORMANCE);
		}
	}
	
	/**
	 * This method is saving the performance in the Data base for the Manager 
	 * 
	 * @param model
	 * @return This method is saving the performance in the Data base for the Manager
	 */
	@PostMapping(value = "/byReviewer",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addPerformanceByReviewer(@Valid @RequestBody PerformanceDTO model) {
		try {

			List<EntityDTO> save = service.saveAndUpdatePerformanceByReviewer(model);
			if (save.isEmpty()) {
				logger.info("Manager added or updated the performance for the employee");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("failed to add  or updated the performance for employee");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save), HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while manager adding or updating the performance for employee");
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.PERFORMANCE);
		}
	}
	
}
