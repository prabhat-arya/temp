package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.DesignationDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.DesignationService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Designation Record
 *
 * @author {Ramesh}
 *
 */
@CrossOrigin
@RestController
@RequestMapping(URLConstants.ADMIN_DESIGNATION)
public class DesignationController {

	private static final Logger logger = LoggerFactory.getLogger(DesignationController.class);

	@Autowired
	DesignationService designationService;

	/**
	 * Returns Designation and status code when designation data is available by id
	 *
	 * @param id - designation Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable("id") String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		String cmpId = AES.decryptUrl(companyId);
		try {
			DesignationDTO designationById = designationService.getById(data,cmpId);
			if (designationById == null) {
				logger.info("Designation not found by designationId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				List<DesignationDTO> list = new ArrayList<>();
				list.add(designationById);
				logger.info("Designation found with designationId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Designation by designationId:{} : {}", data, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Returns status code when new designation is created
	 *
	 * @param model - new designation data
	 * @return - ResponseEntity
	 */

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody DesignationDTO model) {

		try {

			// here call validation method
			boolean isExists = designationService.validate(model, true);
			if (isExists) {
				logger.info("Designation record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> designation = designationService.save(model);
				if (!designation.isEmpty()) {
					logger.info("Designation Added:{}", model.getDepartmentName());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, designation),
							HttpStatus.CREATED);
				} else {
					logger.info("Designation failed to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding designation:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Returns status code when existing designation data is updated
	 *
	 * @param model - new designation data
	 * @param id    - designation Id
	 * @return - ResponseEntity
	 */
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody DesignationDTO model) {

		try {
			boolean isExists = designationService.validate(model, false);
			if (isExists) {
				logger.info("Designation record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> designation = designationService.updateDesignation(model);
				if (!designation.isEmpty()) {
					logger.info("Designation record is updated with designationId:{}", model.getId());
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, designation),
							HttpStatus.OK);
				} else {
					logger.info("Designation failed to update with designationId:{}", model.getId());
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Designation:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Returns status code when designation data is deleted
	 *
	 * @param id - designation id
	 * @return - ResponseEntity
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allDesigationByDepartmentId(@PathVariable String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		String cmpId = AES.decryptUrl(companyId);
		try {
			List<DesignationDTO> allDesignations = designationService.getDepartmentById(data,cmpId);
			if (!allDesignations.isEmpty()) {
				logger.info("Found:{} designation with designationId:{}", allDesignations.size(), data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allDesignations),
						HttpStatus.OK);
			} else {
				logger.info("Designation not found with designationId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all designation Records:{}",e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Returns All Attendance data when Designation data is available
	 *
	 * @return - List of DesignationModel
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId ) {
		try {
			Map<String, Object> data = designationService.getAllDesignation(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					pagingDto.getStatus(),AES.decryptUrl(companyId));
			if (data.isEmpty()) {
				logger.info("No Designation found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Designation found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Designation:{}",e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Sodt Delete
	 * @param id - designationId
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/delete")
	public ResponseEntity<ResponseDTO> softDeleteDesignation(@RequestBody StatusDTO dto) {
		try {
			
			List<EntityDTO> designationList = designationService.softDeleteDesignation(dto.getId());
			if (!designationList.isEmpty()) {
				logger.info("Designation soft deleted with designationId:{}",dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, designationList),
						HttpStatus.OK);

			} else {
				logger.info("Designation not soft deleted with designationId:{}",dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while soft deleting designation by designationId:{} : {}",dto.getId(),e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.DESIGNATION);
		}
	}

	/**
	 * Update Designation By Status
	 * @param id  - DesignationId
	 * @param Map object
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/status")
	public ResponseEntity<ResponseDTO> updateDesignationByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> designationList = designationService.updateDesignationByStatus(status.getId(),
					status.getStatus());
			if (!designationList.isEmpty()) {
				logger.info("Designation updated with designationId:{}",status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, designationList),
						HttpStatus.OK);
			} else {
				logger.info("Designation not found by designationId:{}",status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating designation status by designationId:{} : {}",status.getId(),e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.DESIGNATION);
		}
	}

}