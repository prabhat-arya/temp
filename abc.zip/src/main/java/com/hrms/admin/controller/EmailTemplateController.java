package com.hrms.admin.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EmailTemplateDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.EmailTemplateService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Email Template
 * 
 *
 */
@CrossOrigin
@RestController
@RequestMapping(URLConstants.ADMIN_MAILTEMPLATE)
public class EmailTemplateController {

	private static final Logger logger = LoggerFactory.getLogger(EmailTemplateController.class);

	@Autowired
	private EmailTemplateService emailTemplateService;

	/**
	 * Returns status code when new email template is created
	 * 
	 * @param model - new email template data
	 * @param id    - employee Id
	 * @return - ResponseEntity
	 */
	@PostMapping(value = { "/userInvite", "/paySlipNotification", "/employeeInvitation" })
	public ResponseEntity<ResponseDTO> eMailTemplate(@RequestBody EmailTemplateDTO emailTemplateDto,@RequestHeader String companyId,
			Principal principal) {
		try {
			List<EntityDTO> save = emailTemplateService.saveTemplate(emailTemplateDto, principal,
					emailTemplateDto.getEmpId(),companyId);
			if (save != null) {

				logger.info("email template saved successfully");
				return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, save),
						HttpStatus.OK);
			} else {
				logger.info("email template not saved");
				return new ResponseEntity<>(new ResponseDTO(Constants.BAD_REQUEST, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while adding Template:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + "Eamil Template");
		}

	}

	/**
	 * Returns Email Template and status code when email template data is available
	 * by employee id
	 * 
	 * @param id - employee Id, template name
	 * @return - ResponseEntity
	 */

	@GetMapping(value = { "/userInvite/{empId}/{templateName}", "/paySlipNotification/{empId}/{templateName}",
			"/employeeInvitation/{empId}/{templateName}" })
	public ResponseEntity<ResponseDTO> getById(@PathVariable String empId, @PathVariable String templateName) {
		Long employeeId = Long.parseLong(AES.decryptUrl(empId));
		String template = AES.decryptUrl(templateName);
//		Long employeeId = Long.parseLong(empId);
//		String template = templateName;

		try {
			EmailTemplateDTO emailTemplate = emailTemplateService.getEmailTemplateByEmpId(employeeId, template);

			if (emailTemplate != null) {
				List<EmailTemplateDTO> list = new ArrayList<>();
				list.add(emailTemplate);
				logger.info("Email Template found with employeeId:{}", employeeId);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("No data while getting Email Template by employeeId:{}", employeeId);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting email template with employeeId:{} : {}", employeeId, e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.EMAIL_TEMPLATE);
		}
	}

	/**
	 * Returns status code when existing email template data is updated
	 * 
	 * @param model - new email template data
	 * @param id    - employee Id, template name
	 * @return - ResponseEntity
	 */

	@PutMapping(value = { "/userInvite", "/paySlipNotification", "/employeeInvitation" })
	public ResponseEntity<ResponseDTO> updateTemplate(@RequestBody EmailTemplateDTO model) {
		try {
			List<EntityDTO> emailTemplateList = emailTemplateService.updateByEmpId(model, model.getEmpId(),
					model.getTemplateName());
			if (!emailTemplateList.isEmpty()) {
				logger.info("Email template upadated with employeeId:{}", model.getEmpId());
				return new ResponseEntity<>(
						new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, emailTemplateList), HttpStatus.OK);
			} else {
				logger.info("Email template is not available:{}", model.getEmpId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(
					String.format("Error while updating email template by employeeId:{} : {}", model.getEmpId(), e));
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.EMAIL_TEMPLATE);
		}
	}

}
