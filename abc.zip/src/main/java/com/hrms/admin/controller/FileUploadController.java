/*
 * package com.hrms.admin.controller;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.web.bind.annotation.CrossOrigin; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestParam; import
 * org.springframework.web.bind.annotation.RestController; import
 * org.springframework.web.multipart.MultipartFile;
 * 
 * import com.hrms.admin.dto.BatchResponseDTO; import
 * com.hrms.admin.dto.DataCountDTO; import
 * com.hrms.admin.repository.BatchDetailsDao; import
 * com.hrms.admin.service.impl.FileStorageServiceImpl;
 * 
 * 
 * //@RestController
 * 
 * @CrossOrigin
 * 
 * @RequestMapping("/admin/attendance") public class FileUploadController {
 * 
 * @Autowired private FileStorageServiceImpl fileStorageService;
 * 
 * @Autowired private AttendanceInfoLoadController infoLoad;
 * 
 * @Autowired private BatchDetailsDao batchDetailDao;
 * 
 * //@PostMapping("/uploadFile") public BatchResponseDTO
 * uploadFile(@RequestParam("file") MultipartFile file) {
 * 
 * BatchResponseDTO batchResponse = new BatchResponseDTO(); DataCountDTO
 * batchStatus = null;
 * 
 * try {
 * 
 * String fileName = fileStorageService.storeFile(file);
 * if(fileName.contains(fileName)) { //infoLoad.load(); batchStatus =
 * batchDetailDao.getBatchStatus("ATTENDANCE-file-load");
 * System.out.println(batchDetailDao.getBatchStatus("ATTENDANCE-file-load").
 * getSuccessCount()); batchResponse.setMessage(" Upload File successfully...");
 * batchResponse.setData(batchStatus); batchResponse.setStatus("success"); }
 * 
 * } catch (Exception e) { batchResponse.setMessage(" Upload File fail...");
 * batchStatus = batchDetailDao.getBatchStatus("ATTENDANCE-file-load");
 * batchResponse.setData(batchStatus); batchResponse.setStatus("failure");
 * 
 * return batchResponse; } return batchResponse; } }
 */