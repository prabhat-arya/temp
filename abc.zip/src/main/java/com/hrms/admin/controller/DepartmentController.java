package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.DepartmentDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.DepartmentService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Department Record
 * 
 * @author {Prabhat}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_DEPARTMENT)
public class DepartmentController {

	private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	@Autowired
	private DepartmentService service;

	/**
	 * Returns status code when new department is created
	 * 
	 * @param model - new department data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody DepartmentDTO model) {

		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Department record is Already is exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.OK);
			} else {
				List<EntityDTO> departmentLIst = service.save(model);
				if (departmentLIst.isEmpty()) {
					logger.info("Department fail to insert");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
							HttpStatus.OK);
				} else {
					logger.info("Department record is inserted");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, departmentLIst),
							HttpStatus.CREATED);
				}
			}
		} catch (Exception e) {
			logger.error("Error while storing Department record:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + Constants.DEPARTMENT);
		}
	}

	/**
	 * Returns status code when existing department data is updated
	 * 
	 * @param model - new department data
	 * @param id    - depatment Id
	 * @return - ResponseEntity
	 */

	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody DepartmentDTO model) {

		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("Department record is Already is exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> updateDepartment = service.updateDepartment(model, model.getId());
				if (updateDepartment.isEmpty()) {
					logger.info("Department failed to update");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}else {
					logger.info("Department record is updated with departmentId:{}", model.getId());
					return new ResponseEntity<>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateDepartment), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Department:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.DEPARTMENT);
		}
	}

	/**
	 * Returns Department and status code when department data is available by id
	 * 
	 * @param id - depatment Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id,@RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		String cmpId = AES.decryptUrl(companyId);
		try {
			DepartmentDTO departmentById = service.getById(data,cmpId);
			if (departmentById != null) {
				List<DepartmentDTO> list = new ArrayList<>();
				list.add(departmentById);
				logger.info("Department found with departmentId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				logger.info("Department not found with departmentId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting department with Id:{} : {}",data,e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEPARTMENT);
		}
	}

	/**
	 * Returns All company data when company data is available
	 * 
	 * @return - List of company
	 */

	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> departments(@RequestHeader String companyId) {
		String cmpId = AES.decryptUrl(companyId);
		try {
			List<DepartmentDTO> allDepartment = service.AllDepartment(cmpId);
			if (!allDepartment.isEmpty()) {
				logger.info("Found all Departments list");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allDepartment),
						HttpStatus.OK);
			} else {
				logger.info("Department Records are not available");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all departments records:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEPARTMENT);
		}
	}

	
	/**
	 * Returns attendance and status code when attendance data is available by id
	 * 
	 * @param PaginationDTO
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto ,@RequestHeader String companyId) {
		try {
			
			Map<String, Object> data = service.getAllDepartment(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(), AES.decryptUrl(companyId));
			if (data.isEmpty()){
				logger.info("Department record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("Department records found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting department:{}",e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEPARTMENT);
		}
	}

	
	/**
	 * Returns all departments data is available by branchId
	 * 
	 * @return - ResponseEntity
	 */
	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allDepartmentsByBranchId(@PathVariable String id,@RequestHeader  String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		String cmpId = AES.decryptUrl(companyId);
		try {
			List<DepartmentDTO> allDepartments = service.getBranchById(data,cmpId);
			if (!allDepartments.isEmpty()) {
				logger.info("Found all Department based on branchId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allDepartments),
						HttpStatus.OK);
			} else {
				logger.info("No Department found with branchId:{}",data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("error while getting all Department based on branchId:{}:{}",data,e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.DEPARTMENT);
		}
	}


	/**
	 * Soft Delete
	 * @param id - DepartmentId
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/delete",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteDepartment(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> departmentList = service.softDeleteDepartment(dto.getId());
			if (!departmentList.isEmpty()) {
				logger.info("Department soft deleted with departmentId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, departmentList),
						HttpStatus.OK);
			} else {
				logger.info("Department soft deletion failed with departmentId:{}",dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while soft deleting deparment by departmentId:{}:{}",dto.getId(),e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.DEPARTMENT);
		}
	}

	/**
	 * Update Department by status
	 * @param id  - Department Id
	 * @param Map object
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/status",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateDepartmentByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> departmentList = service.updateDepartmentByStatus(status.getId(),status.getStatus());
			if (!departmentList.isEmpty()) {
				logger.info("Department upadated with departmentId:{}",status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, departmentList),
						HttpStatus.OK);
			} else {
				logger.info("Department is not available with departmentId:{}",status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			logger.error("Error while updating Department Status by departmentId:{}",e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.DEPARTMENT);

		}
	}
}