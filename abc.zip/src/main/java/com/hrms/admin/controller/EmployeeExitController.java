package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EmployeeExitMgmtDTO;
import com.hrms.admin.dto.EmployeeExitMgmtShowDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.QuestionsDTO;
import com.hrms.admin.dto.ResignationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.Resignation;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.service.EmployeeExitService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/*
 * @author Atif Ansari
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_EXIT)
public class EmployeeExitController {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeExitController.class);

	@Autowired
	private EmployeeExitService service;

	/**
	 * This method is used to save the Employee Exit Details
	 * 
	 * @param model
	 * @return This method is used to save the Employee Exit Details
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody EmployeeExitMgmtDTO model) {
		try {

			List<EntityDTO> saveAndUpdateEmployeeExit = service.saveAndUpdateEmployeeExit(model);
			if (saveAndUpdateEmployeeExit.isEmpty()) {
				logger.info("EmployeeExit failed to add");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("EmployeeExit Added successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, saveAndUpdateEmployeeExit),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding EmployeeExit:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This method is used to show all the question and answers and comment what he
	 * initially filled
	 * 
	 * @param employeeId
	 * @return This method is used to show all the question and answers and comment
	 *         what he initially filled
	 */
	@GetMapping("/oneEmployee/{employeeId}")
	public ResponseEntity<ResponseDTO> show(@PathVariable String employeeId, @RequestHeader String companyId) {
		try {

			EmployeeExitMgmtShowDTO empExit = service
					.findExitFormByEmployeeId(Long.parseLong(AES.decryptUrl(employeeId)), AES.decryptUrl(companyId));
			if (empExit == null) {
				logger.info("EmployeeExit failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("EmployeeExit found to show");
				return new ResponseEntity<>(new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, empExit),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while finding EmployeeExit :{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This method is used to get all the employees from the exit-management list
	 * 
	 * @param employeeId
	 * @return This method is used to get all the employees from the exit-management
	 *         list
	 */
	@GetMapping("/oneEmployee/allEmpExit")
	public ResponseEntity<ResponseDTO> getAllEmpExitDetails(@RequestHeader(value = "companyId") String companyId) {
		try {

			List<EmployeeExitMgmtDTO> allEmpExitDetails = service.getAllEmpExitDetails(AES.decryptUrl(companyId));
			if (allEmpExitDetails.isEmpty()) {
				logger.info("EmployeeExit failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("All EmployeeExit found");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allEmpExitDetails),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while finding EmployeeExit:{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This Method is used to show all Employees Pagination
	 * 
	 * @param pagingDto
	 * @return This Method is used to show all Employees Pagination
	 */
	@PostMapping("/allEmpExit/page")
	public ResponseEntity<ResponseDTO> getAllEmpExitDetails(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {

			Map<String, Object> data = service.getAllEmpExitDetails(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					AES.decryptUrl(companyId));
			if (data.isEmpty()) {
				logger.info("Exit form  record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Exit form found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding EmployeeExit:{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This method is used to deleting the ExitMgmt record based on ExitId
	 * 
	 * @param ExitId
	 * @return This method is used to deleting the ExitMgmt record based on ExitId
	 */
	@DeleteMapping("/delete/{exitId}")
	public ResponseEntity<ResponseDTO> deleteExitRecordBasedOnExitId(@PathVariable String exitId) {
		Long data = Long.parseLong(AES.decryptUrl(exitId));
		try {

			List<EntityDTO> deleted = service.deleteEmployeeExitRecordByExitId(data);
			if (deleted.isEmpty()) {
				logger.info("EmployeeExit recored failed to delete with exitId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("EmployeeExit recored Successfully deleted");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, null),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting EmployeeExit with exitId:{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This method is used to save the SubjectiveAndObjectiveQuestion Details
	 * 
	 * @param model
	 * @return This method is used to save theSubjectiveAndObjectiveQuestion Details
	 */
	@PostMapping(value = "/saveSubjAndObjQuestions", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addSubjectiveAndObjectiveQuestion(@Valid @RequestBody QuestionsDTO model,
			@RequestHeader(value = "companyId") String companyId) {
		try {
			List<EntityDTO> saveSubjectiveAndObjectiveQuestion = service.saveSubjectiveAndObjectiveQuestion(model,
					AES.decryptUrl(companyId));
			if (saveSubjectiveAndObjectiveQuestion.isEmpty()) {
				logger.info("All details has been failed to save");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("  All details has been successfully saved");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, saveSubjectiveAndObjectiveQuestion),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding  All details ExitRecordQuestion :{}", e);
			e.printStackTrace();
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This method is used to get all ExitRecordQuestions list
	 * 
	 * @return This method is used to get all ExitRecordQuestions list
	 */
	@GetMapping("/AllExitRecordQuestions")
	public ResponseEntity<ResponseDTO> getAllExitRecordQuestions(@RequestHeader(value = "companyId") String companyId) {
		try {

			QuestionsDTO allEmpExitDetails = service.getAllExitRecordQuestions(AES.decryptUrl(companyId));
			if (Objects.isNull(allEmpExitDetails)) {
				logger.info("ExitRecordQuestions failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("All ExitRecordQuestions found");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, allEmpExitDetails),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Error while finding ExitRecordQuestions:{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}

	}

	/**
	 * This method is used to save the Employee Resignation Details
	 * 
	 * @param model
	 * @return This method is used to save the Employee Resignation Details
	 */
	@PostMapping(value = "/emp/resignation", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addResignation(@Valid @RequestBody ResignationDTO model) {
		try {

			List<EntityDTO> saveEmployeeResignation = service.saveEmployeeResignation(model);
			if (saveEmployeeResignation.isEmpty()) {
				logger.info("Employee Resigntaion failed to add");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("Employee Resignation Added successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, saveEmployeeResignation),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while adding EmployeeResignation:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	@GetMapping(value = "/emp/resignationTable/{employeeId}")
	public ResponseEntity<ResponseDTO> getResignationDetails(@PathVariable String employeeId) {
		try {
			Long data = Long.parseLong(AES.decryptUrl(employeeId));
			ResignationDTO resignationDto = service.findResignedEmpByEmployee(data);
			if (resignationDto == null) {
				logger.info("Applied resigned Employee failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.info("Applied resigned Employee found to show");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE, resignationDto),
						HttpStatus.OK);
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while finding applied resigned Employee :{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	/**
	 * This Method is used to show all Employees Pagination
	 * 
	 * @param pagingDto
	 * @return This Method is used to show all Resigned Employees Pagination
	 */
	@PostMapping("/allEmpResignation/page")
	public ResponseEntity<ResponseDTO> getAllEmpResignationDetails(@RequestBody PaginationDTO pagingDto,
			@RequestHeader(value = "companyId") String companyId) {
		try {

			Map<String, Object> data = service.getAllEmpResignationDetails(pagingDto.getPageIndex(),
					pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(),
					AES.decryptUrl(companyId), pagingDto.getManagerId());
			if (data.isEmpty()) {
				logger.info("Resignation employee  record is not avaliable");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Resignation employees records found");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while finding EmployeeResignation:{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	@PutMapping(value = "/resignationFormEdit", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateResignation(@Valid @RequestBody ResignationDTO model) {
		try {

			List<EntityDTO> updateEmployeeResignation = service.updateEmployeeResignation(model);
			if (updateEmployeeResignation.isEmpty()) {
				logger.info("Employee Resigntaion failed to update");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("Employee Resignation updated successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, updateEmployeeResignation),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while updating EmployeeResignation:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	@GetMapping("/getResignationStatus/{empId}")
	public ResponseEntity<ResponseDTO> getReportingManagerApprovalStatus(@PathVariable String empId) {
		try {
			Long data = Long.parseLong(AES.decryptUrl(empId));

			String resignationStatus = service.getResignationStatus(data);
			if (resignationStatus.equals(Constants.EXIT_PROCESS)) {
				logger.info("Employee  ReportingManager Status  found to show");
				return new ResponseEntity<>(new ResponseDTO(Constants.TRUE, Constants.TRUE, true), HttpStatus.CREATED);
			} else {
				logger.info("Employee  ReportingManager Status failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.TRUE, Constants.TRUE, false), HttpStatus.OK);

			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while finding Employee  ReportingManager Status :{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT_RM_STATUS);
		}

	}

	@PutMapping(value = "/resignationFormRevoke", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> revokeResignation(@Valid @RequestBody ResignationDTO model) {
		try {

			List<EntityDTO> revokeEmployeeResignation = service.revokeEmployeeResignation(model);
			if (revokeEmployeeResignation.isEmpty()) {
				logger.info("Employee Resigntaion failed to revoke");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("Employee Resignation revoked successfully");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, revokeEmployeeResignation),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while revoking EmployeeResignation:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

	@GetMapping("/getResignationSubmitted/{empId}")
	public ResponseEntity<ResponseDTO> getResignationSubmitted(@PathVariable String empId) {
		try {
			Long data = Long.parseLong(AES.decryptUrl(empId));

			Resignation resignationStatus = service.getResignationSubmitted(data);
			if (resignationStatus == null || resignationStatus.getStatus().equals(Constants.REVOKE_APPROVED)) {
				logger.info("Employee  Resignation Status failed to load");
				return new ResponseEntity<>(new ResponseDTO(Constants.TRUE, Constants.TRUE, Boolean.FALSE),
						HttpStatus.OK);

			} else {
				logger.info("Employee  Resignation Status  found to show");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, Boolean.TRUE),
						HttpStatus.CREATED);
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while finding Employee  ReportingManager Status :{}", e);
			throw new NotFoundException(Constants.NOT_EXECUTED + " " + Constants.EMPLOYEE_EXIT);
		}

	}
	
	@PutMapping(value = "/resigFormEditByMngrAfterRevokeApply", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateResignationAfterRevoke(@Valid @RequestBody ResignationDTO model) {
		try {

			List<EntityDTO> updateResigAfterRevokeApply = service.updateResigAfterRevokeApply(model);
			if (updateResigAfterRevokeApply.isEmpty()) {
				logger.info("Employee Resigntaion failed to update after revoke applied");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			} else {

				logger.info("Employee Resignation updated successfully after revoke applied");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, updateResigAfterRevokeApply),
						HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while updating EmployeeResignation after revoke applied:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.EMPLOYEE_EXIT);
		}
	}

}
