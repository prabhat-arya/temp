package com.hrms.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.CompanyDTO;
import com.hrms.admin.dto.CompanyRegisterDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.CompanyService;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Company Record
 * 
 * @author {Benarji}
 *
 */
@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_COMPANY)
public class CompanyController {
	private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);

	@Autowired
	private CompanyService service;

	@Autowired
	private EmployeeService employeeService;

	/**
	 * Returns status code when new Company is created
	 * 
	 * @param model - new Company data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody CompanyDTO model) {

		try {
			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Company Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<CompanyDTO> save = service.save(model);
				if (!save.isEmpty()) {
					logger.info("Company inserted");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, save),
							HttpStatus.CREATED);
				} else {
					logger.info("Company failed to add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while creating Company:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Returns status code when existing Company data is updated
	 * 
	 * @param model - new Company data
	 * @param id    - Company Id
	 * @return - ResponseEntity
	 * @throws Exception
	 * @throws JsonMappingException
	 */
	@PutMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<ResponseDTO> update(@RequestPart String company,
			@RequestPart(required = false) MultipartFile image) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		CompanyDTO model = mapper.readValue(company, CompanyDTO.class);
		try {
			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("Company Already Exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				service.saveCompanyImage(image, model.getId());
				List<EntityDTO> updateCompany = service.updateCompany(model);

				if (!updateCompany.isEmpty()) {
					logger.info("Company updated successfully");
					return new ResponseEntity<>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, updateCompany), HttpStatus.OK);
				} else {
					logger.info("Company Updation failed");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating company:{}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Returns Company and status code when Company data is available by id
	 * 
	 * @param id - Company Id
	 * @return - ResponseEntity
	 */

	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id) {

		String data = AES.decryptUrl(id);
		try {
			CompanyDTO companyById = service.getById(data);
			if (companyById == null) {
				logger.info("Company not found with companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				List<CompanyDTO> list = new ArrayList<>();
				list.add(companyById);
				logger.info("Company found with companyId:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting company:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Returns All Company data when Company data is available
	 * 
	 * @return - List of CompanyModel
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		try {
			Map<String, Object> data = service.getAllCompany(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					AES.decryptUrl(companyId));
			if (data.isEmpty()) {
				logger.info("Company not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Company found:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Company:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Returns All company data when company data is available
	 * 
	 * @return - List of company
	 */
	@GetMapping("/list")
	public ResponseEntity<ResponseDTO> companys(@RequestHeader String companyId) {
		String cmpId = AES.decryptUrl(companyId);
		try {
			List<CompanyDTO> allCompany = service.AllCompany(cmpId);
			if (!allCompany.isEmpty()) {
				logger.info("Found all Company Records");
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allCompany), HttpStatus.OK);
			} else {
				logger.info("Company records not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Company Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Soft delete
	 * 
	 * @param id - company Id
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteCompany(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> companyList = service.softDeleteCompany(dto.getId());
			if (!companyList.isEmpty()) {
				logger.info("Company soft deleted with companyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, companyList),
						HttpStatus.OK);
			} else {
				logger.info("Company not soft deleted with companyId:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while soft deleting company by CompanyId:{} : {}", dto.getId(), e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Update company by status
	 * 
	 * @param id  - company Id
	 * @param Map object
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateCompanyByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> assetsList = service.updateCompanyByStatus(status.getId(), status.getStatus());
			if (!assetsList.isEmpty()) {
				logger.info("Company Upadted With id: " + "", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, assetsList),
						HttpStatus.OK);
			} else {
				logger.info("Error while deactiving Company by Id: " + "", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Company Status by Id: " + status.getId() + "; " + "", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.COMPANY);
		}
	}

	/**
	 * Based on company update image
	 * 
	 * @author Kamesh Based on company update image
	 * @param id
	 * @param file
	 * @return ResponseDTO
	 * @throws IOException
	 */

	@PutMapping(value = "/companyImage/{id}")
	public ResponseEntity<ResponseDTO> companyImageUpload(@PathVariable String id,
			@RequestParam("file") MultipartFile file) throws IOException {

		String data = AES.decryptUrl(id);
		try {
			List<EntityDTO> imageStatus = service.saveCompanyImage(file, data);
			if (!imageStatus.isEmpty()) {
				logger.info("Company image uploading With id: " + "", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, imageStatus),
						HttpStatus.OK);
			} else {
				logger.info("Error while uploading Company image by Id: " + "", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while uploading Company image by Id: " + data + "; " + "", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + "CompanyImage");
		}
	}

	/**
	 * returns Multi delete
	 * 
	 * @param ids
	 * @return ResponseEntity
	 * @throws IOException
	 */
	@PostMapping(value = "/delete-all", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> multipleDelete(@RequestBody List<Long> ids) throws IOException {
		try {
			List<EntityDTO> deleteStatus = service.multipleCompanyDelete(ids);
			if (!deleteStatus.isEmpty()) {
				logger.info("Company Records are delete With Multiple ids: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, deleteStatus),
						HttpStatus.OK);
			} else {
				logger.info("Error while deleting Company by multiple Ids: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while deleting Company by multiple Ids: " + "", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.COMPANY);
		}
	}

	@PostMapping(path = "/register", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody CompanyRegisterDTO model) {

		try {

			boolean isExists = service.validateCompanyRegister(model, true);
			if (isExists) {
				logger.info("Company record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			}
			boolean isExists1 = service.validateCompanyEmail(model, true);
			if (isExists1 || employeeService.validateEmployeeEmail(model.getEmail()) != 0L
					|| employeeService.validateEmployeeOfficalEmail(model.getEmail()) != 0L) {
				logger.info("Company Email record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.COMPANY_EMAIL, Constants.FALSE), HttpStatus.OK);
			}
			boolean isExists2 = service.validateCompanyUserName(model, true);
			if (isExists2 || employeeService.validateEmployeeUserNmae(model.getUserName()) != 0L) {
				logger.info("Company username record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.COMPANY_USER, Constants.FALSE), HttpStatus.OK);
			}
			boolean isExists3 = service.validateCompanyContactNo(model, true);
			if (isExists3 || employeeService.validateEmployeeContact(model.getMobileNo()) != 0L) {
				logger.info("Company Contact No record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.COMPANY_CONTACT, Constants.FALSE), HttpStatus.OK);
			}
			boolean isExists4 = service.validateCompanyName(model, true);
			if (isExists4) {
				logger.info("Company Name record is Already exist");
				return new ResponseEntity<>(new ResponseDTO(Constants.COMPANY_NAME, Constants.FALSE), HttpStatus.OK);
			}

			Map<String, String> saveUser = service.companyRegister(model);
			if (!saveUser.isEmpty()) {
				logger.info("Company record is inserted");
				return new ResponseEntity<>(new ResponseDTO(Constants.PAGE_LIST, Constants.TRUE, saveUser),
						HttpStatus.CREATED);
			} else {
				logger.info("Company failed to insert");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while adding Company:{}", e.getMessage());
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.COMPANY);
		}
	}
}
