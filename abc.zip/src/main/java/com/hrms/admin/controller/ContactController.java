package com.hrms.admin.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.ContactUSDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.service.ContactUSService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@CrossOrigin
@RequestMapping(URLConstants.ADMIN_CONTACT)
public class ContactController {

	@Autowired
	private ContactUSService contactService;

	private static final Logger logger = LoggerFactory.getLogger(ContactController.class);

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> addContact(@RequestBody ContactUSDTO model) {
		try {
			EntityDTO contact = contactService.save(model);
			
			if (contact == null) {
				logger.info("Contact fail to insert");
				return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
						HttpStatus.OK);
			} else {
				logger.info("Contact record is inserted");
				return new ResponseEntity<>(
						new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, contact),
						HttpStatus.CREATED);
			}
		}
		catch (Exception e) {
			logger.error("Error while storing Contact record:{}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + Constants.CONTACT);
		}
	}
	}
