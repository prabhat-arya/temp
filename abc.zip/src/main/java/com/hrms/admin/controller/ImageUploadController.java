package com.hrms.admin.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.ImageUploadUtil;
import com.hrms.admin.util.URLConstants;

@RestController
@RequestMapping(URLConstants.IMAGE)
public class ImageUploadController {

	private static final Logger logger = LoggerFactory.getLogger(ImageUploadController.class);
	@Autowired
	private ImageUploadUtil imageUploadUtil;

	/**
	 * Can update employee profile image
	 * 
	 * @param image
	 * @param type
	 * @return can update employee profile image
	 */
	@PostMapping(value = "/imageUpload/{type}", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseDTO> updateEmployeeProfileImage(@RequestPart MultipartFile image,
			@PathVariable String type) {

		try {
			imageUploadUtil.uploadFile(image, type);
			logger.info("image uploaded successfully");
			return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.IMAGE_UPLOAD);
		}
	}

	/**
	 * Image upload in employee profile
	 * 
	 * @param files
	 * @return image upload in employee profile
	 *//*
		 * @PostMapping(value = "/upload", consumes = { "multipart/form-data" }) public
		 * ResponseEntity<ResponseDTO> imageUpload(@RequestParam("files")
		 * MultipartFile[] files) { try { String imageStatus =
		 * imageUploadUtil.mailImageUpload(files); if (!imageStatus.equals("Exception"))
		 * { logger.info("mail image uploaded"); return new ResponseEntity<>(new
		 * ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, imageStatus),
		 * HttpStatus.OK); } else { logger.info("mail image not uploaded"); return new
		 * ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.TRUE),
		 * HttpStatus.OK); } } catch (Exception e) {
		 * logger.debug("while mail image uploading exception:{}", e.getMessage());
		 * throw new NotUpdatedException(Constants.UPLOAD_ERROR + " " +
		 * Constants.MAIL_IMAGE); } }
		 * 
		 * @GetMapping("/files/{name}") public ResponseEntity<byte[]>
		 * getFile(@PathVariable String name) { MailImages fileDB =
		 * imageUploadUtil.getFile(name); return
		 * ResponseEntity.ok().header(Constants.CONTENT_DISPOSITION,
		 * "attachment; filename=" + fileDB.getFullFileName()) .body(fileDB.getImage());
		 * }
		 */
}
