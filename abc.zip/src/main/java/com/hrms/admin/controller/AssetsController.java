package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.AssetsDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.AssetsService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Assets Record
 * 
 * @author {Suresh}
 *
 */

@RestController
@RequestMapping(URLConstants.ADMIN_ASSETS)
@CrossOrigin
public class AssetsController {
	private static final Logger logger = LoggerFactory.getLogger(AssetsController.class);
	@Autowired
	private AssetsService assetsService;

	/**
	 * Returns status code when new Assets is created
	 * 
	 * @param model - new assets data
	 * @return - ResponseEntity
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@RequestBody AssetsDTO model) {

		try {
			boolean isExists = assetsService.validate(model, true);
			if (isExists) {
				logger.info("Assets record is Already exist");

				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> assetsList = assetsService.save(model);
				if (!assetsList.isEmpty()) {
					logger.info("Assets record is inserted: {}", model.getName());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, assetsList),
							HttpStatus.CREATED);
				} else {
					logger.info("Assets failed to Add");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while adding Assets: {}", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.ASSETS);
		}
	}

	/**
	 * Returns status code when existing assets data is updated
	 * 
	 * @param model - new assets data
	 * @param id    - assetsId
	 * @return - ResponseEntity
	 */

	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@RequestBody AssetsDTO model) {

		try {

			boolean isExists = assetsService.validate(model, false);
			if (isExists) {
				logger.info("Assets Already existed");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);

			} else {

				List<EntityDTO> assetsList = assetsService.updateAssets(model);
				if (!assetsList.isEmpty()) {
					logger.info("Assets is updated");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, assetsList),
							HttpStatus.OK);
				} else {
					logger.info("Assets is not updated");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Assets: {}", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.ASSETS);
		}
	}

	/**
	 * Returns assets and status code when assets data is available by id
	 * 
	 * @param id - assetsId
	 * @return - ResponseEntity
	 */

	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));
		companyId=AES.decryptUrl(companyId);
		try {
			AssetsDTO assetById = assetsService.getById(data, companyId);
			if (assetById == null) {
				logger.info("Assets Not found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			} else {
				List<AssetsDTO> list = new ArrayList<>();
				list.add(assetById);
				logger.info("Assets found with Id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Assets by Id:{}", data + " : " + e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSETS);
		}
	}

	/**
	 * Get all Assets based on CompanyId
	 * 
	 * @param id
	 * @param get all Assets based on CompanyId
	 * @return - ResponseEntity with Respective status Code
	 */

	@GetMapping("/list/{id}")
	public ResponseEntity<ResponseDTO> allAssetsByCompanyId(@PathVariable String id) {
		String data = AES.decryptUrl(id);
		try {
			List<AssetsDTO> allAsset = assetsService.AllAssets(data);
			if (!allAsset.isEmpty()) {
				logger.info("Found {} : {} ", allAsset.size(), Constants.ASSETS);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, allAsset), HttpStatus.OK);
			} else {
				logger.info("Assets Record not found with id:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Assets Record:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSETS);
		}
	}

	/**
	 * Soft delete assets
	 * 
	 * @param id - AssetsId
	 * @return - ResposeEntity
	 */
	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteAssets(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> assetsList = assetsService.softDeleteAssets(dto.getId());
			if (!assetsList.isEmpty()) {
				logger.info("Assets Soft Deleted With id:{} ", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, assetsList),
						HttpStatus.OK);
			} else {
				logger.info("Assets Not Soft Deleted With id:{}", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Soft Deleting Assets  by Id:{} ", dto.getId() + " : " + e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.ASSETS);
		}
	}

	/**
	 * Returns assetsId and status code when assets data is available by id
	 * 
	 * @param id - assetsId
	 * @return - ResponseEntity
	 */

	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		companyId=AES.decryptUrl(companyId);
		try {
			Map<String, Object> data = assetsService.getAllAssets(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					companyId);
			if (data.isEmpty()) {
				logger.info("Assets not found");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE, null), HttpStatus.OK);
			} else {
				logger.info("Assets found:{}", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Assets:{}", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ASSETS);
		}

	}

	/**
	 * pdate assects by status
	 * 
	 * @param id  - assets Id
	 * @param Map object
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/status", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateAssetsByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> assetsList = assetsService.updateAssetsByStatus(status.getId(), status.getStatus());
			if (!assetsList.isEmpty()) {
				logger.info("Assets Updated With id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, assetsList),
						HttpStatus.OK);
			} else {
				logger.info("Assets not found by Id:{}", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Assets Status by Id:{}", status.getId() + " : " + e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.ASSETS);
		}
	}

}
