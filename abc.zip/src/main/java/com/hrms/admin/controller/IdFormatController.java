package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.IdFormatDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.IdFormatService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@RestController
@RequestMapping(URLConstants.ADMIN_IDGENERATION)
public class IdFormatController {
	
	private static final Logger logger = LoggerFactory.getLogger(IdFormatController.class);
	
	@Autowired
	private IdFormatService service;
	
	/** 
	 * save method
	 * @param model
	 * @return save method
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@RequestBody IdFormatDTO model) {
		try {
			
			List<EntityDTO> list = service.saveIdFormat(model);
				if (!list.isEmpty()) {
					logger.debug("Idformat added to insert :: ");
					return new ResponseEntity<ResponseDTO>(
							new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE,list),
							HttpStatus.CREATED);
				} else {
					logger.debug("Idformat record is failed to add :: "+model.getCompName());
					return new ResponseEntity<ResponseDTO>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE),
							HttpStatus.BAD_REQUEST);
				}
			}
		 catch (Exception e) {
				logger.error("Error while storing Idformat record :: " + e);
				throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.ID_FORMAT);
		}
	}
	
	/**
	 * update method
	 * @param model
	 * @param customEmpId
	 * @return update method
	 */
	@PutMapping(value = "/{customEmpId}")
	public ResponseEntity<ResponseDTO> update(@RequestBody IdFormatDTO model, @PathVariable Long customEmpId) {

		try {
			List<EntityDTO> list = service.updateIdFormat(model, customEmpId);
			if (!list.isEmpty()) {
				logger.debug("Idformat record is updated with id :: "+model.getCustomEmpId());
					return new ResponseEntity<ResponseDTO>(
							new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE,list),
							HttpStatus.OK);
				} else {
					logger.debug("Idformat fail to update :: ");
					return new ResponseEntity<ResponseDTO>(
							new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE),
							HttpStatus.BAD_REQUEST);
				}
			}catch (Exception e) {
				logger.error("Error while updating Idformat :: " + e);
				throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.ID_FORMAT);
		}
	}
	
	/**
	 * getting records from database based on employeeId
	 * @param customEmpId
	 * @return getting records from database based on employeeId
	 */
	@GetMapping("/{customEmpId}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable Long customEmpId) {

		try {
			IdFormatDTO findByCustomEmpIdGeneration = service.findByIdFormat(customEmpId);
			if(!Objects.isNull(findByCustomEmpIdGeneration)) {
				logger.debug("Idformat find with ID = " + customEmpId + " " + customEmpId);
				return new ResponseEntity<ResponseDTO>(
						new ResponseDTO(Constants.EXECUTED_SUCCESSFULLY, Constants.TRUE,findByCustomEmpIdGeneration),
						HttpStatus.OK);
			}else {
				logger.debug("No Data while getting Job by Id :: " + customEmpId);
				return new ResponseEntity<ResponseDTO>(
						new ResponseDTO(Constants.GET_FAIL, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			logger.error("Error while getting Idformat by Id :: " + customEmpId + e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.ID_FORMAT);
		}
	}
	
	/**
	 * Remove records from database based on employeeId
	 * @param customEmpId
	 * @return Remove records from database based on employeeId
	 */
	@DeleteMapping(value = "/{customEmpId}")
	public ResponseEntity<ResponseDTO> deleteById(@PathVariable Long customEmpId) {

		try {
			boolean deleteCustomEmpIdGeneration = service.deleteIdFormat(customEmpId);
			if(deleteCustomEmpIdGeneration==true) {
				logger.debug("Idformat  Deleted With id::" + customEmpId);
				return new ResponseEntity<ResponseDTO>(
						new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE),
						HttpStatus.OK);
			}else {
				logger.debug("failed to Delete With id::" + customEmpId);
				return new ResponseEntity<ResponseDTO>(
						new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			logger.error("Error while  Deleting Idformat by Id =" + customEmpId+" "+e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.ID_FORMAT);
		}
	}
	
	
	

}
