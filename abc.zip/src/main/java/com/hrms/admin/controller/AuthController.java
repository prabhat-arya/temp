package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PasswordDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ResultDTO;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.JwtToken;
import com.hrms.admin.exceptions.LockedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.jwt.payload.request.LoginRequest;
import com.hrms.admin.jwt.payload.response.JwtResponse;
import com.hrms.admin.jwt.security.jwt.JwtUtils;
import com.hrms.admin.jwt.security.services.UserDetailsImpl;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.JwtTokenRepo;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.role.dto.EmployeeIdsDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.service.EmployeeLoginService;
import com.hrms.admin.service.MenuService;
import com.hrms.admin.service.impl.RoleTestJsonService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmployeeServiceUtil;
import com.hrms.admin.util.FieldsValidation;
import com.hrms.admin.util.URLConstants;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(URLConstants.ADMIN_AUTH)
public class AuthController {

	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	EmployeeRepository userRepository;

	@Autowired
	RolesRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	MenuService menuService;
	@Autowired
	private FieldsValidation validateUtil;
	@Value("${reset.url.link}")
	private String resetPwdLink;

	@Value("${onpassive.app.jwtSecret}")
	private String jwtSecret;

	@Autowired
	private EmployeeLoginService loginService;

	@Autowired
	private JwtTokenRepo jwtRepo;

	@Autowired
	private RoleTestJsonService roleTestService;

	@Value("${page.redirect.link}")
	private String redirectPage;

	@Autowired
	private EmployeeServiceUtil employeeServiceUtil;

	private Employee dbUser;

	@Autowired
	private EmpLeaveRepository empLeaveRepo;

	/**
	 * Login Request
	 * 
	 * @param id - loginRequest
	 * @return - User authentication
	 */
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest,
			HttpServletRequest request) {

		// System.out.println("Encrypted Password :
		// "+AES.encodeKey(loginRequest.getPassword()));
		try {

			dbUser = loginService.getUserByUserName(loginRequest.getUsername());
			if (dbUser.getIsLock() >= Constants.MAX_FAILED_ATTEMPTS) {
				return new ResponseEntity<>(new ResponseDTO(Constants.ACCOUNT_LOCK, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
			if(loginRequest.getOtp() != null) {

				if ( AES.decryptLoginPwd(loginRequest.getOtp()) != null) {
					EmpLeave empLeaveByPassCode = empLeaveRepo.getEmpLeaveByPassCode(AES.decryptLoginPwd(loginRequest.getOtp()));
					if (  AES.decryptLoginPwd(loginRequest.getOtp()).length() != 4) {
						return new ResponseEntity<>(new ResponseDTO(Constants.INVALID_PASSCODE, Constants.FALSE),
								HttpStatus.BAD_REQUEST);
					}
					if (Objects.isNull(empLeaveByPassCode)) {
						return new ResponseEntity<>(new ResponseDTO(Constants.INVALID_PASSCODE, Constants.FALSE),
								HttpStatus.BAD_REQUEST);
					}else {
						if(! AES.decryptLoginPwd(loginRequest.getOtp()).equals(empLeaveByPassCode.getLeavePasscode())) {
							return new ResponseEntity<>(new ResponseDTO(Constants.INVALID_PASSCODE, Constants.FALSE),
									HttpStatus.BAD_REQUEST);
						}
					}
				}
			}
			Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
					loginRequest.getUsername(), AES.decryptLoginPwd(loginRequest.getPassword())));

			SecurityContextHolder.getContext().setAuthentication(authentication);
			String jwt = jwtUtils.generateJwtToken(authentication);
			if (dbUser.getIsLock() != Constants.DEFAULT_FAILED_ATTEMPTS) {
				loginService.isLockZero(loginRequest.getUsername());
			}

			UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
			List<String> roles = userDetails.getAuthorities().stream().map(item -> item.getAuthority())
					.collect(Collectors.toList());
			String roleName = roles.get(0);

			jwtUtils.saveUserBrowserDetails(request, jwt, userDetails.getUsername());

			String name = "100x100";
			ProfileImageDTO profileImage = employeeServiceUtil.copyProfileImage(userDetails.getId(), name);
			List<MenuSortingDTO> menuSorting;
			EmployeeRoles findRoleByCompany = roleRepository.findRoleByCompany(roleName, dbUser.getCompany().getId());
			if (!Objects.isNull(findRoleByCompany)) {
				menuSorting = roleTestService.getRoleById(findRoleByCompany.getRoleId()).getMenuSorting();
			} else {
				List<EmployeeRoles> findRoleByCompany1 = roleRepository.findByName(roleName);
				menuSorting = roleTestService.getRoleById(findRoleByCompany1.get(0).getRoleId()).getMenuSorting();
			}

			return new ResponseEntity<>(new ResponseDTO(Constants.LOGIN_SUCCESS, Constants.TRUE,

					new JwtResponse(jwt, userDetails.getId(), userDetails.getUsername(), userDetails.getFirstName(),
							userDetails.getLastName(), userDetails.getEmail(), userDetails.getCompanyId(),
							// userDetails.getBranchId(), roles, roleService.getRoles(roles)
							userDetails.getBranchId(), roles, menuSorting, // sortedMenus(roleName)//roleService.getRoles(roles)
							profileImage)),
					HttpStatus.OK);

		} catch (NotFoundException e) {

			e.printStackTrace();
			return new ResponseEntity<>(new ResponseDTO(Constants.LOGIN_FILURE, Constants.FALSE, null),
					HttpStatus.BAD_GATEWAY);
		} catch (Exception e) {

			e.printStackTrace();
			Employee dbUser = loginService.getUserByUserName(loginRequest.getUsername());

			if (dbUser == null) {
				new ResponseEntity<>(new ResponseDTO(Constants.LOGIN_FILURE, Constants.FALSE, null),
						HttpStatus.BAD_REQUEST);
			} else if (dbUser.getIsLock() < Constants.MAX_FAILED_ATTEMPTS) {
				loginService.increaseFailedAttempts(loginRequest.getUsername());
			} else {
				throw new LockedException("Your account locked due to 3 failed attempts.");
			}
			if (dbUser.getIsLock() == 1) {
				return new ResponseEntity<>(new ResponseDTO(Constants.ACCOUNT_LOCK1, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
			if (dbUser.getIsLock() == 2) {
				return new ResponseEntity<>(new ResponseDTO(Constants.ACCOUNT_LOCK2, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
			if (dbUser.getIsLock() == 3) {
				return new ResponseEntity<>(new ResponseDTO(Constants.ACCOUNT_LOCK, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>(new ResponseDTO(Constants.LOGIN_FILURE, Constants.FALSE, null),
					HttpStatus.BAD_REQUEST);
		}

	}

	/*	*//**
	 * @param id - request
	 * @param id - userName
	 * @return - New password generation
	 *//*
	 * @PostMapping(path = "/forgotPassword")
	 * 
	 * public ResponseEntity<ResponseDTO> resetPassword(HttpServletRequest request,
	 * 
	 * @RequestParam("userName") String userName) throws MailException,
	 * MessagingException {
	 * logger.debug("*************resetPassword Starting***************"); Employee
	 * dbUser = loginService.getUserByUserName(userName); if (dbUser == null) {
	 * logger.info("User not found in the record."); throw new
	 * UserNotFoundException("User not found in the record."); }
	 * 
	 * Employee employee = loginService.createPasswordResetTokenForUser(userName);
	 * String to = dbUser.getEmail(); String link = resetPwdLink + "token=" +
	 * employee.getToken(); mailService.sendForgotMail(to, "Reset your Password",
	 * "Hii,\n\nTo complete the password reset process, please click here:\n" + link
	 * + " " + "\n\nThanks\nHRMS");
	 * logger.info("*************resetPassword mail sent**************"); return new
	 * ResponseEntity<>(new ResponseDTO("reset password mail sent.",
	 * Constants.TRUE), HttpStatus.OK); }
	 */

	/*
	 * @PostMapping(path = "/generateforgotPasswordToken")
	 * 
	 * public ResponseEntity<ResponseDTO> forgotPassword(HttpServletRequest
	 * request, @RequestBody PasswordDTO passwordDTO) throws MailException,
	 * MessagingException {
	 * logger.info("*************forgotPassword Starting***************"); Employee
	 * userByUserEmail = loginService.getUserByUserEmail(passwordDTO.getEmail()); if
	 * (userByUserEmail == null) { logger.info("User not found in the record.");
	 * throw new UserNotFoundException("User not found in the record."); } Employee
	 * createFogotPasswordResetToken =
	 * loginService.createForgotPasswordResetToken(passwordDTO.getEmail()); String
	 * link = resetPwdLink + "token=" + createFogotPasswordResetToken.getToken();
	 * String clicklink = "<a href=" + link +
	 * " style='cursor: pointer;'>Click Here</a> ";
	 * mailService.sendForgotMail(passwordDTO.getEmail(),
	 * "O-Staff Password reset confirmation",
	 * "Hii,\n\n There was recently a request to change the password on your account. If you requested this password change, please click the link below to set a new password within 24 hours:\n"
	 * + clicklink + " " + "\n\nThanks\nHRMS", clicklink);
	 * logger.info("*************Reset Password mail sent***************"); return
	 * new ResponseEntity<>(new ResponseDTO("reset password mail sent.",
	 * Constants.TRUE), HttpStatus.OK); }
	 */

	/*
	 * // From Mail user will get link and temp password and if temp password
	 * available
	 *//**
	 * @param id - token
	 * @return - Password reset
	 */

	/*
	 * @PostMapping("/validateforgotPasswordToken")
	 * 
	 * public ResponseEntity<ResponseDTO> showChangePasswordPage(@Valid @RequestBody
	 * PasswordDTO passwordDto) { String result =
	 * loginService.findtoken(passwordDto.getToken()); if (result != null) {
	 * List<EntityDTO> list =
	 * loginService.validatetTokenAndSavePassword(passwordDto); if
	 * (list.get(0).getName().equals("enter valid password")) { return new
	 * ResponseEntity<>(new ResponseDTO("Provide proper password", Constants.FALSE),
	 * HttpStatus.OK); } if (list.get(0).getName().equals("Password mismatched")) {
	 * return new ResponseEntity<>( new
	 * ResponseDTO("Password doesn't match. Please enter it correctly.",
	 * Constants.FALSE), HttpStatus.OK); } return new ResponseEntity<>(new
	 * ResponseDTO("password reset done sucessfully.", Constants.TRUE, list),
	 * HttpStatus.OK); } else {
	 * logger.info("*************ResetPassword mail sent***************"); return
	 * new ResponseEntity<>(new ResponseDTO("password reset  failed.",
	 * Constants.FALSE),
	 * 
	 * HttpStatus.BAD_REQUEST); } }
	 */

	/*
	 * @GetMapping(value = "/tokenValidate") public String tokenValidate(Model
	 * passwordDTO, @PathParam("token") String token) {
	 * 
	 * String result = loginService.findtoken(token); EntityDTO
	 * validatetTokenAndSavePassword = null; if (result != null) {
	 * logger.info("*************Token Validate done ***************");
	 * validatetTokenAndSavePassword =
	 * loginService.validatetTokenAndSavePassword(token);
	 * passwordDTO.addAttribute("token", token); } return "reset-password"; }
	 */

	/**
	 * @param id - loogedUser
	 * @return - Password reset change password
	 * 
	 */
	@PostMapping("/resetPassword")
	public ResponseEntity<ResponseDTO> changePassword(@Valid @RequestBody PasswordDTO passwordDto) {

		String newPwd = AES.decryptLoginPwd(passwordDto.getNewPassword());
		String confirmPwd = AES.decryptLoginPwd(passwordDto.getConfirmPassword());
		String oldPassword = AES.decryptLoginPwd(passwordDto.getOldPassword());
		Boolean newPassword = validateUtil.validatePassword(newPwd);
		Boolean conformPassword = validateUtil.validatePassword(confirmPwd);

		if (Boolean.FALSE.equals(conformPassword) || Boolean.FALSE.equals(newPassword)) {
			List<ResultDTO> resultlist = new ArrayList<>();
			ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE, Constants.VALID_CHANGE_PASSWORD);
			resultlist.add(result);
			return new ResponseEntity<>(new ResponseDTO(Constants.VALID_CHANGE_PASSWORD, Constants.FALSE, resultlist),
					HttpStatus.OK);
		}
		if (!newPwd.equals(confirmPwd)) {
			return new ResponseEntity<>(
					new ResponseDTO("Passwords doesn't match. Please enter it correctly", Constants.FALSE),
					HttpStatus.OK);
		}

		List<EntityDTO> list = loginService.resetPassword(newPwd, confirmPwd, oldPassword, passwordDto.getLoggedUser());
		if (!list.isEmpty()) {
			if (list.get(0).getName().equals("Old password not matched")) {
				return new ResponseEntity<>(new ResponseDTO("Enter correct password", Constants.FALSE), HttpStatus.OK);
			}
			return new ResponseEntity<>(new ResponseDTO("Password Reset Sucessfully", Constants.TRUE, list),
					HttpStatus.OK);
		} else {
			logger.info("Password reset fail");
			return new ResponseEntity<>(new ResponseDTO("Password Reset Failed", Constants.FALSE),
					HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @param id - request
	 * @return - User Logout
	 */
	@GetMapping("/logout")
	public ResponseEntity<ResponseDTO> logout(HttpServletRequest request) {

		String jwt = parseJwt(request);
		JwtToken jwtToken = new JwtToken();
		try {
			jwtToken.setJwtToken(jwt);
			jwtRepo.save(jwtToken);
			jwtUtils.deleteBrowserDetails(jwt);
			logger.info("****logout***black listed tocken is store in database Tocken is:{} ", jwt);
			return new ResponseEntity<>(new ResponseDTO("Logged out successfully", Constants.TRUE,
					"Tocken is stored in black List table Tocken==>::" + jwt), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("****logout***Error occure while logout time:{}", e);
			return new ResponseEntity<>(
					new ResponseDTO("logout fail", Constants.FALSE, "Error occure while logout time ::" + jwt),
					HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * @param request
	 * @return JWD token generation
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader("Authorization");
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
			logger.info("****logout*** Tocken is claim based on the Logout request");
			return headerAuth.substring(7, headerAuth.length());
		}
		logger.info("****logout*** Tocken is not claim based on the Logout request");
		return null;
	}

	// Every day 12 AM

	@Scheduled(cron = "0 0 0 * * *", zone = "IST")
	public void unlockEmployeeEveryDay() {
		logger.info("inside unlockEmployeeEveryDay inn every day 12 am");
		loginService.unlockEmployeeEveryDay();
	}

	/**
	 * @param employeeIdsDTO
	 */
	@PostMapping("/unlockEmployee")
	public void unlockEmployee(@RequestBody EmployeeIdsDTO employeeIdsDTO) {
		logger.info("inside unlockEmployee id::" + employeeIdsDTO.getEmpIds());
		loginService.unlockEmployee(employeeIdsDTO);
	}
}
