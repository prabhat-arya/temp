package com.hrms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.State;
import com.hrms.admin.service.CityService;
import com.hrms.admin.service.CountryService;
import com.hrms.admin.service.StateService;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

@CrossOrigin
@Controller
@RequestMapping(value = { URLConstants.ADMIN_CASCADE })
public class CascadeController {
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	private CountryService countryService;

	@Autowired
	private StateService stateService;

	@Autowired
	private CityService cityService;

	/**
	 * Getting all countries in database
	 * @return getting all countries in database
	 */
	@GetMapping("/country")
	public ResponseEntity<ResponseDTO> getAll() {
		List<Country> contries = countryService.findAll();
		logger.info("Found:{} {}", contries.size(),Constants.COUNTRIES);
		return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, contries),
				HttpStatus.OK);
	}

	/**
	 * Getting all states based on countryId
	 * @param countryId
	 * @return getting all states based on countryId
	 */
	@GetMapping("/state/{countryId}")
	public ResponseEntity<ResponseDTO> getAllStatesByCountryId(@PathVariable String countryId) {
		Long id = Long.parseLong(AES.decryptUrl(countryId));
		List<State> states = stateService.findByCountry(id);
		logger.info("Found:{} {}",states.size(),Constants.STATES);
		return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, states),
				HttpStatus.OK);
	}

	/**
	 * Getting all cities based on stateId
	 * @param stateId
	 * @return getting all cities based on stateId
	 */
	@GetMapping("/city/{stateId}")
	public ResponseEntity<ResponseDTO> getAllCitiesByStateId(@PathVariable String stateId) {
		Long id = Long.parseLong(AES.decryptUrl(stateId));
		List<City> cities = cityService.findByState(id);
		logger.info("Found: {} {}", cities.size(), Constants.CITIES);
		return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, cities),
				HttpStatus.OK);
	}
	/**@author Manikanta
	 * Getting all countries from json file
	 * @return getting all countries json file
	 */
	@GetMapping("/country/list")
	public ResponseEntity<ResponseDTO> getAllCountries() {
		List<Country> contries = countryService.readCountriesDataFromJson();
		logger.info("Found:{} {}", contries.size(),Constants.COUNTRIES);
		return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, contries),
				HttpStatus.OK);
	}
}