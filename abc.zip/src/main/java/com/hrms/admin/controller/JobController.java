package com.hrms.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.JobDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.StatusDTO;
import com.hrms.admin.exceptions.NotCreatedException;
import com.hrms.admin.exceptions.NotDeletedException;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.exceptions.NotUpdatedException;
import com.hrms.admin.service.impl.JobServiceImpl;
import com.hrms.admin.util.AES;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.URLConstants;

/**
 * Contains method to provide APIs for Department Record
 * 
 * @author {Nikhil}
 *
 */
@RestController
@RequestMapping(URLConstants.ADMIN_JOB)
@CrossOrigin
public class JobController {

	private static final Logger logger = LoggerFactory.getLogger(JobController.class);

	@Autowired
	JobServiceImpl service;

	/**
	 * Returns status code when new job is created
	 * 
	 * @param model - new job data
	 * @return - ResponseEntity
	 */

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> add(@Valid @RequestBody JobDTO model) {

		try {

			boolean isExists = service.validate(model, true);
			if (isExists) {
				logger.info("Job record is Already is exist :: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> joblist = service.save(model);
				if (!joblist.isEmpty()) {
					logger.info("Job added to insert :: ");
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_SUCCESS, Constants.TRUE, joblist),
							HttpStatus.CREATED);
				} else {
					logger.info("Job record is failed to add :: " + "", model.getName());
					return new ResponseEntity<>(new ResponseDTO(Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while storing Job record :: " + "", e);
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.JOB);
		}
	}

	/**
	 * Returns status code when existing job data is updated
	 * 
	 * @param model - new job data
	 * @param id    - job Id
	 * @return - ResponseEntity
	 */

	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> update(@Valid @RequestBody JobDTO model) {

		try {

			boolean isExists = service.validate(model, false);
			if (isExists) {
				logger.info("Job record is Already is exist :: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.OK);
			} else {
				List<EntityDTO> joblist = service.updateJob(model, model.getId());
				if (!joblist.isEmpty()) {
					logger.info("Job record is updated with id :: " + "", model.getId());
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, joblist),
							HttpStatus.OK);
				} else {
					logger.info("Job fail to upadate :: ");
					return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			logger.error("Error while updating Job :: " + "", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.JOB);
		}

	}

	/**
	 * Returns Department and status code when job data is available by id
	 * 
	 * @param id - job Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ResponseDTO> getById(@PathVariable String id, @RequestHeader String companyId) {
		Long data = Long.parseLong(AES.decryptUrl(id));

		try {
			JobDTO jobById = service.getJobByCompanyId(data, AES.decryptUrl(companyId));
			if (jobById != null) {
				List<JobDTO> list = new ArrayList<>();
				list.add(jobById);
				logger.info("Job find with ID = " + "", data, "" + " " + "", jobById);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, list), HttpStatus.OK);
			} else {
				List<JobDTO> list = new ArrayList<>();
				logger.info("No Job Found by Id :: " + "", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.TRUE,list), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting Job by Id :: " + data + "", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.JOB);
		}
	}

	/**
	 * Returns status code when department data is deleted
	 * 
	 * @param id - job id
	 * @return - ResponseEntity
	 */
	@PostMapping(value = "/page", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> getAll(@RequestBody PaginationDTO pagingDto, @RequestHeader String companyId) {
		try {
			Map<String, Object> data = service.getAllJob(pagingDto.getPageIndex(), pagingDto.getPageSize(),
					pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy(), pagingDto.getStatus(),
					AES.decryptUrl(companyId));
			if (data.isEmpty()) {
				logger.info("Job record is not avaliable :: ");
				return new ResponseEntity<>(new ResponseDTO(Constants.NO_LIST, Constants.FALSE, null), HttpStatus.OK);
			} else {
				logger.info("Job founded" + "", data);
				return new ResponseEntity<>(new ResponseDTO(Constants.LIST, Constants.TRUE, data), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting all Job record :: " + "", e);
			throw new NotFoundException(Constants.FINDING_ERROR + " " + Constants.JOB);
		}
	}

	/**
	 * Job update by status
	 * 
	 * @param id  - Job Id
	 * @param Map object
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/jobStatus", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> updateJobByStatus(@RequestBody StatusDTO status) {
		try {
			List<EntityDTO> list = service.updateJobByStatus(status.getId(), status.getStatus());
			if (!list.isEmpty()) {
				logger.info("Job Upadated With id::" + "", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_SUCCESS, Constants.TRUE, list),
						HttpStatus.OK);
			} else {
				logger.info("Job is not available :: " + "", status.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while updating Job Status by Id :: " + "", status.getId(), "" + " " + "", e);
			throw new NotUpdatedException(Constants.UPDATING_ERROR + " " + Constants.JOB);
		}
	}

	/**
	 * Soft delete method
	 * 
	 * @param id - JobId
	 * @return - ResposeEntity
	 */

	@PutMapping(value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseDTO> softDeleteJob(@RequestBody StatusDTO dto) {
		try {
			List<EntityDTO> jobList = service.softDeleteJob(dto.getId());
			if (!jobList.isEmpty()) {
				logger.info("Job Soft Deleted With id::" + "", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_SUCCESS, Constants.TRUE, jobList),
						HttpStatus.OK);
			} else {
				logger.info("Job Not Soft Deleted With id::" + "", dto.getId());
				return new ResponseEntity<>(new ResponseDTO(Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while Soft Deleting Job by Id =" + "", dto.getId(), "" + " " + "", e);
			throw new NotDeletedException(Constants.DELETING_ERROR + " " + Constants.JOB);
		}
	}
}
