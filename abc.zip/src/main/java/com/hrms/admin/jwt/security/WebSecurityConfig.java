package com.hrms.admin.jwt.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;

import com.hrms.admin.jwt.security.jwt.AuthEntryPointJwt;
import com.hrms.admin.jwt.security.jwt.AuthTokenFilter;
import com.hrms.admin.jwt.security.services.UserDetailsServiceImpl;

/*
 * @author Sachin H
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
		// securedEnabled = true,
		// jsr250Enabled = true,
		prePostEnabled = true)

public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	UserDetailsServiceImpl userDetailsService;

	@Autowired
	private AuthEntryPointJwt unauthorizedHandler;

	@Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {
		return new AuthTokenFilter();
	}

	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
		authenticationManagerBuilder.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().disable().exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests()
				// allow anonymous resource requests
				.antMatchers(HttpMethod.GET, "/", "/v2/api-docs", // swagger
						"/webjars/**", // swagger-ui webjars
						"/swagger-resources/**", // swagger-ui resources
						"/configuration/**", // swagger configuration
						"/*.html", "/favicon.ico", "/**/*.html", "/**/*.css", "/**/*.js")
				.permitAll().antMatchers("/admin/auth/**").permitAll().antMatchers("/api/test/**").permitAll()
				.antMatchers("/tokenValidate/**").permitAll().antMatchers("/generateforgotPasswordToken/**").permitAll()
				.antMatchers("/validateforgotPasswordToken/**").permitAll().antMatchers("/templates/**").permitAll()
				.antMatchers("/admin/company/register/**").permitAll().antMatchers("/admin/cascade/country/list/**")
				.permitAll().antMatchers("/image/files/**").permitAll().antMatchers("/admin/payroll/payslip/**")
				.permitAll().antMatchers("/admin/contact/**").permitAll().anyRequest().authenticated();
		// http.csrf().disable();
		http.headers().contentSecurityPolicy("content=\"connect-src 'self' https://ostaffapidev.onpassive.com/ ;"
				+ " font-src 'self' data: https://cdnjs.cloudflare.com/ https://fonts.googleapis.com/ https://fonts.gstatic.com/;"
				+ " img-src 'self' data: https://d12tbw7k1ju33p.cloudfront.net/ ; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com/"
				+ "  https://maxcdn.bootstrapcdn.com/  https://maxcdn.bootstrapcdn.com/ https://fonts.googleapis.com/"
				+ " https://cdn.ckeditor.com/; script-src 'self' 'unsafe-inline' 'unsafe-eval' data: https://apis.google.com https://ajax.googleapis.com/"
				+ " https://canvasjs.com/ https://maxcdn.bootstrapcdn.com/ https://developers.google.com/ ; child-src 'none';"
				+ " frame-src https://www.youtube.com/ https://www.google.com");
		http.headers().cacheControl().disable();
		http.headers().frameOptions().sameOrigin();
		http.headers().httpStrictTransportSecurity().disable();
		http.headers().referrerPolicy(ReferrerPolicy.SAME_ORIGIN);
		http.headers().featurePolicy("geolocation 'self'");
		http.headers().httpStrictTransportSecurity().includeSubDomains(true).maxAgeInSeconds(31536000);
		http.sessionManagement().invalidSessionUrl("/admin/auth/signin");
		http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
	}

}
