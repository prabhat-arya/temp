package com.hrms.admin.jwt.security.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.hrms.admin.entity.UserRequestDetails;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.jwt.security.services.UserDetailsServiceImpl;
import com.hrms.admin.repository.UserRequestDetailsRepo;
import com.hrms.admin.util.Constants;

public class AuthTokenFilter extends OncePerRequestFilter {
	@Autowired
	private JwtUtils jwtUtils;

	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@Autowired
	private UserRequestDetailsRepo userRequestRepo;

	private static final Logger logger = LoggerFactory.getLogger(AuthTokenFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			String jwt = parseJwt(request);
			if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
				String username = jwtUtils.getUserNameFromJwtToken(jwt);
				if (validateUser(jwt, username, request)) {

					UserDetails userDetails = userDetailsService.loadUserByUsername(username);
					UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
							userDetails, null, userDetails.getAuthorities());
					authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(authentication);
				} else {

					throw new NotFoundException("Bad Request Please Logout from other browser");
				}
			}
		} catch (NotFoundException e) {
			logger.error("Accessing user from other browser: {}", e);
		} catch (Exception e) {
			logger.error("Cannot set user authentication: {}", e);
		}

		filterChain.doFilter(request, response);
	}

	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader(Constants.AUTHORIZATION);

		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith(Constants.BEARER)) {
			return headerAuth.substring(7, headerAuth.length());
		}

		return null;
	}

	private boolean validateUser(String jwt, String userName, HttpServletRequest request) {

		UserRequestDetails user = userRequestRepo.findByUserJwtToken(jwt);
		if (user != null && user.getUserBrowserName().equals(request.getHeader(Constants.USER_AGENT))) {
			/*
			 * if(user.getUserPortNumber().equalsIgnoreCase(request.getLocalAddr())) {
			 * 
			 * return true; }
			 */
			return true;
		}
		return false;
	}
}
