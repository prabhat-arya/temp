package com.hrms.admin.jwt.payload.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder
public class JwtResponse {
	
	private String token;
	private String type = "Bearer";
	private Long id;
	private String userName;
	private String firstName;
	private String lastName;
	private String email;
	private List<String> roles;
	private String companyId;
	private Long branchId;
	//private String status;
	private List<MenuSortingDTO> menus;
	//private String message;
	//private List<?> menus;
	
	private ProfileImageDTO image;
	

	

	public JwtResponse(String token, Long id, String userName,String firstName, String lastName, String email,String companyId,Long branchId, List<String> roles,
			List<MenuSortingDTO> menus, ProfileImageDTO image
			//Object role
			) {
		super();
		this.token = token;
		this.id = id;
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.roles = roles;
		this.companyId = companyId;
		this.branchId = branchId; 
		//this.menus = menus;
		this.menus = menus;
		this.image = image;
	}
	
}
