package com.hrms.admin.fileuploaddownload.property;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.BankDetailsErrorRecords;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;
import com.hrms.admin.util.ExcelHeaders;

@Component
public class ErrorRecordsExcel {
	private static final Logger logger = LoggerFactory.getLogger(ErrorRecordsExcel.class);

	/**
	 * 
	 * @param presentList
	 * @return bank Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream bankDetailsErrorRecordsExcel(List<BankDetailsErrorRecords> presentList)
			throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "ACCOUNT_HOLDER_NAME*", "ACCOUNT_NO*", "BANK_NAME*", "IFSCCODE*",
				"BRANCH_NAME*", "CTC*", "UANNUMBER*", "PFNUMBER*", "ESICNUMBER*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Bank Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (BankDetailsErrorRecords bankError : presentList) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(bankError.getEmployeeID());
				if (bankError.getEmployeeID() != null) {
					if (bankError.getEmployeeID().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(bankError.getEmployeeID().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(bankError.getEmployeeID());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(bankError.getAccountHolderName());
				if (bankError.getAccountHolderName() != null) {
					if (bankError.getAccountHolderName().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(bankError.getAccountHolderName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(bankError.getAccountHolderName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(bankError.getAccountNo());
				if (bankError.getAccountNo() != null) {
					if (bankError.getAccountNo().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(bankError.getAccountNo().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(bankError.getAccountNo());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(bankError.getBankName());

				if (bankError.getBankName() != null) {
					if (bankError.getBankName().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(bankError.getBankName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(bankError.getBankName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(bankError.getIfscCode());
				if (bankError.getIfscCode() != null) {
					if (bankError.getIfscCode().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(bankError.getIfscCode().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(bankError.getIfscCode());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(5).setCellValue(bankError.getBranchName());
				if (bankError.getBranchName() != null) {
					if (bankError.getBranchName().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(bankError.getBranchName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(bankError.getBranchName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(6).setCellValue(bankError.getCtc());
				if (bankError.getCtc() != null) {
					if (bankError.getCtc().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(bankError.getCtc().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(bankError.getCtc());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(7).setCellValue(bankError.getUanNumber());
				if (bankError.getUanNumber() != null) {
					if (bankError.getUanNumber().endsWith("*")) {
						Cell cell = row.createCell(7);
						cell.setCellValue(bankError.getUanNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(7);
						cell.setCellValue(bankError.getUanNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(8).setCellValue(bankError.getPfNumber());
				if (bankError.getPfNumber() != null) {
					if (bankError.getPfNumber().endsWith("*")) {
						Cell cell = row.createCell(8);
						cell.setCellValue(bankError.getPfNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(8);
						cell.setCellValue(bankError.getPfNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(9).setCellValue(bankError.getEsicNumber());
				if (bankError.getEsicNumber() != null) {
					if (bankError.getEsicNumber().endsWith("*")) {
						Cell cell = row.createCell(9);
						cell.setCellValue(bankError.getEsicNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(9);
						cell.setCellValue(bankError.getEsicNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}

			workbook.write(out);
			logger.info("bank Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param presentList
	 * @return professional Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream professionalDetailsErrorRecordsExcel(
			List<ProfessionalDetailsErrorRecords> presentList) throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "COMPANY_NAME*", "JOINING_DATE*", "RELIEVING_DATE*", "EXPERIENCE*",
				"CLIENT", "IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Experiance Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (ProfessionalDetailsErrorRecords pdeError : presentList) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(pdeError.getEmployeeId());
				if (pdeError.getEmployeeId() != null) {
					if (pdeError.getEmployeeId().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getCompanyName());
				if (pdeError.getCompanyName() != null) {
					if (pdeError.getCompanyName().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getCompanyName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getCompanyName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getJoiningDate() != null) {
					row.createCell(2).setCellValue(pdeError.getJoiningDate().toString());
				} else {
					row.createCell(2).setCellValue("");
				}
				if (pdeError.getRelievingDate() != null) {
					row.createCell(3).setCellValue(pdeError.getRelievingDate().toString());
				} else {
					row.createCell(3).setCellValue("");
				}
//				row.createCell(4).setCellValue(pdeError.getExperience());
				if (pdeError.getExperience() != null) {
					if (pdeError.getExperience().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getExperience().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getExperience());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(5).setCellValue(pdeError.getClient());

				if (pdeError.getClient() != null) {
					if (pdeError.getClient().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getClient().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getClient());
						cell.setCellStyle(headerCellStyle);
					}
				} else {
					row.createCell(5).setCellValue("");
				}
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}

				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}

			workbook.write(out);
			logger.info("professional Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param presentList
	 * @return employee Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream employeeDetailsErrorRecordsExcel(List<EmployeeErrorRecords> presentList)
			throws IOException {

		String[] BASICDETAILS = { "FIRST_NAME*", "MIDDLE_NAME", "LAST_NAME*", "EMAIL*", "USERNAME*", "DATE_OF_BIRTH*",
				"MARITAL_STATUS*", "MARRIAGE_DAY", "GENDER*", "CONTACT_NO*", "ALTERNATE_CONTACT_NO", "AADHAAR_CARD*",
				"PANCARD*", "VOTER_ID", "PASSPORT_NO", "JOINING_DATE*", "BLOOD_GROUP*", "PERMANENT_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "TEMPORARY_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "COMPANY_NAME*",
				"BRANCH*", "DEPARTMENT*", "DESIGNATION*", "PRIMARY_SKILLS*", "SECONDARY_SKILLS", "MANAGER*", "ROLE*",
				"EMPLOYMENT_TYPE*", "EMPTYPE_START_DATE*", "EMPTYPE_END_DATE*" };

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Basic Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < BASICDETAILS.length; col++) {
				if (BASICDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeErrorRecords empError : presentList) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(empError.getFirstName());
				if (empError.getFirstName() != null) {
					if (empError.getFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(empError.getFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(empError.getFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(empError.getMiddleName());
				if (empError.getMiddleName() != null) {
					if (empError.getMiddleName().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(empError.getMiddleName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(empError.getMiddleName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(empError.getLastName());
				if (empError.getLastName() != null) {
					if (empError.getLastName().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(empError.getLastName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(empError.getLastName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(empError.getEmail());
				if (empError.getEmail() != null) {
					if (empError.getEmail().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(empError.getEmail().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(empError.getEmail());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(empError.getUserName());
				if (empError.getUserName() != null) {
					if (empError.getUserName().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(empError.getUserName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(empError.getUserName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getDateOfBirth() != null) {
					row.createCell(5).setCellValue(empError.getDateOfBirth().toString());
				} else {
					row.createCell(5).setCellValue("");
				}
//				row.createCell(6).setCellValue(empError.getMaritalStatus());
				if (empError.getMaritalStatus() != null) {
					if (empError.getMaritalStatus().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(empError.getMaritalStatus().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(empError.getMaritalStatus());
						cell.setCellStyle(headerCellStyle);
					}
				}

				if (empError.getMarriageDay() != null) {
					row.createCell(7).setCellValue(empError.getMarriageDay().toString());
				} else {
					row.createCell(7).setCellValue("");
				}
//				row.createCell(8).setCellValue(empError.getGender());
				if (empError.getGender() != null) {
					if (empError.getGender().endsWith("*")) {
						Cell cell = row.createCell(8);
						cell.setCellValue(empError.getGender().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(8);
						cell.setCellValue(empError.getGender());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(9).setCellValue(empError.getContactNo());
				if (empError.getContactNo() != null) {
					if (empError.getContactNo().endsWith("*")) {
						Cell cell = row.createCell(9);
						cell.setCellValue(empError.getContactNo().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(9);
						cell.setCellValue(empError.getContactNo());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(10).setCellValue(empError.getAlternateContactNo());
				if (empError.getAlternateContactNo() != null) {
					if (empError.getAlternateContactNo() != null) {
						if (empError.getAlternateContactNo().endsWith("*")) {
							Cell cell = row.createCell(10);
							cell.setCellValue(empError.getAlternateContactNo().replace("*", ""));
							cell.setCellStyle(headerCellStyleSpl);
						} else {
							Cell cell = row.createCell(10);
							cell.setCellValue(empError.getAlternateContactNo());
							cell.setCellStyle(headerCellStyle);
						}
					}
				}
//				row.createCell(11).setCellValue(empError.getAADHAAR_CARD());
				if (empError.getAadharCard() != null) {
					if (empError.getAadharCard().endsWith("*")) {
						Cell cell = row.createCell(11);
						cell.setCellValue(empError.getAadharCard().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(11);
						cell.setCellValue(empError.getAadharCard());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(12).setCellValue(empError.getPanCard());
				if (empError.getPanCard() != null) {
					if (empError.getPanCard().endsWith("*")) {
						Cell cell = row.createCell(12);
						cell.setCellValue(empError.getPanCard().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(12);
						cell.setCellValue(empError.getPanCard());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(13).setCellValue(empError.getVoterID());
				if (empError.getVoterID() != null) {
					if (empError.getVoterID().endsWith("*")) {
						Cell cell = row.createCell(13);
						cell.setCellValue(empError.getVoterID().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(13);
						cell.setCellValue(empError.getVoterID());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(14).setCellValue(empError.getPassportNo());
				if (empError.getPassportNo() != null) {
					if (empError.getPassportNo().endsWith("*")) {
						Cell cell = row.createCell(14);
						cell.setCellValue(empError.getPassportNo().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(14);
						cell.setCellValue(empError.getPassportNo());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getJoiningDate() != null) {
					row.createCell(15).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(15).setCellValue("");
				}
//				row.createCell(16).setCellValue(empError.getBloodGroup());
				if (empError.getBloodGroup() != null) {
					if (empError.getBloodGroup().endsWith("*")) {
						Cell cell = row.createCell(16);
						cell.setCellValue(empError.getBloodGroup().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(16);
						cell.setCellValue(empError.getBloodGroup());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(17).setCellValue(empError.getPermanantAddress());
				if (empError.getPermanantAddress() != null) {
					if (empError.getPermanantAddress().endsWith("*")) {
						Cell cell = row.createCell(17);
						cell.setCellValue(empError.getPermanantAddress().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(17);
						cell.setCellValue(empError.getPermanantAddress());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(18).setCellValue(empError.getPermanantLandmark());
				if (empError.getPermanantLandmark() != null) {
					if (empError.getPermanantLandmark().endsWith("*")) {
						Cell cell = row.createCell(18);
						cell.setCellValue(empError.getPermanantLandmark().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(18);
						cell.setCellValue(empError.getPermanantLandmark());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(19).setCellValue(empError.getPermanantStreet());
				if (empError.getPermanantStreet() != null) {
					if (empError.getPermanantStreet().endsWith("*")) {
						Cell cell = row.createCell(19);
						cell.setCellValue(empError.getPermanantStreet().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(19);
						cell.setCellValue(empError.getPermanantStreet());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(20).setCellValue(empError.getPermanantCity());
				if (empError.getPermanantCity() != null) {
					if (empError.getPermanantCity().endsWith("*")) {
						Cell cell = row.createCell(20);
						cell.setCellValue(empError.getPermanantCity().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(20);
						cell.setCellValue(empError.getPermanantCity());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(21).setCellValue(empError.getPermanantDistrict());
				if (empError.getPermanantDistrict() != null) {
					if (empError.getPermanantDistrict().endsWith("*")) {
						Cell cell = row.createCell(21);
						cell.setCellValue(empError.getPermanantDistrict().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(21);
						cell.setCellValue(empError.getPermanantDistrict());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(22).setCellValue(empError.getPermanantState());
				if (empError.getPermanantState() != null) {
					if (empError.getPermanantState().endsWith("*")) {
						Cell cell = row.createCell(22);
						cell.setCellValue(empError.getPermanantState().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(22);
						cell.setCellValue(empError.getPermanantState());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(23).setCellValue(empError.getPermanantCountry());
				if (empError.getPermanantCountry() != null) {
					if (empError.getPermanantCountry().endsWith("*")) {
						Cell cell = row.createCell(23);
						cell.setCellValue(empError.getPermanantCountry().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(23);
						cell.setCellValue(empError.getPermanantCountry());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(24).setCellValue(empError.getPermanantPincode());
				if (empError.getPermanantPincode() != null) {
					if (empError.getPermanantPincode().endsWith("*")) {
						Cell cell = row.createCell(24);
						cell.setCellValue(empError.getPermanantPincode().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(24);
						cell.setCellValue(empError.getPermanantPincode());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(25).setCellValue(empError.getTemporaryAddress());
				if (empError.getTemporaryAddress() != null) {
					if (empError.getTemporaryAddress().endsWith("*")) {
						Cell cell = row.createCell(25);
						cell.setCellValue(empError.getTemporaryAddress().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(25);
						cell.setCellValue(empError.getTemporaryAddress());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(26).setCellValue(empError.getTemporaryLandmark());
				if (empError.getTemporaryLandmark() != null) {
					if (empError.getTemporaryLandmark().endsWith("*")) {
						Cell cell = row.createCell(26);
						cell.setCellValue(empError.getTemporaryLandmark().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(26);
						cell.setCellValue(empError.getTemporaryLandmark());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(27).setCellValue(empError.getTemporaryStreet());
				if (empError.getTemporaryStreet() != null) {
					if (empError.getTemporaryStreet().endsWith("*")) {
						Cell cell = row.createCell(27);
						cell.setCellValue(empError.getTemporaryStreet().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(27);
						cell.setCellValue(empError.getTemporaryStreet());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(28).setCellValue(empError.getTemporaryCity());
				if (empError.getTemporaryCity() != null) {
					if (empError.getTemporaryCity().endsWith("*")) {
						Cell cell = row.createCell(28);
						cell.setCellValue(empError.getTemporaryCity().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(28);
						cell.setCellValue(empError.getTemporaryCity());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(29).setCellValue(empError.getTemporaryDistrict());
				if (empError.getTemporaryDistrict() != null) {
					if (empError.getTemporaryDistrict().endsWith("*")) {
						Cell cell = row.createCell(29);
						cell.setCellValue(empError.getTemporaryDistrict().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(29);
						cell.setCellValue(empError.getTemporaryDistrict());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(30).setCellValue(empError.getTemporaryState());
				if (empError.getTemporaryState() != null) {
					if (empError.getTemporaryState().endsWith("*")) {
						Cell cell = row.createCell(30);
						cell.setCellValue(empError.getTemporaryState().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(30);
						cell.setCellValue(empError.getTemporaryState());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(31).setCellValue(empError.getTemporaryCountry());
				if (empError.getTemporaryCountry() != null) {
					if (empError.getTemporaryCountry().endsWith("*")) {
						Cell cell = row.createCell(31);
						cell.setCellValue(empError.getTemporaryCountry().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(31);
						cell.setCellValue(empError.getTemporaryCountry());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(32).setCellValue(empError.getTemporaryPincode());
				if (empError.getTemporaryPincode() != null) {
					if (empError.getTemporaryPincode().endsWith("*")) {
						Cell cell = row.createCell(32);
						cell.setCellValue(empError.getTemporaryPincode().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(32);
						cell.setCellValue(empError.getTemporaryPincode());
						cell.setCellStyle(headerCellStyle);
					}
				}
				/*
				 * // row.createCell(33).setCellValue(empError.getPersonDetails1()); if
				 * (empError.getPersonDetails1() != null) { if
				 * (empError.getPersonDetails1().endsWith("*")) { Cell cell =
				 * row.createCell(33);
				 * cell.setCellValue(empError.getPersonDetails1().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(33); cell.setCellValue(empError.getPersonDetails1());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(34).setCellValue(empError.getPd1Relation()); if
				 * (empError.getPd1Relation() != null) { if
				 * (empError.getPd1Relation().endsWith("*")) { Cell cell = row.createCell(34);
				 * cell.setCellValue(empError.getPd1Relation().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(34); cell.setCellValue(empError.getPd1Relation());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(35).setCellValue(empError.getPd1ContactNumber()); if
				 * (empError.getPd1ContactNumber() != null) { if
				 * (empError.getPd1ContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(35);
				 * cell.setCellValue(empError.getPd1ContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(35); cell.setCellValue(empError.getPd1ContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(36).setCellValue(empError.getPd1AaltContactNumber()); if
				 * (empError.getPd1AaltContactNumber() != null) { if
				 * (empError.getPd1AaltContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(36);
				 * cell.setCellValue(empError.getPd1AaltContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(36); cell.setCellValue(empError.getPd1AaltContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(37).setCellValue(empError.getPersonDetails2()); if
				 * (empError.getPersonDetails2() != null) { if
				 * (empError.getPersonDetails2().endsWith("*")) { Cell cell =
				 * row.createCell(37);
				 * cell.setCellValue(empError.getPersonDetails2().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(37); cell.setCellValue(empError.getPersonDetails2());
				 * cell.setCellStyle(headerCellStyle); } }
				 * 
				 * // row.createCell(38).setCellValue(empError.getPd2Relation()); if
				 * (empError.getPd2Relation() != null) { if
				 * (empError.getPd2Relation().endsWith("*")) { Cell cell = row.createCell(38);
				 * cell.setCellValue(empError.getPd2Relation().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(38); cell.setCellValue(empError.getPd2Relation());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(39).setCellValue(empError.getPd2ContactNumber()); if
				 * (empError.getPd2ContactNumber() != null) { if
				 * (empError.getPd2ContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(39);
				 * cell.setCellValue(empError.getPd2ContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(39); cell.setCellValue(empError.getPd2ContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(40).setCellValue(empError.getPd2AaltContactNumber()); if
				 * (empError.getPd2AaltContactNumber() != null) { if
				 * (empError.getPd2AaltContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(40);
				 * cell.setCellValue(empError.getPd2AaltContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(40); cell.setCellValue(empError.getPd2AaltContactNumber());
				 * cell.setCellStyle(headerCellStyle); } }
				 */ // row.createCell(41).setCellValue(empError.getCompanyName());
				if (empError.getCompanyName() != null) {
					if (empError.getCompanyName().endsWith("*")) {
						Cell cell = row.createCell(33);
						cell.setCellValue(empError.getCompanyName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(33);
						cell.setCellValue(empError.getCompanyName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(42).setCellValue(empError.getBranchName());
				if (empError.getBranchName() != null) {
					if (empError.getBranchName().endsWith("*")) {
						Cell cell = row.createCell(34);
						cell.setCellValue(empError.getBranchName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(34);
						cell.setCellValue(empError.getBranchName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(43).setCellValue(empError.getDepartmentName());
				if (empError.getDepartmentName() != null) {
					if (empError.getDepartmentName().endsWith("*")) {
						Cell cell = row.createCell(35);
						cell.setCellValue(empError.getDepartmentName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(35);
						cell.setCellValue(empError.getDepartmentName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(44).setCellValue(empError.getDesignationName());
				if (empError.getDesignationName() != null) {
					if (empError.getDesignationName().endsWith("*")) {
						Cell cell = row.createCell(36);
						cell.setCellValue(empError.getDesignationName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(36);
						cell.setCellValue(empError.getDesignationName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(45).setCellValue(empError.getSkillsList());
				if (empError.getSkillsList() != null) {
					if (empError.getSkillsList().endsWith("*")) {
						Cell cell = row.createCell(37);
						cell.setCellValue(empError.getSkillsList().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(37);
						cell.setCellValue(empError.getSkillsList());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(46).setCellValue(empError.getSecondarySkillsList());
				if (empError.getSecondarySkillsList() != null) {
					if (empError.getSecondarySkillsList().endsWith("*")) {
						Cell cell = row.createCell(38);
						cell.setCellValue(empError.getSecondarySkillsList().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(38);
						cell.setCellValue(empError.getSecondarySkillsList());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(47).setCellValue(empError.getManagar());
				if (empError.getManagar() != null) {
					if (empError.getManagar().endsWith("*")) {
						Cell cell = row.createCell(39);
						cell.setCellValue(empError.getManagar().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(39);
						cell.setCellValue(empError.getManagar());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(48).setCellValue(empError.getRoles());
				if (empError.getRoles() != null) {
					if (empError.getRoles().endsWith("*")) {
						Cell cell = row.createCell(40);
						cell.setCellValue(empError.getRoles().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(40);
						cell.setCellValue(empError.getRoles());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(49).setCellValue(empError.getEmploymentType());
				if (empError.getEmploymentType() != null) {
					if (empError.getEmploymentType().endsWith("*")) {
						Cell cell = row.createCell(41);
						cell.setCellValue(empError.getEmploymentType().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(41);
						cell.setCellValue(empError.getEmploymentType());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getEmpTypeStartDate() != null) {
					row.createCell(42).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(42).setCellValue("");
				}
				if (empError.getEmpTypeEndDate() != null) {
					row.createCell(43).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(43).setCellValue("");
				}
				for (int i = 0; i < BASICDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}
			workbook.write(out);
			logger.info("employee Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param empSuccessList
	 * @return empDetails Success Records Excel Sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream empDetailsSuccessRecordsExcel(List<Employee> empSuccessList) throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID", "FIRST_NAME", "LAST_NAME ", "MAILID", "USERNAME", "PHONE_NUMBER" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Basic Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (Employee emp : empSuccessList) {
				Row row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(emp.getId());
				row.createCell(1).setCellValue(emp.getFirstName());
				row.createCell(2).setCellValue(emp.getLastName());
				row.createCell(3).setCellValue(emp.getEmail());
				row.createCell(4).setCellValue(emp.getUserName());
				row.createCell(5).setCellValue(emp.getContactNo());
				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			logger.info("employee Details Success Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param empDetailsError
	 * @return employee MialId Error Records Excel sheet
	 * @throws Exception
	 */
	public static ByteArrayInputStream employeeMialIdErrorRecordsExcel(List<EmployeeMailErrorRecords> empDetailsError)
			throws Exception {
		String[] COLUMNS = { "EMPLOYEE_ID*", "OFFICAL_MAIL_ID*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Offical MailIDs");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.index);
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.index);
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeMailErrorRecords pdeError : empDetailsError) {
				Row row = sheet.createRow(rowIdx++);
				if (pdeError.getEmployeeId() != null) {
					if (pdeError.getEmployeeId().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getOfficalMailId() != null) {
					if (pdeError.getOfficalMailId().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getOfficalMailId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getOfficalMailId());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(0).setCellValue(pdeError.getEmployeeId());
//				row.createCell(1).setCellValue(pdeError.getOfficalMailId());
				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}
			workbook.write(out);
			logger.info("employee MialId Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return bank Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream bankDetailsErrorRecordsExcelSampleFile() throws IOException {
		String[] BANKDETAILS = { "EMPLOYEE_ID*", "ACCOUNT_HOLDER_NAME*", "ACCOUNT_NO*", "BANK_NAME*", "IFSCCODE*",
				"BRANCH_NAME*", "CTC*", "UANNUMBER*", "PFNUMBER*", "ESICNUMBER*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
//			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Bank Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < BANKDETAILS.length; col++) {
				if (BANKDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BANKDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BANKDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row = sheet.createRow(1);

			row.createCell(0).setCellValue("Employee Id");
			row.createCell(1).setCellValue("Nmae As per Account");
			row.createCell(2).setCellValue("Account No");
			row.createCell(3).setCellValue("Bank Name");
			row.createCell(4).setCellValue("Ifsc Code");
			row.createCell(5).setCellValue("Bank Branch Name");
			row.createCell(6).setCellValue("Employee CTC");
			row.createCell(7).setCellValue("Employee UAN Number");
			row.createCell(8).setCellValue("Employee PF Number");
			row.createCell(9).setCellValue("Employee Esic Number");

			workbook.write(out);
			logger.info("bank details sample Excel file generated:: ");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return empDetails Success Records Excel Sample File
	 * @throws IOException
	 *//*
		 * public static ByteArrayInputStream empDetailsSuccessRecordsExcelSampleFile()
		 * throws IOException { String[] COLUMNS = { "EMPLOYEEID", "FIRSTNAME",
		 * "LASTNAME ", "MAILID", "USERNAME", "PHONENUMBER" }; try (Workbook workbook =
		 * new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();)
		 * { // CreationHelper createHelper = workbook.getCreationHelper();
		 * 
		 * Sheet sheet = workbook.createSheet("Employee Basic Details");
		 * 
		 * Font headerFont = workbook.createFont(); headerFont.setBold(true);
		 * headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
		 * 
		 * CellStyle headerCellStyle = workbook.createCellStyle();
		 * headerCellStyle.setFont(headerFont);
		 * 
		 * // Row for Header Row headerRow = sheet.createRow(0);
		 * 
		 * // Header for (int col = 0; col < COLUMNS.length; col++) { Cell cell =
		 * headerRow.createCell(col); cell.setCellValue(COLUMNS[col]);
		 * cell.setCellStyle(headerCellStyle); }
		 * 
		 * workbook.write(out); logger.info("employee sample Excel file generated");
		 * return new ByteArrayInputStream(out.toByteArray()); } }
		 */
	/**
	 * 
	 * @return emp Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream empDetailsErrorRecordsExcelSampleFile() throws IOException {

		String[] BASICDETAILS = { "FIRST_NAME*", "MIDDLE_NAME", "LAST_NAME*", "EMAIL*", "USERNAME*", "DATE_OF_BIRTH*",
				"MARITAL_STATUS*", "MARRIAGE_DAY", "GENDER*", "CONTACT_NO*", "ALTERNATE_CONTACT_NO", "AADHAAR_CARD*",
				"PANCARD*", "VOTER_ID", "PASSPORT_NO", "JOINING_DATE*", "BLOOD_GROUP*", "PERMANENT_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "TEMPORARY_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "COMPANY_NAME*",
				"BRANCH*", "DEPARTMENT*", "DESIGNATION*", "PRIMARY_SKILLS*", "SECONDARY_SKILLS", "MANAGER*", "ROLE*",
				"EMPLOYMENT_TYPE*", "EMPTYPE_START_DATE*", "EMPTYPE_END_DATE*" };

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			Sheet sheet = workbook.createSheet("Employee Basic Details");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);
			// Row for Header
			Row headerRow = sheet.createRow(0);
			// Header
			for (int col = 0; col < BASICDETAILS.length; col++) {

				if (BASICDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			Row row = sheet.createRow(1);
			row.createCell(0).setCellValue("First Name");
			row.createCell(1).setCellValue("Middle Name");
			row.createCell(2).setCellValue("Last Name");
			row.createCell(3).setCellValue("Ex: user@onpassive.com");
			row.createCell(4).setCellValue("User Name");
			row.createCell(5).setCellValue("dd-MM-yyyy");
			row.createCell(6).setCellValue("Marital Status");
			row.createCell(7).setCellValue("dd-MM-yyyy");
			row.createCell(8).setCellValue("Gender");
			row.createCell(9).setCellValue("Ex: 0000000000");
			row.createCell(10).setCellValue("Ex: 0000000000");
			row.createCell(11).setCellValue("Adheer Card");
			row.createCell(12).setCellValue("Ex: ABCDE1234A");
			row.createCell(13).setCellValue("voter Id");
			row.createCell(14).setCellValue("A0000000");
			row.createCell(15).setCellValue("dd-MM-yyyy");
			row.createCell(16).setCellValue("Ex: O +ve");
			row.createCell(17).setCellValue("Door No/Flat No");
			row.createCell(18).setCellValue("Landmark");
			row.createCell(19).setCellValue("Street Name");
			row.createCell(20).setCellValue("City Name");
			row.createCell(21).setCellValue("District Name");
			row.createCell(22).setCellValue("State Name");
			row.createCell(23).setCellValue("Country Name");
			row.createCell(24).setCellValue("Pin/Zipcode");
			row.createCell(25).setCellValue("Door No/Flat No");
			row.createCell(26).setCellValue("Landmark");
			row.createCell(27).setCellValue("Street Name");
			row.createCell(28).setCellValue("City Name");
			row.createCell(29).setCellValue("District Name");
			row.createCell(30).setCellValue("State Name");
			row.createCell(31).setCellValue("Country Name");
			row.createCell(32).setCellValue("Pin/Zipcode");

			row.createCell(33).setCellValue("company Name as per DataBase");
			row.createCell(34).setCellValue("Branch Name as per DataBase");
			row.createCell(35).setCellValue("Department Name as per DataBase");
			row.createCell(36).setCellValue("Designation Name as per DataBase");
			row.createCell(37).setCellValue("skill1" + "," + "skill2" + "..." + "as per List");
			row.createCell(38).setCellValue("skill1" + "," + "skill2" + "..." + "as per List");
			row.createCell(39).setCellValue("Manager First Name as per DataBase");
			row.createCell(40).setCellValue("Role Name as per DataBase");
			row.createCell(41).setCellValue("Employement Type");
			row.createCell(42).setCellValue("dd-MM-yyyy");
			row.createCell(43).setCellValue("dd-MM-yyyy");

			workbook.write(out);

			logger.info("employee details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return professional Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream professionalDetailsErrorRecordsExcelSampleFile() throws IOException {

		String[] EXPRIENCEDETAILS = { "EMPLOYEE_ID*", "COMPANY_NAME*", "JOINING_DATE*", "RELIEVING_DATE*",
				"EXPERIENCE*", "CLIENT", "IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
//			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Experiance Details");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			// Row for Header
			Row headerRow = sheet.createRow(0);
			// Header
			for (int col = 0; col < EXPRIENCEDETAILS.length; col++) {
				if (EXPRIENCEDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row3 = sheet.createRow(1);
			row3.createCell(0).setCellValue("Employee Id");
			row3.createCell(1).setCellValue("Previous Company Name");
			row3.createCell(2).setCellValue("dd-MM-yyyy");
			row3.createCell(3).setCellValue("dd-MM-yyyy");
			row3.createCell(4).setCellValue("Experience in numbers only");
			row3.createCell(5).setCellValue("Client Name");
			row3.createCell(6).setCellValue("YES/NO");

			workbook.write(out);
			logger.info("Employee experience details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return employee Mial Id Error Records Excel Sample File
	 * @throws Exception
	 */
	public static ByteArrayInputStream employeeMialIdErrorRecordsExcelSampleFile() throws Exception {
		String[] OFFICALMAILIDS = { "EMPLOYEE_ID*", "OFFICAL_MAIL_ID*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Offical MailIDs");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < OFFICALMAILIDS.length; col++) {
				if (OFFICALMAILIDS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row4 = sheet.createRow(1);
			row4.createCell(0).setCellValue("Employee Id");
			row4.createCell(1).setCellValue("Ex: user@onpassive.com");

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			workbook.write(out);
			logger.info("Employee mail id sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return Educational Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream employeeEducationalDetailsErrorRecordsExcelSampleFile() throws IOException {
		String[] EDUCATIONALDETAILS = { "EMPLOYEE_ID*", "QUALIFICATION*", "INSTITUTE_NAME*", "YEAR_OF_PASSING*",
				"STREAM*", "PERCENTAGE/GRADE*", "IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			Sheet sheet = workbook.createSheet("Employee Educational Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < EDUCATIONALDETAILS.length; col++) {
				if (EDUCATIONALDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row1 = sheet.createRow(1);
			row1.createCell(0).setCellValue("Employee Id");
			row1.createCell(1).setCellValue("Qualification");
			row1.createCell(2).setCellValue("Institute Name");
			row1.createCell(3).setCellValue("Year Of Passing");
			row1.createCell(4).setCellValue("Stream");
			row1.createCell(5).setCellValue("Percentage/Grade in number format only");
			row1.createCell(6).setCellValue("YES/NO");
			workbook.write(out);
			logger.info("Employee educational details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param presentList
	 * @return Educational Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream educationalDetailsErrorRecordsExcel(List<AcadmicDetailsErrorRecords> presentList)
			throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID", "QULIFICATION", "INSTITUTE_NAME", "YEAR_OF_PASSING", "STREAM",
				"PERCENTAGE/GRADE", "IS_DEFAULT(YES/NO)" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Employee Educational Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (AcadmicDetailsErrorRecords pdeError : presentList) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(pdeError.getEmployeeId());
				if (pdeError.getEmployeeId() != null) {
					if (pdeError.getEmployeeId().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getQualification());
				if (pdeError.getQualification() != null) {
					if (pdeError.getQualification().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getQualification().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getQualification());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getInstituteName());
				if (pdeError.getInstituteName() != null) {
					if (pdeError.getInstituteName().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getInstituteName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getInstituteName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(pdeError.getYearOfPassing());
				if (pdeError.getYearOfPassing() != null) {
					if (pdeError.getYearOfPassing().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getYearOfPassing().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getYearOfPassing());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(pdeError.getType());
				if (pdeError.getType() != null) {
					if (pdeError.getType().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getType().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getType());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(5).setCellValue(pdeError.getPercentage());
				if (pdeError.getPercentage() != null) {
					if (pdeError.getPercentage().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getPercentage().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getPercentage());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getPercentage().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}

			workbook.write(out);
			logger.info("Educational Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return Educational Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream employeeEmergencyDetailsErrorRecordsExcelSampleFile() throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "CONTACT_PERSON*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*",
				"IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			Sheet sheet = workbook.createSheet("Emp Emergency Contact Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row2 = sheet.createRow(1);
			row2.createCell(0).setCellValue("Employee Id");
			row2.createCell(1).setCellValue("Contact Person Name");
			row2.createCell(2).setCellValue("Ex: 0000000000");
			row2.createCell(3).setCellValue("Ex: 0000000000 Optional");
			row2.createCell(4).setCellValue("Relation with employee");
			row2.createCell(5).setCellValue("YES/NO");
			workbook.write(out);
			logger.info("Employee emergency contact details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @param presentList
	 * @return Educational Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream emergencyContactDetailsErrorRecordsExcel(
			List<EmergencyContactDetailErrorRecords> presentList) throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "CONTACT_PERSON*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*",
				"IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Emp Emergency Contact Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmergencyContactDetailErrorRecords pdeError : presentList) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(pdeError.getEmployeeId());
				if (pdeError.getEmployeeId() != null) {
					if (pdeError.getEmployeeId().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getContactPerson());
				if (pdeError.getContactPerson() != null) {
					if (pdeError.getContactPerson().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getContactPerson().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getContactPerson());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getContactNumber());
				if (pdeError.getContactNumber() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}

				if (pdeError.getAltContactNumber() != null) {
					row.createCell(3).setCellValue(pdeError.getAltContactNumber());
				}
				if (pdeError.getRelation() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getRelation().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getRelation());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(pdeError.getRelation());
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}

				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}

			workbook.write(out);
			logger.info("Emergency Contact Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return emp Details Error Records Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream allEmpDetailsErrorRecordsExcelSampleFile() throws IOException {

		String[] BASICDETAILS = { "FIRST_NAME*", "MIDDLE_NAME", "LAST_NAME*", "EMAIL*", "USERNAME*", "DATE_OF_BIRTH*",
				"MARITAL_STATUS*", "MARRIAGE_DAY", "GENDER*", "CONTACT_NO*", "ALTERNATE_CONTACT_NO", "AADHAAR_CARD*",
				"PANCARD*", "VOTER_ID", "PASSPORT_NO", "JOINING_DATE*", "BLOOD_GROUP*", "PERMANENT_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "TEMPORARY_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "COMPANY_NAME*",
				"BRANCH*", "DEPARTMENT*", "DESIGNATION*", "PRIMARY_SKILLS*", "SECONDARY_SKILLS", "MANAGER*", "ROLE*",
				"EMPLOYMENT_TYPE*", "EMPTYPE_START_DATE*", "EMPTYPE_END_DATE*" };
		String[] EDUCATIONALDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "QUALIFICATION*",
				"INSTITUTE_NAME*", "YEAR_OF_PASSING*", "STREAM*", "PERCENTAGE/GRADE*", "IS_DEFAULT(YES/NO)*" };
		String[] EMERGENCYCONTACTDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "CONTACT_PERSON_NAME*",
				"CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*", "IS_DEFAULT(YES/NO)*" };
		String[] EXPRIENCEDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "COMPANY_NAME*", "JOINING_DATE*",
				"RELIEVING_DATE*", "EXPERIENCE*", "CLIENT", "IS_DEFAULT(YES/NO)*" };
		String[] OFFICALMAILIDS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "OFFICAL_MAIL_ID*" };
		String[] PERSONALCONTACTDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "CONTACT_PERSON_NAME*",
				"CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*", "IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			Sheet sheet = workbook.createSheet(ExcelHeaders.EMP_BASIC_DETAILS_SHEETNAME);
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);
			// Row for Header
			Row headerRow = sheet.createRow(0);
			// Header
			for (int col = 0; col < BASICDETAILS.length; col++) {

				if (BASICDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			Row row = sheet.createRow(1);
			row.createCell(0).setCellValue("First Name");
			row.createCell(1).setCellValue("Middle Name");
			row.createCell(2).setCellValue("Last Name");
			row.createCell(3).setCellValue("Ex: user@onpassive.com");
			row.createCell(4).setCellValue("User Name");
			row.createCell(5).setCellValue("dd-MM-yyyy");
			row.createCell(6).setCellValue("Marital Status");
			row.createCell(7).setCellValue("dd-MM-yyyy");
			row.createCell(8).setCellValue("Gender");
			row.createCell(9).setCellValue("Ex: 0000000000");
			row.createCell(10).setCellValue("Ex: 0000000000");
			row.createCell(11).setCellValue("Adheer Card");
			row.createCell(12).setCellValue("Ex: ABCDE1234A");
			row.createCell(13).setCellValue("voter Id");
			row.createCell(14).setCellValue("A0000000");
			row.createCell(15).setCellValue("dd-MM-yyyy");
			row.createCell(16).setCellValue("Ex: O +ve");
			row.createCell(17).setCellValue("Door No/Flat No");
			row.createCell(18).setCellValue("Landmark");
			row.createCell(19).setCellValue("Street Name");
			row.createCell(20).setCellValue("City Name");
			row.createCell(21).setCellValue("District Name");
			row.createCell(22).setCellValue("State Name");
			row.createCell(23).setCellValue("Country Name");
			row.createCell(24).setCellValue("Pin/Zipcode");
			row.createCell(25).setCellValue("Door No/Flat No");
			row.createCell(26).setCellValue("Landmark");
			row.createCell(27).setCellValue("Street Name");
			row.createCell(28).setCellValue("City Name");
			row.createCell(29).setCellValue("District Name");
			row.createCell(30).setCellValue("State Name");
			row.createCell(31).setCellValue("Country Name");
			row.createCell(32).setCellValue("Pin/Zipcode");

			row.createCell(33).setCellValue("company Name as per DataBase");
			row.createCell(34).setCellValue("Branch Name as per DataBase");
			row.createCell(35).setCellValue("Department Name as per DataBase");
			row.createCell(36).setCellValue("Designation Name as per DataBase");
			row.createCell(37).setCellValue("skill1" + "," + "skill2" + "..." + "as per List");
			row.createCell(38).setCellValue("skill1" + "," + "skill2" + "..." + "as per List");
			row.createCell(39).setCellValue("Manager First Name as per DataBase");
			row.createCell(40).setCellValue("Role Name as per DataBase");
			row.createCell(41).setCellValue("Employement Type");
			row.createCell(42).setCellValue("dd-MM-yyyy");
			row.createCell(43).setCellValue("dd-MM-yyyy");

			Sheet sheet1 = workbook.createSheet(ExcelHeaders.EMP_EDUCATIONAL_DETAILS_SHEETNAME);
			// Row for Header
			Row headerRow1 = sheet1.createRow(0);
			// Header
			for (int col = 0; col < EDUCATIONALDETAILS.length; col++) {
				if (EDUCATIONALDETAILS[col].endsWith("*")) {
					Cell cell = headerRow1.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow1.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row1 = sheet1.createRow(1);
			row1.createCell(0).setCellValue("Employee First Name");
			row1.createCell(1).setCellValue("Ex: 0000000000");
			row1.createCell(2).setCellValue("Qualification");
			row1.createCell(3).setCellValue("Institute Name");
			row1.createCell(4).setCellValue("Year Of Passing");
			row1.createCell(5).setCellValue("Stream");
			row1.createCell(6).setCellValue("Percentage/Grade in number format only");
			row1.createCell(7).setCellValue("YES/NO");

			Sheet sheet2 = workbook.createSheet(ExcelHeaders.EMP_EMERGENCY_CONTACT_DETAILS_SHEETNAME);
			// Row for Header
			Row headerRow2 = sheet2.createRow(0);
			// Header
			for (int col = 0; col < EMERGENCYCONTACTDETAILS.length; col++) {
				if (EMERGENCYCONTACTDETAILS[col].endsWith("*")) {
					Cell cell = headerRow2.createCell(col);
					cell.setCellValue(EMERGENCYCONTACTDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow2.createCell(col);
					cell.setCellValue(EMERGENCYCONTACTDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row2 = sheet2.createRow(1);
			row2.createCell(0).setCellValue("Employee First Name");
			row2.createCell(1).setCellValue("Ex: 0000000000");
			row2.createCell(2).setCellValue("Contact Person Name");
			row2.createCell(3).setCellValue("Ex: 0000000000");
			row2.createCell(4).setCellValue("Ex: 0000000000 Optional");
			row2.createCell(5).setCellValue("Relation with employee");
			row2.createCell(6).setCellValue("YES/NO");
			Sheet sheet3 = workbook.createSheet(ExcelHeaders.EMP_EXPRIENCE_DETAILS_SHEETNAME);

			// Row for Header
			Row headerRow3 = sheet3.createRow(0);
			// Header
			for (int col = 0; col < EXPRIENCEDETAILS.length; col++) {
				if (EXPRIENCEDETAILS[col].endsWith("*")) {
					Cell cell = headerRow3.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow3.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row3 = sheet3.createRow(1);
			row3.createCell(0).setCellValue("Employee First Name");
			row3.createCell(1).setCellValue("Ex: 0000000000");
			row3.createCell(2).setCellValue("Previous Company Name");
			row3.createCell(3).setCellValue("dd-MM-yyyy");
			row3.createCell(4).setCellValue("dd-MM-yyyy");
			row3.createCell(5).setCellValue("Experience in numbers only");
			row3.createCell(6).setCellValue("Client Name");
			row3.createCell(7).setCellValue("YES/NO");

			Sheet sheet4 = workbook.createSheet(ExcelHeaders.EMP_OFFICAL_MAIL_IDS_SHEETNAME);

			// Row for Header
			Row headerRow4 = sheet4.createRow(0);
			// Header
			for (int col = 0; col < OFFICALMAILIDS.length; col++) {
				if (OFFICALMAILIDS[col].endsWith("*")) {
					Cell cell = headerRow4.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow4.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row4 = sheet4.createRow(1);
			row4.createCell(0).setCellValue("Employee First Name");
			row4.createCell(1).setCellValue("Ex: 0000000000");
			row4.createCell(2).setCellValue("Ex: user@onpassive.com");

			Sheet sheet5 = workbook.createSheet(ExcelHeaders.EMP_PERSONAL_CONTACT_DETAILS_SHEETNAME);
			// Row for Header
			Row headerRow5 = sheet5.createRow(0);
			// Header
			for (int col = 0; col < PERSONALCONTACTDETAILS.length; col++) {
				if (PERSONALCONTACTDETAILS[col].endsWith("*")) {
					Cell cell = headerRow5.createCell(col);
					cell.setCellValue(PERSONALCONTACTDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow5.createCell(col);
					cell.setCellValue(PERSONALCONTACTDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row5 = sheet5.createRow(1);
			row5.createCell(0).setCellValue("Employee First Name");
			row5.createCell(1).setCellValue("Ex: 0000000000");
			row5.createCell(2).setCellValue("Contact Person Name");
			row5.createCell(3).setCellValue("Ex: 0000000000");
			row5.createCell(4).setCellValue("Ex: 0000000000 Optional");
			row5.createCell(5).setCellValue("Relation with employee");
			row5.createCell(6).setCellValue("YES/NO");

			workbook.write(out);

			logger.info("employee details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	/**
	 * 
	 * @return Personal Details Excel Sample File
	 * @throws IOException
	 */
	public static ByteArrayInputStream employeePersonalDetailsExcelSampleFile() throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "CONTACT_PERSON*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*",
				"IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			Sheet sheet = workbook.createSheet("Emp Personal Contact Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			Row row2 = sheet.createRow(1);
			row2.createCell(0).setCellValue("Employee Id");
			row2.createCell(1).setCellValue("Contact Person Name");
			row2.createCell(2).setCellValue("Ex: 0000000000");
			row2.createCell(3).setCellValue("Ex: 0000000000 Optional");
			row2.createCell(4).setCellValue("Relation with employee");
			row2.createCell(5).setCellValue("YES/NO");
			workbook.write(out);
			logger.info("Employee emergency contact details sample Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public static ByteArrayInputStream personalContactDetailsErrorRecordsExcel(
			List<PersonalDetailsErrorRecords> personalDetailsError) throws IOException {
		String[] COLUMNS = { "EMPLOYEE_ID*", "PERSON_NAME*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*",
				"IS_DEFAULT(YES/NO)*" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Emp Personal Contact Details");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNS.length; col++) {
				if (COLUMNS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(COLUMNS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (PersonalDetailsErrorRecords pdeError : personalDetailsError) {
				Row row = sheet.createRow(rowIdx++);
//				row.createCell(0).setCellValue(pdeError.getEmployeeId());
				if (pdeError.getEmployeeId() != null) {
					if (pdeError.getEmployeeId().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmployeeId());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getContactPerson());
				if (pdeError.getContactPerson() != null) {
					if (pdeError.getContactPerson().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getContactPerson().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getContactPerson());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getContactNumber());
				if (pdeError.getContactNumber() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getAltContactNumber() != null) {
					row.createCell(3).setCellValue(pdeError.getAltContactNumber());
				}
				if (pdeError.getRelation() != null) {
					if (pdeError.getRelation().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getRelation().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getRelation());
						cell.setCellStyle(headerCellStyle);
					}
				} else {
					row.createCell(4).setCellValue("");
				}
//				row.createCell(4).setCellValue(pdeError.getRelation());

				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < COLUMNS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}

			workbook.write(out);
			logger.info("Personal Contact Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}
}
