package com.hrms.admin.fileuploaddownload.property;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeReportDTO;
import com.hrms.admin.dto.ExitReportDTO;
import com.hrms.admin.dto.LeaveReportDTO;
import com.hrms.admin.dto.PayrollReportResponseDTO;
import com.hrms.admin.dto.PerfomanceReportDTO;
import com.hrms.admin.dto.ShiftReportDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.State;
import com.hrms.admin.repository.AddressRepository;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.StateRepository;
import com.hrms.admin.util.StringToDateUtility;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PdfReportGenerator {

	@Autowired
	private StringToDateUtility dateUtil;

	@Autowired
	private ProfileImageRepository profileImageRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private CityRepository cityRepo;

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private StateRepository stateRepo;

	public ByteArrayInputStream attendanceReport(List<AttendanceInfoDTO> allAttendenceDetails, String companyId)
			throws Exception {

		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));

		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);

		try {
			PdfPTable table = new PdfPTable(11);
			table.setWidthPercentage(100);
			table.setWidths(new int[] { 30, 50, 35, 32, 30, 20, 25, 30, 30, 45, 30 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Shift", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("In Time", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Out Time", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Total Hours", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Work Hours", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Break Hours", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Attendance Percentage", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Reason", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (AttendanceInfoDTO attendance : allAttendenceDetails) {

				PdfPCell cell;
				cell = new PdfPCell(new Phrase(attendance.getEmpId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getEmployee(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getShift(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(
						new Phrase(dateUtil.changeDateFormatFromStringDateAndTime(attendance.getInTime()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(
						new Phrase(dateUtil.changeDateFormatFromStringDateAndTime(attendance.getOutTime()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormatFromString(attendance.getDate()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getTotalHrs(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getNoOfHrs(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getBreakHrs(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getAttndsPercentage().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(attendance.getReason(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);
			}
			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream leaveReport(List<LeaveReportDTO> allleaveDetails, String companyId) throws Exception {

		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);

		try {
			PdfPTable table = new PdfPTable(7);
			table.setWidthPercentage(85);
			table.setWidths(new int[] { 20, 30, 20, 30, 20, 20, 15 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Applied Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Leave Type", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("From Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("To Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Leave Days", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (LeaveReportDTO leave : allleaveDetails) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(leave.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(leave.getEmployeeName(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormat(leave.getAppliedDate()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(leave.getLeaveType(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormat(leave.getFromDate()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormat(leave.getToDate()), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(leave.getLeaveDays().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);
			}
			document.add(table);
			document.close();

		} catch (DocumentException ex) {
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream OnboardToPdf(List<EmployeeReportDTO> employees, String companyId) throws Exception {

		Document document = new Document(PageSize._11X17);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));

		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);
		try {

			PdfPTable table = new PdfPTable(8);
			table.setWidthPercentage(95);
			table.setWidths(new int[] { 8, 15, 10, 15, 15, 6, 13, 6 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			hcell.setFixedHeight(25);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Contact No.", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Email", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Action", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Department", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Gender", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (EmployeeReportDTO emp : employees) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(emp.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmployeeName(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getMobileNumber().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmailId(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getDesignation(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getIsActive(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getDepartment(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getGender(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}

			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream perfomanceReport(List<PerfomanceReportDTO> allPerfomanceDetails, String companyId)
			throws Exception {
		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		/*
		 * Optional<Company> company = companyRepo.findById(companyId); Paragraph head1
		 * = new Paragraph(new Phrase(company.get().getName(), mainHeadFont));
		 * 
		 * Address addr = company.get().getAddress(); Address address =
		 * addressRepo.getOne(addr.getId()); City city =
		 * cityRepo.getOne(address.getCity()); Country country =
		 * countryRepo.getOne(address.getCountry()); State state =
		 * stateRepo.getOne(address.getState()); Paragraph head2 = new Paragraph(new
		 * Phrase(address.getLandmark() + ", " + address.getStreet() + ", " +
		 * address.getAddress() + ", " + city.getCityName() + ", " +
		 * address.getDistrict() + ", " + state.getStateName() + "-" +
		 * address.getPincode() + " " + country.getCountryName(), fontbasic)); //
		 * Paragraph head1 = new Paragraph(new Phrase(Constants.PARAGRAPH1,
		 * mainHeadFont)); // Paragraph head2 = new Paragraph(new
		 * Phrase(Constants.PARAGRAPH2, fontbasic));
		 */
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);

		try {
			PdfPTable table = new PdfPTable(7);
			table.setWidthPercentage(100);
			table.setWidths(new int[] { 8, 15, 15, 10, 10, 15, 10 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Review Month", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Submited Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Review Period", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Status", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (PerfomanceReportDTO perfomance : allPerfomanceDetails) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(perfomance.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(perfomance.getEmployeeName(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(perfomance.getDesignation(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(perfomance.getReviewMonth(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);
				if (perfomance.getSubmitedDate() != null) {
					cell = new PdfPCell(new Phrase(perfomance.getSubmitedDate(), bodyFont));
				} else {
					cell = new PdfPCell(new Phrase("", bodyFont));
				}
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);
				String reviewRange = dateUtil.changeDateFormatFromString(perfomance.getReviewStart()).concat("-")
						.concat(dateUtil.changeDateFormatFromString(perfomance.getReviewEnd()));
				cell = new PdfPCell(new Phrase(reviewRange, bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(perfomance.getStatus(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}

			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			// log.error("Error occurred: {0}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	// payroll pdf report
	public ByteArrayInputStream payrollPDFReport(List<PayrollReportResponseDTO> payrollReportResponseDTO,
			String companyId) throws DocumentException, MalformedURLException, IOException {

		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);

		try {
			PdfPTable table = new PdfPTable(6); // 11
			table.setWidthPercentage(100);
			table.setWidths(new int[] { 20, 43, 37, 40, 22, 25 });// , 25, 35, 40, 35, 40

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Department", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("CTC", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Gross Salary", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (PayrollReportResponseDTO payroll : payrollReportResponseDTO) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(payroll.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(payroll.getFirstName() + " " + payroll.getLastName(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(payroll.getDepartmentName(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(payroll.getDesignationName(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				if (payroll.getCsvCtc() == null) {
					cell = new PdfPCell(new Phrase(""));
				} else {
					cell = new PdfPCell(new Phrase(payroll.getCsvCtc(), bodyFont));
				}
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				if (payroll.getCsvMonthlySalary() == null) {
					cell = new PdfPCell(new Phrase(""));
				} else {
					cell = new PdfPCell(new Phrase(payroll.getCsvMonthlySalary(), bodyFont));
				}
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}
			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream EmpReport(List<EmployeeInfoDTO> employees, String companyId)
			throws DocumentException, MalformedURLException, IOException, Exception {

		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont1 = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);
		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);

		try {

			PdfPTable table = new PdfPTable(12);
			table.setWidthPercentage(100);
			table.setWidths(new int[] { 5, 7, 9, 5, 6, 5, 5, 5, 4, 5, 5, 6 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			hcell.setFixedHeight(15);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Email", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("User Name", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Date Of Birth", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Marital Status", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Contact No.", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Aadhar Card", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Pan Card", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			/*
			 * hcell = new PdfPCell(new Phrase("Voter ID", headFont1));
			 * hcell.setHorizontalAlignment(Element.ALIGN_CENTER); table.addCell(hcell);
			 */

			hcell = new PdfPCell(new Phrase("Joining Date", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Blood Group", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont1));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (EmployeeInfoDTO emp : employees) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(emp.getId().toString(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getFirstName() + " " + emp.getLastName(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getOfficalMail(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getUserName(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormat(emp.getDateOfBirth()), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getMaritalStatus(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getContactNo(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getAadharCard(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getPanCard(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				/*
				 * cell = new PdfPCell(new Phrase(emp.getVoterID(), headFont));
				 * cell.setVerticalAlignment(Element.ALIGN_LEFT);
				 * cell.setHorizontalAlignment(Element.ALIGN_LEFT); table.addCell(cell);
				 */

				cell = new PdfPCell(new Phrase(dateUtil.changeDateFormat(emp.getJoiningDate()), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getBloodGroup(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getDesignationName(), headFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}
			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {0}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream shiftReport(List<ShiftReportDTO> allshiftDetails, String companyId) throws Exception {
		Document document = new Document(PageSize._11X17);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font headFont1 = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));
		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);
		try {
			PdfPTable table = new PdfPTable(8);
			table.setWidthPercentage(100);
			table.setWidths(new int[] { 4, 6, 9, 5, 6, 5, 5, 6 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Email", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Department", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Project Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Shift Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Reporting Manager", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (ShiftReportDTO shift : allshiftDetails) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(shift.getEmployeeId().toString(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getEmployeeName(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getEmailId(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getDesignation(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getDepartment(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getProjectName(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getShiftName(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(shift.getReportingManager(), headFont1));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}

			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {0}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream employeePromotionalToPdf(List<EmployeeReportDTO> employees, String companyId)
			throws Exception {

		Document document = new Document(PageSize._11X17);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));

		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);
		try {

			PdfPTable table = new PdfPTable(6);
			table.setWidthPercentage(95);
			table.setWidths(new int[] { 8, 15, 10, 15, 15, 10 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			hcell.setFixedHeight(25);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employement Type", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Start Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("End Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (EmployeeReportDTO emp : employees) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(emp.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmployeeName(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmploymentType(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getDesignation(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmpTypeStartDate(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmpTypeEndDate(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}

			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	
	public ByteArrayInputStream employeeExitToPdf(List<ExitReportDTO> exitReport, String companyId) throws Exception {
		Document document = new Document(PageSize._11X17);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document, out);
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
		Font bodyFont = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL, BaseColor.BLACK);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD, BaseColor.BLUE);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		Rectangle rect = new Rectangle(20, 20, 780, 1200);
		// rect.setBorder(Rectangle.BOX);
		// rect.setBorderWidth(1);
		canvas.rectangle(rect);

		canvas.addImage(getCompanyImage(companyId));

		List<String> getheaders = getheaders(companyId);
		Paragraph head1 = new Paragraph(new Phrase(getheaders.get(0), mainHeadFont));
		Paragraph head2 = new Paragraph(new Phrase(getheaders.get(1), fontbasic));
		head2.setSpacingAfter(20);
		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);
		try {

			PdfPTable table = new PdfPTable(5);
			table.setWidthPercentage(95);
			table.setWidths(new int[] { 8, 15, 10, 10, 10 });

			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("Employee ID", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			hcell.setFixedHeight(25);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Employee Name", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Designation", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Start Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			hcell = new PdfPCell(new Phrase("Relieving Date", headFont));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);

			for (ExitReportDTO emp : exitReport) {

				PdfPCell cell;

				cell = new PdfPCell(new Phrase(emp.getEmployeeId().toString(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmployeeName(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getEmpDesignation(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getJoiningDate(), bodyFont));
				cell.setPaddingLeft(5);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase(emp.getExitDate(), bodyFont));
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				table.addCell(cell);

			}

			document.add(table);
			document.close();

		} catch (DocumentException ex) {
			log.error("Error occurred: {}", ex);
		}

		return new ByteArrayInputStream(out.toByteArray());
	}
	public Image getCompanyImage(String companyId) throws BadElementException, MalformedURLException, IOException {
		List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(companyId);
		if (!companyImages.isEmpty()) {
			for (ProfileImage image : companyImages) {
				if (!image.getImageName().contains("_")) {
					Image img = Image.getInstance(image.getImageurl());
					img.setAbsolutePosition(40, 1150);
					img.scaleAbsolute(130, 40);
					img.setBorderWidth(35);
					img.setScaleToFitHeight(true);
					return img;
				}
			}
		} else {
			Image img = Image.getInstance("classpath:Images/ostafflogo.png");
			img.setAbsolutePosition(40, 1150);
			img.scaleAbsolute(130, 40);
			img.setBorderWidth(35);
			img.setScaleToFitHeight(true);
			return img;
		}
		return null;
	}

	public List<String> getheaders(String companyId) {
		List<String> list = new ArrayList<>();
		Optional<Company> company = companyRepo.findById(companyId);
		if (company.isPresent()) {
			list.add(company.get().getName());
			Address addr = company.get().getAddress();
			Address address = addressRepo.getOne(addr.getId());
			City city = cityRepo.getOne(address.getCity());
			Country country = countryRepo.getOne(address.getCountry());
			State state = stateRepo.getOne(address.getState());
			String add = address.getLandmark() + ", " + address.getStreet() + ", " + city.getCityName() + ", "
					+ address.getDistrict() + ", " + state.getStateName() + "-" + address.getPincode() + " "
					+ country.getCountryName();
			list.add(add);
			return list;
		}
		return list;

	}

}
