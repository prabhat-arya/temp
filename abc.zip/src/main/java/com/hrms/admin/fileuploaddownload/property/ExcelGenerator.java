package com.hrms.admin.fileuploaddownload.property;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeReportDTO;
import com.hrms.admin.dto.ExitReportDTO;
import com.hrms.admin.dto.LeaveReportDTO;
import com.hrms.admin.dto.PayrollReportResponseDTO;
import com.hrms.admin.dto.PerfomanceReportDTO;
import com.hrms.admin.dto.ShiftReportDTO;
import com.hrms.admin.util.StringToDateUtility;

@Component
public class ExcelGenerator {

	@Autowired
	private StringToDateUtility dateUtil;

	public ByteArrayInputStream attendanceInfoToExcel(List<AttendanceInfoDTO> presentList) throws Exception {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Shift", "In Time", "Out Time", "Date", "Total Hours",
				"Work Hours", "Break Hours", "Reason", "Attendance Percentage" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("attendanceInfo");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);

			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (AttendanceInfoDTO attendance : presentList) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(attendance.getEmpId());
				row.createCell(1).setCellValue(attendance.getEmployee());
				row.createCell(2).setCellValue(attendance.getShift());
				row.createCell(3).setCellValue(dateUtil.changeDateFormatFromStringDateAndTime(attendance.getInTime()));
				row.createCell(4).setCellValue(dateUtil.changeDateFormatFromStringDateAndTime(attendance.getOutTime()));
				row.createCell(5).setCellValue(dateUtil.changeDateFormatFromString(attendance.getDate()));
				row.createCell(6).setCellValue(attendance.getTotalHrs());
				row.createCell(7).setCellValue(attendance.getNoOfHrs());
				row.createCell(8).setCellValue(attendance.getBreakHrs());
				row.createCell(9).setCellValue(attendance.getReason());
				Cell cell1 = row.createCell(10);
				row.createCell(10).setCellValue(attendance.getAttndsPercentage());
				cell.setCellStyle(ageCellStyle);
				cell1.setCellStyle(ageCellStyle);

				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream EmployeeToExcel(List<EmployeeInfoDTO> allEmployeeDetails) throws Exception {
		String[] COLUMNs = { "Id", "Name", "Email", "User Name", "Date Of Birth", "Marital Status", "Contact Number",
				"Aadhar Card", "Pan Card", "Joining Date", "Blood Group", "Designation" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("employee");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeInfoDTO emp : allEmployeeDetails) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(emp.getId());
				row.createCell(1).setCellValue(emp.getFirstName() + " " + emp.getLastName());
				row.createCell(2).setCellValue(emp.getOfficalMail());
				row.createCell(3).setCellValue(emp.getUserName());
				row.createCell(4).setCellValue(dateUtil.changeDateFormat(emp.getDateOfBirth()));
				row.createCell(5).setCellValue(emp.getMaritalStatus());
				row.createCell(6).setCellValue(emp.getContactNo());
				row.createCell(7).setCellValue(emp.getAadharCard());
				row.createCell(8).setCellValue(emp.getPanCard());
				row.createCell(9).setCellValue(dateUtil.changeDateFormat(emp.getJoiningDate()));
				row.createCell(10).setCellValue(emp.getBloodGroup());
				row.createCell(11).setCellValue(emp.getDesignationName());
				cell.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream ShiftToExcel(List<ShiftReportDTO> allshiftDetails) throws IOException {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Email ID", "Designation", "Department", "Project Name",
				"Shift Name", "Reporting Manager" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("assignShift");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (ShiftReportDTO shift : allshiftDetails) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(shift.getEmployeeId());
				row.createCell(1).setCellValue(shift.getEmployeeName());
				row.createCell(2).setCellValue(shift.getEmailId());
				row.createCell(3).setCellValue(shift.getDesignation());
				row.createCell(4).setCellValue(shift.getDepartment());
				row.createCell(5).setCellValue(shift.getProjectName());
				row.createCell(6).setCellValue(shift.getShiftName());
				row.createCell(7).setCellValue(shift.getReportingManager());
				cell.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream LeaveToExcel(List<LeaveReportDTO> allLeaveDetails) throws Exception {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Applied Date", "Leave Type", "From Date", "To Date",
				"Leave Days" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("empLeave");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (LeaveReportDTO leave : allLeaveDetails) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(leave.getEmployeeId());
				row.createCell(1).setCellValue(leave.getEmployeeName());
				row.createCell(2).setCellValue(dateUtil.changeDateFormat(leave.getAppliedDate()));
				row.createCell(3).setCellValue(leave.getLeaveType());
				row.createCell(4).setCellValue(dateUtil.changeDateFormat(leave.getFromDate()));
				row.createCell(5).setCellValue(dateUtil.changeDateFormat(leave.getToDate()));
				Cell cell1 = row.createCell(6);
				row.createCell(6).setCellValue(leave.getLeaveDays());
				cell.setCellStyle(ageCellStyle);
				cell1.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream OnboardToExcel(List<EmployeeReportDTO> allEmployeeDetails) throws IOException {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Mobile Number", "Email ID", "Designation", "Action",
				"Department", "Gender" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("employee");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeReportDTO emp : allEmployeeDetails) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(emp.getEmployeeId());
				row.createCell(1).setCellValue(emp.getEmployeeName());
				row.createCell(2).setCellValue(emp.getMobileNumber());
				row.createCell(3).setCellValue(emp.getEmailId());
				row.createCell(4).setCellValue(emp.getDesignation());
				row.createCell(5).setCellValue(emp.getIsActive());
				row.createCell(6).setCellValue(emp.getDepartment());
				row.createCell(7).setCellValue(emp.getGender());
				cell.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream employeePromotionalToExcel(List<EmployeeReportDTO> empList) throws Exception {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Employement Type", "Designation", "Start Date",
				"End Date" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("employee-promotional");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);

			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeReportDTO emp : empList) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(emp.getEmployeeId());
				row.createCell(1).setCellValue(emp.getEmployeeName());
				row.createCell(2).setCellValue(emp.getEmploymentType());
				row.createCell(3).setCellValue(emp.getDesignation());
				row.createCell(4).setCellValue(emp.getEmpTypeStartDate());
				row.createCell(5).setCellValue(emp.getEmpTypeEndDate());
				cell.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream PerfomanceToExcel(List<PerfomanceReportDTO> allPerfomanceDetails) throws Exception {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Designation", "Review Month", "Submited Date",
				"Review Period", "Status" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("perfomance");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (PerfomanceReportDTO perfomance : allPerfomanceDetails) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(perfomance.getEmployeeId());
				row.createCell(1).setCellValue(perfomance.getEmployeeName());
				row.createCell(2).setCellValue(perfomance.getDesignation());
				row.createCell(3).setCellValue(perfomance.getReviewMonth());
				if (perfomance.getSubmitedDate() != null) {
					row.createCell(4).setCellValue(perfomance.getSubmitedDate());
				} else {
					row.createCell(4).setCellValue("");
				}
				String reviewRange = dateUtil.changeDateFormatFromString(perfomance.getReviewStart()).concat("-")
						.concat(dateUtil.changeDateFormatFromString(perfomance.getReviewEnd()));
				row.createCell(5).setCellValue(reviewRange);
				row.createCell(6).setCellValue(perfomance.getStatus());
				cell.setCellStyle(ageCellStyle);
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	// Payroll report generation
	public static ByteArrayInputStream payrollToExcel(List<PayrollReportResponseDTO> payrollReportResponseDTO)
			throws IOException {

		String[] COLUMNs = { "Employee ID", "Employee Name", "Department", "Designation", "CTC", "Gross Salary" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Payroll");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (PayrollReportResponseDTO payroll : payrollReportResponseDTO) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(payroll.getEmployeeId());
				row.createCell(1).setCellValue(payroll.getFirstName() + " " + payroll.getLastName());
				if (payroll.getDepartmentName() == null) {
					row.createCell(2).setCellValue("");
				} else {
					row.createCell(2).setCellValue(payroll.getDepartmentName());
				}
				if (payroll.getDesignationName() == null) {
					row.createCell(3).setCellValue("");
				} else {
					row.createCell(3).setCellValue(payroll.getDesignationName());
				}
				Cell cell1 = row.createCell(4);
				if (payroll.getCsvCtc() == null) {
					row.createCell(4).setCellValue("");
				} else {
					row.createCell(4).setCellValue(payroll.getCsvCtc());
				}
				if (payroll.getCsvMonthlySalary() == null) {
					row.createCell(5).setCellValue("");
				} else {
					row.createCell(5).setCellValue(payroll.getCsvMonthlySalary());
				}
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
				cell.setCellStyle(ageCellStyle);
				cell1.setCellStyle(ageCellStyle);
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream employeeExitToExcel(List<ExitReportDTO> list) throws Exception {
		String[] COLUMNs = { "Employee ID", "Employee Name", "Designation", "Joining Date", "Relieving Date" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet("Exit Employee List");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (ExitReportDTO exitlist : list) {
				Row row = sheet.createRow(rowIdx++);
				Cell cell = row.createCell(0);
				ageCellStyle.setAlignment(HorizontalAlignment.LEFT);
				row.createCell(0).setCellValue(exitlist.getEmployeeId());
				row.createCell(1).setCellValue(exitlist.getEmployeeName());

				if (exitlist.getEmpDesignation() == null) {
					row.createCell(2).setCellValue("");
				} else {
					row.createCell(2).setCellValue(exitlist.getEmpDesignation());
				}
				if (exitlist.getJoiningDate() == null) {
					row.createCell(3).setCellValue("");
				} else {
					row.createCell(3).setCellValue(dateUtil.changeDateFormat(exitlist.getJoiningDate()));
				}
				if (exitlist.getExitDate() == null) {
					row.createCell(4).setCellValue("");
				} else {
					row.createCell(4).setCellValue(dateUtil.changeDateFormat(exitlist.getExitDate()));
				}
				for (int i = 0; i < COLUMNs.length; i++) {
					sheet.autoSizeColumn(i);
				}
				cell.setCellStyle(ageCellStyle);
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}
}