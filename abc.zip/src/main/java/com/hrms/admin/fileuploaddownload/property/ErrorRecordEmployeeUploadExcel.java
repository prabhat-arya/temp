package com.hrms.admin.fileuploaddownload.property;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;
import com.hrms.admin.util.ExcelHeaders;

@Component
public class ErrorRecordEmployeeUploadExcel {
	private static final Logger logger = LoggerFactory.getLogger(ErrorRecordEmployeeUploadExcel.class);

	/**
	 * 
	 * @param presentList
	 * @param personalContactDetailsList 
	 * @return employee Details Error Records Excel sheet
	 * @throws IOException
	 */
	public static ByteArrayInputStream allEmployeeDetailsErrorRecordsExcel(List<EmployeeErrorRecords> presentList,
			List<AcadmicDetailsErrorRecords> educationList, List<EmergencyContactDetailErrorRecords> emergencyList,
			List<ProfessionalDetailsErrorRecords> professionalList, List<EmployeeMailErrorRecords> employeeMaillList, List<PersonalDetailsErrorRecords> personalContactDetailsList)
			throws IOException {

		String[] BASICDETAILS = { "FIRST_NAME*", "MIDDLE_NAME", "LAST_NAME*", "EMAIL*", "USERNAME*", "DATE_OF_BIRTH*",
				"MARITAL_STATUS*", "MARRIAGE_DAY", "GENDER*", "CONTACT_NO*", "ALTERNATE_CONTACT_NO", "AADHARCARD*",
				"PANCARD*", "VOTER_ID", "PASSPORT_NO", "JOINING_DATE*", "BLOOD_GROUP*", "PERMANENT_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "TEMPORARY_ADDRESS*",
				"LANDMARK*", "STREET*", "CITY*", "DISTRICT*", "STATE*", "COUNTRY*", "PINCODE*", "PERSON_DETAIL_NAME_1*",
				"RELATION*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "PERSON_DETAIL_NAME_2*", "RELATION*",
				"CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "COMPANY_NAME*", "BRANCH*", "DEPARTMENT*", "DESIGNATION*",
				"PRIMARY_SKILLS*", "SECONDARY_SKILLS", "MANAGER*", "ROLE*", "EMPLOYMENT_TYPE*", "EMPTYPE_START_DATE*",
				"EMPTYPE_END_DATE*" };
		String[] EDUCATIONALDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "QUALIFICATION*",
				"INSTITUTE_NAME*", "YEAR_OF_PASSING*", "STREAM*", "PERCENTAGE/GRADE*", "IS_DEFAULT(YES/NO)" };
		String[] EMERGENCYCONTACTDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "CONTACT_PERSON_NAME*",
				"CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*", "IS_DEFAULT(YES/NO)" };
		String[] EXPRIENCEDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "COMPANY_NAME*", "JOINING_DATE*",
				"RELIEVING_DATE*", "EXPERIENCE*", "CLIENT", "IS_DEFAULT(YES/NO)" };
		String[] OFFICALMAILIDS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*", "OFFICAL_MAIL_ID*" };
		String[] PERSONALCONTACTDETAILS = { "EMPLOYEE_FIRST_NAME*", "EMPLOYEE_CONTACT_NO*",
				"CONTACT_PERSON_NAME*", "CONTACT_NUMBER*", "ALT_CONTACT_NUMBER", "RELATION*", "IS_DEFAULT(YES/NO)*" };

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			CreationHelper createHelper = workbook.getCreationHelper();

			Sheet sheet = workbook.createSheet(ExcelHeaders.EMP_BASIC_DETAILS_SHEETNAME);

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.AUTOMATIC.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			Font headerFontSpl = workbook.createFont();
			headerFontSpl.setBold(true);
			headerFontSpl.setColor(IndexedColors.ORANGE.getIndex());
			CellStyle headerCellStyleSpl = workbook.createCellStyle();
			headerCellStyleSpl.setFont(headerFontSpl);

			Font headerFontSpl1 = workbook.createFont();
			headerFontSpl1.setBold(true);
			headerFontSpl1.setColor(IndexedColors.RED.getIndex());
			CellStyle headerCellStyleSpl1 = workbook.createCellStyle();
			headerCellStyleSpl1.setFont(headerFontSpl1);
			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < BASICDETAILS.length; col++) {
				if (BASICDETAILS[col].endsWith("*")) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(BASICDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			CellStyle ageCellStyle = workbook.createCellStyle();
			ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));

			int rowIdx = 1;
			for (EmployeeErrorRecords empError : presentList) {
				Row row = sheet.createRow(rowIdx++);

//				row.createCell(0).setCellValue(empError.getFirstName());
				if (empError.getFirstName() != null) {
					if (empError.getFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(empError.getFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(empError.getFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(empError.getMiddleName());
				if (empError.getMiddleName() != null) {
					if (empError.getMiddleName().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(empError.getMiddleName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(empError.getMiddleName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(empError.getLastName());
				if (empError.getLastName() != null) {
					if (empError.getLastName().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(empError.getLastName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(empError.getLastName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(empError.getEmail());
				if (empError.getEmail() != null) {
					if (empError.getEmail().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(empError.getEmail().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(empError.getEmail());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(empError.getUserName());
				if (empError.getUserName() != null) {
					if (empError.getUserName().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(empError.getUserName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(empError.getUserName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getDateOfBirth() != null) {
					row.createCell(5).setCellValue(empError.getDateOfBirth().toString());
				} else {
					row.createCell(5).setCellValue("");
				}
//				row.createCell(6).setCellValue(empError.getMaritalStatus());
				if (empError.getMaritalStatus() != null) {
					if (empError.getMaritalStatus().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(empError.getMaritalStatus().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(empError.getMaritalStatus());
						cell.setCellStyle(headerCellStyle);
					}
				}

				if (empError.getMarriageDay() != null) {
					row.createCell(7).setCellValue(empError.getMarriageDay().toString());
				} else {
					row.createCell(7).setCellValue("");
				}
//				row.createCell(8).setCellValue(empError.getGender());
				if (empError.getGender() != null) {
					if (empError.getGender().endsWith("*")) {
						Cell cell = row.createCell(8);
						cell.setCellValue(empError.getGender().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(8);
						cell.setCellValue(empError.getGender());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(9).setCellValue(empError.getContactNo());
				if (empError.getContactNo() != null) {
					if (empError.getContactNo().endsWith("*")) {
						Cell cell = row.createCell(9);
						cell.setCellValue(empError.getContactNo().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(9);
						cell.setCellValue(empError.getContactNo());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(10).setCellValue(empError.getAlternateContactNo());
				if (empError.getAlternateContactNo() != null) {
					if (empError.getAlternateContactNo() != null) {
						if (empError.getAlternateContactNo().endsWith("*")) {
							Cell cell = row.createCell(10);
							cell.setCellValue(empError.getAlternateContactNo().replace("*", ""));
							cell.setCellStyle(headerCellStyleSpl);
						} else {
							Cell cell = row.createCell(10);
							cell.setCellValue(empError.getAlternateContactNo());
							cell.setCellStyle(headerCellStyle);
						}
					}
				}
//				row.createCell(11).setCellValue(empError.getAadharCard());
				if (empError.getAadharCard() != null) {
					if (empError.getAadharCard().endsWith("*")) {
						Cell cell = row.createCell(11);
						cell.setCellValue(empError.getAadharCard().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(11);
						cell.setCellValue(empError.getAadharCard());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(12).setCellValue(empError.getPanCard());
				if (empError.getPanCard() != null) {
					if (empError.getPanCard().endsWith("*")) {
						Cell cell = row.createCell(12);
						cell.setCellValue(empError.getPanCard().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(12);
						cell.setCellValue(empError.getPanCard());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(13).setCellValue(empError.getVoterID());
				if (empError.getVoterID() != null) {
					if (empError.getVoterID().endsWith("*")) {
						Cell cell = row.createCell(13);
						cell.setCellValue(empError.getVoterID().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(13);
						cell.setCellValue(empError.getVoterID());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(14).setCellValue(empError.getPassportNo());
				if (empError.getPassportNo() != null) {
					if (empError.getPassportNo().endsWith("*")) {
						Cell cell = row.createCell(14);
						cell.setCellValue(empError.getPassportNo().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(14);
						cell.setCellValue(empError.getPassportNo());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getJoiningDate() != null) {
					row.createCell(15).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(15).setCellValue("");
				}
//				row.createCell(16).setCellValue(empError.getBloodGroup());
				if (empError.getBloodGroup() != null) {
					if (empError.getBloodGroup().endsWith("*")) {
						Cell cell = row.createCell(16);
						cell.setCellValue(empError.getBloodGroup().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(16);
						cell.setCellValue(empError.getBloodGroup());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(17).setCellValue(empError.getPermanantAddress());
				if (empError.getPermanantAddress() != null) {
					if (empError.getPermanantAddress().endsWith("*")) {
						Cell cell = row.createCell(17);
						cell.setCellValue(empError.getPermanantAddress().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(17);
						cell.setCellValue(empError.getPermanantAddress());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(18).setCellValue(empError.getPermanantLandmark());
				if (empError.getPermanantLandmark() != null) {
					if (empError.getPermanantLandmark().endsWith("*")) {
						Cell cell = row.createCell(18);
						cell.setCellValue(empError.getPermanantLandmark().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(18);
						cell.setCellValue(empError.getPermanantLandmark());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(19).setCellValue(empError.getPermanantStreet());
				if (empError.getPermanantStreet() != null) {
					if (empError.getPermanantStreet().endsWith("*")) {
						Cell cell = row.createCell(19);
						cell.setCellValue(empError.getPermanantStreet().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(19);
						cell.setCellValue(empError.getPermanantStreet());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(20).setCellValue(empError.getPermanantCity());
				if (empError.getPermanantCity() != null) {
					if (empError.getPermanantCity().endsWith("*")) {
						Cell cell = row.createCell(20);
						cell.setCellValue(empError.getPermanantCity().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(20);
						cell.setCellValue(empError.getPermanantCity());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(21).setCellValue(empError.getPermanantDistrict());
				if (empError.getPermanantDistrict() != null) {
					if (empError.getPermanantDistrict().endsWith("*")) {
						Cell cell = row.createCell(21);
						cell.setCellValue(empError.getPermanantDistrict().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(21);
						cell.setCellValue(empError.getPermanantDistrict());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(22).setCellValue(empError.getPermanantState());
				if (empError.getPermanantState() != null) {
					if (empError.getPermanantState().endsWith("*")) {
						Cell cell = row.createCell(22);
						cell.setCellValue(empError.getPermanantState().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(22);
						cell.setCellValue(empError.getPermanantState());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(23).setCellValue(empError.getPermanantCountry());
				if (empError.getPermanantCountry() != null) {
					if (empError.getPermanantCountry().endsWith("*")) {
						Cell cell = row.createCell(23);
						cell.setCellValue(empError.getPermanantCountry().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(23);
						cell.setCellValue(empError.getPermanantCountry());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(24).setCellValue(empError.getPermanantPincode());
				if (empError.getPermanantPincode() != null) {
					if (empError.getPermanantPincode().endsWith("*")) {
						Cell cell = row.createCell(24);
						cell.setCellValue(empError.getPermanantPincode().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(24);
						cell.setCellValue(empError.getPermanantPincode());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(25).setCellValue(empError.getTemporaryAddress());
				if (empError.getTemporaryAddress() != null) {
					if (empError.getTemporaryAddress().endsWith("*")) {
						Cell cell = row.createCell(25);
						cell.setCellValue(empError.getTemporaryAddress().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(25);
						cell.setCellValue(empError.getTemporaryAddress());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(26).setCellValue(empError.getTemporaryLandmark());
				if (empError.getTemporaryLandmark() != null) {
					if (empError.getTemporaryLandmark().endsWith("*")) {
						Cell cell = row.createCell(26);
						cell.setCellValue(empError.getTemporaryLandmark().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(26);
						cell.setCellValue(empError.getTemporaryLandmark());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(27).setCellValue(empError.getTemporaryStreet());
				if (empError.getTemporaryStreet() != null) {
					if (empError.getTemporaryStreet().endsWith("*")) {
						Cell cell = row.createCell(27);
						cell.setCellValue(empError.getTemporaryStreet().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(27);
						cell.setCellValue(empError.getTemporaryStreet());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(28).setCellValue(empError.getTemporaryCity());
				if (empError.getTemporaryCity() != null) {
					if (empError.getTemporaryCity().endsWith("*")) {
						Cell cell = row.createCell(28);
						cell.setCellValue(empError.getTemporaryCity().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(28);
						cell.setCellValue(empError.getTemporaryCity());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(29).setCellValue(empError.getTemporaryDistrict());
				if (empError.getTemporaryDistrict() != null) {
					if (empError.getTemporaryDistrict().endsWith("*")) {
						Cell cell = row.createCell(29);
						cell.setCellValue(empError.getTemporaryDistrict().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(29);
						cell.setCellValue(empError.getTemporaryDistrict());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(30).setCellValue(empError.getTemporaryState());
				if (empError.getTemporaryState() != null) {
					if (empError.getTemporaryState().endsWith("*")) {
						Cell cell = row.createCell(30);
						cell.setCellValue(empError.getTemporaryState().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(30);
						cell.setCellValue(empError.getTemporaryState());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(31).setCellValue(empError.getTemporaryCountry());
				if (empError.getTemporaryCountry() != null) {
					if (empError.getTemporaryCountry().endsWith("*")) {
						Cell cell = row.createCell(31);
						cell.setCellValue(empError.getTemporaryCountry().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(31);
						cell.setCellValue(empError.getTemporaryCountry());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(32).setCellValue(empError.getTemporaryPincode());
				if (empError.getTemporaryPincode() != null) {
					if (empError.getTemporaryPincode().endsWith("*")) {
						Cell cell = row.createCell(32);
						cell.setCellValue(empError.getTemporaryPincode().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(32);
						cell.setCellValue(empError.getTemporaryPincode());
						cell.setCellStyle(headerCellStyle);
					}
				}
				/*
				 * // row.createCell(33).setCellValue(empError.getPersonDetails1()); if
				 * (empError.getPersonDetails1() != null) { if
				 * (empError.getPersonDetails1().endsWith("*")) { Cell cell =
				 * row.createCell(33);
				 * cell.setCellValue(empError.getPersonDetails1().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(33); cell.setCellValue(empError.getPersonDetails1());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(34).setCellValue(empError.getPd1Relation()); if
				 * (empError.getPd1Relation() != null) { if
				 * (empError.getPd1Relation().endsWith("*")) { Cell cell = row.createCell(34);
				 * cell.setCellValue(empError.getPd1Relation().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(34); cell.setCellValue(empError.getPd1Relation());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(35).setCellValue(empError.getPd1ContactNumber()); if
				 * (empError.getPd1ContactNumber() != null) { if
				 * (empError.getPd1ContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(35);
				 * cell.setCellValue(empError.getPd1ContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(35); cell.setCellValue(empError.getPd1ContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(36).setCellValue(empError.getPd1AaltContactNumber()); if
				 * (empError.getPd1AaltContactNumber() != null) { if
				 * (empError.getPd1AaltContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(36);
				 * cell.setCellValue(empError.getPd1AaltContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(36); cell.setCellValue(empError.getPd1AaltContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(37).setCellValue(empError.getPersonDetails2()); if
				 * (empError.getPersonDetails2() != null) { if
				 * (empError.getPersonDetails2().endsWith("*")) { Cell cell =
				 * row.createCell(37);
				 * cell.setCellValue(empError.getPersonDetails2().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(37); cell.setCellValue(empError.getPersonDetails2());
				 * cell.setCellStyle(headerCellStyle); } }
				 * 
				 * // row.createCell(38).setCellValue(empError.getPd2Relation()); if
				 * (empError.getPd2Relation() != null) { if
				 * (empError.getPd2Relation().endsWith("*")) { Cell cell = row.createCell(38);
				 * cell.setCellValue(empError.getPd2Relation().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(38); cell.setCellValue(empError.getPd2Relation());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(39).setCellValue(empError.getPd2ContactNumber()); if
				 * (empError.getPd2ContactNumber() != null) { if
				 * (empError.getPd2ContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(39);
				 * cell.setCellValue(empError.getPd2ContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(39); cell.setCellValue(empError.getPd2ContactNumber());
				 * cell.setCellStyle(headerCellStyle); } } //
				 * row.createCell(40).setCellValue(empError.getPd2AaltContactNumber()); if
				 * (empError.getPd2AaltContactNumber() != null) { if
				 * (empError.getPd2AaltContactNumber().endsWith("*")) { Cell cell =
				 * row.createCell(40);
				 * cell.setCellValue(empError.getPd2AaltContactNumber().replace("*", ""));
				 * cell.setCellStyle(headerCellStyleSpl); } else { Cell cell =
				 * row.createCell(40); cell.setCellValue(empError.getPd2AaltContactNumber());
				 * cell.setCellStyle(headerCellStyle); } }
				 */				// row.createCell(41).setCellValue(empError.getCompanyName());
				if (empError.getCompanyName() != null) {
					if (empError.getCompanyName().endsWith("*")) {
						Cell cell = row.createCell(33);
						cell.setCellValue(empError.getCompanyName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(33);
						cell.setCellValue(empError.getCompanyName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(42).setCellValue(empError.getBranchName());
				if (empError.getBranchName() != null) {
					if (empError.getBranchName().endsWith("*")) {
						Cell cell = row.createCell(34);
						cell.setCellValue(empError.getBranchName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(34);
						cell.setCellValue(empError.getBranchName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(43).setCellValue(empError.getDepartmentName());
				if (empError.getDepartmentName() != null) {
					if (empError.getDepartmentName().endsWith("*")) {
						Cell cell = row.createCell(35);
						cell.setCellValue(empError.getDepartmentName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(35);
						cell.setCellValue(empError.getDepartmentName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(44).setCellValue(empError.getDesignationName());
				if (empError.getDesignationName() != null) {
					if (empError.getDesignationName().endsWith("*")) {
						Cell cell = row.createCell(36);
						cell.setCellValue(empError.getDesignationName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(36);
						cell.setCellValue(empError.getDesignationName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(45).setCellValue(empError.getSkillsList());
				if (empError.getSkillsList() != null) {
					if (empError.getSkillsList().endsWith("*")) {
						Cell cell = row.createCell(37);
						cell.setCellValue(empError.getSkillsList().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(37);
						cell.setCellValue(empError.getSkillsList());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(46).setCellValue(empError.getSecondarySkillsList());
				if (empError.getSecondarySkillsList() != null) {
					if (empError.getSecondarySkillsList().endsWith("*")) {
						Cell cell = row.createCell(38);
						cell.setCellValue(empError.getSecondarySkillsList().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(38);
						cell.setCellValue(empError.getSecondarySkillsList());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(47).setCellValue(empError.getManagar());
				if (empError.getManagar() != null) {
					if (empError.getManagar().endsWith("*")) {
						Cell cell = row.createCell(39);
						cell.setCellValue(empError.getManagar().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(39);
						cell.setCellValue(empError.getManagar());
						cell.setCellStyle(headerCellStyle);
					}
				}
				// row.createCell(48).setCellValue(empError.getRoles());
				if (empError.getRoles() != null) {
					if (empError.getRoles().endsWith("*")) {
						Cell cell = row.createCell(40);
						cell.setCellValue(empError.getRoles().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(40);
						cell.setCellValue(empError.getRoles());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(49).setCellValue(empError.getEmploymentType());
				if (empError.getEmploymentType() != null) {
					if (empError.getEmploymentType().endsWith("*")) {
						Cell cell = row.createCell(41);
						cell.setCellValue(empError.getEmploymentType().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(41);
						cell.setCellValue(empError.getEmploymentType());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (empError.getEmpTypeStartDate() != null) {
					row.createCell(42).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(42).setCellValue("");
				}
				if (empError.getEmpTypeEndDate() != null) {
					row.createCell(43).setCellValue(empError.getJoiningDate().toString());
				} else {
					row.createCell(43).setCellValue("");
				}
				/*
				 * row.createCell(0).setCellValue(empError.getFirstName());
				 * row.createCell(1).setCellValue(empError.getMiddleName());
				 * row.createCell(2).setCellValue(empError.getLastName());
				 * row.createCell(3).setCellValue(empError.getEmail());
				 * row.createCell(4).setCellValue(empError.getUserName()); if
				 * (empError.getDateOfBirth() != null) {
				 * row.createCell(5).setCellValue(empError.getDateOfBirth().toString()); } else
				 * { row.createCell(5).setCellValue(""); }
				 * row.createCell(6).setCellValue(empError.getMaritalStatus()); if
				 * (empError.getMarriageDay() != null) {
				 * row.createCell(7).setCellValue(empError.getMarriageDay().toString()); } else
				 * { row.createCell(7).setCellValue(""); }
				 * row.createCell(8).setCellValue(empError.getGender());
				 * row.createCell(9).setCellValue(empError.getContactNo());
				 * row.createCell(10).setCellValue(empError.getAlternateContactNo());
				 * row.createCell(11).setCellValue(empError.getAadharCard());
				 * row.createCell(12).setCellValue(empError.getPanCard());
				 * row.createCell(13).setCellValue(empError.getVoterID());
				 * row.createCell(14).setCellValue(empError.getPassportNo()); if
				 * (empError.getJoiningDate() != null) {
				 * row.createCell(15).setCellValue(empError.getJoiningDate().toString()); } else
				 * { row.createCell(15).setCellValue(""); }
				 * row.createCell(16).setCellValue(empError.getBloodGroup());
				 * row.createCell(17).setCellValue(empError.getPermanantAddress());
				 * row.createCell(18).setCellValue(empError.getPermanantLandmark());
				 * row.createCell(19).setCellValue(empError.getPermanantStreet());
				 * row.createCell(20).setCellValue(empError.getPermanantCity());
				 * row.createCell(21).setCellValue(empError.getPermanantDistrict());
				 * row.createCell(22).setCellValue(empError.getPermanantState());
				 * row.createCell(23).setCellValue(empError.getPermanantCountry());
				 * row.createCell(24).setCellValue(empError.getPermanantPincode());
				 * row.createCell(25).setCellValue(empError.getTemporaryAddress());
				 * row.createCell(26).setCellValue(empError.getTemporaryLandmark());
				 * row.createCell(27).setCellValue(empError.getTemporaryStreet());
				 * row.createCell(28).setCellValue(empError.getTemporaryCity());
				 * row.createCell(29).setCellValue(empError.getTemporaryDistrict());
				 * row.createCell(30).setCellValue(empError.getTemporaryState());
				 * row.createCell(31).setCellValue(empError.getTemporaryCountry());
				 * row.createCell(32).setCellValue(empError.getTemporaryPincode());
				 * 
				 * row.createCell(33).setCellValue(empError.getPersonDetails1());
				 * row.createCell(34).setCellValue(empError.getPd1Relation());
				 * row.createCell(35).setCellValue(empError.getPd1ContactNumber());
				 * row.createCell(36).setCellValue(empError.getPd1AaltContactNumber());
				 * 
				 * row.createCell(37).setCellValue(empError.getPersonDetails2());
				 * row.createCell(38).setCellValue(empError.getPd2Relation());
				 * row.createCell(39).setCellValue(empError.getPd2ContactNumber());
				 * row.createCell(40).setCellValue(empError.getPd2AaltContactNumber());
				 * 
				 * row.createCell(41).setCellValue(empError.getCompanyName());
				 * row.createCell(42).setCellValue(empError.getBranchName());
				 * row.createCell(43).setCellValue(empError.getDepartmentName());
				 * row.createCell(44).setCellValue(empError.getDesignationName());
				 * row.createCell(45).setCellValue(empError.getSkillsList());
				 * row.createCell(46).setCellValue(empError.getSecondarySkillsList());
				 * row.createCell(47).setCellValue(empError.getManagar());
				 * row.createCell(48).setCellValue(empError.getRoles());
				 * row.createCell(49).setCellValue(empError.getEmploymentType()); if
				 * (empError.getEmpTypeStartDate() != null) {
				 * row.createCell(50).setCellValue(empError.getJoiningDate().toString()); } else
				 * { row.createCell(50).setCellValue(""); } if (empError.getEmpTypeEndDate() !=
				 * null) {
				 * row.createCell(51).setCellValue(empError.getJoiningDate().toString()); } else
				 * { row.createCell(51).setCellValue(""); }
				 */
				for (int i = 0; i < BASICDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}
			Sheet sheet1 = workbook.createSheet(ExcelHeaders.EMP_EDUCATIONAL_DETAILS_SHEETNAME);
			// Row for Header
			Row headerRow1 = sheet1.createRow(0);

			// Header
			for (int col = 0; col < EDUCATIONALDETAILS.length; col++) {
				if (EDUCATIONALDETAILS[col].endsWith("*")) {
					Cell cell = headerRow1.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow1.createCell(col);
					cell.setCellValue(EDUCATIONALDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			int rowIdx1 = 1;
			for (AcadmicDetailsErrorRecords pdeError : educationList) {
				Row row = sheet1.createRow(rowIdx1++);
//				row.createCell(0).setCellValue(pdeError.getEmpFirstName());
				if (pdeError.getEmpFirstName() != null) {
					if (pdeError.getEmpFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getEmpContactNO());
				if (pdeError.getEmpContactNO() != null) {
					if (pdeError.getEmpContactNO().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getQualification());
				if (pdeError.getQualification() != null) {
					if (pdeError.getQualification().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getQualification().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getQualification());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(pdeError.getInstituteName());
				if (pdeError.getInstituteName() != null) {
					if (pdeError.getInstituteName().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getInstituteName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getQualification());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(4).setCellValue(pdeError.getYearOfPassing());
				if (pdeError.getYearOfPassing() != null) {
					if (pdeError.getYearOfPassing().endsWith("*")) {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getYearOfPassing().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(4);
						cell.setCellValue(pdeError.getYearOfPassing());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(5).setCellValue(pdeError.getType());
				if (pdeError.getType() != null) {
					if (pdeError.getType().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getType().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getType());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(6).setCellValue(pdeError.getPercentage());
				if (pdeError.getYearOfPassing() != null) {
					if (pdeError.getYearOfPassing().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getYearOfPassing().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getYearOfPassing());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(7);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(7);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < EDUCATIONALDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			Sheet sheet2 = workbook.createSheet(ExcelHeaders.EMP_EMERGENCY_CONTACT_DETAILS_SHEETNAME);

			// Row for Header
			Row headerRow2 = sheet2.createRow(0);

			// Header
			for (int col = 0; col < EMERGENCYCONTACTDETAILS.length; col++) {
				if (EMERGENCYCONTACTDETAILS[col].endsWith("*")) {
					Cell cell = headerRow2.createCell(col);
					cell.setCellValue(EMERGENCYCONTACTDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow2.createCell(col);
					cell.setCellValue(EMERGENCYCONTACTDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			int rowIdx2 = 1;
			for (EmergencyContactDetailErrorRecords pdeError : emergencyList) {
				Row row = sheet2.createRow(rowIdx2++);
//				row.createCell(0).setCellValue(pdeError.getEmpFirstName());
				if (pdeError.getEmpFirstName() != null) {
					if (pdeError.getEmpFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getEmpContactNO());
				if (pdeError.getEmpContactNO() != null) {
					if (pdeError.getEmpContactNO().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getContactPerson());
				if (pdeError.getContactPerson() != null) {
					if (pdeError.getContactPerson().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactPerson().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactPerson());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(pdeError.getContactNumber());
				if (pdeError.getContactNumber() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getContactNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getContactNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getAltContactNumber() != null) {
					row.createCell(4).setCellValue(pdeError.getAltContactNumber());
				}
//				row.createCell(5).setCellValue(pdeError.getRelation());
				if (pdeError.getRelation() != null) {
					if (pdeError.getRelation().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getRelation().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getRelation());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < EMERGENCYCONTACTDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}

			Sheet sheet3 = workbook.createSheet(ExcelHeaders.EMP_EXPRIENCE_DETAILS_SHEETNAME);

			// Row for Header
			Row headerRow3 = sheet3.createRow(0);

			// Header
			for (int col = 0; col < EXPRIENCEDETAILS.length; col++) {
				if (EXPRIENCEDETAILS[col].endsWith("*")) {
					Cell cell = headerRow3.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow3.createCell(col);
					cell.setCellValue(EXPRIENCEDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			int rowIdx3 = 1;
			for (ProfessionalDetailsErrorRecords pdeError : professionalList) {
				Row row = sheet3.createRow(rowIdx3++);
//				row.createCell(0).setCellValue(pdeError.getEmpFirstName());
				if (pdeError.getEmpFirstName() != null) {
					if (pdeError.getEmpFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getEmpContactNO());
				if (pdeError.getEmpContactNO() != null) {
					if (pdeError.getEmpContactNO().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getCompanyName());
				if (pdeError.getCompanyName() != null) {
					if (pdeError.getCompanyName().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getCompanyName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getCompanyName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getJoiningDate() != null) {
					row.createCell(3).setCellValue(pdeError.getJoiningDate().toString());
				} else {
					row.createCell(3).setCellValue("");
				}
				if (pdeError.getRelievingDate() != null) {
					row.createCell(4).setCellValue(pdeError.getRelievingDate().toString());
				} else {
					row.createCell(4).setCellValue("");
				}
//				row.createCell(5).setCellValue(pdeError.getExperience());
				if (pdeError.getExperience() != null) {
					if (pdeError.getExperience().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getExperience().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getExperience());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(6).setCellValue(pdeError.getClient());
				if (pdeError.getClient() != null) {
					if (pdeError.getClient().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getClient().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getClient());
						cell.setCellStyle(headerCellStyle);
					}
				}

				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(7);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(7);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < EXPRIENCEDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}

			}
			Sheet sheet4 = workbook.createSheet(ExcelHeaders.EMP_OFFICAL_MAIL_IDS_SHEETNAME);

			// Row for Header
			Row headerRow4 = sheet4.createRow(0);

			// Header
			for (int col = 0; col < OFFICALMAILIDS.length; col++) {
				if (OFFICALMAILIDS[col].endsWith("*")) {
					Cell cell = headerRow4.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow4.createCell(col);
					cell.setCellValue(OFFICALMAILIDS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}
			int rowIdx4 = 1;
			for (EmployeeMailErrorRecords pdeError : employeeMaillList) {
				Row row = sheet4.createRow(rowIdx4++);
//				row.createCell(0).setCellValue(pdeError.getEmpFirstName());
//				row.createCell(1).setCellValue(pdeError.getEmpContactNO());
//				row.createCell(2).setCellValue(pdeError.getOfficalMailId());
				if (pdeError.getEmpFirstName() != null) {
					if (pdeError.getEmpFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getEmpContactNO() != null) {
					if (pdeError.getEmpContactNO().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getOfficalMailId() != null) {
					if (pdeError.getOfficalMailId().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getOfficalMailId().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getOfficalMailId());
						cell.setCellStyle(headerCellStyle);
					}
				}

				for (int i = 0; i < OFFICALMAILIDS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}
			Sheet sheet5 = workbook.createSheet(ExcelHeaders.EMP_PERSONAL_CONTACT_DETAILS_SHEETNAME);

			// Row for Header
			Row headerRow5 = sheet5.createRow(0);

			// Header
			for (int col = 0; col < PERSONALCONTACTDETAILS.length; col++) {
				if (PERSONALCONTACTDETAILS[col].endsWith("*")) {
					Cell cell = headerRow5.createCell(col);
					cell.setCellValue(PERSONALCONTACTDETAILS[col].replace("*", ""));
					cell.setCellStyle(headerCellStyleSpl1);
				} else {
					Cell cell = headerRow5.createCell(col);
					cell.setCellValue(PERSONALCONTACTDETAILS[col]);
					cell.setCellStyle(headerCellStyle);
				}
			}

			// CellStyle for Age
			int rowIdx5 = 1;
			for (PersonalDetailsErrorRecords pdeError : personalContactDetailsList) {
				Row row = sheet5.createRow(rowIdx5++);
//				row.createCell(0).setCellValue(pdeError.getEmpFirstName());
				if (pdeError.getEmpFirstName() != null) {
					if (pdeError.getEmpFirstName().endsWith("*")) {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(0);
						cell.setCellValue(pdeError.getEmpFirstName());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(1).setCellValue(pdeError.getEmpContactNO());
				if (pdeError.getEmpContactNO() != null) {
					if (pdeError.getEmpContactNO().endsWith("*")) {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(1);
						cell.setCellValue(pdeError.getEmpContactNO());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(2).setCellValue(pdeError.getContactPerson());
				if (pdeError.getContactPerson() != null) {
					if (pdeError.getContactPerson().endsWith("*")) {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactPerson().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(2);
						cell.setCellValue(pdeError.getContactPerson());
						cell.setCellStyle(headerCellStyle);
					}
				}
//				row.createCell(3).setCellValue(pdeError.getContactNumber());
				if (pdeError.getContactNumber() != null) {
					if (pdeError.getContactNumber().endsWith("*")) {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getContactNumber().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(3);
						cell.setCellValue(pdeError.getContactNumber());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getAltContactNumber() != null) {
					row.createCell(4).setCellValue(pdeError.getAltContactNumber());
				}
//				row.createCell(5).setCellValue(pdeError.getRelation());
				if (pdeError.getRelation() != null) {
					if (pdeError.getRelation().endsWith("*")) {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getRelation().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(5);
						cell.setCellValue(pdeError.getRelation());
						cell.setCellStyle(headerCellStyle);
					}
				}
				if (pdeError.getIsDefault() != null) {
					if (pdeError.getIsDefault().endsWith("*")) {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault().replace("*", ""));
						cell.setCellStyle(headerCellStyleSpl);
					} else {
						Cell cell = row.createCell(6);
						cell.setCellValue(pdeError.getIsDefault());
						cell.setCellStyle(headerCellStyle);
					}
				}
				for (int i = 0; i < PERSONALCONTACTDETAILS.length; i++) {
					sheet.autoSizeColumn(i);
				}
			}

			workbook.write(out);
			logger.info("employee Details Error Records Excel file generated");
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

}



