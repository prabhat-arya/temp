package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfessionalDetailsDTO implements Serializable{

	
	private static final long serialVersionUID = 9027171518793670808L;

	private Long id;

	private String companyName;

	private Date joiningDate;

	private Date relievingDate;

	private String experience;

	private String client;
	
	private Boolean isDefault;
	
}
