package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmergencyContactDetailsDTO implements Serializable{

	
	private static final long serialVersionUID = 7909898176411477315L;

	private Long id;

	private String altContactNumber;

	private String contactNumber;

	private String contactPerson;

	private String relation;
	
	private Boolean isDefault;

	
}
