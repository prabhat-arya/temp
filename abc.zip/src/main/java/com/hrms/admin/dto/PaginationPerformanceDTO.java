package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaginationPerformanceDTO implements Serializable{

	
	
	private static final long serialVersionUID = 2055822565875232725L;
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;
	private String status;
	private Long projectId;
	private String managerName;

	
}
