package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeaveReportDTO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long employeeId;
	private String employeeName;
	private Date appliedDate;
	private String leaveType;
	private Date fromDate;
	private Date toDate;
	private Long leaveDays;

	private String csvAppliedDate;
	private String csvFromDate;
	private String csvToDate;
	
	public LeaveReportDTO(Long employeeId, String employeeName, String leaveType, Long leaveDays, String csvAppliedDate,
			String csvFromDate, String csvToDate) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.leaveType = leaveType;
		this.leaveDays = leaveDays;
		this.csvAppliedDate = csvAppliedDate;
		this.csvFromDate = csvFromDate;
		this.csvToDate = csvToDate;
	}
	
	
	
}
