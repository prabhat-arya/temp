package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResignationDTO implements Serializable {

	private static final long serialVersionUID = -3822154095502219322L;

	private Long resignationId;
	private Long empId;
	private String empName;
	private String designName;
	private String deptName;
	private Date resigSubDate;
	private Date tentLeaveDate;
	private String reason;
	private String description;
	private String reportMngr;
	private Integer noticePeriod;
	private String status;
	private String reasonForReject;
	private Boolean isChecked;
	private String reasonForEmpRevoke;
	private Date resignationApprovedDate;
	private Date revokeAppliedDate;
	private String reasonForManagerRevoke;
	private Date revokeApprovedDate;

}
