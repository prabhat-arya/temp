package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDTO implements Serializable {

	private static final long serialVersionUID = 9200627859311609496L;

	private long id;

	private String address;

	private String landmark;

	private String street;

	private Long city;

	private String district;

	private Long state;

	private String pincode;

	private Long country;

	private String type;

	private Long tcountry;
	private Long tstate;
	private Long tcity;
}
