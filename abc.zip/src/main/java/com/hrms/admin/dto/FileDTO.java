package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileDTO implements Serializable{

	
	private static final long serialVersionUID = -8188481924088701501L;
	private Long id;
	private String filename;
	private String filePath;
	private String folderName;
	private String fileType;
	private String certificateName;
	
}
