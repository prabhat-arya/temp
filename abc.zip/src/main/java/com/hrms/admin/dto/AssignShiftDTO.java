package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssignShiftDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private List<Long> empId;
	private Long employeeId;
	private String employeeName;
	private String date;
	private Long shiftId;
	private String shiftName;
	private String fromdate;
	private String todate;
	private String dayStatus;
	private String projectName;
	private Long projectId;
	private Long managerId;


	public AssignShiftDTO(Long shiftId, String shiftName) {
		super();
		this.shiftId = shiftId;
		this.shiftName = shiftName;
	}


	public AssignShiftDTO(Long id, String fromdate, String todate, Long managerId , Long shiftId, String shiftName) {
		super();
		this.id = id;
		this.shiftId = shiftId;
		this.shiftName = shiftName;
		this.fromdate = fromdate;
		this.todate = todate;
		this.managerId = managerId;
	}
	
}
