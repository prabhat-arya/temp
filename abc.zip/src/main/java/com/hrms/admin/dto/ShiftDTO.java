package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author SandeepJagiri
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShiftDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String companyId;
	private String companyName;
	private String inTime;
	private String outTime;
	private Boolean type;
	private Map<String, List<Integer>> weekofDays;
	private String shiftName;
	private Boolean isDelete;
	private Boolean isActive;
	private Boolean allowanceApplicable;
	private Double allowanceAmount;
	private Long locationId;

	

}
