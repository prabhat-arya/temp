package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class EmployeeBranchDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = -5730062657276787625L;
	private Long id;
	private String firstName;
	private String lastName;
	private String email;
	private String contactNo;
	private String designationName;
	private Date joiningDate;
	private Boolean isActive;
	private Boolean isDelete;
	public EmployeeBranchDTO(Long id, String firstName, String lastName, String email, String contactNo,
			String designationName, Date joiningDate, Boolean isActive, Boolean isDelete) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNo = contactNo;
		this.designationName = designationName;
		this.joiningDate = joiningDate;
		this.isActive = isActive;
		this.isDelete = isDelete;
	}
	
	
	
}
