package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class EmployeePageDTO implements Serializable{

	private static final long serialVersionUID = -361854944632235066L;
	private String select;
	private Long id;
	private String firstName;
	private String lastName;
	private String email;
	private String officalMail;
	private String contactNo;
	private Boolean isActive;
	private Boolean isApprove;
	private Boolean isDelete;
	private String designationName;
	private ProfileImageDTO profileimage;
	private Date joiningDate;
	private String departmentName;
	private String gender;
	private String employmentType;
	private Date empTypeStartDate;
	private Date empTypeEndDate;
	private Date exitDate;

	public EmployeePageDTO(Long id, String firstName, String lastName, String officalMail, String contactNo,
			Boolean isActive, String designationName, Date joiningDate, String departmentName, String gender) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
		this.contactNo = contactNo;
		this.isActive = isActive;
		this.designationName = designationName;
		this.joiningDate = joiningDate;
		this.departmentName = departmentName;
		this.gender = gender;
	}

	public EmployeePageDTO(Long id, String firstName, String lastName, String officalMail, String contactNo,
			Boolean isActive, String designationName, String departmentName, String gender ) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
		this.contactNo = contactNo;
		this.isActive = isActive;
		this.designationName = designationName;
		this.departmentName = departmentName;
		this.gender = gender;
	}

	public EmployeePageDTO(Long id, String firstName, String lastName, String officalMail,
			String contactNo, Boolean isActive, Boolean isApprove, Boolean isDelete, String designationName,
			Date joiningDate, String departmentName, String gender) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
		this.contactNo = contactNo;
		this.isActive = isActive;
		this.isApprove = isApprove;
		this.isDelete = isDelete;
		this.designationName = designationName;
		this.joiningDate = joiningDate;
		this.departmentName = departmentName;
		this.gender = gender;
	}
	
	public EmployeePageDTO(Long id,String firstName, String lastName, Boolean isActive, String designationName, String employmentType,
			Date empTypeStartDate, Date empTypeEndDate) {	
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.isActive = isActive;
		this.designationName = designationName;
		this.employmentType = employmentType;
		this.empTypeStartDate = empTypeStartDate;
		this.empTypeEndDate = empTypeEndDate;
	}

	public EmployeePageDTO(Long id, String firstName, String lastName, String designationName, Date joiningDate,
			Date exitDate) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designationName = designationName;
		this.joiningDate = joiningDate;
		this.exitDate = exitDate;
	}

	
}
