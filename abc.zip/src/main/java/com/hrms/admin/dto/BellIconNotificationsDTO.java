package com.hrms.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ramesh
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BellIconNotificationsDTO {

	private Long notificationId;

	private boolean notificationFlag;

	private Long approverId;

	private String notificationMenuPath;

	private String notificationType;

	private boolean employeeNotificationFlag;

	private Long employeeId;

	private String employeeName;

	private String notificationMessage;

	private String notificationDate;

	private String roleName;
}
