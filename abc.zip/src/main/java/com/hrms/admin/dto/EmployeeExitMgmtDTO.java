package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeExitMgmtDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long employeeExitId;
	private Long employeeId;
	private String employeeName;
	private Date hireDate;
	private Date lastWorkingDate;	
	private String status;
	@Valid
	private Set<ExitMgmtQuestionAnswersDTO> questionAnswers;

	
	
	
	
}
