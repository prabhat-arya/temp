package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author SandeepJagiri
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeReportDTO implements Serializable {

	private static final long serialVersionUID = 6983173039824174185L;
	private Long employeeId;
	private String employeeName;
	private ProfileImageDTO profileimage;
	private String mobileNumber;
	private String emailId;
	private String designation;
	private Boolean action;
	private String joinDate;
	private String isActive;
	private String department;
	private String gender;
	private String employmentType;
	private String empTypeStartDate;
	private String empTypeEndDate;
	
	
	
}
