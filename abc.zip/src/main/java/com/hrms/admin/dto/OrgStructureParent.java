package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrgStructureParent implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8480906847329676097L;
	private String label;
	private String type;
	private String styleClass;
	private OrgStructureData data;
	private List<OrgStructureChild> children;

	
}
