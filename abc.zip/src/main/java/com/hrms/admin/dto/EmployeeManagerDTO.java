package com.hrms.admin.dto;

import java.io.Serializable;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeManagerDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8041858409496389997L;

	private Long empId;
	private String empFirstName;
	private String empLastName;
	private String empOfficeMail;
	private Long managerId;
	private String managerFirstName;
	private String managerLastName;
	private String mangaerOfficeMmail;
	private String empDesignation;
	private String empDesignBand;
	private String companyId;

	public EmployeeManagerDTO(Long empId, String empFirstName, String empLastName, String empOfficeMail, Long managerId,
			String managerFirstName, String managerLastName, String mangaerOfficeMmail,String companyId) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empOfficeMail = empOfficeMail;
		this.managerId = managerId;
		this.managerFirstName = managerFirstName;
		this.managerLastName = managerLastName;
		this.mangaerOfficeMmail = mangaerOfficeMmail;
		this.companyId=companyId;
	}
	public EmployeeManagerDTO(Long empId, String empFirstName, String empOfficeMail, String empDesignation,
			String empDesignBand) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empOfficeMail = empOfficeMail;
		this.empDesignation = empDesignation;
		this.empDesignBand = empDesignBand;
	}


}
