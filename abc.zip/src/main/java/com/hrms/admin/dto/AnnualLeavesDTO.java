package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AnnualLeavesDTO implements Serializable{

	
	private static final long serialVersionUID = 4261962582811198563L;

	private Long id;

	private String gender;

	@NotNull(message = "designationId should not be Empty")
	private Long designationId;

	@NotNull(message = "leaveTypeId should not be Empty")
	private Long leaveTypeId;

	private String leaveTypeName;
	
	private Long annualLeaves;
	
	private Long initialLeaves;
	
	private String designationName;
	
	private Boolean isActive;
	
	private Boolean isDelete;

	
}
