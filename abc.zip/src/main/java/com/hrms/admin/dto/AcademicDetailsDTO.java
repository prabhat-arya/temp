package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AcademicDetailsDTO implements Serializable{

	
	private static final long serialVersionUID = -2628063570235611685L;

	private Long id;

	private String instituteName;

	private String yearOfPassing;

	private String percentage;
	
	private String type;
	
	private String qualification;
	
	private Boolean isDefault;



}
