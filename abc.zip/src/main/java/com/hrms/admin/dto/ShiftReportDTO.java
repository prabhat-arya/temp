package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShiftReportDTO implements Serializable {

	
	
	private static final long serialVersionUID = 1L;
	private Long employeeId;
	private String employeeName;
	private String EmailId;
	private String designation;
	private String department;
	private String projectName;
	private String shiftName;
	private String reportingManager;
	private String startDate;
	private String endDate;

	
}
