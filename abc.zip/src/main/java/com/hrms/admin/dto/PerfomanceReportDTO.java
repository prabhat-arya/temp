package com.hrms.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PerfomanceReportDTO {
	
	
	private Long employeeId;
	private String employeeName;
	private String designation;
	private String reviewMonth;
	private String submitedDate;
	private String reviewPeriod;
	private String status;
	private String reviewStart;
	private String reviewEnd;

	
}
