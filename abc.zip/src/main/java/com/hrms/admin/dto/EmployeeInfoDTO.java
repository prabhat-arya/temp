package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeInfoDTO implements Serializable {

	private static final long serialVersionUID = -4418986916608435017L;

	private Long id;

	@NotBlank(message = "first Name should not be Empty")
	// @Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String firstName;

	@NotBlank(message = "last Name should not be Empty")
	private String lastName;

	@Email(message = "Provide Proper Email")
	@Pattern(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", message = "Provide Proper Email")
	private String email;

	private String officalMail;

	@NotBlank(message = "user Name should not be Empty")
	// @Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String userName;

	@NotNull(message = "DOB must not be empty")
	private Date dateOfBirth;

	private Date marriageDate;

	@NotBlank(message = "gender should not be empty")
	private String gender;

	@NotBlank(message = "merital status should not be empty")
	private String maritalStatus;

	@NotBlank(message = "Mobile Number should not be empty")
	// @Size(min = 10, max = 10, message = "Mobile number must be 10 digits")
	private String contactNo;

	private String alternateContactNo;
	@NotBlank(message = "aadharCard should not be empty")
	// @Size(min = 12, max = 12, message = "Aadhaar Number must be 12 digits")
	private String aadharCard;

	@NotBlank(message = "panCard should not be empty")
	// @Size(min = 10, max = 10, message = "PanCard should be 10 digits")
	private String panCard;

	private String voterID;

	@NotNull(message = "joining Date should not be empty")
	private Date joiningDate;

	@NotNull(message = "blood Group should not be empty")
	private String bloodGroup;

	@NotNull(message = "departmentId should not be empty")
	private Long departmentId;
	private String departmentName;

	@NotNull(message = "designation Id should not be empty")
	private Long designationId;
	private String designationName;

	private Set<String> designation;

	@NotNull(message = "company Id should not be empty")
	private String companyId;
	private String companyName;

	@NotNull(message = "branch Id should not be empty")
	private Long branchId;
	private String branchName;
	private Map<String, Object> addresses = new HashMap<>();
	private List<AcademicDetailsDTO> academicDetails = new ArrayList<>();
//	private List<Long> skills = new ArrayList<>();
	private List<ProfessionalDetailsDTO> professionalDetails = new ArrayList<>();
	private List<EmergencyContactDetailsDTO> emergencyContactDetails = new ArrayList<>();
	private List<PersonalDetailsDTO> personalDetails = new ArrayList<>();
	private String middleName;
	private String passport;
	private Set<String> roles;
	@NotNull(message = "manager Id should not be empty")
	private Long managerId;
	private String managerName;
	private Long roleId;
	private Boolean isSameAddress;
	private Boolean isActive;
	private List<Long> primarySkills = new ArrayList<>();
	private List<Long> secondarySkills = new ArrayList<>();
	private Long employmentTypeId;
	private Date empTypeStartDate;
	private Date empTypeEndDate;
	private List<EmployeePromotionalDTO> employeePromotionalDetails = new ArrayList<>();
	private Boolean isExit;
	
	
	public EmployeeInfoDTO(Long id, String firstName, String lastName, String officalMail, String userName,
			Date dateOfBirth, String gender, String maritalStatus, String contactNo, String alternateContactNo,
			String aadharCard, String panCard, String voterID, Date joiningDate, String bloodGroup,
			String designationName, Boolean isActive) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
		this.userName = userName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.contactNo = contactNo;
		this.alternateContactNo = alternateContactNo;
		this.aadharCard = aadharCard;
		this.panCard = panCard;
		this.voterID = voterID;
		this.joiningDate = joiningDate;
		this.bloodGroup = bloodGroup;
		this.designationName = designationName;
		this.isActive = isActive;
	}

	// csvfields
	private String csvDateOfBirth;
	private String csvJoiningDate;
	private String name;

}
