package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpLeaveCountDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = -519333431690895097L;
	private Long totalLeaves;
	private Long pendingLeaves;
	private Long cancelLeaves;
	private Long approvedLeaves;
	private Long rejectedLeaves;
	
	
	
	
}
