package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubjectiveQuestions implements Serializable{
	private static final long serialVersionUID = -6403988706940106174L;
	
	private Long subjectiveQuestionId;
	@Size(min = 3, max = 2500, message = "Subjective Question Max should be 2500 characters.")
	private String subjectiveQuestion;
	
	

}
