package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Ramesh
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceInfoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long empId;
	private String employee;
	private String inTime;
	private String outTime;
	private String date;
	private String reason;
	private String noOfHrs;
	private String totalHrs;
	private String breakHrs;
	private Long attndsPercentage;
	private Long shiftId;
	private String shift;
	private String status;
	private String firstName;
	private String lastName;

	// csc variables
	private String csvInTime;
	private String csvOutTime;
	private String csvDate;

	public AttendanceInfoDTO(Long empId, String inTime, String outTime, String date, String reason, String noOfHrs,
			String totalHrs, String breakHrs, Long attndsPercentage, Long shiftId, String shift, String status,
			String firstName, String lastName) {
		super();
		this.empId = empId;

		this.inTime = inTime;
		this.outTime = outTime;
		this.date = date;
		this.reason = reason;
		this.noOfHrs = noOfHrs;
		this.totalHrs = totalHrs;
		this.breakHrs = breakHrs;
		this.attndsPercentage = attndsPercentage;
		this.shiftId = shiftId;
		this.shift = shift;
		this.status = status;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public AttendanceInfoDTO(Long empId, String firstName, String lastName, String date, String inTime, String outTime,
			String noOfHrs, String shift, String breakHrs) {
		super();
		this.empId = empId;
		this.inTime = inTime;
		this.outTime = outTime;
		this.date = date;
		this.noOfHrs = noOfHrs;
		this.shift = shift;
		this.firstName = firstName;
		this.lastName = lastName;
		this.breakHrs = breakHrs;
	}

	public AttendanceInfoDTO(Long empId, String employee, String reason, String noOfHrs, String totalHrs,
			String breakHrs, Long attndsPercentage, Long shiftId, String shift, String status, String firstName,
			String lastName, String csvInTime, String csvOutTime, String csvDate) {
		super();
		this.empId = empId;
		this.employee = employee;
		this.reason = reason;
		this.noOfHrs = noOfHrs;
		this.totalHrs = totalHrs;
		this.breakHrs = breakHrs;
		this.attndsPercentage = attndsPercentage;
		this.shiftId = shiftId;
		this.shift = shift;
		this.status = status;
		this.firstName = firstName;
		this.lastName = lastName;
		this.csvInTime = csvInTime;
		this.csvOutTime = csvOutTime;
		this.csvDate = csvDate;
	}

}
