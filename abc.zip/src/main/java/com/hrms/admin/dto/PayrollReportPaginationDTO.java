package com.hrms.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayrollReportPaginationDTO {
	
	
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;
	private String status;
	private Long departmentId;
	private Long designationId;
	private String salaryRange;
	private String fromDate;
	private String toDate;
	
}
