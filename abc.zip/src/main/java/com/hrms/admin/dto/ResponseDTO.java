package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDTO implements Serializable {

	private static final long serialVersionUID = 1225034391854416462L;
	private String message;
	private String status;
	private Object result;

	
	public ResponseDTO(String message, String status) {
		super();
		this.message = message;
		this.status = status;
	}

	

}
