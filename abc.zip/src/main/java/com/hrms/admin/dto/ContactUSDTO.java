package com.hrms.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContactUSDTO {

	private Long id;

	private String email;

	private String firstName;

	private Boolean isDelete;

	private String lastName;

	private String message;

	private Long phoneNumber;

	private Boolean status;

}
