package com.hrms.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttendPaginationDTO {
	
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;
	private String status;
	private Long projectId;
	private String date;
	
	

}
