package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaginationDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = 8733865172404900378L;
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;
	private String status;
	private Long projectId;
	private Long companyId;
	private Long managerId;
	private Long employmentTypeId;

	
}
