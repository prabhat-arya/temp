package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileImageDTO implements Serializable {
	
	
	private static final long serialVersionUID = 2179171876313994517L;
	private Long id;
	private String	imageName;
	private String  imageurl;
	private String fileType;

	
}
