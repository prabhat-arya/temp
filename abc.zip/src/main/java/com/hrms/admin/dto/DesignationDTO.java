package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DesignationDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	@NotBlank(message = "designation should not be Empty")
	@Size(min = 2, max = 25, message = "designation should contain 2 to 25 characters")
	private String designation;

	@NotBlank(message = "skills should not be Empty")
	@Size(min = 2, max = 5000, message = "skills should contain 2 to 5000 character")
	private String skills;

	@NotBlank(message = "experiance should not be empty")
	private String experiance;

	private Long departmentId;

	private String departmentName;

	@NotNull(message = "branch Id should not be empty")
	private Long branchId;

	@NotNull(message = "company Id should not be empty")
	private String companyId;

	private String branchName;
	private String companyName;
	private Boolean isDelete;
	private Boolean isActive;
	private String band;
	private Long designationBandsId;

	public DesignationDTO(Long id,
			@Size(min = 2, max = 25, message = "designation should contain 2 to 25 characters") String designation,
			@Size(min = 2, max = 5000, message = "skills should contain 2 to 5000 character") String skills,
			String experiance, String companyName, String branchName, String departmentName, Long departmentId,
			@NotNull(message = "branch Id should not be empty") Long branchId,
			@NotNull(message = "company Id should not be empty") String companyId, Boolean isDelete, Boolean isActive) {
		super();
		this.id = id;
		this.designation = designation;
		this.skills = skills;
		this.experiance = experiance;
		this.companyName = companyName;
		this.branchName = branchName;
		this.departmentName = departmentName;
		this.departmentId = departmentId;
		this.branchId = branchId;
		this.companyId = companyId;
		this.isDelete = isDelete;
		this.isActive = isActive;
	}

}
