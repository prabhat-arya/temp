package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = -3949704108800186651L;
	
	private Long id;
	@NotBlank(message = "name should not be Empty")
	@Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String name;

	@Email(message = "Provide Proper Email")
	@Pattern(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", message = "Provide Proper Email")
	private String mailId;

}
