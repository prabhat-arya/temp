package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class WishesDTO implements Serializable{
	
	
	private static final long serialVersionUID = -8492961007324608351L;
	private Long empId;
	private String type;
	private String teamName;
	private String date;
	private String reason;
	private String phone;
	private String fax;
	private String email;

}
