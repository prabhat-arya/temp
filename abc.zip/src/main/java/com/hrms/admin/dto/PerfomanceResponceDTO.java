package com.hrms.admin.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class PerfomanceResponceDTO {

	private Long employeeId;

	private Date reviewStart;

	private Date reviewEnd;

	private Date assignDate;

	private String managerStatus;

	private Date completedDate;

	private String designation;

	private String firstName;

	private String lastName;

	
}
