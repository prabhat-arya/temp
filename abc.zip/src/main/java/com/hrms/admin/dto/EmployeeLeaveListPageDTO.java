package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeLeaveListPageDTO implements Serializable{

	
	
	private static final long serialVersionUID = -7407236201590363249L;
	private String date;
	private String inTime;
	private String outTime;
	private String status;
	private Long empId;
	private String employee;
	private String noOfHrs;

	
}
