package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PasswordDTO implements Serializable {

	private static final long serialVersionUID = -7291536578608009854L;

	private String oldPassword;

	@Valid
	private String newPassword;

	@Valid
	private String confirmPassword;
	
	private String loggedUser;
	
	private String token;
	
	private String email;

}
