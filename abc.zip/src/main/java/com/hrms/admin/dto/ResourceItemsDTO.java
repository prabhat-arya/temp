package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResourceItemsDTO implements Serializable {

	private static final long serialVersionUID = -5478321610417189775L;
	private long id;
	@NotNull(message = "asset Id should not be empty")
	private Long assetId;
	private String value;

	@NotBlank(message = "Name should not be Empty")
	@Size(min = 2, max = 25, message = "Name should contain 2 to 25 characters")
	private String name;

	private String description;

	public ResourceItemsDTO(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

}
