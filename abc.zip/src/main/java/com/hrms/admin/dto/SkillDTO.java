package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkillDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	@NotBlank(message = "skillset should not be empty")
	@Size(min = 2, max = 25, message = "skillset should contain 2 to 25 characters")

	private String skillSet;

	private String description;

	@NotNull(message = "company Id should not be empty")
	private String companyId;

	private String companyName;
	private Boolean isActive;

	private Boolean isDelete;

	public SkillDTO(Long id,
			@Size(min = 3, max = 100, message = "skill set should contain 3 to 100 characters") String skillSet,
			String description, @NotNull(message = "company Id should not be empty") String companyId,
			String companyName) {
		super();
		this.id = id;
		this.skillSet = skillSet;
		this.description = description;
		this.companyId = companyId;
		this.companyName = companyName;
	}

}
