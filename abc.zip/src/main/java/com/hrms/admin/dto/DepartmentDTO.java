package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class DepartmentDTO  implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long id;
	@NotBlank(message = "Name should not be Empty")
	@Size(min = 2, max = 25, message = "Name should contain 2 to 25 character")
	private String name;

	private String description;

	@NotNull(message = "branch id should not be Empty")
	private Long branchId;

	@NotNull(message = "company id should not be Empty")
	private String companyId;
	private String branchName;
	private String companyName;
	private Boolean isDelete;
	private Boolean isActive;
	
	public DepartmentDTO(Long id,
			@Size(min = 2, max = 25, message = "Name should contain 2 to 25 character") String name, String description,
			@NotNull(message = "branch id should not be Empty") Long branchId,
			@NotNull(message = "company id should not be Empty") String companyId, String branchName, String companyName,
			Boolean isDelete, Boolean isActive) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.branchId = branchId;
		this.companyId = companyId;
		this.branchName = branchName;
		this.companyName = companyName;
		this.isDelete = isDelete;
		this.isActive = isActive;
	}
	
}
