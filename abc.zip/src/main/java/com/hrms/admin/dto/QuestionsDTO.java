package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionsDTO implements Serializable{
	
	private static final long serialVersionUID = -4108532069494882210L;
	
	private Long questionId;
	private String boxQuestion;
	private String radioQuestion;
	private String radioQuestionComment;
	private String companyId;
	public List<SubjectiveQuestions> subjective;
	public List<ObjectiveQuestions> objective;
	public List<SubjectiveQuestions> defaultsubjective;
	public List<ObjectiveQuestions> defaultobjective;
	
}
