package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeOrgDTO implements Serializable{
	
	
	private static final long serialVersionUID = 3523677253879318598L;
	protected Long id;
	protected String name;
	protected String designation;	
	protected String email;
	protected Long managerId;
	protected List<EmployeeOrgDTO> childs;
	
}
