package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.lang.Nullable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpLeaveDTO implements Serializable {

	private static final long serialVersionUID = -676454716605940991L;

	private Long id;
	@NotNull(message = "employeeId should not empty")
	private Long employeeId;

	private Long leaveTypeId;

	private String leaveType;

	private Date startDate;

	private Date endDate;

	private Date leaveApplyDate;

	private Long totalDays;

	private String reason;

	private String emailId;

	private String status;

	private Long managerId;

	private String remark;

	private String employeeName;

	private Boolean isDelete;

	private Boolean isActive;

	private String attachmentId;

	private String fileType;

	private String name;

	@Nullable
	private String reportingManager;
	
	private Long notificationId;
	
	@NotNull(message = "reasonLeaveCancel should not empty")
	private String reasonLeaveCancel;
}
