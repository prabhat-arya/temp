package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttendancePaginationDto implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long empId;
	private String fromDate;
	private String toDate;
	private Long shiftId;
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;

	
}
