package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDTO implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	private Long id;

	@NotBlank(message = "subject should not be Empty")
	private String subject;

	@NotBlank(message = "description should not be Empty")
	private String description;

	@NotNull(message = "event Date should not be empty")
	private Date eventDate;

	private String toMail;

	@NotNull(message = "company id should not be empty")
	private String companyId;

	private String companyName;

	@NotBlank(message = "Email should not be Empty")
	private String fromMail;

	private Boolean isActive;

	private Boolean isDelete;

}
