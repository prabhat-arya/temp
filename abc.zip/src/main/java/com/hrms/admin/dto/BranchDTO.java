package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BranchDTO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long id;
	@NotBlank(message = "Name should not be Empty")
	@Size(min = 2, max = 50, message = "Name should contain 2 to 50 characters")
	private String name;

	@Size(min = 10, max = 10, message = "Mobile number must be 10 digits")
	private String contactNo;

	@Email(message = "Provide Proper Email")
	@Pattern(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", message = "Provide Proper Email")
	private String email;

	private String fax;
	@NotNull(message = "companyId must not be empty")
	private String companyId;
	@Valid
	private AddressDTO address;

	private String companyName;

	private Boolean isDelete;

	private Boolean isActive;

	private Map<String, List<Integer>> weekend;

	
	public BranchDTO(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	
}
