package com.hrms.admin.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDTO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private String id;
	@NotBlank(message = "name should not be Empty")
	@Size(min = 4, max = 50, message = "name should contain 4 to 50 character")
	private String name;

	@Size(min = 10, max = 10, message = "Mobile number must be 10 digits")
	private String contact;

	@Email(message = "Provide Proper Email")
	@Pattern(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", message = "Provide Proper Email")
	private String email;
	private String website;

	@Valid
	private AddressDTO address;
	private Boolean isDelete;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	private String branch;

	private String location;

	private String tanNumber;

	private String panNumber;

	private String gstNumber;

	private String contactPerson;

	/*
	 * private byte[] image;
	 * 
	 * private String contantType;
	 */
	
//	private String attechementId;
	
	private ProfileImageDTO image;
}
