package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrgStructureData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6043586556207936856L;
	private Long id;
	private Long managerid;
	private String name;
	private String email;
	private String departmentname;
	private String count;

	
}
