package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttendanceDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private String companyName;
	private String branchName;
	private String companyId;
	private Long branchId;
	private String inTime;
	private String outTime;
	private Boolean isDelete;
	private Boolean isActive;
	private Long defaultShiftId;
	private List<Long> shiftIds;
	private String shiftName;
	private Boolean isDefault;
	private Long shiftId;

	

}
