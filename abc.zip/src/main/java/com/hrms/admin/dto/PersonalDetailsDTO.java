package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonalDetailsDTO implements Serializable{

	
	private static final long serialVersionUID = 8700529157074150362L;

	private Long id;

	private String personName;

	private String relation;

	private String contactNumber;

	private String altContactNumber;
	
	private Boolean isDefault;

	
}
