package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDTO implements Serializable {

	private static final long serialVersionUID = -2682133534587124625L;

	private Long id;

	@Email(message = "Provide Proper Email")
	@Pattern(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", message = "Provide Proper Email")
	private String email;

	@NotBlank(message = "first Name should not be Empty")
	// @Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String firstName;

	@NotBlank(message = "last Name should not be Empty")
	// @Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String lastName;

	@NotBlank(message = "user Name should not be Empty")
	// @Size(min = 2, max = 25, message = "name should contain 2 to 25 character")
	private String userName;

	@NotNull(message = "DOB must not be empty")
	private Date dateOfBirth;

	private String officalMail;

	private Date marriageDate;

	@NotBlank(message = "merital status should not be empty")
	private String maritalStatus;

	@NotBlank(message = "gender should not be empty")
	private String gender;

	// @Size(min = 10, max = 10, message = "Mobile number must be 10 digits")
	private String alternateContactNo;

	@Size(min = 12, max = 12, message = "Aadhaar Number must be 12 digits")
	private String aadharCard;

	@NotBlank(message = "Mobile Number should not be empty")
	@Size(min = 10, max = 10, message = "Mobile number must be 10 digits")
	private String contactNo;

	@NotBlank(message = "panCard should not be empty")
	@Size(min = 10, max = 10, message = "PanCard should be 10 digits")
	private String panCard;

	@NotNull(message = "blood Group should not be empty")
	private String bloodGroup;

	@NotNull(message = "departmentId should not be empty")
	private Long departmentId;

	@NotBlank(message = "voterID should not be empty")
	@Size(min = 10, max = 10, message = "voterID should be 10 digits")
	private String voterID;

	@NotNull(message = "joining Date should not be empty")
	private Date joiningDate;

	@NotNull(message = "designation Id should not be empty")
	private Long designationId;

	@NotNull(message = "company Id should not be empty")
	private String companyId;

	private String companyName;

	@NotNull(message = "branch Id should not be empty")
	private Long branchId;
	private String branchName;

	private String departmentName;

	private Set<String> roles;

	private String designationName;

	@NotNull(message = "manager Id should not be empty")
	private Long managerId;
	private String managerName;
	private Boolean isActive;
	private Boolean isApprove;
	private Boolean isDelete;
	private String folderName;
	private Double ctc;
	private String ipAddress;
	private String port;
	private String middleName;
	private String passport;

	private BankDTO bankDetail;
	private ProfileImageDTO profileimage;
	private Map<String, Object> addresses = new HashMap<>();
	private List<AcademicDetailsDTO> academicDetails = new ArrayList<>();
	private List<FileDTO> files = new ArrayList<>();
	private List<ProjectDTO> projects;
	private List<PolicyDTO> policies;
//	private List<Long> skills;
	private List<ResourceItemsDTO> resourceItems;
	private List<ProfessionalDetailsDTO> professionalDetails;
	private List<EmergencyContactDetailsDTO> emergencyContactDetails = new ArrayList<>();
	private List<PersonalDetailsDTO> personalDetails = new ArrayList<>();
	private String schedule;
	private Long roleId;
	private Boolean isSameAddress;
	private List<Long> primarySkills;
	private List<Long> secondarySkills;

	private List<EmployeePromotionalDTO> employeePromotionalDetails = new ArrayList<>();

	private Long employmentTypeId;
	private Date empTypeStartDate;
	private Date empTypeEndDate;

}