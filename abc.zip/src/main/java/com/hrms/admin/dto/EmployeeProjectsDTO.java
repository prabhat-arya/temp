package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeProjectsDTO implements Serializable{
	
	
	private static final long serialVersionUID = -8236069800378464491L;

	private Long projectId;
	private String projectName;
	private String projectDescription;
	
}
