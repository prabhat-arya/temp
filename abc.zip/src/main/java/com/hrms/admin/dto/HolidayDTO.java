package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HolidayDTO  implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long id;
	@NotBlank(message = "Name should not be Empty")
	//@Size(min = 2, max = 50, message = "Name should contain 2 to 50 characters")
	private String name;

	@NotNull(message = "date should not be Empty")
	private Date date;

	@NotNull(message = "company Id should not be empty")
	private String companyId;

	@NotNull(message = "branch Id should not be empty")
	private Long branchId;
	private String companyName;
	private String branchName;
	private Boolean isActive;
	private Boolean isDelete;
	private String day;
	private ProfileImageDTO image;

	
}
