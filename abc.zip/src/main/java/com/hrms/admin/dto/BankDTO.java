package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BankDTO implements Serializable  {

	
	private static final long serialVersionUID = 489778899436400440L;

	private Long id;

	@NotBlank(message = "Bank Name should not be Empty")
	@Size(min = 2, max = 25, message = "Bank Name should be 2 to 25 character Long")
	private String bankName;

	@NotBlank(message = "Account Number should not be Empty")
	private String accountNo;

	@NotBlank(message = "Account Holder Name should not be Empty")
	@Size(min = 2, max = 25, message = "Account Holder Name should be 2 to 25 character Long")
	private String accountHolderName;

	@NotBlank(message = "ifscCode should not be Empty")
	private String ifscCode;

	@NotBlank(message = "branch Name should not be Empty")
	@Size(min = 2, max = 25, message = "branch Name should be 2 to 25 character Long")
	private String branchName;

	private String esicNumber;

	private String pfNumber;

	private String uanNumber;

	
}
