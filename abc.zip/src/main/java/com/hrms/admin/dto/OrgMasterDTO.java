/*
 * package com.hrms.admin.dto;
 * 
 * import java.io.Serializable;
 * 
 * import javax.validation.constraints.NotNull; import
 * javax.validation.constraints.Pattern; import
 * javax.validation.constraints.Size;
 * 
 * import org.hibernate.validator.constraints.Email; import
 * org.hibernate.validator.constraints.NotBlank;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.NoArgsConstructor;
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor public class OrgMasterDTO implements Serializable {
 * 
 * private static final long serialVersionUID = 1L; private Long userId;
 * 
 * private String firstName;
 * 
 * private String lastName;
 * 
 * private String mobileNo;
 * 
 * @Email(message = "Provide Proper Email")
 * 
 * @Pattern(regexp =
 * "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$",
 * message = "Provide Proper Email") private String email;
 * 
 * private String address;
 * 
 * @NotNull(message = "company Name should not be empty") private String
 * companyName;
 * 
 * @NotNull(message = "company Id should not be empty") private Long countryId;
 * 
 * @NotBlank(message = "UserName should not be empty")
 * 
 * @Size(min = 2, max = 25, message =
 * "UserName should contain 2 to 25 characters") private String userName;
 * 
 * 
 * }
 */