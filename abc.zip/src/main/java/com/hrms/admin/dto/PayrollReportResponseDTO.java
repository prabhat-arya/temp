package com.hrms.admin.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PayrollReportResponseDTO {

	private Long employeeId;
	private String firstName;
	private String lastName;
	private String departmentName;
	private String designationName;
	private Double ctc;
	private Double monthlySalary;
	private Date joiningDate;
	
	public PayrollReportResponseDTO(Long employeeId, String firstName, String lastName, Double ctc, Date joiningDate) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ctc = ctc;
		this.joiningDate =joiningDate;
	}
	public PayrollReportResponseDTO(Long employeeId, String firstName, String lastName, Double ctc) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ctc = ctc;
	}
	
	private String csvCtc;
	private String csvMonthlySalary;
	
	
}

