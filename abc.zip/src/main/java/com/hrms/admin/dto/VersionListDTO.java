package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class VersionListDTO implements Serializable{

	
	private static final long serialVersionUID = -1551417959853750834L;
	
	private String attachmentLink;
	private String version;
	private Long id;
	private String name;
	private Boolean isActive;
	private Boolean isDelete;
	private Date updatedDate;
	private String fileType;
	
}
