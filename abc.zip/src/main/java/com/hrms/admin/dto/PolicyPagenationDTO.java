package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyPagenationDTO implements Serializable {

	
	private static final long serialVersionUID = 7962669066441457444L;

	private Long id;

	private String name;
	private String companyId;
	private String companyName;
	private Boolean isActive;
	private Boolean isDelete;
	private String attachmentLink;
	private String version;
	private Date updatedDate;
	private String fileType;
	private List<VersionListDTO> versionList;

	

}
