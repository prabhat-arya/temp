package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExitFeedbackDTO implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	private Long feedbackId;
	private Long exitId;
	private Date submitDate;
	private String feedback;
//	private String submission;
	private String signature;
	private String department;
	private String designation;
	private List<FeedBackFromFileDetailsDTO> feedBackFromFileDetails;
	private String status;
	private String isSubmit;
	private Long employeeExitMgmtId;
	private List<Long> submission;
	
}
