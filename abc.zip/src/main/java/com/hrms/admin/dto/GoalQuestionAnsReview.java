package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GoalQuestionAnsReview implements Serializable{

	private static final long serialVersionUID = 1L;
	private Long questionId;
	@NotBlank(message = "Goal Can't be Empty")
	@Size(min = 3, max = 2500, message = "Limitation is 3-2500 characters")
	private String question;
	@Size(max = 2500, message = "Limitation is 2500 characters")
	private String employeeAnswer;
	@Size(max = 2500, message = "Limitation is 2500 characters")
	private String managerAnswer;
	private Double employeeReview;
	private Double managerReview;
	@Size(max = 2500, message = "Limitation is 2500 characters")
	private String reviwerAnswer;
	private Double reviwerReview;

	
}
