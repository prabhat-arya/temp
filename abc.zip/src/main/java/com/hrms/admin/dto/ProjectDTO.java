package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDTO implements Serializable {

	
	private static final long serialVersionUID = 6099435226390783246L;

	private Long id;

	@NotBlank(message = "Name must not be Empty")
	@Size(min = 2, message = "Name length greater then 2")
	private String name;

	private String description;

	private List<ProjectEmployeeListDTO> employeeDtoList;

	@NotNull(message = "company Id should not be empty")
	private String companyId;
	private String companyName;

	private Long branchId;
	private String branchName;

	private Boolean isDelete;

	private String status;

	private String remarks;

	private String clientName;

	private String startDate;

	private String endDate;

	private Long estimatedHours;

	private Boolean isActive;

	public Boolean getIsDelete() {
		return isDelete;
	}

	public ProjectDTO(Long id, @Size(min = 2, message = "Name length greater then 2") String name,
			@NotNull(message = "company Id should not be empty") String companyId, String companyName, String startDate, String endDate, Long estimatedHours) {
		super();
		this.id = id;
		this.name = name;
		this.companyId = companyId;
		this.companyName = companyName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.estimatedHours = estimatedHours;
	}	
	
}
