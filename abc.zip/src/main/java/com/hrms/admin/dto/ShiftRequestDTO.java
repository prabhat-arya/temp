package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShiftRequestDTO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private Long id;
	private String fromdate;
	private String todate;
	private String currentShift;
	private Long requestShiftId;
	private String requestShiftName;
	private String status;
	//private String remarks;
	private String reason;
	private Long employeeId;
	private String employeeName;
	private String remark;

}
