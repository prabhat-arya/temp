package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResourceDTO implements Serializable{

	
	private static final long serialVersionUID = -1909434223927846136L;

	private Long employeeId;
	
	@NotBlank(message = "ipAddress should not be empty")
	@Size(min = 15, max = 15, message = "ipAddess should be 15 digits")
	private String ipAddress;
	
	@NotBlank(message = "port should not be empty")
	@Size(min = 4, max = 5, message = "port should be 15 digits")
	private Long port;
	
	
}
