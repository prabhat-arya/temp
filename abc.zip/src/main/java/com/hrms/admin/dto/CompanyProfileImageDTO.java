/*
 * package com.hrms.admin.dto;
 * 
 * import java.io.Serializable; import java.util.Date;
 * 
 * import com.hrms.admin.entity.CompanyProfileImage;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.NoArgsConstructor;
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor public class CompanyProfileImageDTO implements
 * Serializable {
 * 
 * 
 *//**
	* 
	*//*
		 * private static final long serialVersionUID = -4355437393880168279L;
		 * 
		 * private byte[] imagedata;
		 * 
		 * private String contantType; private String imageName; private String
		 * fileType;
		 * 
		 * }
		 */