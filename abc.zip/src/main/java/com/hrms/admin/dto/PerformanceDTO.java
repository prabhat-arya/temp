package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PerformanceDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long perfomanceId;
	private String departmentName;
	private Long employeeId;
	private String employeeName;
	private Integer period;
	@Valid
	private List<GoalQuestionAnsReview> goalQuestionsDto;
	private Date reviewStart;
	private Date reviewEnd;
	private Date dueDate;
	private String reviewManager;
	private Date assignDate;
	private String employeeStatus;
	private String managerStatus;
	private String finalComment;
	private String finalRating;
	private Date completedDate;
	private Boolean tempSave;
	private String reviwerStatus;
	private String hrReviewer;
	private String hrFinalComment;
	private String hrFinalRating;
	private Date HrCompletedDate;
	private String reviwerComment;
	private String reviwerRating;
	private String reviwercompletedDate;
	private Long reviewerId;
	private String reviwerName;

}
