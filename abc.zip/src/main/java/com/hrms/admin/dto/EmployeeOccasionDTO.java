package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeOccasionDTO implements Serializable {
	
	
	private static final long serialVersionUID = 8517259595811882704L;
	private String firstName;
	private String lastName;
	private String email;
	private String occasionDay;
	private String occasion;
	private ProfileImageDTO image;
	
}
