package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeaveTypeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String description;

	@NotNull(message = "leaveType should not be Empty")
	private String leaveType;

	@NotNull(message = "company Id should not be Empty")
	private String companyId;

	private Long branchId;

	private String companyName;

	private String branchName;
	private Boolean isActive;
	private Boolean isDelete;
	private Long annualLeaves;
	private Boolean isCarryForward;
	private Long monthlyLeaves;
	private Boolean isDocumentReq;

}