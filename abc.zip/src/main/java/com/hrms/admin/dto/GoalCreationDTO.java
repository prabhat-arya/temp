package com.hrms.admin.dto;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GoalCreationDTO {

	private Long goalId;
	private Long departmentId;
	private String departmentName;
	private Long employeeId;
	private String employeeName;
	private Integer period;
	@Valid
	private List<GoalQuestionAnsReview> goalQuestionsDto;
	private Date reviewStart;
	private Date reviewEnd;
	private Date dueDate;
	private String reviewManager;
	private Date assignDate;
	private String status;

	
}
