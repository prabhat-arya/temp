package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PolicyDTO implements Serializable {

	private static final long serialVersionUID = -7508355256312624795L;

	private Long id;
	private String name;
	private String description;
	private String attachmentLink;
	private String companyId;
	private String version;
	private String fileType;
	private String companyName;
	private Boolean isActive;
	private Boolean isDelete;
	private Date updatedDate;

	public PolicyDTO(Long id, String name, String description, String attachmentLink) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.attachmentLink = attachmentLink;
	}

	public PolicyDTO(Long id, String name, String description, String attachmentLink, String companyId, String version,
			String fileType, String companyName, Boolean isActive, Boolean isDelete, Date updatedDate) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.attachmentLink = attachmentLink;
		this.companyId = companyId;
		this.version = version;
		this.fileType = fileType;
		this.companyName = companyName;
		this.isActive = isActive;
		this.isDelete = isDelete;
		this.updatedDate = updatedDate;
	}

}
