package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class OfficeUseOnlyDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = -5642193721627012130L;
	private BankDTO bankDetail;
	private Double ctc;
	private String esicNumber;
	private String pfNumber;
	private String uanNumber;
	private Long empId;

	
}
