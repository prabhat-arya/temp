package com.hrms.admin.dto;

import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeExitBoxQuesAnsDTO {
	
	private Long questionId;
	private String boxQuestion;
	@Size(max = 1000, message = "Maximum 1000 characters allowed..")
	private String boxAnswer;
	
	
	
	

}
