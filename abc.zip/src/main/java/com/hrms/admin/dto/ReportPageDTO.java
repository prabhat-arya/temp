package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportPageDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = 7543679957941172387L;
	private String sortBy;
	private int pageSize;
	private int pageIndex;
	private String searchKey;
	private String orderBy;
	private String status;
	private String startDate;
	private String endDate;
	private Long projectId;
	private Long shiftId;
	private String gender;
	private Long departmentId;
	private Long designationId;
	private Long employmentTypeId;

	
}
