package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MailDTO implements Serializable{

	
	private static final long serialVersionUID = 4043552931170552511L;
	private String name;
	private String to;
	private String subject;
	private String template;
	private String from;
	private String companyId;

	
}
