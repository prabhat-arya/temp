package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssetsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String companyName;

	private Boolean isDelete;

	private Boolean isActive;

	@NotBlank(message = "Name should not be Empty")
	@Size(min = 2, max = 25, message = "Name should 2 to 25 character long")
	private String name;
	private String description;
	private String companyId;

	public AssetsDTO(Long id, String companyName, Boolean isDelete, Boolean isActive,
			@Size(min = 2, max = 25, message = "Name should 2 to 25 character long") String name, String description,
			String companyId) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.isDelete = isDelete;
		this.isActive = isActive;
		this.name = name;
		this.description = description;
		this.companyId = companyId;
	}

}
