package com.hrms.admin.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeBankDTO implements Serializable{
	
	
	
	private static final long serialVersionUID = -258052434163891687L;
	private Long id;
	private String firstName;
	private String LastName;
	private Double ctc;
	
	private BankDTO bank;

	
}
