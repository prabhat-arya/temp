package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeExitMgmtShowDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Long employeeExitId;
	private Long employeeId;
	private Date hireDate;
	private Date lastWorkingDate;
	private List<ExitMgmtQuestionAnswersDTO>  questionAnswers;
	private String employeeName;
	private Long departmentId;
	private String departmentName;
	private String managerName;
	private Long managerId;
	private String designation;

	
	
	
}
