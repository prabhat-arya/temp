package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	@NotBlank(message = "Job Name should not be Empty")
	@Size(min = 3, max = 100, message = "Job Name should contain 3 to 100 characters")
	private String name;

	private String description;

	@NotNull(message = "experience should not be empty")
	private String experience;

	@NotNull(message = "company Id should not be empty")
	private String companyId;

	private String companyName;

	@NotNull(message = "branch Id should not be empty")
	private Long branchId;

	private String branchName;
	private Boolean isActive;
	private Boolean isDelete;

	public JobDTO(Long id, String name, String description, String experience, String companyId, String companyName,
			Long branchId, String branchName) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.experience = experience;
		this.companyId = companyId;
		this.companyName = companyName;
		this.branchId = branchId;
		this.branchName = branchName;
	}

}
