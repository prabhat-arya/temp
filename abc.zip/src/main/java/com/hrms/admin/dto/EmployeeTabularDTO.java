package com.hrms.admin.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeTabularDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String firstName;
	private String lastName;
	private String officalMail;
	private String userName;
	private Date dateOfBirth;
	private String contactNo;
	private String panCard;
	private Date joiningDate;
	private String bloodGroup;
	private String aadharCard;
	private String companyName;
	private String branchName;
	private String departmentName;
	private String designationName;
	private String employmentType;
	private String reportingTo;
	private String profileImageUrl;
	private String emergencyContactNumber;
	private String emergencyContactPerson;
	private String professionalCompanyName;
	private Date professionalJoiningDate;
	private Date professionalDateOfRelieving;
	private String professionalExperience;
	private String professionalClientName;
	private String empDesignation;
	private Date promotionStartDate;
	private Boolean isActive;
	private Boolean isApprove;
	private Boolean isDelete;
	private Boolean isExit;

	// private String email;
	// private String password;
	// private String alternateContactNo;
	// private Date marriageDay;
//	private String gender;
	// private String voterID;
	// private Double ctc;
	// private String passport;
//	private String roleName;
//	private String primarySkills;
//	private String secondarySkills;
//	private Boolean isSameAddress;
//	private Long employmentTypeId;
//	private Date empTypeStartDate;
//	private Date empTypeEndDate;
//	private String address;
//	private String landmark;
//	private String street;
//	private String city;
//	private String district;
//	private String state;
//	private String country;
//	private String pincode;
//	private String tempAddress;
//	private String tempLandmark;
//	private String tempStreet;
//	private String tempCity;
//	private String tempDistrict;
//	private String tempState;
//	private String tempCountry;
//	private String tempPincode;
//	private String instituteName;
//	private String qualification;
//	private String yearOfPassing;
//	private String percentage;
//	private String type;
//	private String personName;
//	private String relation;
//	private String contactNumber;
//	private String altContactNumber;
//	private String professionalCompanyName;
//	private Date professionalJoiningDate;
//	private Date professionalRelievingDate;
//	private String professionalExperience;
//	private String professionalClient;
	// private String emergencyAltContactNumber;
//	private String emergencyContactNumber;
//	private String emergencyContactPerson;
//	private String emergencyRelation;

}
