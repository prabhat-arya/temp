package com.hrms.admin.dto;

import java.io.Serializable;

import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ObjectiveQuestions implements Serializable {

	private static final long serialVersionUID = 3101807635449287321L;

	private Long ObjectiveQuestionId;
	@Size(min = 3, max = 2500, message = "Objective Question Max should be 2500 characters.")
	private String ObjectiveQuestion;
}
