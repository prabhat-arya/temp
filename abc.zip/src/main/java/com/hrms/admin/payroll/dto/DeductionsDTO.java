package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeductionsDTO implements Serializable{

	private static final long serialVersionUID = -4555845097282832432L;
	
	private Long id;
	private String deductionType;
	private String deductionName;
	private String nameInPayslip;
	private String calculationType;
	private Double flatAmount;
	private Double percentage;
	private Long branchId;
	private Boolean status;
	
}
