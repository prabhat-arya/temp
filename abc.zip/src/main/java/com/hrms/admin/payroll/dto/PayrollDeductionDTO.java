package com.hrms.admin.payroll.dto;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PayrollDeductionDTO implements Serializable{

	private static final long serialVersionUID = 3106036763311656552L;
	
	private Map<String,Double> earningsMap;
	private Map<String,Double> deductionsMap;
	private long branchId;
}