package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayrollEmpListDTO implements Serializable{

	private static final long serialVersionUID = 2244665375195054035L;
	
	private Long employeeId;
	private String firstName;
	private String lastName;
	private String userName;
}
