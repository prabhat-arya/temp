package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpSalaryDto implements Serializable{

	private static final long serialVersionUID = 4764764648450661116L;
	

	private Long empid;
	private Double salary;

}
