package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayrollRequestDTO implements Serializable{

	private static final long serialVersionUID = 5346907961709226305L;
	
	private Long employeeId;
	private String date;
	private Double empCTC;
	
}
