package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EarningsDTO implements Serializable{

	private static final long serialVersionUID = 6545442798298205746L;
	
	private Long id;
	private String earningType;
	private String earningName;
	private String nameInPayslip;
	private String calculationType;
	private Double flatAmount;
	private Double percentage;
	private Boolean status;
	private Long branchId;
	private String payType;
	private Boolean inclusiveOfNetSalary;
	private Boolean exclusiveOfNetSalary;
}
