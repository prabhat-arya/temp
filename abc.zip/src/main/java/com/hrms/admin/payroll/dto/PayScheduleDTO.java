package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayScheduleDTO implements Serializable{

	private static final long serialVersionUID = 653291122650880108L;

	private Long id;

	private String workingday;

	private Integer daySelected;

	private String payday;

	private Integer payDateSelected;

	private String[] calenderWeek;

	private Long branchId;

}
