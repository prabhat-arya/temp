package com.hrms.admin.payroll.dto;

import java.io.Serializable;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayslipGenerationDTO implements Serializable{

	private static final long serialVersionUID = 2955667632363386986L;
	
	private Map<String,String> payslipFields;
	private Map<String,Double> earningMap;
	private Map<String,Double> deductionMap;
	private Double totalEarnings;
	private Double totalDeductions;
	private Double netPay;
	private Double specialAllowance;
}
