package com.hrms.admin.payroll.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayCalculateViewDTO implements Serializable{
	
	private static final long serialVersionUID = -1044572769667273505L;
	
	private Double basicPay;
	private Double hra;
	private Double sa;
	private Double otherAllowance;
	private Double netPay;
	private Double	pf;
	private Double pt;
}
