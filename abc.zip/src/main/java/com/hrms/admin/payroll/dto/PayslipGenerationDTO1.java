package com.hrms.admin.payroll.dto;

import java.io.Serializable;
import java.util.Map;

import com.hrms.admin.dto.ProfileImageDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayslipGenerationDTO1 implements Serializable{

	private static final long serialVersionUID = 5412547783847494596L;
	
	private Map<String,String> payslipFields;
	private Map<String,String> earningMap;
	private Map<String,String> deductionMap;
	private String totalEarnings;
	private String totalDeductions;
	private String netPay;
	private ProfileImageDTO image;
	private String companyName;
	private String companyAddress1;
	private String companyAddress2;
	private String companyAddress3;

}
