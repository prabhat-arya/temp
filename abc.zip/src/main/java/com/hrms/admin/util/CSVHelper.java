package com.hrms.admin.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.transaction.Transactional;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.AssignShift;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.entity.AttendanceInfoBreaksHistory;
import com.hrms.admin.entity.AttendanceInfoErrorRecords;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.repository.AssignShiftRepository;
import com.hrms.admin.repository.AttendanceInfoBreaksHistoryRepository;
import com.hrms.admin.repository.AttendanceInfoErrorRecordsRepository;
import com.hrms.admin.repository.AttendanceInfoRepository;
import com.hrms.admin.repository.EmployeeRepository;

@Component
public class CSVHelper {

	private static final Logger logger = LoggerFactory.getLogger(CSVHelper.class);

	@Autowired
	private StringToDateUtility util;
	@Autowired
	private EmployeeRepository empRepo;

	@Autowired
	private AttendanceInfoErrorRecordsRepository attErrorRecordrepo;

	@Autowired
	private AttendanceInfoBreaksHistoryRepository historyRepo;

	@Autowired
	private AttendanceInfoRepository attRepo;
	@Autowired
	private AssignShiftRepository assignShiftRepo;

	public static final String TYPE = "*.csv";

	public static boolean hasCSVFormat(MultipartFile file) {

		if (!TYPE.equals(file.getContentType())) {
			return false;
		}

		return true;
	}
	/*
	 * @SuppressWarnings({ "resource", "unlikely-arg-type" }) public
	 * List<Map<String, Integer>> csvToAttendanceInfo(InputStream is, String
	 * companyId) throws UnsupportedEncodingException, IOException { BufferedReader
	 * fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
	 * CSVParser csvParser = new CSVParser(fileReader,
	 * CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim()
	 * ); List<AttendanceInfo> infoSize = new ArrayList<>();
	 * List<AttendanceInfoErrorRecords> infoErrorSize = new ArrayList<>();
	 * 
	 * List<Map<String, Integer>> list3 = new ArrayList<>(); Iterable<CSVRecord>
	 * csvRecords = csvParser.getRecords(); for (CSVRecord csvRecord : csvRecords) {
	 * List<AttendanceInfo> info = new ArrayList<>();
	 * List<AttendanceInfoErrorRecords> infoError = new ArrayList<>();
	 * AttendanceInfoErrorRecords infoError1 = new AttendanceInfoErrorRecords();
	 * String empIdIndexVal = csvRecord.get(0);
	 * 
	 * long empId = 0; if (empIdIndexVal.isEmpty()) { infoError1.setEmpId(null);
	 * infoError1.setInTime(csvRecord.get(1));
	 * infoError1.setOutTime(csvRecord.get(2));
	 * infoError1.setDate(csvRecord.get(3)); infoError.add(infoError1); } else {
	 * empId = Long.parseLong(empIdIndexVal); Boolean flag =
	 * empRepo.findById(empId).isPresent(); List<AssignShift> findShiftId =
	 * assignShiftRepo.findShiftId(empId, csvRecord.get(3), companyId); if
	 * (csvRecord.get(0).equals("") || findShiftId == null ||
	 * csvRecord.get(1).equals("") || csvRecord.get(2).equals("") ||
	 * csvRecord.get(3).trim().equals("") || Boolean.TRUE.equals(flag)) {
	 * 
	 * if (csvRecord.get(0).equals("")) infoError1.setEmpId(null); else
	 * infoError1.setEmpId(empId);
	 * 
	 * if (csvRecord.get(1).equals("")) infoError1.setInTime(null); else
	 * infoError1.setInTime(csvRecord.get(1));
	 * 
	 * if (csvRecord.get(2).equals("")) infoError1.setOutTime(null); else
	 * infoError1.setOutTime(csvRecord.get(2));
	 * 
	 * if (csvRecord.get(3).equals("")) infoError1.setDate(null); else
	 * infoError1.setDate(csvRecord.get(3)); infoError.add(infoError1); } else {
	 * AttendanceInfo attInfo1 = new AttendanceInfo(); Optional<Employee> findById =
	 * empRepo.findById(Long.parseLong(csvRecord.get("empId"))); if
	 * (findById.isPresent()) { attInfo1.setEmployee(findById.get()); }
	 * attInfo1.setInTime(csvRecord.get(Constants.IN_TIME));
	 * attInfo1.setOutTime(csvRecord.get(Constants.OUT_TIME));
	 * attInfo1.setDate(csvRecord.get(Constants.DATE));
	 * attInfo1.setShiftId(findShiftId.get(0).getShift().getId()); String noOfHrs =
	 * util.calculateWorkingHours(csvRecord.get(1), csvRecord.get(2));
	 * attInfo1.setNoOfHrs(noOfHrs); Long attendsPersentage =
	 * util.attendsPersentage(findShiftId.get(0).getShift().getInTime(),
	 * findShiftId.get(0).getShift().getOutTime(), noOfHrs);
	 * attInfo1.setAttndsPercentage(attendsPersentage); info.add(attInfo1);
	 * 
	 * } attRepo.saveAll(info); attErrorRecordrepo.saveAll(infoError); }
	 * infoSize.addAll(info); infoErrorSize.addAll(infoError); } Map<String,
	 * Integer> map = new HashedMap<>(); map.put(Constants.SUCCESS,
	 * infoSize.size()); Map<String, Integer> map1 = new HashedMap<>();
	 * map1.put(Constants.FAILURE, infoErrorSize.size()); list3.add(0, map);
	 * list3.add(1, map1); return list3; }
	 */

	@Transactional
	public List<EntityDTO> attendanceBreaksInsertToAttInfo(List<AttendanceInfoBreaksHistory> findAll,
			String companyId) {
		List<EntityDTO> list = new ArrayList<>();
		Long previousId = 0l;
		String previousDate = null;
		List<AttendanceInfo> attList = new ArrayList<>();

		for (AttendanceInfoBreaksHistory entity : findAll) {
			AttendanceInfo model = new AttendanceInfo();
			Employee employee = entity.getEmployee();
			if (employee.getId().equals(previousId) && entity.getDate().equals(previousDate)) {
				continue;
			} else {

				previousId = employee.getId();
				previousDate = entity.getDate();
				model.setEmployee(employee);
				model.setDate(entity.getDate());
				String intime = historyRepo.getIntime(entity.getEmployee().getId(), entity.getDate());
				String outTime = historyRepo.getOutTime(entity.getEmployee().getId(), entity.getDate());
				model.setInTime(intime);
				model.setOutTime(outTime);
				String totalhrs = util.calculateWorkingHours(intime, outTime);
				model.setTotalHrs(totalhrs);
				try {
					model.setBreakHrs(historyRepo.getBreakHrs(entity.getEmployee().getId(), entity.getDate()));
				} catch (Exception e) {
					throw new RuntimeException("In DataBase available for these data " + e.getMessage());
				}
				String wrkinghrs = historyRepo.getNoOfhrs(entity.getEmployee().getId(), entity.getDate());
				model.setNoOfHrs(wrkinghrs);
				List<AssignShift> findShiftId = assignShiftRepo.findShiftId(entity.getEmployee().getId(),
						entity.getDate(), companyId);
				model.setShiftId(findShiftId.get(0).getShift().getId());
				Long percentage = util.attendsPersentage(findShiftId.get(0).getShift().getInTime(),
						findShiftId.get(0).getShift().getOutTime(), wrkinghrs);
				if (percentage <= 100) {
					model.setAttndsPercentage(percentage);
				} else {
					model.setAttndsPercentage(100l);
				}
				attList.add(model);
			}
		}
		List<AttendanceInfo> a = attRepo.saveAll(attList);
		EntityDTO dto = new EntityDTO();
		dto.setId(a.get(0).getEmployee().getId());
		dto.setName(a.get(0).getEmployee().getFirstName() + " " + a.get(0).getEmployee().getLastName());
		list.add(dto);
		return list;

	}

	@SuppressWarnings("resource")
	@Transactional
	public List<Map<String, Integer>> attendanceBreakHistoryCsv(InputStream is, String companyId) {

		BufferedReader fileReader;
		CSVParser csvParser = null;
		try {
			fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			try {
				csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
			} catch (IOException e) {
				logger.info("Error in attendance Break HistoryCsv");
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("Error in attendance Break History Csv");
		}
		Set<AttendanceInfoErrorRecords> infoErrorList = new HashSet<>();
		List<AttendanceInfoBreaksHistory> successlist = new CopyOnWriteArrayList<>();
		List<AttendanceInfoErrorRecords> initalRecords = new ArrayList<>();
		List<Map<String, Integer>> list3 = new ArrayList<>();
		Iterable<CSVRecord> csvRecords = null;
		try {
			csvRecords = csvParser.getRecords();
		} catch (IOException e) {
			logger.info("Error in attendanceBreak History Csv");
		}
		for (CSVRecord csvRecord : csvRecords) {
			AttendanceInfoErrorRecords erroeRecord = new AttendanceInfoErrorRecords();
			if (!csvRecord.get(0).trim().equals("")) {
				erroeRecord.setEmpId(Long.parseLong(csvRecord.get(0).trim()));
			}

			if (!csvRecord.get(1).trim().equals("")) {
				erroeRecord.setInTime(csvRecord.get(1).trim());
			}
			if (!csvRecord.get(2).trim().equals("")) {
				erroeRecord.setOutTime(csvRecord.get(2).trim());
			}
			if (!csvRecord.get(3).trim().equals("")) {
				erroeRecord.setDate(csvRecord.get(3).trim());
			}
			initalRecords.add(erroeRecord);
		}
		for (AttendanceInfoErrorRecords record : initalRecords) {
			if (record.getEmpId() == null || record.getInTime() == null || record.getOutTime() == null
					|| record.getDate() == null) {
				AttendanceInfoErrorRecords error = new AttendanceInfoErrorRecords();
				BeanUtils.copyProperties(record, error);
				infoErrorList.add(error);
				continue;
			}
			Boolean flag = empRepo.findByIdByCompany(record.getEmpId(), companyId).isPresent();
			if (Boolean.FALSE.equals(flag)) {
				AttendanceInfoErrorRecords error = new AttendanceInfoErrorRecords();
				BeanUtils.copyProperties(record, error);
				infoErrorList.add(error);
				continue;
			}
			List<AssignShift> findShiftId = assignShiftRepo.findShiftId(record.getEmpId(), record.getDate(), companyId);
			if (findShiftId.isEmpty()) {
				AttendanceInfoErrorRecords error = new AttendanceInfoErrorRecords();
				BeanUtils.copyProperties(record, error);
				infoErrorList.add(error);
				continue;
			}
			if (record.getEmpId() != null || record.getInTime() != null || record.getOutTime() != null
					|| record.getDate() != null) {
				AttendanceInfoBreaksHistory attInfo = new AttendanceInfoBreaksHistory();
				Optional<Employee> findById = empRepo.findById(record.getEmpId());
				if (findById.isPresent()) {
					attInfo.setEmployee(findById.get());
					attInfo.setInTime(record.getInTime());
					attInfo.setOutTime(record.getOutTime());
					attInfo.setDate(record.getDate());
				}
				successlist.add(attInfo);
			}
		}
		Set<AttendanceInfoErrorRecords> infoErrorNew = new HashSet<>();
		for (AttendanceInfoErrorRecords error : infoErrorList) {
			for (AttendanceInfoBreaksHistory success : successlist) {
				if (error.getEmpId().equals(success.getEmployee().getId())) {
					AttendanceInfoErrorRecords errorRecord = new AttendanceInfoErrorRecords();
					errorRecord.setEmpId(success.getEmployee().getId());
					errorRecord.setDate(success.getDate());
					errorRecord.setInTime(success.getInTime());
					errorRecord.setOutTime(success.getOutTime());
					infoErrorNew.add(errorRecord);
					successlist.remove(success);
				}
			}
		}
		infoErrorList.addAll(infoErrorNew);
		try {
			historyRepo.saveAll(successlist);
			attErrorRecordrepo.saveAll(infoErrorList);
		} catch (Exception e) {
			throw new RuntimeException("error while saving AttendanceInfoBreaksHistory ");
		}

		try {
			attendanceBreaksInsertToAttInfo(successlist, companyId);

		} catch (Exception e) {
			throw new RuntimeException("Data is already available with these Date ");
		}
		Map<String, Integer> map = new HashedMap<>();
		map.put(Constants.SUCCESS, successlist.size());
		list3.add(0, map);
		Map<String, Integer> map1 = new HashedMap<>();
		map1.put(Constants.FAILURE, infoErrorList.size());
		list3.add(1, map1);
		return list3;
	}
}
