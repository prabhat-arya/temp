package com.hrms.admin.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;




@Component
public class EncryptingPayrollFields {
	
	private static final Logger logger = LoggerFactory.getLogger(EncryptingPayrollFields.class);
	
	@Value("${aes.secret}")
	private String secretKey;
	
	//Actuall input we take as an argument to encrypt and decrypt
	public void encryption()
	{
		
	     
	    String annualCTC = "5,00,000";
	    String encryptedString = AES.encrypt(annualCTC, secretKey) ;
	    String decryptedString = AES.decrypt(encryptedString, secretKey) ;
	    
	    logger.info(annualCTC+"AnnualCTC------------ "+encryptedString+" "+decryptedString);
	     
			 
	}

}
