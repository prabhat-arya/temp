package com.hrms.admin.util;

public class PayrollConstants {
	
	private PayrollConstants() {
		
	}
	
	public static final String NAME = "Name";
	public static final String JOIN_DATE = "JoinDate";
	public static final String DESIGNATION = "Designation";
	public static final String DEPARTMENT = "Department";
	public static final String LOCATION = "Location";
	public static final String DAYS_IN_MONTH = "DaysInMonth";
	public static final String EFFECTIVE_WORKING_DAYS = "effectiveWorkingDays";
	public static final String BANK_NAME = "BankName";
	public static final String BANK_ACCOUNT_NO = "BankAccountNo";
	public static final String PFNO = "PFNO";
	public static final String PFUAN = "PFUAN";
	public static final String ESI_NO = "ESINo";
	public static final String PAN_NO = "PANNo";
	public static final String LOP = "LOP";
	public static final String EARNINGS = "Earnings";
	public static final String DEDUCTIONS = "Deductions";
	public static final String ACTUAL = "Actual";
	public static final String SPECIAL_ALLOWANCE = "Special Allowance";
	
	public static final String JOIN__DATE = "Join Date";
	public static final String DAYS__IN__MONTH = "Days In Month";
	public static final String EFFECTIVE__WORKING__DAYS = "effective Working Days";
	public static final String BANK__NAME = "Bank Name";
	public static final String BANK__ACCOUNT__NO = "Bank Account No";
	public static final String PF_NO = "PF NO";
	public static final String PF_UAN = "PF UAN";
	public static final String ESI__NO = "ESI No";
	public static final String PAN__NO = "PAN No";
	public static final String PF__NO = "PF No";
	public static final String TOTAL_EARNINGS_INR = "Total Earnings:INR.";
	public static final String TOTAL_DEDUCTIONS_INR = "Total Deductions:INR.";
	public static final String NET_PAY_FOR_THE_MONTH = "Net Pay for the month";

}
