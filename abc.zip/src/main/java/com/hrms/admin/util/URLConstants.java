package com.hrms.admin.util;

public class URLConstants {

	private URLConstants() {

	}

	public static final String ADMIN_ASSETS = "/admin/Assets";
	public static final String SHIFT_ASSIGN = "/shift/assign";
	public static final String ADMIN_ATTENDANCEINFO = "/admin/attendanceinfo";
	public static final String ADMIN_ATTENDANCE = "/admin/attendance";
	public static final String ADMIN_AUTH = "/admin/auth";
	public static final String ADMIN_BRANCH = "/admin/branch";
	public static final String ADMIN_CASCADE = "/admin/cascade";
	public static final String COMMON_OPERATIONS = "/common/operations";
	public static final String ADMIN_COMPANY = "/admin/company";
	public static final String ADMIN_DEPARTMENT = "/admin/department";
	public static final String ADMIN_DESIGNATION = "/admin/designation";
	public static final String ADMIN_MAILTEMPLATE = "/admin/mailTemplate";
	public static final String EMPLOYEE_LEAVE = "/employee/leave";
	public static final String ONBOARD_EMPLOYEE = "/onboard/employee";
	public static final String ADMIN_EXIT = "/admin/exit";
	public static final String ADMIN_EXITFEEDBACK = "/admin/exitFeedback";
	public static final String ADMIN_GOAL = "/admin/goal";
	public static final String ADMIN_HOLIDAY = "/admin/holiday";
	public static final String ADMIN_IDGENERATION = "/admin/IdGeneration";
	public static final String IMAGE = "/image";
	public static final String ADMIN_JOB = "/admin/job";
	public static final String ADMIN_LEAVETYPE = "/admin/leavetype";
	public static final String ADMIN_NOTIFICATION = "/admin/notification";
	public static final String ADMIN_ORG = "/admin/org";
	public static final String ADMIN_PAYROLL = "/admin/payroll";
	public static final String ADMIN_PERFORMANCE = "/admin/performance";
	public static final String ADMIN_POLICY = "/admin/policy";
	public static final String ADMIN_PROJECT = "/admin/project";
	public static final String ADMIN_REPORTS = "/admin/reports";
	public static final String ADMIN_ROLE = "/admin/role";
	public static final String ADMIN_SHIFT = "/admin/shift";
	public static final String ADMIN_SKILL = "/admin/skill";
	public static final String ADMIN_USER = "/admin/user";
	public static final String API_TEST = "/api/test";	
	public static final String ADMIN_CONTACT = "/admin/contact";
	public static final String ADMIN_EXIT_RECORD_QUESTION = "/admin/exitRecordsQuestion";

}
