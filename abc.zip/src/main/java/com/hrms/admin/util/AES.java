package com.hrms.admin.util;

import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.crypto.RuntimeCryptoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class AES {
	private static final Logger logger = LoggerFactory.getLogger(AES.class);

	
	private static String aessecretkey="ONPASSIVE@)@)!@#";

	private static String algo ="AES";

	private static SecretKeySpec secretKey;
	private static byte[] key;

	public static void setKey(String myKey) {
		MessageDigest sha = null;
		try {
			key = myKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = Arrays.copyOf(key, 16);
			secretKey = new SecretKeySpec(key, "AES");
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			logger.info("Error while encrypting: {}", e.getMessage());
		}
	}

	// method to encrypt payroll related sensitive data
	public static String encrypt(String strToEncrypt, String secret) {
		try {
			setKey(secret);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception e) {
			logger.info("Error while encrypting:{}",e.getMessage());
		}
		return null;
	}

	// method to decrypt payroll related sensitive data
	public static String decrypt(String strToDecrypt, String secret) {
		try {
			setKey(secret);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			logger.info("Error while decrypting: {}" ,e.getMessage());
		}
		return null;
	}

	public static String encryptUrl(String plainText) {
		try {
			String encodedBase64Key = encodeKey(aessecretkey);
			Key key = generateKey(encodedBase64Key);
			Cipher c = Cipher.getInstance(algo);
			c.init(Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(plainText.getBytes());
			return Base64.getUrlEncoder().encodeToString(encVal);
		} catch (Exception e) {
			logger.info("Error while decrypting:{} ", e.getMessage());
			throw new RuntimeCryptoException();
		}
	}

	public static String decryptUrl(String encryptText) {
		try {
			String encodedBase64Key = encodeKey(aessecretkey);
			Key key = generateKey(encodedBase64Key);
			Cipher cipher = Cipher.getInstance(algo);
			cipher.init(Cipher.DECRYPT_MODE, key);
			return new String(cipher.doFinal(Base64.getUrlDecoder().decode(encryptText)));
		} catch (Exception e) {
			logger.info("Error while decrypting:{} ", e.getMessage());
			throw new RuntimeCryptoException();
		}
	}

	private static Key generateKey(String secret) {
		byte[] decoded = Base64.getDecoder().decode(secret.getBytes());
		return new SecretKeySpec(decoded, algo);

	}

	public static String encodeKey(String str) {
		byte[] encoded = Base64.getEncoder().encode(str.getBytes());
		return new String(encoded);
	}

	/**
	 * @author Prabhat
	 */
	public static String decryptLoginPwd(String encryptPwd) {
		try {
			String s1="/";
			String s2="+";
			String pwd = encryptPwd.replace("_",s1);
			String replace = pwd.replace("-",s2);
			String encodedBase64Key = encodeKey(aessecretkey);
			Key key = generateKey(encodedBase64Key);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key);
			return new String(cipher.doFinal(Base64.getDecoder().decode(replace)));
		} catch (Exception e) {
			logger.info("Error while decrypting: {}", e);
		}
		return null;
	}
}