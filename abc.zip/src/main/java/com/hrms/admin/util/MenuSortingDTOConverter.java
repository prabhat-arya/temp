package com.hrms.admin.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.role.dto.MenuSortingDTO;

@Component
public class MenuSortingDTOConverter implements AttributeConverter<List<MenuSortingDTO>, String>{

	@Autowired
	private ObjectMapper objectMapper;
	
	@Override
	public String convertToDatabaseColumn(List<MenuSortingDTO> menuJson) {
		
		String customerInfoJson = null;
        try {
            customerInfoJson = objectMapper.writeValueAsString(menuJson);
        } catch (final JsonProcessingException e) {
            e.printStackTrace();
        }

        return customerInfoJson;
	}

	@Override
	public List<MenuSortingDTO> convertToEntityAttribute(String dbData) {
		
		List<MenuSortingDTO> customerInfo = new ArrayList<>();
        try {
        	customerInfo = objectMapper.readValue(dbData, new TypeReference<List<MenuSortingDTO>>() {});
        } catch (final IOException e) {
            
        	e.printStackTrace();
        }
        return customerInfo;
	}
}
