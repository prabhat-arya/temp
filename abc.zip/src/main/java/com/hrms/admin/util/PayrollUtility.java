package com.hrms.admin.util;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.Deductions;
import com.hrms.admin.entity.Earnings;
import com.hrms.admin.payroll.dto.PayCalculateViewDTO;
import com.hrms.admin.repository.DeductionsRepository;
import com.hrms.admin.repository.EarningsRepository;

@Component
public class PayrollUtility {

	@Autowired
	private DeductionsRepository deductionsRepository;

	@Autowired
	private EarningsRepository earningsRepository;

	public PayCalculateViewDTO calculateView(Double costToCompany, Long branchId,String companyId) {
		Double basic = 0.0;

		Double ctc = (costToCompany / 12);

		List<Earnings> earningDetails = earningsRepository.getAllFields(companyId);

		PayCalculateViewDTO payCalculateViewDTO = new PayCalculateViewDTO();

		for (Earnings earnings : earningDetails) {

			if (earnings.getCalculationType().contains(Constants.GROSS)) {
				basic = ctc * (earnings.getPercentageOfGrossSalary() / 100.0);
				payCalculateViewDTO.setBasicPay(round(basic, 2));

			} else if (earnings.getCalculationType().contains(Constants.BASIC)
					|| earnings.getCalculationType().contains(Constants.FLAT)) {

				if (earnings.getEarningName().equalsIgnoreCase(Constants.HRA)
						|| earnings.getEarningName().equalsIgnoreCase(Constants.HUMAN_RESOURCE_ALLOWANCE)) {
					payCalculateViewDTO.setHra(round(basic * (earnings.getPercentageOfBasic() / 100.0), 2));
				} else if (earnings.getEarningName().equalsIgnoreCase(Constants.SA)
						|| earnings.getEarningName().equalsIgnoreCase(Constants.SPECIAL_ALLOWANCE)) {
					if (earnings.getPercentageOfBasic() != null && earnings.getPercentageOfBasic() > 1.00) {

						payCalculateViewDTO.setSa(round(basic * (earnings.getPercentageOfBasic() / 100.0), 2));
					} else {
						if (earnings.getFlatAmount() != null && earnings.getFlatAmount() > 1.00) {

							payCalculateViewDTO.setSa(round(earnings.getFlatAmount(), 2));
						} else
							payCalculateViewDTO.setSa(0.0);
					}
				} else if (earnings.getEarningName().equalsIgnoreCase(Constants.OTHER_ALLOWANCE)) {
					if (earnings.getPercentageOfBasic() != null && earnings.getPercentageOfBasic() > 1.00) {
						payCalculateViewDTO
								.setOtherAllowance(round(basic * (earnings.getPercentageOfBasic() / 100.0), 2));
					} else {
						if (earnings.getFlatAmount() != null && earnings.getFlatAmount() > 1.00) {
							payCalculateViewDTO.setOtherAllowance(round(earnings.getFlatAmount(), 2));
						} else
							payCalculateViewDTO.setOtherAllowance(0.0);
					}
				}

			}

		}

		List<Deductions> deductionsDetails = deductionsRepository.getAllFields(companyId);
		for (Deductions deductions : deductionsDetails) {

			if (deductions.getDeductionName().equalsIgnoreCase("pf")) {
				if (deductions.getPercentageOfBasic() != null && deductions.getPercentageOfBasic() > 1.00) {
					payCalculateViewDTO.setPf(round(basic * (deductions.getPercentageOfBasic() / 100.0), 2));
				} else {
					if (deductions.getFlatAmount() != null && deductions.getFlatAmount() > 1.00) {
						payCalculateViewDTO.setPf(round(deductions.getFlatAmount(), 2));
					} else
						payCalculateViewDTO.setPf(0.0);
				}
			} else if (deductions.getDeductionName().equalsIgnoreCase(Constants.PT)) {
				if (deductions.getPercentageOfBasic() != null && deductions.getPercentageOfBasic() > 1.00) {
					payCalculateViewDTO.setPt(round(basic * (deductions.getPercentageOfBasic() / 100.0), 2));
				} else {
					if (deductions.getFlatAmount() != null && deductions.getFlatAmount() > 1.00) {
						payCalculateViewDTO.setPt(deductions.getFlatAmount());
					} else
						payCalculateViewDTO.setPt(0.0);
				}
			}

		}

		basic = (payCalculateViewDTO.getBasicPay() == null) ? 0 : payCalculateViewDTO.getBasicPay();
		Double hra = (payCalculateViewDTO.getHra() == null) ? 0 : payCalculateViewDTO.getHra();
		Double otherAllowance = (payCalculateViewDTO.getOtherAllowance() == null)?0: payCalculateViewDTO.getOtherAllowance();
		Double sa = (payCalculateViewDTO.getSa() == null)?0: payCalculateViewDTO.getSa();
		Double pf = (payCalculateViewDTO.getPf() == null)?0: payCalculateViewDTO.getPf();
		Double pt = (payCalculateViewDTO.getPt() == null)?0: payCalculateViewDTO.getPt();

		Double netPay = basic+hra+otherAllowance+sa-pf-pt;

		payCalculateViewDTO.setNetPay(netPay);
		return payCalculateViewDTO;
	}

	public static Double round(Double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		Double factor = Math.pow(10.00, places);
		value = value * factor;
		Long tmp = Math.round(value);
		return tmp / factor;
	}

	public static Double round2(Double value) {
		DecimalFormat df = new DecimalFormat("#.##");
		df.setRoundingMode(RoundingMode.CEILING);

		return Double.parseDouble(df.format(value));
	}
	
	public static String formattedValue(Double value) {
		 NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
		 String moneyString = formatter.format(value);
		 return moneyString;
	}
}
