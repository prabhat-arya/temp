package com.hrms.admin.util;

public class Constants {
	private Constants() {

	}

	public static final String INSERT_SUCCESS = "Saved Successfully";
	public static final String UPDATE_SUCCESS = "Updated Successfully";
	public static final String DELETE_SUCCESS = "Deleted Successfully";
	public static final String DEACTIVE_SUCCESS = "Deactived Successfully";
	public static final String APPROVE_SUCCESS = "Approved Successfully";
	public static final String REJECT_SUCCESS = "Rejected Successfully";
	public static final String INSERT_FAIL = "Failed To Save";
	public static final String UPDATE_FAIL = "Failed To Update";
	public static final String DELETE_FAIL = "Failed To Delete";
	public static final String DEACTIVE_FAIL = "Failed To Deactive";
	public static final String APPROVE_FAIL = "Failed To Approve";
	public static final String GET_FAIL = "Failed To Get Details";
	public static final String TRUE = "Success";
	public static final String FALSE = "Failure";
	public static final String POST = "POST";
	public static final String PUT = "PUT";
	public static final String DELETE = "DELETE";
	public static final String POST_INTERNAL_SERVER_ERROR = "Post Internal Server Error";
	public static final String PUT_NOT_FOUND = "Put Not Found";
	public static final String PUT_BAD_REQUEST = "Put Bad Request";
	public static final String DELETE_NO_CONTENT = "Delete Fail";
	public static final String ALREADY_EXIST = "Record is Already Exist";
	public static final String DUPLICATE_YEAR = "Academinc Year Duplicated";
	public static final String LEAVE_APPLIED = "Leave Already applied On this date";
	public static final String LEAVE_APROVAL = "Applied Leave ";
	public static final String DELETE_CANNOT = "This Record can't be Deleted";
	public static final String PAGE_LIST = "Executed Successfully";
	public static final String VALIDATE = "Validation Error";
	public static final String EXECUTED_SUCCESSFULLY = "Executed Successfully";
	public static final String NOT_EXECUTED = "Not Executed";
	public static final String LIST = "Executed Successfully";
	public static final String NO_LIST = "No Records Found";
	public static final String LOGIN_SUCCESS = "User Logged in Successfully";
	public static final String SEND_SUCCESS = "Mail send successfully";
	public static final String SEND_FAIL = "Failed To Mail Send";

	// Exception messages
	public static final String INSERTION_ERROR = "Exception while creating";
	public static final String FINDING_ERROR = "Exception while finding";
	public static final String UPDATING_ERROR = "Exception while updating";
	public static final String DELETING_ERROR = "Exception while deleting";
	public static final String EXCEPTION = "Exception";
	public static final String LOGIN_FILURE = "UserName Or Password Is Wrong";
	public static final String UPLOAD_FILURE = "Exception while File Uploading";
	public static final String BAD_REQUEST = "Opps Record Does Not Exits";
	public static final String ALREADY_APPROVE = "Already Approved";

	public static final String STATUS = "status";
	public static final String UPLOAD_ERROR = "Upload Valid File";
	public static final String APPLIED = "Applied";
	public static final String APPROVED = "Approved";
	public static final String CANCEL_APPLIED = "Cancel Applied";
	public static final String REJECTED = "Rejected";
	public static final String CANCEL_REJECTED ="Cancel Rejected";
	public static final String CANCEL_APPROVED="Cancel Approved";
	public static final String ACTIVATE = "Activate";
	public static final String DEACTIVATE = "Deactivate";
	public static final String PENDING = "Pending";
	public static final String REQUESTEDSHIFTNOTAVAILABLE = "Requested Shift is not available";
	public static final String SHIFT = "shift";
	public static final String SHIFTREQUESTSUCCESS = "Shift Requested Successfully";
	public static final String VALID_OFFICE_MAIL = "Provide Proper Official MailId";
	public static final String PAGE_INDEX = "pageIndex";
	public static final String TOTAL_RECORDS = "totalRecords";
	public static final String TOTAL_PAGES = "totalPages";
	public static final String ASC_ORDER = "asc";
	public static final String DESC_ORDER = "desc";
	public static final String FILE_EXTENSION = "xls";
	public static final String FILE_EXTENSION_ONE = "xlsx";
	public static final String TEMPPASS = "tempPass";
	public static final String USERNAME = "userName";
	public static final String URL = "url";
	public static final String TEMPLATE_NAME = "mail_verification.html";
	public static final String MAIL_FROM = "HR";

	public static final String TYPE = "type";
	public static final String FILE = "file";
	public static final String TITLE = "title";

	// pagination Constant Values
	public static final String DATA = "data";
	public static final String PAGEINDEX = "pageIndex";
	public static final String TOTALRECORDS = "totalRecords";
	public static final String TOTALPAGES = "totalPages";

	// Notification retailed Constant Values
	public static final String NAME = "name";
	public static final String MSG = "msg";
	public static final String TEAMNAME = "teamName";
	public static final String PHONE = "phone";
	public static final String FAX = "fax";
	public static final String EMAIL = "email";
	public static final String DATE = "date";
	public static final String REASON = "reason";
	public static final String EVENT = "Event";
	public static final String EVENTDATE = "eventDate";
	public static final String HR = "HR";
	public static final String WELCOME_ONBOARD = "Welcome Onboard!!";
	public static final String HRMS = "OSTAFF";
	public static final String HOLIDAY_DECLARE = "Holiday_Declare";
	public static final String HAPPY_JOINNINGDAY = "Happy Joining Day";
	public static final String CONGRATULATIONS_ON_YOUR_NEW_BABY = "Congratulations On Your New Baby";
	public static final String WE_HAVE_YOUR_NEXT_GREAT_OPPORTUNITY = "We have your next GREAT OPPORTUNITY!";
	public static final String BABYGIRL = "babyGirl";
	public static final String BABYBOY = "babyBoy";
	public static final String TEAMAPPRECIALS = "teamApprecials";
	public static final String PROMOTION = "promotion";
	public static final String TRAINING = "training";
	public static final String ZERO = "0";
	public static final String DESCRIPTION = "description";
	public static final String HOLIDAY = "holiday";
	public static final Object PRODUCTLAUNCH = "productLaunch";

	// Account lock
	public static final int DEFAULT_FAILED_ATTEMPTS = 0;
	public static final int MAX_FAILED_ATTEMPTS = 3;

	public static final String COMPLETED = "Completed";
	public static final String IN_PROGRASS = "In Progress";
	public static final String SUBMITTED = "Submitted";
	public static final String REVIEWED = "Reviewed";
	public static final String DATEFORMAT = "yyyy-MM-dd";

	// payroll Constant Values

	public static final String BASIC = "Basic";
	public static final String GROSS = "Gross";
	public static final String INCLUSIVE = "inclusive";
	public static final String EXCLUSIVE = "exclusive";
	public static final String EMP_NAME = "Name:";
	public static final String BANK_NAME = "Bank Name:";
	public static final String JOIN_DATE = "Join Date:";
	public static final String BANK_ACCOUNT_NO = "Bank Account No:";
	public static final String DESIGNATION = "Designation:";
	public static final String PF_NO = "PF No:";
	public static final String DEPARTMENT = "Department:";
	public static final String PF_UAN = "PF UAN:";
	public static final String LOCATION = "Location:";
	public static final String ESI_NO = "ESI No:";
	public static final String EFFECTIVE_WORK_DAYS = "Effective Work Days:";
	public static final String PAN_NO = "PAN No:";
	public static final String DAYS_IN_MONTH = "Days In Month:";
	public static final String LOP = "LOP:";
	public static final String EARNINGS = "Earnings:";
	public static final String ACTUAL = "Actual";
	public static final String DEDUCTIONS = "Deductions:";

	public static final String INCLUSIVE1 = "Inclusive";
	public static final String EXCLUSIVE1 = "Exclusive";

	public static final String TOTAL_EARNINGS_INR = "Total Earnings:INR.";
	public static final String TOTAL_DEDUCTIONS_INR = "Total Deductions:INR.";
	public static final String NET_PAY_FOR_THE_MONTH = "Net Pay for the month:";
	public static final String TOTAL_EARNINGS_MINUS_TOTAL_DEDUCTIONS = "( Total Earnings - Total Deductions )";

	// weekdays
	public static final String MON = "Mon";
	public static final String TUE = "Tue";
	public static final String WED = "Wed";
	public static final String THU = "Thu";
	public static final String FRI = "Fri";
	public static final String SAT = "Sat";
	public static final String SUN = "Sun";

	public static final String VERSION = "V_1";
	public static final Boolean NULL = null;

	public static final String AGREED = "Agreed";
	public static final String NOT_AGREED = "Not Agreed";

	public static final String EMPLOYEE = "employee";
	public static final String FILE_GENERATE = "Error While File Generation";
	public static final String SUFFIX = "/";

	public static final String SUCCESS = "Success";

	public static final String FAILURE = "Failure";

	// Attendance

	public static final String ATTENDANCE_INFO = "Attendance Info";
	public static final String FILEFORMATE = "text/csv";
	public static final String DATEFORMATE = "yyyy-MM-dd_HH-mm-ss";
	public static final String ATTACHMENT_FILEPATH = "attachment; filename=users_";
	public static final String PRESENT = "Present";
	public static final String ABSENT = "Absent";
	public static final String ZERO_HRS = "00:00:00";
	public static final String PDF_FILEPATH = "inline; filename=Employee_Attendance_";

	public static final String BIRTHDAY = "Birthday ";
	public static final String MARRIAGEDAY = "Marriage Day ";
	public static final String JOINNINGDAY = "Joining Day ";

	public static final String ADVANCE_BIRTHDAY = "Advance Birthday";
	public static final String ADVANCE_MARRIAGEDAY = "Advance Marriage Day ";
	public static final String ADVANCE_JOINNINGDAY = "Advance Joining Day ";

	public static final String CONTENT_DISPOSITION = "Content-Disposition";
	public static final String EXCEL_EXTENTION = ".xlsx";
	public static final String EXCEL_FILEPATH = "attachment; filename=Employee_Attendance_";

	public static final String ASSETS = "Assets";
	public static final String ATTENDANCE = "Aattendance";
	public static final String BRANCH = "Branch";
	public static final String LEAVETYPE = "leavetype";
	public static final String EMP_LEAVE = "Empleave";
	public static final String POLICY = "Policy";

	public static final String NOTIFICATION = "Notification";
	public static final String PROJECT = "Project";
	public static final String SKILLS = "Skills";
	public static final String COMPANY = "company";
	public static final String STATES = "states";
	public static final String CITIES = "cities";
	public static final String COUNTRIES = "countries";

	// Status used in Performance Mgmt
	public static final String EMP_INPROGRESS = "Emp. In Progress";
	public static final String MANAGER_INPROGRESS = "Mgr. In Progress";
	public static final String EMP_SUBMITTED = "Emp. Submitted";
	public static final String MANAGER_REVIEWED = "Mgr. Reviewed";
	public static final String REV_INPROGRESS = "Rev. In Progress";
	public static final String REV_REVIEWED = "Rev. Reviewed";
	// module name constants
	public static final String EMPLOYEE_EXIT = "EmployeeExit";
	public static final String EXIT_FEEDBACK = "ExitFeedback";
	public static final String PERFORMANCE = "Performance";
	public static final String EMPLOYEE_EXIT_RM_STATUS = "Employee Reporting Manager not found";

	// FieldsValidation
	public static final String PATTREN_NAME = "[^a-zA-Z ]";
	public static final String PATTREN_NAME_NUMBER = "[^a-zA-Z0-9]";
	public static final String PATTREN_NUMBER = "[^0-9]";
	public static final String CONSTANT_DATEFORMATE = "yyyy-MM-dd HH:mm:ss";
	public static final String VALIDATE_MSG = "Enter valid data";
	public static final String PATTREN_PF = "[^A-Z0-9]";

	public static final String ACTIVE = "Active";
	public static final String INACTIVE = "Inactive";

	public static final String ROLE_DEACTIVE_FAILURE = "Role Can't Be Deactivated, Relation exists";
	public static final String ROLE_DEACTIVE_SUCCESS = "Role Deactivated Successfully";

	public static final String ROLE = "Role";

	public static final String ACCOUNT_LOCK = "Account locked due to 3 failed attempts";

	public static final String BAD_BROWSER = "Wrong Browser..";

	public static final String USER = "user";
	public static final String PASSWORD = "password";

	public static final String ASSIGNING_SHIFT = "AssigningShift";
	public static final String SHIFT_ASSIGNED = "Shift Assigned";

	public static final String EMAIL_TEMPLATE = "Email Template";

	public static final String MANAGER_LIST = "managerList";
	public static final String FEEDBACK = "feedback";
	public static final String FEEDBACK_FILE = "feedBackFile";
	public static final String EXIT_FEEDBACK_DOCUMNET = "ExitFeedbackDocumnet";

	public static final String GOAL = "Goal";
	public static final String ID_FORMAT = "Idformat";
	public static final String IMAGE_UPLOAD = "ImageUpload";
	public static final String MAIL_IMAGE = "MailImage";

	public static final String JOB = "Job";
	public static final String LEAVE = "Leave";

	public static final String ORG_STRUCTURE = "Org_Structure";

	public static final String EARNING = "Earning";
	public static final String DEDUCTION = "Deduction";
	public static final String PAY_SCHEDULE = "PaySchedule";

	public static final String ASSIGN_SHIFT = "AssignShift";
	public static final String EMPLOYEE_ATTENDANCE = "Employee Attendance";

	public static final String PERFORMANCE_DATA = "perfomance data";

	public static final String AUTHORIZATION = "Authorization";

	public static final String USER_AGENT = "User-Agent";

	public static final String BEARER = "Bearer";

	public static final String HAPPY_BIRTHDAY = "Happy Birthday";
	public static final String HAPPY_MARRIAGEDAY = "Happy Marriage Day";
	public static final String ADVANCE_BIRTHDAY_WISHES = "Advance Birthday Wishes - ";
	public static final String ADVANCE_MARRIAGEDAY_ANNIVERSARY_WISHES = "Advance MarriageDay Anniversary Wishes - ";
	public static final String ADVANCE_JOINNINGDAY_WISHES = "Advance JoiningDay Wishes - ";

	public static final String IN_TIME = "InTime";
	public static final String OUT_TIME = "OutTime";

	public static final String RELATED = "related";

	public static final String ONPASSIVE_LOGO = "onpassiveLogo";
	public static final String EMPLOYEE_OF_MONTH = "employeeOfMonth";
	public static final String WEDDING_TOP = "weddingTop";
	public static final String WEDDING_BOTTOM = "weddingBottom";
	public static final String EMP_ONBOARDING = "empOnboarding";

	public static final String MONTH = "month";
	public static final String YEAR = "year";

	public static final String MAIL_SENDING_FAILURE = "Mail Sending failure : ";

	public static final String PERMANENT = "permanent";

	public static final String TEMPORARY = "temporary";

	public static final String HIGHER = "higher";

	public static final String POSTGRADUATION = "postGraduation";

	public static final String GRADUATION = "graduation";

	public static final String INTERMEDIATE = "intermediate";
	public static final String SSC = "ssc";
	public static final String OTHERS = "others";

	public static final String XLSX = "xlsx";

	public static final String QA_MANUAL = "QA manual";

	public static final String MANAGER = "Manager";

	public static final String LEAD_DEVELOPER = "Lead Developer";

	public static final String OPERATIONS = "Operations";
	public static final String AWS = "AWS";

	public static final String LOGO = "logo";

	public static final String FLAT = "flat";

	public static final String HRA = "hra";

	public static final String HUMAN_RESOURCE_ALLOWANCE = "human resource allowance";

	public static final String SA = "sa";

	public static final String SPECIAL_ALLOWANCE = "special allowance";

	public static final String OTHER_ALLOWANCE = "other Allowance";

	public static final String PF = "pf";

	public static final String APPROVAL = "Approval";

	public static final String PT = "pt";

	public static final String SUNDAY = "Sunday";
	public static final String MONDAY = "Monday";
	public static final String TUESDAY = "Tuesday";
	public static final String WEDNESDAY = "Wednesday";
	public static final String THURSDAY = "Thursday";
	public static final String FRIDAY = "Friday";
	public static final String SATURDAY = "Saturday";

	public static final String EMP = "emp";

	public static final String SELECTED_DAY = "SelectedDay";

	public static final String LAST_DAY = "LastDay";

	public static final String VALID_PASSWORD = "Provide Proper Password";
	public static final String VALID_CHANGE_PASSWORD = "Password must has at least 8 characters that include at least 1 lowercase character,1 uppercase character,1 number and 1 special character in @#&_-";
	public static final String SIGNUP_TEMPLATE_NAME = "mail_verification.html";
	public static final String OSTAFF_LOGO = "ostafflogo";
	public static final String COMPANY_EMAIL = "Company email is already exist with other company";

	public static final String CONTACT = "Contact";

	public static final String PARAGRAPH1 = "ONPASSIVE India Pvt. Ltd.";
	public static final String PARAGRAPH2 = "DSR Inspire, Plot No.21, HUDA Techno Enclave, HITECH City, Hyderabad, Telangana - 500 081.";

	public static final String ROLE_ACTIVE_SUCCESS = "Role Activated Successfully";

	public static final String COMPANY_NAME = "Company name is already exist with other company";
	public static final String COMPANY_USER = "User Name is already exist with other company";
	public static final String COMPANY_CONTACT = "Company contact number is already exist with other company";
	public static final String COMP_NAME = "companyName";
	public static final String PROMOTIONAL_DATA = "promotional data";

	public static final String INVALID_PASSCODE = "Invalid Passcode";
	public static final String ACCOUNT_LOCK1 = "Invalid credentials, your account will lock after 2 failure attempts";
	public static final String ACCOUNT_LOCK2 = "Invalid credentials, your account will lock after 1 failure attempt";

	public static final String LEAVE_APPROVAL_MENU_PATH = "leave/leave-approval";
	public static final String LEAVE_NOTIFICATION_TYPE = "Leave";
	public static final String LEAVE_NOTIFICATION_MESSAGE = "Leave to be approve";
	public static final String LEAVE_REJECTED_MESSAGE = "Leave Rejected";
	public static final String LEAVE_APPROVED_MESSAGE = "Leave Approved";
	public static final String REVOKED = "Revoked";
	public static final String EXIT_PROCESS = "Exit Process";
	public static final String REVOKE_APPLIED = "Revoke Applied";
	public static final String REVOKE_APPROVED = "Revoke Approved";
	public static final String REVOKE_REJECTED = "Revoke Rejected";
	public static final String SELECTIVE_LIST = "Selected employees list is more than 25";

	public static final String YES = "yes";
	public static final String NO = "no";
}
