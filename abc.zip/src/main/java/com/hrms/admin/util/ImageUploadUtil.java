package com.hrms.admin.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.exceptions.NotCreatedException;

@Component
public class ImageUploadUtil {
	private static final Logger logger = LoggerFactory.getLogger(ImageUploadUtil.class);
	private String UPLOADED_FOLDER = ".//src//main//resources//Images//";

	/*
	 * @Autowired private SequenceGeneratorUtil seqGeneratorService;
	 * 
	 * @Autowired private MailImagesRepository mailImagesRepo;
	 */
	public void uploadFile(MultipartFile file, String type) {

		try {

			if (type.equals(Constants.WEDDING_TOP)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "weddingTop.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.WEDDING_BOTTOM)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "weddingBottom.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.BIRTHDAY)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "birthday.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.EMPLOYEE_OF_MONTH)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "employeeOfMonth.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.EMP_ONBOARDING)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "empOnboarding.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.HOLIDAY)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "holiday.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.BABYBOY)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "babyBoy.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.BABYGIRL)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "babyGirl.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.EVENT)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "event.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.LOGO)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "logo.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.TRAINING)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "training.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.PROMOTION)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "promotion.png");
				Files.write(path, bytes);
			} else if (type.equals("productLaunch")) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "productLaunch.png");
				Files.write(path, bytes);
			} else if (type.equals(Constants.TEAMAPPRECIALS)) {
				byte[] bytes = file.getBytes();
				Path path = Paths.get(UPLOADED_FOLDER + "teamApprecials.png");
				Files.write(path, bytes);
			}
		} catch (IOException e) {
			throw new NotCreatedException(Constants.INSERTION_ERROR + " " + Constants.IMAGE_UPLOAD);
		}
	}

	/*
	 * @Transactional public String mailImageUpload(MultipartFile[] files) { String
	 * str = "Images uploaded successfully"; try { for (MultipartFile file : files)
	 * { String imageName =
	 * FilenameUtils.removeExtension(file.getOriginalFilename()); MailImages
	 * mailImages = new MailImages();
	 * mailImages.setId(seqGeneratorService.generateSequence(MailImages.
	 * SEQUENCE_NAME)); mailImages.setImage(file.getBytes());
	 * mailImages.setContantType(file.getContentType());
	 * mailImages.setFileName(imageName);
	 * mailImages.setFullFileName(file.getOriginalFilename());
	 * mailImagesRepo.insert(mailImages); } return str; } catch (IOException e) {
	 * return "Exception"; } }
	 * 
	 * public MailImages getFile(String name) { MailImages findByFileName =
	 * mailImagesRepo.findByFileName(name);
	 * 
	 * String encodedString =
	 * Base64.getEncoder().encodeToString(findByFileName.getImage()); StringBuffer
	 * br=new StringBuffer(); br.append(encodedString);
	 * logger.info("+++++++++++"+br.toString());
	 * 
	 * return findByFileName; }
	 */
}
