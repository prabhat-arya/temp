package com.hrms.admin.util;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class StringToDateUtility {

	private static final Logger logger = LoggerFactory.getLogger(StringToDateUtility.class);

	public static Date convertToDate(String stringDate) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		return simpleDateFormat.parse(stringDate);
	}

	public static Date stringToDate(String stringDate) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
		return simpleDateFormat.parse(stringDate);
	}

	public String calculateWorkingHours(String inTime, String outTime) {
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		String hms = null;
		try {
			Date inTimeDate = sdf1.parse(inTime);
			Date outTimeDate = sdf2.parse(outTime);
			Long diffTime = outTimeDate.getTime() - inTimeDate.getTime();
			hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(diffTime),
					TimeUnit.MILLISECONDS.toMinutes(diffTime)
							- TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(diffTime)),
					TimeUnit.MILLISECONDS.toSeconds(diffTime)
							- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(diffTime)));
		} catch (ParseException e) {
			logger.info("Error in calculating working hours");
		}
		return hms;
	}

	public Long attendsPersentage(String inTime, String outTime, String noOfHrs) {
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		Long percentage = 0l;
		try {
			Date inTimeDate = sdf1.parse(inTime);
			Date outTimeDate = sdf2.parse(outTime);
			Long diffTime = outTimeDate.getTime() - inTimeDate.getTime();
			LocalTime localTime = LocalTime.parse(noOfHrs);
			Long millis = (long) (localTime.toSecondOfDay() * 1000);
			Long noOfhrs = (millis / (1000 * 60 * 60)) % 24;
			Long actualHrs = (diffTime / (1000 * 60 * 60)) % 24;
			percentage = noOfhrs * 100 / actualHrs;
		} catch (ParseException e) {
			logger.info("Error in calculating attendances Percentage");
		}
		return percentage;
	}

	public String getYesterdayDateString() {
		DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return dateFormat.format(cal.getTime());
	}

	public List<String> getWeekDateString() {
		List<String> list = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATEFORMAT);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		Date date = cal.getTime();
		list.add(sdf.format(date));
		for (int i = 1; i < 6; i++) {
			cal.add(Calendar.DAY_OF_MONTH, -1);
			date = cal.getTime();
			list.add(sdf.format(date));
		}
		return list;
	}

	public Long daysCount(Date startDate, Date endDate) {
		long diffInMillies = Math.abs(endDate.getTime() - startDate.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;
		return (Long) diff;
	}

	public List<String> getInBetweenDates(Date startDate, Date endDate) {
		List<String> list = new ArrayList<>();
		Object day = startDate;
		Long count = daysCount(startDate, endDate);
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATEFORMAT);
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		list.add(sdf.format(day));
		for (int i = 1; i < count; i++) {
			cal.add(Calendar.DAY_OF_MONTH, +1);
			date = cal.getTime();
			list.add(sdf.format(date));
		}
		return list;
	}

	public String daysConverter(Integer number) {
		Map<Integer, String> map = new HashedMap<>();
		map.put(0, Constants.SUNDAY);
		map.put(1, Constants.MONDAY);
		map.put(2, Constants.TUESDAY);
		map.put(3, Constants.WEDNESDAY);
		map.put(4, Constants.THURSDAY);
		map.put(5, Constants.FRIDAY);
		map.put(6, Constants.SATURDAY);
		return map.get(number);
	}

	public String dateToString(Date date) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
		return dateFormat.format(date);

	}

	public List<String> getInBetweenDate(Date startDate, Date endDate) {
		List<String> list = new ArrayList<>();
		Object day = startDate;
		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATEFORMAT);
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		list.add(sdf.format(day));
		cal.setTime(startDate);
		while (cal.getTime().before(endDate)) {
			cal.add(Calendar.DATE, 1);
			date = cal.getTime();
			list.add(sdf.format(date));
		}
		return list;
	}

	public Double roundTwoDecimalsInPercentage(Double value) {
		DecimalFormat df = new DecimalFormat("#.##");
		df.setRoundingMode(RoundingMode.FLOOR);
		return Double.valueOf(df.format(value));
	}

	public Date getNextYearCurrentDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, 1); // to get previous year add -1
		Date nextYear = cal.getTime();
		return nextYear;
	}

	public String changeDateFormat(Date date) throws Exception {
		String strDate = date.toString();
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("MMM dd, yyyy");
		Date dateNew = format1.parse(strDate);
		return format2.format(dateNew);
	}

	public String changeDateFormatFromString(String strDate) throws Exception {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("MMM dd, yyyy");
		Date dateNew = format1.parse(strDate);
		return format2.format(dateNew);
	}

	public String changeDateFormatFromStringDateAndTime(String strDate) throws Exception {
		SimpleDateFormat format1 = new SimpleDateFormat(Constants.CONSTANT_DATEFORMATE);
		SimpleDateFormat format2 = new SimpleDateFormat("HH:mm:ss");
		Date dateNew = format1.parse(strDate);
		return format2.format(dateNew);
	}

	public String formattedValue(Double value) {
		NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
		String moneyString = formatter.format(value);
		return moneyString.substring(1);
	}

	public String changeISTDate(Date date) throws Exception {
		DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		Date date1 = (Date) formatter.parse(date.toString());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		String formatedDate = cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + "-"
				+ cal.get(Calendar.YEAR);
		return formatedDate;
	}
	public String changeDateFormat(String date) throws Exception {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("MMM dd, yyyy");
		Date dateNew = format1.parse(date);
		return format2.format(dateNew);
	}

}
