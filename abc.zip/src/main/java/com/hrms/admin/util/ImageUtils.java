package com.hrms.admin.util;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class ImageUtils {

	static {
		ImageIO.scanForPlugins();
	}
	@Value("${file.s3UploadImg}")
	private String folderpath;

	/**
	 * Resizes an image to a absolute width and height (the image may not be
	 * proportional)
	 * 
	 * @param inputImagePath  Path of the original image
	 * @param outputImagePath Path to save the resized image
	 * @param scaledWidth     absolute width in pixels
	 * @param scaledHeight    absolute height in pixels
	 * @throws IOException
	 */
	public void resize(String inputImagePath, int scaledWidth, int scaledHeight, String fileType, String fileName)
			throws IOException {
		// reads input image
		File file = new File(inputImagePath);
		BufferedImage inputImage = ImageIO.read(file);

		// creates output image
		BufferedImage outputImage = new BufferedImage(scaledWidth, scaledHeight, inputImage.getType());

		// scales the input image to the output image
		Graphics2D g2d = outputImage.createGraphics();
		g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
		g2d.dispose();

		// writes to output file filetype for file extension
		ImageIO.write(outputImage, fileType, new File(folderpath + Constants.SUFFIX + fileName));
	}

	public MultipartFile file(String fileName, String contantType) {
		try {
			File file = new File(folderpath + Constants.SUFFIX + fileName);
			FileInputStream input;

			input = new FileInputStream(file);
			byte[] byteArray = IOUtils.toByteArray(input);
			return new MockMultipartFile(Constants.FILE, file.getName(), contantType, byteArray);
		} catch (IOException e) {
			return null;
		}
	}

	public Boolean deleteAllTempFiles() {

		File dir = new File(folderpath);

		if (Boolean.FALSE.equals(dir.isDirectory())) {
			return false;
		}
		File[] listFiles = dir.listFiles();
		for (File file : listFiles) {
			file.delete();
		}
		return true;
	}
}
