package com.hrms.admin.util;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.AnnualLeaves;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.LeaveType;
import com.hrms.admin.repository.AnnualLeavesRepository;
import com.hrms.admin.repository.LeaveTypeRepository;

@Component
public class AnnualLeavesUtil {

	@Autowired
	private AnnualLeavesRepository repo;
	@Autowired
	private LeaveTypeRepository leaveTypeRepo;

	/**
	 * adding annual leaves for employee based on leaveTypes
	 */
	@Transactional
	public void addingAnnualLeaves(Employee emp) {
		List<LeaveType> leaveTpes = leaveTypeRepo.findByCompanyId(emp.getCompany().getId(),emp.getBranch().getId());
		for (LeaveType lt : leaveTpes) {
			AnnualLeaves entity = new AnnualLeaves();
			entity.setYearlyLeaves(lt.getAnnualLeaves());
			entity.setEmployee(emp);
			entity.setLeaveType(lt);
			Long leave = 0L;
			entity.setAvailableLeaves(leave);
			entity.setTotalTookLeaves(leave);
			repo.save(entity);
		}
	}

	/**
	 * adding available leaves for every employee based on leaveType
	 */
	public void addIntialLeaves() {
		List<LeaveType> leaveTpes = leaveTypeRepo.findAll();
		for (LeaveType lt : leaveTpes) {
			List<AnnualLeaves> l = repo.findByLeaveTypeId(lt.getId());
			for (AnnualLeaves entity : l) {
				entity.setAvailableLeaves(entity.getAvailableLeaves() + lt.getMonthlyLeaves());
				repo.save(entity);
			}
		}
	}

	/**
	 * delete the uncarryforward annual leaves
	 */
	public void deleteAnnualLeaves() {
		List<LeaveType> leaveTpes = leaveTypeRepo.findAll();
		for (LeaveType lt : leaveTpes) {
			if (lt.getIsCarryForward().equals(Boolean.FALSE)) {
				List<AnnualLeaves> l = repo.findByLeaveTypeId(lt.getId());
				for (AnnualLeaves entity : l) {
					entity.setAvailableLeaves(0L);
					repo.save(entity);
				}
			}
		}
	}
	
	public void addIntialLeavesForNewJoinee(Long empId) {
		List<LeaveType> leaveTpes = leaveTypeRepo.findAll();
		for (LeaveType lt : leaveTpes) {
			List<AnnualLeaves> l = repo.findByLeaveTypeIdAndEmpId(lt.getId(),empId);
			for (AnnualLeaves entity : l) {
				entity.setAvailableLeaves(entity.getAvailableLeaves() + lt.getMonthlyLeaves());
				repo.save(entity);
			}
		}
	}
}
