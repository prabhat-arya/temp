package com.hrms.admin.util;

//@Component
public class EmployeeIDGeneratorUtil {


//	@Autowired
//	private EmployeeRepository repository;
//
//	public String generateEmployeeId() {
//
//		
//		String str = "ONP"; // provided from the front end
//
//		Long increamentedEmployeeId = 10120001L;
//
//		
//		String lastDbEmployeeId = repository.getLastEmployeeIdForCustomeIdGeneration();
//
//		if (lastDbEmployeeId == null || lastDbEmployeeId.equals("")) {
//			return (str + increamentedEmployeeId);
//		}
//
//		Long numID = 0L;
//		//String preString = null;
//		StringBuffer alpha = new StringBuffer();
//		StringBuffer num = new StringBuffer();
//
//		for (int i = 0; i < lastDbEmployeeId.length(); i++) {
//			if (Character.isDigit(lastDbEmployeeId.charAt(i)))
//				num.append(lastDbEmployeeId.charAt(i));
//			else if (Character.isAlphabetic(lastDbEmployeeId.charAt(i)))
//				alpha.append(lastDbEmployeeId.charAt(i));
//
//		}
//		//preString = alpha.toString(); // ONP
//		numID = Long.parseLong(num.toString()); // 567
//
//		AtomicLong numberGenerator = new AtomicLong(numID);
//		for (int i = 1; i <= 2; i++) {
//
//			// it will generate the Next EmployeeId
//			increamentedEmployeeId = numberGenerator.getAndIncrement();
//		}
//		return str + increamentedEmployeeId;
//	}
}
