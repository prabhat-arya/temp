package com.hrms.admin.util;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class ExcelHeaderCheckUtil {

	@Autowired
	private EmployeeDataUploadUtil employeeDataUploadUtil;

	public Boolean compareExcelHeader(MultipartFile file, String[] headerArray) {
		Map<Integer, String> convertExcelHeaderToMap = convertExcelHeaderToMap(file);
		Map<Integer, String> convertArrayToMap = convertArrayToMap(headerArray);
		return convertExcelHeaderToMap.equals(convertArrayToMap);

	}

	public Map<Integer, String> convertExcelHeaderToMap(MultipartFile file) {
		Workbook wb = employeeDataUploadUtil.getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		Row row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		Map<Integer, String> headersMap = new HashedMap<>();
		Integer i = 1;
		while (cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			headersMap.put(i++, cell.getStringCellValue());
		}
		return headersMap;
	}

	public Map<Integer, String> convertArrayToMap(String[] array) {
		Map<Integer, String> headersMap = new HashedMap<>();
		Integer i = 1;
		for (String str : array) {
			headersMap.put(i++, str);
		}
		return headersMap;
	}

	public Map<Integer, String> convertExcelHeaderToMapWithSheetNo(MultipartFile file, int sheetno) {
		Workbook wb = employeeDataUploadUtil.getWorkBook(file);
		Sheet sheet = wb.getSheetAt(sheetno);
		Row row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		Map<Integer, String> headersMap = new HashedMap<>();
		Integer i = 1;
		while (cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			headersMap.put(i++, cell.getStringCellValue());
		}
		return headersMap;
	}
	public Boolean compareExcelSheetNames(MultipartFile file) {
		Map<Integer, String> convertExcelHeaderToMap = getExcelSheetNames(file);
		Map<Integer, String> convertArrayToMap = ExcelSheetNames();
		return convertExcelHeaderToMap.equals(convertArrayToMap);

	}
	public Map<Integer, String> getExcelSheetNames(MultipartFile file) {
		Workbook wb = employeeDataUploadUtil.getWorkBook(file);
		Map<Integer, String> headersMap = new HashedMap<>();
		headersMap.put(1, wb.getSheetAt(0).getSheetName());
		headersMap.put(2, wb.getSheetAt(1).getSheetName());
		headersMap.put(3, wb.getSheetAt(2).getSheetName());
		headersMap.put(4, wb.getSheetAt(3).getSheetName());
		headersMap.put(5, wb.getSheetAt(4).getSheetName());
		headersMap.put(6, wb.getSheetAt(5).getSheetName());
		return headersMap;
	}
	
	public Map<Integer, String> ExcelSheetNames() {
		Map<Integer, String> headersMap = new HashedMap<>();
		headersMap.put(1, ExcelHeaders.EMP_BASIC_DETAILS_SHEETNAME);
		headersMap.put(2,  ExcelHeaders.EMP_EDUCATIONAL_DETAILS_SHEETNAME);
		headersMap.put(3, ExcelHeaders.EMP_EMERGENCY_CONTACT_DETAILS_SHEETNAME);
		headersMap.put(4, ExcelHeaders.EMP_EXPRIENCE_DETAILS_SHEETNAME);
		headersMap.put(5, ExcelHeaders.EMP_OFFICAL_MAIL_IDS_SHEETNAME);
		headersMap.put(6, ExcelHeaders.EMP_PERSONAL_CONTACT_DETAILS_SHEETNAME);
		return headersMap;
	}

	public Boolean compareExcelHeaderForMultipleSheets(MultipartFile file) {

		Map<Integer, String> convertExcelHeaderToMap = convertExcelHeaderToMapWithSheetNo(file, 0);
		Map<Integer, String> convertArrayToMap = convertArrayToMap(ExcelHeaders.EMP_BASIC_DETAILS);
		Map<Integer, String> convertExcelHeaderToMap1 = convertExcelHeaderToMapWithSheetNo(file, 1);
		Map<Integer, String> convertArrayToMap1 = convertArrayToMap(ExcelHeaders.EMP_EDUCATIONAL_DETAILS);
		Map<Integer, String> convertExcelHeaderToMap2 = convertExcelHeaderToMapWithSheetNo(file, 2);
		Map<Integer, String> convertArrayToMap2 = convertArrayToMap(ExcelHeaders.EMP_EMERGENCY_CONTACT_DETAILS);
		Map<Integer, String> convertExcelHeaderToMap3 = convertExcelHeaderToMapWithSheetNo(file, 3);
		Map<Integer, String> convertArrayToMap3 = convertArrayToMap(ExcelHeaders.EMP_EXPRIENCE_DETAILS);
		Map<Integer, String> convertExcelHeaderToMap4 = convertExcelHeaderToMapWithSheetNo(file, 4);
		Map<Integer, String> convertArrayToMap4 = convertArrayToMap(ExcelHeaders.EMP_OFFICAL_MAIL_IDS);
		Map<Integer, String> convertExcelHeaderToMap5 = convertExcelHeaderToMapWithSheetNo(file, 5);
		Map<Integer, String> convertArrayToMap5 = convertArrayToMap(ExcelHeaders.EMP_PERSONAL_CONTACT_DETAILS);
		
		boolean isflag = convertExcelHeaderToMap.equals(convertArrayToMap);
		boolean isflag1 = convertExcelHeaderToMap1.equals(convertArrayToMap1);
		boolean isflag2 = convertExcelHeaderToMap2.equals(convertArrayToMap2);
		boolean isflag3 = convertExcelHeaderToMap3.equals(convertArrayToMap3);
		boolean isflag4 = convertExcelHeaderToMap4.equals(convertArrayToMap4);
		boolean isflag5 = convertExcelHeaderToMap5.equals(convertArrayToMap5);
		if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
				|| Boolean.FALSE.equals(isflag3) || Boolean.FALSE.equals(isflag4)|| Boolean.FALSE.equals(isflag5)) {
			return false;
		}
		return true;

	}
}
