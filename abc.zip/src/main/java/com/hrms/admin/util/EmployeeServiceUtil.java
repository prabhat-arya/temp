package com.hrms.admin.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.AcademicDetailsDTO;
import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.EmergencyContactDetailsDTO;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeProfileDTO;
import com.hrms.admin.dto.EmployeePromotionalDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.FileDTO;
import com.hrms.admin.dto.OfficeUseOnlyDTO;
import com.hrms.admin.dto.PersonalDetailsDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.ProfessionalDetailsDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.AcademicDetails;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.AssignShift;
import com.hrms.admin.entity.BankDetails;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Department;
import com.hrms.admin.entity.Designation;
import com.hrms.admin.entity.EmergencyContactDetails;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeePromotional;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.FileDetails;
import com.hrms.admin.entity.PersonalDetails;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.entity.ProfessionalDetails;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.ResourceItems;
import com.hrms.admin.entity.Shift;
import com.hrms.admin.repository.AcademicDetailsRepository;
import com.hrms.admin.repository.AssignShiftRepository;
import com.hrms.admin.repository.BankRepository;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.DepartmentRepository;
import com.hrms.admin.repository.Designationrepository;
import com.hrms.admin.repository.EmergencyContactDetailsRepository;
import com.hrms.admin.repository.EmployeePromotionalRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.FilesRepository;
import com.hrms.admin.repository.PersonalDetailsRepository;
import com.hrms.admin.repository.ProfessionalDetailsRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.repository.ResourceItemsRepository;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.repository.ShiftRepository;

@Component
public class EmployeeServiceUtil {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceUtil.class);
	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private BankRepository bankRepo;

	@Autowired
	private ProfileImageRepository profileRepo;

	@Autowired
	private FilesRepository filerepo;

//	@Autowired
//	private AddressRepository addressRepository;

	@Autowired
	private ProfessionalDetailsRepository prRepo;

	@Autowired
	private ResourceItemsRepository resourceItemsRepo;

	@Autowired
	private EmergencyContactDetailsRepository ecdrepo;

	@Autowired
	private RolesRepository roleRepo;

	/*
	 * @Autowired private SkillRepository skillRepo;
	 */

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private BranchRepository branchRepo;

	@Autowired
	private DepartmentRepository deptRepo;

	@Autowired
	private Designationrepository designationRepo;

	@Autowired
	private AssignShiftRepository asRepo;

//	@Autowired
//	private EmployeeProfileImageRepository employeeProfileImageRepo;

	@Autowired
	private RolesRepository rolesRepo;

	@Autowired
	private PersonalDetailsRepository pdRepo;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private AcademicDetailsRepository adRepo;

	@Autowired
	private ProjectRepository projectRepo;

	@Autowired
	private ShiftRepository shiftRepo;

	@Autowired
	private StringToDateUtility dateUtil;

	@Autowired
	private EmergencyContactDetailsRepository ecdRepo;

	@Autowired
	private EmployeePromotionalRepository empPromotionalRepo;

	@Autowired
	private PersonalDetailsRepository personalDetailsRepo;

	@Autowired
	private ConversionUtils conversionUtils;

	/**
	 * 
	 * @param employeedto
	 * @return save employee info
	 */
	@Transactional
	public Employee saveEmployee(EmployeeInfoDTO employeedto) {
		Employee employee = new Employee();
		employee.setFirstName(employeedto.getFirstName());
		employee.setMiddleName(employeedto.getMiddleName());
		employee.setLastName(employeedto.getLastName());
		employee.setEmail(employeedto.getEmail().toLowerCase());
		if (!employeedto.getOfficalMail().isEmpty()) {
			employee.setOfficalMail(employeedto.getOfficalMail().toLowerCase());
		}
		employee.setUserName(employeedto.getUserName());
		employee.setAlternateContactNo(employeedto.getAlternateContactNo());
		employee.setMarriageDay(employeedto.getMarriageDate());
		employee.setDateOfBirth(employeedto.getDateOfBirth());
		employee.setGender(employeedto.getGender());
		employee.setMaritalStatus(employeedto.getMaritalStatus());
		employee.setContactNo(employeedto.getContactNo());
		employee.setAadharCard(employeedto.getAadharCard());
		employee.setVoterID(employeedto.getVoterID());
		employee.setPassport(employeedto.getPassport());
		employee.setJoiningDate(employeedto.getJoiningDate());
		employee.setPanCard(employeedto.getPanCard());
		employee.setBloodGroup(employeedto.getBloodGroup());
		employee.setIsSameAddress(employeedto.getIsSameAddress());
		employee.setAddress(copyAddressWhileAdd(employeedto.getAddresses()));
		// academicDetail adding
		employee.setPrimarySkills(employeedto.getPrimarySkills().toString());
		employee.setSecondarySkills(employeedto.getSecondarySkills().toString());
//		employee.setSkills(copySkills(employeedto.getSkills()));
		employee.setEmploymentTypeId(employeedto.getEmploymentTypeId());
		employee.setEmpTypeStartDate(employeedto.getEmpTypeStartDate());
		employee.setEmpTypeEndDate(employeedto.getEmpTypeEndDate());
//		employee.setPersonalDetails(copyPersonalDetails(employeedto.getPersonalDetails()));

		Optional<Company> company1 = companyRepo.findById(employeedto.getCompanyId());
		if (company1.isPresent()) {
			employee.setCompany(company1.get());
		}
		Optional<Branch> branch1 = branchRepo.findById(employeedto.getBranchId());
		if (branch1.isPresent()) {
			employee.setBranch(branch1.get());
		}
		Optional<Department> dept1 = deptRepo.findById(employeedto.getDepartmentId());
		if (dept1.isPresent()) {
			employee.setDepartment(dept1.get());
		}
		Optional<Designation> designation1 = designationRepo.findById(employeedto.getDesignationId());
		if (designation1.isPresent()) {
			employee.setDesignation(designation1.get());
		}
		Optional<Employee> manager1 = employeeRepo.findById(employeedto.getManagerId());
		if (manager1.isPresent()) {
			employee.setManager(manager1.get());
		}
		employee.setIsActive(Boolean.FALSE);
		employee.setIsApprove(Boolean.FALSE);
		employee.setIsDelete(Boolean.FALSE);
		employee.setIsExit(Boolean.FALSE);
		employee.setRoles(copyEmployeeRoles(employeedto.getRoleId()));

		Employee employeeNew = employeeRepo.save(employee);

		if (!employeedto.getProfessionalDetails().isEmpty()) {
			prRepo.saveAll(copyProfessionalDetails(employeedto.getProfessionalDetails(), employeeNew));
		}
		if (!employeedto.getAcademicDetails().isEmpty()) {
			adRepo.saveAll(copyAcademicDetailsWhileAdd(employeedto.getAcademicDetails(), employeeNew));
		}
		if (!employeedto.getEmergencyContactDetails().isEmpty()) {
			ecdRepo.saveAll(copyEmergencyContactDetails(employeedto.getEmergencyContactDetails(), employeeNew));
		}
		if (!employeedto.getEmployeePromotionalDetails().isEmpty()) {
			empPromotionalRepo
					.saveAll(copyEmployeePromotionalDetails(employeedto.getEmployeePromotionalDetails(), employeeNew));
		}
		if (!employeedto.getPersonalDetails().isEmpty()) {
			personalDetailsRepo.saveAll(copyPersonalContactDetails(employeedto.getPersonalDetails(), employeeNew));
		}
		logger.info("Employee saved with id:{}", employeeNew.getId());
		return employeeNew;

	}

	/**
	 * 
	 * @param employee
	 * @return get employee info
	 */
	public EmployeeDTO getEmployee(Employee employee) {
		EmployeeDTO employeedto = new EmployeeDTO();
		employeedto.setId(employee.getId());
		employeedto.setFirstName(employee.getFirstName());
		employeedto.setMiddleName(employee.getMiddleName());
		employeedto.setLastName(employee.getLastName());
		employeedto.setEmail(employee.getEmail());
		employeedto.setOfficalMail(employee.getOfficalMail());
		employeedto.setUserName(employee.getUserName());
		employeedto.setManagerId(employee.getManager().getId());
		employeedto.setDateOfBirth(employee.getDateOfBirth());
		employeedto.setGender(employee.getGender());
		employeedto.setMaritalStatus(employee.getMaritalStatus());
		employeedto.setContactNo(employee.getContactNo());
		employeedto.setAlternateContactNo(employee.getAlternateContactNo());
		employeedto.setAadharCard(employee.getAadharCard());
		employeedto.setPanCard(employee.getPanCard());
		employeedto.setVoterID(employee.getVoterID());
		employeedto.setPassport(employee.getPassport());
		employeedto.setJoiningDate(employee.getJoiningDate());
		employeedto.setBloodGroup(employee.getBloodGroup());
		employeedto.setMarriageDate(employee.getMarriageDay());
		employeedto.setIsSameAddress(employee.getIsSameAddress());
		employeedto.setEmploymentTypeId(employee.getEmploymentTypeId());
		employeedto.setEmpTypeStartDate(employee.getEmpTypeStartDate());
		employeedto.setEmpTypeEndDate(employee.getEmpTypeEndDate());
		// addresses
		employeedto.setAddresses(copyAddressWhileGet(employee.getAddress()));
		// AcademicDetails
		employeedto.setAcademicDetails(copyAcademicDetailsWhileGet(adRepo.findByEmployee(employee.getId())));
		// Projects
		employeedto.setProjects(copyProjectsWhileGet(employee.getProjects()));
		// files
		employeedto.setFiles(copyFilesWhileGet(employee.getId()));
		// policies
		employeedto.setPolicies(copyPoliciesWhileGet(employee.getPolicies()));

		// Skills
//		List<Long> skills = new ArrayList<>();
//		for (Skill skill : employee.getSkills()) {
//			skills.add(skill.getId());
//		}
//		employeedto.setSkills(skills);
		if (employee.getPrimarySkills() != null || !employee.getPrimarySkills().equals("[]")) {
			employeedto.setPrimarySkills(conversionUtils.ListConversion(employee.getPrimarySkills()));
		}
		if (employee.getSecondarySkills() != null || !employee.getSecondarySkills().equals("[]")) {
			employeedto.setSecondarySkills(conversionUtils.ListConversion(employee.getSecondarySkills()));
		}
		// Resource items
		employeedto.setResourceItems(copyResourceItemsWhileGet(employee.getId()));

		// ProfessionalDetails
		employeedto.setProfessionalDetails(copyProfessionalDetailsWhileGet(employee.getId()));

		// EmergencyContactDetails
		employeedto.setEmergencyContactDetails(
				copyEmergencyContactDetailsWhileGet(ecdRepo.findByEmployee(employee.getId())));
		employeedto.setPersonalDetails(
				copyPersonalContactDetailsWhileGet(personalDetailsRepo.findByEmployee(employee.getId())));
		// personal details
//		if (!employee.getPersonalDetails().isEmpty()) {
//			employeedto.setPersonalDetails(copyPersonalDetailsWhileGet(employee.getPersonalDetails()));
//		}

		// promotional details
		employeedto.setEmployeePromotionalDetails(
				copyEmployeePromotionalDetailsWhileGet(empPromotionalRepo.findByEmployee(employee.getId())));
		// employee roles
		if (!employee.getRoles().isEmpty()) {
			for (EmployeeRoles role : employee.getRoles()) {
				employeedto.setRoleId(role.getRoleId());
			}
		}
		// profile image details
		String name = "_";
		employeedto.setProfileimage(copyProfileImage(employee.getId(), name));

		employeedto.setIpAddress(employee.getIpAddress());
		employeedto.setPort(employee.getPort());
		employeedto.setDepartmentId(employee.getDepartment().getId());
		employeedto.setDepartmentName(employee.getDepartment().getName());
		employeedto.setDesignationId(employee.getDesignation().getId());
		employeedto.setDesignationName(employee.getDesignation().getDesignation());
		employeedto.setCompanyId(employee.getCompany().getId());
		employeedto.setCompanyName(employee.getCompany().getName());
		employeedto.setBranchId(employee.getBranch().getId());
		employeedto.setBranchName(employee.getBranch().getName());
		employeedto.setManagerId(employee.getManager().getId());
		employeedto.setManagerName(employee.getManager().getFirstName() + " " + employee.getManager().getLastName());
		employeedto.setIsApprove(employee.getIsApprove());
		employeedto.setIsActive(employee.getIsActive());
		employeedto.setIsDelete(employee.getIsDelete());
		employeedto.setCtc(employee.getCtc());
		logger.info("Employee found with Id:{}", employeedto.getId());
		return employeedto;
	}

	/**
	 * 
	 * @param employeedto
	 * @param id
	 * @return update employee info
	 */
	@Transactional
	public Employee updateEmplyee(EmployeeInfoDTO employeedto, Long id) {
		Optional<Employee> optionalEmployee = employeeRepo.findById(id);
		if (!optionalEmployee.isPresent()) {
			return null;
		}
		Employee employee = optionalEmployee.get();
		employee.setFirstName(employeedto.getFirstName());
		employee.setAlternateContactNo(employeedto.getAlternateContactNo());
		employee.setMiddleName(employeedto.getMiddleName());
		employee.setLastName(employeedto.getLastName());
		employee.setEmail(employeedto.getEmail().toLowerCase());
		employee.setMaritalStatus(employeedto.getMaritalStatus());
		employee.setUserName(employeedto.getUserName());
		employee.setOfficalMail(employeedto.getOfficalMail().toLowerCase());
		employee.setDateOfBirth(employeedto.getDateOfBirth());
		employee.setContactNo(employeedto.getContactNo());
		employee.setBloodGroup(employeedto.getBloodGroup());
		employee.setAadharCard(employeedto.getAadharCard());
		employee.setGender(employeedto.getGender());
		employee.setVoterID(employeedto.getVoterID());
		employee.setPassport(employeedto.getPassport());
		employee.setPanCard(employeedto.getPanCard());
		employee.setJoiningDate(employeedto.getJoiningDate());
		employee.setMarriageDay(employeedto.getMarriageDate());
		employee.setIsSameAddress(employeedto.getIsSameAddress());
		employee.setEmploymentTypeId(employeedto.getEmploymentTypeId());
		employee.setEmpTypeStartDate(employeedto.getEmpTypeStartDate());
		employee.setEmpTypeEndDate(employeedto.getEmpTypeEndDate());
		// Address
		employee.setAddress(copyAddressWhileUpdate(employeedto.getAddresses(), employee.getAddress()));
		// academicDetail adding

		employee.setPrimarySkills(employeedto.getPrimarySkills().toString());
		if (!employeedto.getSecondarySkills().equals("[]")) {
			employee.setSecondarySkills(employeedto.getSecondarySkills().toString());
		}
//		employee.setSkills(copySkills(employeedto.getSkills()));

		Optional<Company> company = companyRepo.findById(employeedto.getCompanyId());
		if (company.isPresent()) {
			employee.setCompany(company.get());
		}
		Optional<Branch> branch = branchRepo.findById(employeedto.getBranchId());
		if (branch.isPresent()) {
			employee.setBranch(branch.get());
		}
		Optional<Department> dept = deptRepo.findById(employeedto.getDepartmentId());
		if (dept.isPresent()) {
			employee.setDepartment(dept.get());
		}
		Optional<Designation> designation = designationRepo.findById(employeedto.getDesignationId());
		if (designation.isPresent()) {
			employee.setDesignation(designation.get());
		}
		Optional<Employee> manager = employeeRepo.findById(employeedto.getManagerId());
		if (manager.isPresent()) {
			employee.setManager(manager.get());
		}
		// roles to employees
		employee.setRoles(copyEmployeeRoles(employeedto.getRoleId()));

		Employee emp = employeeRepo.save(employee);
		List<ProfessionalDetails> list = prRepo.findByEmployee(employee.getId());
		if (!Objects.isNull(employeedto.getProfessionalDetails())) {
			for (ProfessionalDetails prod : list) {
				prRepo.deleteById(prod.getId());
			}
			List<ProfessionalDetails> copyProfessionalDetails = copyProfessionalDetails(
					employeedto.getProfessionalDetails(), emp);
			prRepo.saveAll(copyProfessionalDetails);
			logger.info("Employee experience details updated with Id:{}", emp.getId());
		}

		if (!Objects.isNull(employeedto.getAcademicDetails())) {
			List<AcademicDetails> academicDetails = adRepo.findByEmployee(employee.getId());
			for (AcademicDetails ecd : academicDetails) {
				adRepo.deleteById(ecd.getId());
			}
			adRepo.saveAll(copyAcademicDetailsWhileAdd(employeedto.getAcademicDetails(), emp));
		}

		// EmergencyContactDetails
		if (!Objects.isNull(employeedto.getEmergencyContactDetails())) {
			List<EmergencyContactDetails> list1 = ecdrepo.findByEmployee(employee.getId());
			for (EmergencyContactDetails ecd : list1) {
				ecdrepo.deleteById(ecd.getId());
			}
			ecdRepo.saveAll(copyEmergencyContactDetails(employeedto.getEmergencyContactDetails(), emp));
		}
		if (!Objects.isNull(employeedto.getEmployeePromotionalDetails())) {
			List<EmployeePromotional> list1 = empPromotionalRepo.findByEmployee(employee.getId());
			if (!list1.isEmpty()) {
				for (EmployeePromotional ecd : list1) {
					empPromotionalRepo.deleteById(ecd.getId());
				}
			}
			empPromotionalRepo
					.saveAll(copyEmployeePromotionalDetails(employeedto.getEmployeePromotionalDetails(), emp));
		}
		// PersonalDetails
		if (!Objects.isNull(employeedto.getPersonalDetails())) {
			List<PersonalDetails> list1 = personalDetailsRepo.findByEmployee(employee.getId());
			for (PersonalDetails pd : list1) {
				pdRepo.deleteById(pd.getId());
			}
			personalDetailsRepo.saveAll(copyPersonalContactDetails(employeedto.getPersonalDetails(), emp));
		}

		logger.info("Employee saved with Id:{}", emp.getId());
		return emp;
	}

	public Set<EmployeeRoles> setRoles(EmployeeInfoDTO employeedto) {
		String massege = "Error role is not found";
		Set<String> strRoles = employeedto.getRoles();
		Set<EmployeeRoles> roles = new HashSet<>();

		if (strRoles == null) {
			EmployeeRoles userRole = roleRepo.findByRoleName("").orElseThrow(() -> new RuntimeException(massege));
			roles.add(userRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case Constants.QA_MANUAL:
					EmployeeRoles adminRole = roleRepo.findByRoleName("")
							.orElseThrow(() -> new RuntimeException(massege));
					roles.add(adminRole);
					break;

				case Constants.MANAGER:
					EmployeeRoles modRole = roleRepo.findByRoleName("")
							.orElseThrow(() -> new RuntimeException(massege));
					roles.add(modRole);
					break;

				case Constants.LEAD_DEVELOPER:
					EmployeeRoles managerRole = roleRepo.findByRoleName("")
							.orElseThrow(() -> new RuntimeException(massege));
					roles.add(managerRole);
					break;

				case Constants.OPERATIONS:
					EmployeeRoles brmanagerRole = roleRepo.findByRoleName("")
							.orElseThrow(() -> new RuntimeException(massege));
					roles.add(brmanagerRole);
					break;

				case Constants.AWS:
					EmployeeRoles hrRole = roleRepo.findByRoleName("").orElseThrow(() -> new RuntimeException(massege));
					roles.add(hrRole);
					break;

				default:
					EmployeeRoles userRole = roleRepo.findByRoleName("")
							.orElseThrow(() -> new RuntimeException(massege));
					roles.add(userRole);
				}
			});
		}
		return roles;
	}

	/**
	 * @param employee bank info employee id
	 * @return data added or not
	 */
	public List<EntityDTO> saveEmployeeOfficeUseOnlyDetails(OfficeUseOnlyDTO model, Long id) {
		Optional<Employee> findById = employeeRepo.findById(id);

		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Employee emp = findById.get();
		BankDetails oldbank = bankRepo.findByEmployee(id);
		BankDetails bankdetails = new BankDetails();
		if (!Objects.isNull(oldbank)) {
			oldbank.setBankName(model.getBankDetail().getBankName());
			oldbank.setIfscCode(model.getBankDetail().getIfscCode());
			oldbank.setAccountHolderName(model.getBankDetail().getAccountHolderName());
			oldbank.setAccountNo(model.getBankDetail().getAccountNo());
			oldbank.setBranchName(model.getBankDetail().getBranchName());
			oldbank.setUanNumber(model.getUanNumber());
			oldbank.setPfNumber(model.getPfNumber());
			oldbank.setEsicNumber(model.getEsicNumber());
			oldbank.setEmployee(emp);
			bankRepo.save(oldbank);
			logger.info("Bank Details updated to employee");
		} else {
			bankdetails.setBankName(model.getBankDetail().getBankName());
			bankdetails.setIfscCode(model.getBankDetail().getIfscCode());
			bankdetails.setAccountHolderName(model.getBankDetail().getAccountHolderName());
			bankdetails.setAccountNo(model.getBankDetail().getAccountNo());
			bankdetails.setBranchName(model.getBankDetail().getBranchName());
			bankdetails.setUanNumber(model.getUanNumber());
			bankdetails.setPfNumber(model.getPfNumber());
			bankdetails.setEsicNumber(model.getEsicNumber());
			bankdetails.setEmployee(emp);
			bankRepo.save(bankdetails);
			logger.info("Bank Details added to employee");
		}

		emp.setCtc(model.getCtc());
		Employee emp1 = employeeRepo.save(emp);
		logger.info("Office Use Details added to employee with Id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(emp1.getId());
		dto.setName(emp1.getFirstName() + emp1.getLastName());

		list.add(dto);
		return list;
	}

	/**
	 * 
	 * @param id
	 * @return employee info
	 */
	public EmployeeProfileDTO getEmployeeProfileDetails(Long id) {
		EmployeeProfileDTO employeedto = new EmployeeProfileDTO();
		Optional<Employee> findById = employeeRepo.findById(id);
		if (!findById.isPresent()) {
			return null;
		}
		Employee employee = findById.get();
		employeedto.setId(employee.getId());
		employeedto.setFirstName(employee.getFirstName());
		employeedto.setLastName(employee.getLastName());
		employeedto.setEmail(employee.getOfficalMail());
		employeedto.setDateOfBirth(employee.getDateOfBirth());
		employeedto.setGender(employee.getGender());
		employeedto.setContactNo(employee.getContactNo());
		employeedto.setDesignationName(employee.getDesignation().getDesignation());
		employeedto.setMarritalStatus(employee.getMaritalStatus());
		employeedto.setBranchName(employee.getBranch().getName());
		employeedto.setJoiningDate(employee.getJoiningDate());
		List<AssignShift> aslist = asRepo.findByEmployeeId(employee.getId());
		if (!aslist.isEmpty()) {
			AssignShift as = aslist.get(0);
			employeedto.setSchedule(as.getShiftName());
		} else {
			employeedto.setSchedule("");
		}
		// addresses
		employeedto.setAddresses(copyAddressWhileGet(employee.getAddress()));
		String name = "800x600";
		ProfileImageDTO copyProfileImage = copyProfileImage(id, name);
		employeedto.setProfileimage(copyProfileImage);
		List<EmergencyContactDetails> emergencylist = ecdRepo.findByEmployee(employee.getId());
		if (!emergencylist.isEmpty()) {
			EmergencyContactDetails emergency = emergencylist.get(0);
			employeedto.setEmergencyContactNo(emergency.getContactNumber());
		} else {
			employeedto.setEmergencyContactNo("");
		}

		logger.info("Employee Details found with Id:{}", employeedto.getId());
		return employeedto;
	}

	/**
	 * 
	 * @param id
	 * @param employeedto
	 * @return employee info updated or not
	 */
	public List<EntityDTO> updateEmployeeProfileDetails(Long id, EmployeeProfileDTO employeedto) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> employeeObj = employeeRepo.findById(id);
		if (employeeObj.isPresent()) {
			Employee employee = employeeObj.get();
			employee.setFirstName(employeedto.getFirstName());
			employee.setLastName(employeedto.getLastName());
			employee.setDateOfBirth(employeedto.getDateOfBirth());
			employee.setGender(employeedto.getGender());
			employee.setMaritalStatus(employeedto.getMarritalStatus());
			employee.setContactNo(employeedto.getContactNo());
			employee.setJoiningDate(employeedto.getJoiningDate());
			// address adding
			employee.setAddress(copyAddressWhileProfileUpdate(employeedto.getAddresses(), employee.getAddress()));
			Employee emp = employeeRepo.save(employee);
			logger.info("Employee saved in DB with Id:{}", emp.getId());
			EntityDTO dto = new EntityDTO();
			dto.setId(emp.getId());
			dto.setName(emp.getFirstName() + " " + emp.getLastName());

			list.add(dto);
			return list;
		} else {
			return list;
		}
	}

	public List<Address> copyAddressWhileAdd(Map<String, Object> addressMap) {
		List<Address> addresses = new ArrayList<>();
		for (Map.Entry<String, Object> entry : addressMap.entrySet()) {
			String key = entry.getKey();
			ObjectMapper mapper = new ObjectMapper();
			AddressDTO addressdto = mapper.convertValue(entry.getValue(), AddressDTO.class);
			if (key.equals(Constants.TEMPORARY) && !Objects.isNull(addressdto)) {
				Address address = new Address();
				address.setAddress(addressdto.getAddress());
				address.setLandmark(addressdto.getLandmark());
				address.setStreet(addressdto.getStreet());
				address.setCity(addressdto.getTcity());
				address.setDistrict(addressdto.getDistrict());
				address.setState(addressdto.getTstate());
				address.setPincode(addressdto.getPincode());
				address.setCountry(addressdto.getTcountry());
				address.setType(key);
				addresses.add(address);
			}
			if (key.equals(Constants.PERMANENT) && !Objects.isNull(addressdto)) {
				Address address = new Address();
				address.setAddress(addressdto.getAddress());
				address.setLandmark(addressdto.getLandmark());
				address.setStreet(addressdto.getStreet());
				address.setCity(addressdto.getCity());
				address.setDistrict(addressdto.getDistrict());
				address.setState(addressdto.getState());
				address.setPincode(addressdto.getPincode());
				address.setCountry(addressdto.getCountry());
				address.setType(key);
				addresses.add(address);
			}
		}
		return addresses;
	}

	public Map<String, Object> copyAddressWhileGet(List<Address> addresslist) {
		Map<String, Object> addresses = new HashMap<>();
		if (!addresslist.isEmpty()) {
			for (Address address : addresslist) {
				if (address.getType().equals(Constants.TEMPORARY)) {
					AddressDTO addressdto = new AddressDTO();
					addressdto.setId(address.getId());
					addressdto.setAddress(address.getAddress());
					addressdto.setLandmark(address.getLandmark());
					addressdto.setStreet(address.getStreet());
					addressdto.setTcity(address.getCity());
					addressdto.setDistrict(address.getDistrict());
					addressdto.setTstate(address.getState());
					addressdto.setPincode(address.getPincode());
					addressdto.setTcountry(address.getCountry());
					addressdto.setType(address.getType());
					addresses.put(address.getType(), addressdto);
					continue;
				}
				if (address.getType().equals(Constants.PERMANENT)) {
					AddressDTO addressdto = new AddressDTO();
					addressdto.setId(address.getId());
					addressdto.setAddress(address.getAddress());
					addressdto.setLandmark(address.getLandmark());
					addressdto.setStreet(address.getStreet());
					addressdto.setCity(address.getCity());
					addressdto.setDistrict(address.getDistrict());
					addressdto.setState(address.getState());
					addressdto.setPincode(address.getPincode());
					addressdto.setCountry(address.getCountry());
					addressdto.setType(address.getType());
					addresses.put(address.getType(), addressdto);
					continue;
				}

			}
		} else {
			AddressDTO addressdto = new AddressDTO();
			addresses.put(Constants.PERMANENT, addressdto);
			addresses.put(Constants.TEMPORARY, addressdto);
		}
		return addresses;
	}

	public List<ProfessionalDetails> copyProfessionalDetails(List<ProfessionalDetailsDTO> list, Employee emp) {
		List<ProfessionalDetails> proDetails = new ArrayList<>();
		for (ProfessionalDetailsDTO prdDto : list) {
			if (!prdDto.getCompanyName().isEmpty()) {
				ProfessionalDetails details = new ProfessionalDetails();
				details.setId(prdDto.getId());
				details.setClient(prdDto.getClient());
				details.setCompanyName(prdDto.getCompanyName());
				details.setExperience(prdDto.getExperience());
				details.setJoiningDate(prdDto.getJoiningDate());
				details.setRelievingDate(prdDto.getRelievingDate());
				details.setIsDefault(prdDto.getIsDefault());
				details.setEmployee(emp);
				proDetails.add(details);
			}
		}
		return proDetails;
	}

	public List<AcademicDetails> copyAcademicDetailsWhileAdd(List<AcademicDetailsDTO> academicDetailsmap,
			Employee employee) {
		List<AcademicDetails> academicDetaillist = new ArrayList<>();
		for (AcademicDetailsDTO academicDetailsDTO : academicDetailsmap) {
			AcademicDetails academicDetails = new AcademicDetails();
			academicDetails.setInstituteName(academicDetailsDTO.getInstituteName());
			academicDetails.setPercentage(academicDetailsDTO.getPercentage());
			academicDetails.setQualification(academicDetailsDTO.getQualification());
			academicDetails.setYearOfPassing(academicDetailsDTO.getYearOfPassing());
			academicDetails.setType(academicDetailsDTO.getType());
			academicDetails.setIsDefault(academicDetailsDTO.getIsDefault());
			academicDetails.setEmployee(employee);
			academicDetaillist.add(academicDetails);
		}
		return academicDetaillist;
	}

	public ProfileImageDTO copyProfileImage(Long id, String imageName) {
		List<ProfileImage> employeeImages = profileRepo.getEmployeeImages(id);
		ProfileImageDTO profileImageDTO = new ProfileImageDTO();
		if (!employeeImages.isEmpty()) {
			for (ProfileImage image : employeeImages) {
				if (image.getImageName().contains(imageName)) {
					profileImageDTO.setId(image.getId());
					profileImageDTO.setImageurl(image.getImageurl());
//						profileImageDTO.setContentType(profileImageFile1.get().getContantType());
					profileImageDTO.setFileType(image.getFileType());
					profileImageDTO.setImageName(image.getImageName());

				}
			}
			return profileImageDTO;
		} else {
			return new ProfileImageDTO();
		}
	}

	public List<Address> copyAddressWhileUpdate(Map<String, Object> addressMap, List<Address> addresses) {
		List<Address> addressList = new ArrayList<>();
		for (Map.Entry<String, Object> entry : addressMap.entrySet()) {
			String key = entry.getKey();
			ObjectMapper mapper = new ObjectMapper();
			AddressDTO addressdto = mapper.convertValue(entry.getValue(), AddressDTO.class);
			if (!Objects.isNull(addressdto)) {
				for (Address address : addresses) {
					if (address.getType().equals(key) && key.equals(Constants.TEMPORARY)) {
						address.setAddress(addressdto.getAddress());
						address.setLandmark(addressdto.getLandmark());
						address.setStreet(addressdto.getStreet());
						address.setCity(addressdto.getTcity());
						address.setDistrict(addressdto.getDistrict());
						address.setState(addressdto.getTstate());
						address.setPincode(addressdto.getPincode());
						address.setCountry(addressdto.getTcountry());
						address.setType(key);
						addressList.add(address);
						continue;
					}
					if (address.getType().equals(key) && key.equals(Constants.PERMANENT)) {
						address.setAddress(addressdto.getAddress());
						address.setLandmark(addressdto.getLandmark());
						address.setStreet(addressdto.getStreet());
						address.setCity(addressdto.getCity());
						address.setDistrict(addressdto.getDistrict());
						address.setState(addressdto.getState());
						address.setPincode(addressdto.getPincode());
						address.setCountry(addressdto.getCountry());
						address.setType(key);
						addressList.add(address);
					}
				}
			}
		}
		return addressList;
	}

	public List<AcademicDetails> copyAcademicDetailsWhileUpdate(List<AcademicDetailsDTO> academicDetailsmap) {
		List<AcademicDetails> newacademicDetaillist = new ArrayList<>();
		for (AcademicDetailsDTO academicDetailsDTO : academicDetailsmap) {
			AcademicDetails academicDetails = new AcademicDetails();
			academicDetails.setInstituteName(academicDetailsDTO.getInstituteName());
			academicDetails.setPercentage(academicDetailsDTO.getPercentage());
			academicDetails.setQualification(academicDetailsDTO.getQualification());
			academicDetails.setYearOfPassing(academicDetailsDTO.getYearOfPassing());
			academicDetails.setType(academicDetailsDTO.getType());
			newacademicDetaillist.add(academicDetails);
		}
		return newacademicDetaillist;
	}

	public List<EmergencyContactDetails> copyEmergencyContactDetails(List<EmergencyContactDetailsDTO> list,
			Employee emp) {
		List<EmergencyContactDetails> emergencydetails = new ArrayList<>();
		if (!list.isEmpty()) {
			for (EmergencyContactDetailsDTO ecdDto : list) {
				EmergencyContactDetails details = new EmergencyContactDetails();
				details.setContactPerson(ecdDto.getContactPerson());
				details.setRelation(ecdDto.getRelation());
				details.setContactNumber(ecdDto.getContactNumber());
				details.setAltContactNumber(ecdDto.getAltContactNumber());
				details.setIsDefault(ecdDto.getIsDefault());
				details.setEmployee(emp);
				emergencydetails.add(details);
			}
		}
		return emergencydetails;
	}

	public List<PersonalDetails> copyPersonalContactDetails(List<PersonalDetailsDTO> list, Employee emp) {
		List<PersonalDetails> personaldetails = new ArrayList<>();
		if (!list.isEmpty()) {
			for (PersonalDetailsDTO ecdDto : list) {
				PersonalDetails details = new PersonalDetails();
				details.setPersonName(ecdDto.getPersonName());
				details.setRelation(ecdDto.getRelation());
				details.setContactNumber(ecdDto.getContactNumber());
				details.setAltContactNumber(ecdDto.getAltContactNumber());
				details.setIsDefault(ecdDto.getIsDefault());
				details.setEmployee(emp);
				personaldetails.add(details);
			}
		}
		return personaldetails;
	}
//	public List<PersonalDetails> copyPersonalDetails(List<PersonalDetailsDTO> list) {
//		List<PersonalDetails> personalDetails = new ArrayList<>();
//		if (!list.isEmpty()) {
//			for (PersonalDetailsDTO pdDto : list) {
//				PersonalDetails details = new PersonalDetails();
//				details.setPersonName(pdDto.getPersonName());
//				details.setRelation(pdDto.getRelation());
//				details.setContactNumber(pdDto.getContactNumber());
//				details.setAltContactNumber(pdDto.getAltContactNumber());
//				details.setIsDefault(pdDto.getIsDefault());
//				personalDetails.add(details);
//			}
//		}
//		return personalDetails;
//	}

	/*
	 * public List<Skill> copySkills(List<Long> list) { List<Skill> skills = new
	 * ArrayList<>(); if (!list.isEmpty()) { for (Long skillId : list) {
	 * Optional<Skill> findById = skillRepo.findById(skillId); if
	 * (findById.isPresent()) { Skill skill = findById.get(); skills.add(skill); } }
	 * } return skills; }
	 */

	public Set<EmployeeRoles> copyEmployeeRoles(Long roleId) {
		Set<EmployeeRoles> roles = new HashSet<>();
		Optional<EmployeeRoles> empRole = rolesRepo.findByRoleId(roleId);
		if (empRole.isPresent()) {
			roles.add(empRole.get());
		}
		return roles;
	}

	public List<AcademicDetailsDTO> copyAcademicDetailsWhileGet(List<AcademicDetails> list) {
		List<AcademicDetailsDTO> academicDetailmap = new ArrayList<>();
		for (AcademicDetails academicDetail : list) {
			AcademicDetailsDTO academicDetailsDTO = new AcademicDetailsDTO();
			academicDetailsDTO.setId(academicDetail.getId());
			academicDetailsDTO.setInstituteName(academicDetail.getInstituteName());
			academicDetailsDTO.setPercentage(academicDetail.getPercentage());
			academicDetailsDTO.setYearOfPassing(academicDetail.getYearOfPassing());
			academicDetailsDTO.setType(academicDetail.getType());
			academicDetailsDTO.setQualification(academicDetail.getQualification());
			academicDetailsDTO.setIsDefault(academicDetail.getIsDefault());
			academicDetailmap.add(academicDetailsDTO);
		}
		return academicDetailmap;
	}

	public List<ProjectDTO> copyProjectsWhileGet(List<Project> projectlist) {
		List<ProjectDTO> list = new ArrayList<>();
		for (Project project : projectlist) {
			ProjectDTO projectdto = new ProjectDTO();
			projectdto.setId(project.getId());
			projectdto.setName(project.getName());
			projectdto.setDescription(project.getDescription());
			list.add(projectdto);
		}
		return list;
	}

	public List<FileDTO> copyFilesWhileGet(Long empId) {
		List<FileDTO> files = new ArrayList<>();
		List<FileDetails> filesList = filerepo.findByemployee(empId);
		for (FileDetails file : filesList) {
			FileDTO filedto = new FileDTO();
			filedto.setId(file.getId());
			filedto.setFilename(file.getName());
			filedto.setFilePath(file.getFilePath());
			filedto.setFileType(file.getFileType());
			filedto.setCertificateName(file.getCertificate());
			files.add(filedto);
		}
		return files;
	}

	public List<PolicyDTO> copyPoliciesWhileGet(List<Policy> policies) {
		List<PolicyDTO> policylist = new ArrayList<>();
		for (Policy policy : policies) {
			PolicyDTO policydto = new PolicyDTO();
			policydto.setId(policy.getId());
			policydto.setName(policy.getName());
			policydto.setDescription(policy.getDescription());
			policydto.setAttachmentLink(policy.getAttachmentLink());
			policylist.add(policydto);
		}
		return policylist;
	}

	public List<ResourceItemsDTO> copyResourceItemsWhileGet(Long empId) {
		List<ResourceItemsDTO> resourceItemDtolist = new ArrayList<>();
		List<ResourceItems> resourceItem = resourceItemsRepo.findAll();
		List<ResourceItems> resourceItemlist = resourceItem.stream().filter(c -> c.getEmployee().getId().equals(empId))
				.collect(Collectors.toList());

		for (ResourceItems resourceItems : resourceItemlist) {
			if (!Objects.isNull(resourceItems) && Boolean.FALSE.equals(resourceItems.getIsDelete())) {
				ResourceItemsDTO resourceItemsDTO = new ResourceItemsDTO();
				resourceItemsDTO.setId(resourceItems.getId()); // add asset to resource item
				resourceItemsDTO.setName(resourceItems.getAsset().getName());
				resourceItemsDTO.setDescription(resourceItems.getAsset().getDescription());
				resourceItemsDTO.setValue(resourceItems.getValue());
				resourceItemsDTO.setAssetId(resourceItems.getAsset().getId());
				resourceItemDtolist.add(resourceItemsDTO);
			}
		}
		return resourceItemDtolist;
	}

	public List<ProfessionalDetailsDTO> copyProfessionalDetailsWhileGet(Long empId) {
		List<ProfessionalDetails> pdlist = prRepo.findByEmployee(empId);
		List<ProfessionalDetailsDTO> professionalList = new ArrayList<>();
		for (ProfessionalDetails professional : pdlist) {
			ProfessionalDetailsDTO professionalDTO = new ProfessionalDetailsDTO();
			professionalDTO.setId(professional.getId());
			professionalDTO.setClient(professional.getClient());
			professionalDTO.setCompanyName(professional.getCompanyName());
			professionalDTO.setExperience(professional.getExperience());
			professionalDTO.setJoiningDate(professional.getJoiningDate());
			professionalDTO.setRelievingDate(professional.getRelievingDate());
			professionalDTO.setIsDefault(professional.getIsDefault());
			professionalList.add(professionalDTO);
		}
		return professionalList;
	}

	public List<EmergencyContactDetailsDTO> copyEmergencyContactDetailsWhileGet(List<EmergencyContactDetails> list) {
		List<EmergencyContactDetailsDTO> emergencydetails = new ArrayList<>();
		for (EmergencyContactDetails emergency : list) {
			EmergencyContactDetailsDTO details = new EmergencyContactDetailsDTO();
			details.setId(emergency.getId());
			details.setContactPerson(emergency.getContactPerson());
			details.setRelation(emergency.getRelation());
			details.setContactNumber(emergency.getContactNumber());
			details.setAltContactNumber(emergency.getAltContactNumber());
			details.setIsDefault(emergency.getIsDefault());
			emergencydetails.add(details);
		}
		return emergencydetails;
	}

	public List<PersonalDetailsDTO> copyPersonalContactDetailsWhileGet(List<PersonalDetails> list) {
		List<PersonalDetailsDTO> personaldetails = new ArrayList<>();
		for (PersonalDetails personal : list) {
			PersonalDetailsDTO details = new PersonalDetailsDTO();
			details.setId(personal.getId());
			details.setPersonName(personal.getPersonName());
			details.setRelation(personal.getRelation());
			details.setContactNumber(personal.getContactNumber());
			details.setAltContactNumber(personal.getAltContactNumber());
			details.setIsDefault(personal.getIsDefault());
			personaldetails.add(details);
		}
		return personaldetails;
	}

	public List<PersonalDetailsDTO> copyPersonalDetailsWhileGet(List<PersonalDetails> list) {
		List<PersonalDetailsDTO> pdDetails = new ArrayList<>();
		for (PersonalDetails personal : list) {
			PersonalDetailsDTO details = new PersonalDetailsDTO();
			details.setId(personal.getId());
			details.setPersonName(personal.getPersonName());
			details.setRelation(personal.getRelation());
			details.setContactNumber(personal.getContactNumber());
			details.setAltContactNumber(personal.getAltContactNumber());
			details.setIsDefault(personal.getIsDefault());
			pdDetails.add(details);
		}
		return pdDetails;
	}

	/*
	 * public ProfileImageDTO copyOrignalProfileImage(Long id, String imageName) {
	 * List<ProfileImage> employeeImages = profileRepo.getEmployeeImages(id);
	 * ProfileImageDTO profileImageDTO = new ProfileImageDTO(); if
	 * (!employeeImages.isEmpty()) { for (ProfileImage image : employeeImages) { if
	 * (!image.getImageName().contains(imageName)) { Optional<EmployeeProfileImage>
	 * profileImageFile = employeeProfileImageRepo .findById(image.getImageurl());
	 * if (profileImageFile.isPresent()) {
	 * profileImageDTO.setImagedata(profileImageFile.get().getImage());
	 * profileImageDTO.setContentType(profileImageFile.get().getContantType());
	 * profileImageDTO.setId(image.getId());
	 * profileImageDTO.setImageName(image.getImageName());
	 * profileImageDTO.setFileType(image.getFileType()); } } } return
	 * profileImageDTO; } else { return new ProfileImageDTO(); } }
	 */
	public String saveUserToEmployeeDataSave(Company company) {

		Employee employee = new Employee();
		employee.setFirstName(company.getFirstName());
		employee.setLastName(company.getLastName());
		employee.setEmail(company.getEmail().toLowerCase());
		employee.setOfficalMail(company.getEmail().toLowerCase());
		employee.setUserName(company.getUserName());
		employee.setMarriageDay(new Date());
		employee.setDateOfBirth(new Date());
		employee.setContactNo(company.getContact());
		employee.setJoiningDate(new Date());
		employee.setGender("male");
		employee.setPrimarySkills("[]");
		employee.setSecondarySkills("[]");
		Address address = new Address();
		address.setAddress(company.getAddress().getAddress());
		address.setLandmark("");
		address.setStreet("");
		address.setCity(1L);
		address.setDistrict("");
		address.setState(1L);
		address.setCountry(company.getAddress().getCountry());
		address.setPincode("000000");

		employee.setCompany(company);

		Branch entity1 = null;
		Branch branch = null;
		entity1 = new Branch();
		entity1.setName(company.getName());
		entity1.setContactNo(company.getContact());
		entity1.setEmail(company.getEmail().toLowerCase());
		entity1.setFax("");
		entity1.setCompany(company);
		entity1.setAddress(address);
		entity1.setIsDelete(Boolean.FALSE);
		entity1.setIsActive(Boolean.TRUE);
		branch = branchRepo.save(entity1);
		employee.setBranch(branch);

		Department entity2 = null;
		Department department = null;
		entity2 = new Department();
		entity2.setName("Admin Department");
		entity2.setDescription("");
		entity2.setCompany(company);
		entity2.setBranch(branch);
		entity2.setIsDelete(Boolean.FALSE);
		entity2.setIsActive(Boolean.TRUE);
		department = deptRepo.save(entity2);
		employee.setDepartment(department);

		Designation entity3 = null;
		entity3 = new Designation();
		entity3.setDesignation("CEO");
		entity3.setSkills("Skill");
		entity3.setExperiance("25");
		entity3.setBand("L5");
		entity3.setCompany(company);
		entity3.setBranch(branch);
		entity3.setDepartment(department);
		entity3.setIsDelete(Boolean.FALSE);
		entity3.setIsActive(Boolean.TRUE);
		Designation desig = designationRepo.save(entity3);
		employee.setDesignation(desig);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		List<Project> projectList = new ArrayList<>();
		Project project = null;
		project = new Project();
		project.setName("Default Bench");
		project.setDescription("Default Project");
		project.setCompany(company);
		project.setStatus("");
		project.setClientName("");
		project.setRemarks("");
		project.setIsDelete(Boolean.FALSE);
		project.setIsActive(Boolean.TRUE);
		project.setStartDate(formatter.format(new Date()));
		project.setEndDate(formatter.format(dateUtil.getNextYearCurrentDate()));
		project.setEstimatedHours(10000L);
		Project save = projectRepo.save(project);
		projectList.add(save);
		Project project1 = null;
		project1 = new Project();
		project1.setName("Default Admin");
		project1.setDescription("Default Project");
		project1.setCompany(company);
		project1.setStatus("");
		project1.setClientName("");
		project1.setRemarks("");
		project1.setIsDelete(Boolean.FALSE);
		project1.setIsActive(Boolean.TRUE);
		project1.setStartDate(formatter.format(new Date()));
		project1.setEndDate(formatter.format(dateUtil.getNextYearCurrentDate()));
		project1.setEstimatedHours(10000L);
		Project save1 = projectRepo.save(project1);
		projectList.add(save1);
		employee.setProjects(projectList);
		String name = "General Shift";
		Shift shift = null;
		Shift newShift = null;
		shift = new Shift();
		shift.setShiftName(name);
		shift.setCompany(company);
		shift.setInTime("2021-02-25 10:00:00");
		shift.setOutTime("2021-02-25 19:00:00");
		shift.setAllowanceApplicable(null);
		shift.setAllowanceAmount(null);
		shift.setWeekend("{\"week1\":[0,6],\"week2\":[0,6],\"week3\":[0,6],\"week4\":[0,6],\"week5\":[0,6]}");
		shift.setIsActive(Boolean.TRUE);
		shift.setIsDelete(Boolean.FALSE);
		shift.setType(Boolean.TRUE);
		newShift = shiftRepo.save(shift);

		employee.setIsActive(Boolean.TRUE);
		employee.setIsApprove(Boolean.TRUE);
		employee.setIsDelete(Boolean.FALSE);
		employee.setIsExit(Boolean.FALSE);
		List<EmployeeRoles> empRole = rolesRepo.findByName("Admin");
		Set<EmployeeRoles> roles = new HashSet<>();
		if (!empRole.isEmpty()) {
			roles.add(empRole.get(0));
			employee.setRoles(roles);
		}
		List<Address> addrList = new ArrayList<>();
		Address address1 = new Address();
		address1.setAddress(company.getAddress().getAddress());
		address1.setLandmark("");
		address1.setStreet("");
		address1.setCity(1L);
		address1.setDistrict("");
		address1.setState(1L);
		address1.setCountry(company.getAddress().getCountry());
		address1.setPincode("000000");
		address1.setType(Constants.PERMANENT);
		Address address2 = new Address();
		address2.setAddress(company.getAddress().getAddress());
		address2.setLandmark("");
		address2.setStreet("");
		address2.setCity(1L);
		address2.setDistrict("");
		address2.setState(1L);
		address2.setCountry(company.getAddress().getCountry());
		address2.setPincode("000000");
		address2.setType(Constants.TEMPORARY);
		addrList.add(address1);
		addrList.add(address2);
		employee.setAddress(addrList);
		employee.setIsSameAddress(true);
		Employee employeeNew = employeeRepo.save(employee);
		employeeNew.setManager(employeeNew);

		AssignShift assignShift = new AssignShift();
		assignShift.setEmployeeName(employeeNew.getFirstName() + " " + employeeNew.getLastName());
		assignShift.setShift(newShift);
		assignShift.setShiftName(name);
		assignShift.setEmployee(employeeNew);
		Optional<Project> p = projectRepo.getProjectsList("Default Bench", company.getId());
		if (p.isPresent()) {
			assignShift.setFromDate(p.get().getStartDate());
			assignShift.setToDate(p.get().getEndDate());
			assignShift.setProjectName(p.get().getName());
			assignShift.setProjectId(p.get().getId());
		}
		assignShift.setManagerId(employeeNew.getId());
		assignShift.setIsDelete(Boolean.FALSE);
		asRepo.save(assignShift);

		String password = emailServiceUtil.generateCommonLangPassword();
		employeeNew.setPassword(encoder.encode(password));
		employeeRepo.save(employeeNew);
		return password;
	}

	public List<Address> copyAddressWhileProfileUpdate(Map<String, Object> addressMap, List<Address> addresses) {
		List<Address> addressList = new ArrayList<>();
		for (Map.Entry<String, Object> entry : addressMap.entrySet()) {
			String key = entry.getKey();
			ObjectMapper mapper = new ObjectMapper();
			AddressDTO addressdto = mapper.convertValue(entry.getValue(), AddressDTO.class);
			if (!Objects.isNull(addressdto)) {
				for (Address address : addresses) {
					if (address.getType().equals(key) && key.equals(Constants.TEMPORARY)) {
						address.setAddress(addressdto.getAddress());
						address.setLandmark(addressdto.getLandmark());
						address.setCity(addressdto.getTcity());
						address.setState(addressdto.getTstate());
						address.setPincode(addressdto.getPincode());
						address.setCountry(addressdto.getTcountry());
						address.setType(key);
						addressList.add(address);
						continue;
					}
					if (address.getType().equals(key) && key.equals(Constants.PERMANENT)) {
						address.setAddress(addressdto.getAddress());
						address.setLandmark(addressdto.getLandmark());
						address.setCity(addressdto.getCity());
						address.setState(addressdto.getState());
						address.setPincode(addressdto.getPincode());
						address.setCountry(addressdto.getCountry());
						address.setType(key);
						addressList.add(address);
					}
				}
			}
		}
		return addressList;
	}

	public List<EmployeePromotional> copyEmployeePromotionalDetails(List<EmployeePromotionalDTO> epdlist,
			Employee employee) {
		List<EmployeePromotional> eplist = new ArrayList<>();
		for (EmployeePromotionalDTO epddto : epdlist) {
			if (!epddto.getEmpDesignation().isEmpty()) {
				EmployeePromotional details = new EmployeePromotional();
				details.setEmpDesignation(epddto.getEmpDesignation());
				details.setPromotionStartDate(epddto.getPromotionStartDate());
				if (epddto.getPromotionEndDate() != null) {
					details.setPromotionEndDate(epddto.getPromotionEndDate());
				}
				details.setEmployee(employee);
				eplist.add(details);
			}
		}
		return eplist;
	}

	private List<EmployeePromotionalDTO> copyEmployeePromotionalDetailsWhileGet(List<EmployeePromotional> list) {
		List<EmployeePromotionalDTO> eplist = new ArrayList<>();
		for (EmployeePromotional epd : list) {
			EmployeePromotionalDTO details = new EmployeePromotionalDTO();
			details.setId(epd.getId());
			details.setEmpDesignation(epd.getEmpDesignation());
			details.setPromotionStartDate(epd.getPromotionStartDate());
			details.setPromotionEndDate(epd.getPromotionEndDate());
			eplist.add(details);
		}
		return eplist;
	}

}
