package com.hrms.admin.util;

import java.util.Base64;

public class Base64ForgotPasswordUtility {

	public static String decodePassword(String password) {
		
		byte[] decodedBytes = Base64.getDecoder().decode(password);
		String decodedString = new String(decodedBytes);
		String[] split = decodedString.split("/");
		return split[0];
	}
}
