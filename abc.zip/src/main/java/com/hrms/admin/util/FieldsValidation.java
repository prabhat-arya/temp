package com.hrms.admin.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class FieldsValidation {

	public Boolean validateName(String name) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME);
		Matcher matcher = pattern.matcher(name.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validateNameWithLength(String name) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME);
		Matcher matcher = pattern.matcher(name.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || !(name.trim().length() >= 3 && name.trim().length() <= 50)) {
			return false;
		}
		return true;
	}

	public Boolean validateNameWithMeanLength(String name) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME);
		Matcher matcher = pattern.matcher(name.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || name.trim().length() <= 2) {
			return false;
		}
		return true;
	}

	public Boolean validateUserName(String name) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME_NUMBER);
		Matcher matcher = pattern.matcher(name.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || !(name.trim().length() >= 0 && name.trim().length() <= 50)) {
			return false;
		}
		return true;
	}

	public Boolean validateNumber(String number) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NUMBER);
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validatePhoneNumber(String number) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NUMBER);
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || number.trim().length() != 10) {
			return false;
		}
		return true;
	}

	public Boolean validateAadher(String number) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NUMBER);
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || number.trim().length() != 12) {
			return false;
		}
		return true;
	}

	public Boolean validatePincode(String number) {
		Pattern pattern = Pattern.compile(Constants.PATTREN_NUMBER);
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || number.trim().length() != 6) {
			return false;
		}
		return true;
	}

	public Boolean validateMixedWords(String pat) {

		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME_NUMBER);
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validatePanAndVoter(String pat) {

		Pattern pattern = Pattern.compile(Constants.PATTREN_NAME_NUMBER);
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter || pat.trim().length() != 10) {
			return false;
		}
		return true;
	}

	public Boolean validateMixedWordsWithSpace(String pat) {
		Pattern pattern = Pattern.compile("[^0-9a-zA-Z ]");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validateMixedWordsWithSpaceWithSplChar(String pat) {
		Pattern pattern = Pattern.compile("[^a-zA-Z0-9 !@#$&()`.+-,/\\\"]");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validateEmail(String pat) {
		Pattern pattern = Pattern.compile(
				"^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return true;
		}
		return false;
	}

	public Boolean validateSpical(String spl) {
		Pattern pattern = Pattern.compile("^[\\\\$#\\\\+{}:\\\\?\\\\.,~@\\\"a-zA-Z0-9 ]+$\r\n" + "}");
		Matcher matcher = pattern.matcher(spl.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validateDecimalValue(String number) {
		Pattern pattern = Pattern.compile("[^0-9.]");
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public String validateBloodGroup(String strone) {
		String str = strone.trim();
		if (str.contains(" ") || str.contains("ve")) {
			String bg = str.replaceAll(" ", "");
			if (bg.contains("ve")) {
				bg = bg.replace("ve", "");
			}
			return bg;
		} else {
			return str;
		}
	}

	public Boolean validateBloodGroupName(String pat) {
		Pattern pattern = Pattern.compile("[^a-zA-Z .+-]");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validateDecimalValuePercentage(String number) {
		Pattern pattern = Pattern.compile("[^0-9.]");
		Matcher matcher = pattern.matcher(number.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		double num = Double.parseDouble(number.trim());
		double start = 1.0;
		double end = 100.0;
		if (isStringContainsSpecialCharacter || !(num >= start && num <= end)) {
			return false;
		}
		return true;
	}

	public Boolean pfNumber(String pat) {

		Pattern pattern = Pattern.compile("[^A-Z0-9 /\\\\\\\"]");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter) {
			return false;
		}
		return true;
	}

	public Boolean validatePassword(String pat) {
		boolean containsSpaces = pat.contains(" ");
		Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@#&_-]).{8,12}$");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();
		if (isStringContainsSpecialCharacter && !containsSpaces) {
			return true;
		}
		return false;
	}

	public Boolean validateIsDefault(String pat) {
		Pattern pattern = Pattern.compile("[^a-zA-Z]");
		Matcher matcher = pattern.matcher(pat.trim());
		boolean isStringContainsSpecialCharacter = matcher.find();

		if (!isStringContainsSpecialCharacter && Constants.YES.equalsIgnoreCase(pat.trim())) {
			return true;
		}
		if (!isStringContainsSpecialCharacter && Constants.NO.equalsIgnoreCase(pat.trim())) {
			return true;
		}
		return false;
	}
}
