package com.hrms.admin.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ConversionUtils {

	private static final Logger logger = LoggerFactory.getLogger(ConversionUtils.class);
	/**
	 * @param week
	 * @return list of data from given Json String 
	 */
	@SuppressWarnings("unchecked")
	public List<String> stringToList(String week) {
		List<String> list = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			list = mapper.readValue(week, List.class);
		} catch (Exception e) {
			logger.info("Error in converting string to list");
		}
		return list;
	}
	
	public List<String> stringToListArray(String week) {
		List<String> convertedSkillList = Stream.of(week.split(","))
				  .map(String::trim)
				  .collect(Collectors.toList());
		return convertedSkillList;
	}
	public List<Long> ListConversion(String skill) {
		List<Long> skillList = new ArrayList<>();
		if (skill.equals("[]")) {
			return skillList;
		}
		String key = skill.replace("[", "");
		String str = key.replace("]", "");
		List<String> list = Stream.of(str.split(",")).collect(Collectors.toList());

		for (String s : list) {
			skillList.add(Long.parseLong(s.trim()));
		}
		return skillList;
	}
}
