package com.hrms.admin.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.Menu;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.role.dto.MenuSortingDTO;

@Component
public class MenuUtility {

	@Autowired
	private MenuRepository menuRepo;
	
	public List<MenuSortingDTO> getMenuList(Set<Menu> menus){

		List<MenuSortingDTO> menuList = new ArrayList<>();
		
		Set<Menu> parentMenus = new HashSet<>();
		Set<Menu> childMenus = new HashSet<>();
			
		for (Menu menu : menus) {
			if(menu.getIsParent() == 0) {
				
				Menu parentMenu = menuRepo.findByMenuId(menu.getParentId());
				parentMenus.add(parentMenu);
				Menu childMenu = menuRepo.findByMenuId(menu.getMenuId());
				childMenus.add(childMenu);
			}else {
				
				Menu parentMenu = menuRepo.findByMenuId(menu.getMenuId());
				parentMenus.add(parentMenu);
			}
		}
		
		for (Menu menu : parentMenus) {

			MenuSortingDTO sortedMenu = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId());
			List<MenuSortingDTO> childs = new ArrayList<>();
			for (Menu childMenu : childMenus) {
				MenuSortingDTO childMenu1 = new MenuSortingDTO();
				if (menu.getMenuId().equals(childMenu.getParentId())) {
					childMenu1 = new MenuSortingDTO(childMenu.getMenuTitle(), childMenu.getMenuIcon(), childMenu.getMenuPath(), childMenu.getMenuId());
					childs.add(childMenu1);
				}
				sortedMenu.setChilds(childs);
			}
			menuList.add(sortedMenu);
		}
		return menuList;
	}
}
