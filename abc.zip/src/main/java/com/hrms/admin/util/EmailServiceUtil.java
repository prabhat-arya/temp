package com.hrms.admin.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.transaction.Transactional;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.amazonaws.services.s3.model.S3Object;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.PaySchedule;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.PayScheduleRepository;
import com.hrms.admin.repository.ProfileImageRepository;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

/**
 * Contains method to provide APIs for Sending Mails
 * 
 * @author {Sandeep}
 *
 */
@Service
public class EmailServiceUtil {

	private static final Logger logger = LoggerFactory.getLogger(EmailServiceUtil.class);

	@Autowired
	private JavaMailSender sender;

	@Autowired
	private Configuration config;

	@Autowired
	private S3ServiceUtil s3util;

	@Autowired
	private ProfileImageRepository profileImageRepo;

	@Autowired
	private PayScheduleRepository payScheduleRepository;

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Value("${ostaff.frommail}")
	private String fromMail;

	@Value("${reset.url.link}")
	private String resetPwdLink;

	@Value("${user.login.link}")
	private String loginUrl;

	@Value("${aws.bucket.imagefolder}")
	private String foldername;

	/**
	 * Sending Notification Mails
	 */
	@Transactional
	public ResponseDTO sendNotificationEmail(MailDTO request, Map<String, Object> model) {
		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template t = config.getTemplate(request.getTemplate());
			MimeMultipart multipart = new MimeMultipart(Constants.RELATED);
			Map<String, Object> m = model;
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(html, "text/html");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();
			/*
			 * MailImages logo = mailImagesRepo.findByFileName(Constants.ONPASSIVE_LOGO);
			 * DataSource logoDataSource = new FileDataSource(new File(logo.getFileName()));
			 * byte[] file = logo.getImage(); OutputStream sourceOS =
			 * logoDataSource.getOutputStream(); sourceOS.write(file);
			 * messageBodyPart.setDataHandler(new DataHandler(logoDataSource));
			 * messageBodyPart.addHeader("Content-ID", "<logo>");
			 */
			List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(request.getCompanyId());
			if (!companyImages.isEmpty()) {
				for (ProfileImage image : companyImages) {
					if (!image.getImageName().contains("_")) {
						S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
						InputStream in = new BufferedInputStream(s3File.getObjectContent());
						byte[] bytes = in.readAllBytes();
						messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
						messageBodyPart.addHeader("Content-ID", "<logo>");
					}
				}
			} else {
				final String fileName = "Images/ostafflogo.png";
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream file = classLoader.getResourceAsStream(fileName);
				byte[] bytes = file.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<logo>");
			}
			/*
			 * final String fileName = "Images/onpassiveLogo.png"; ClassLoader classLoader =
			 * getClass().getClassLoader(); InputStream file =
			 * classLoader.getResourceAsStream(fileName); byte[] bytes =
			 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
			 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
			 */

			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			String msgg = model.get(Constants.MSG).toString();
			if (msgg.equalsIgnoreCase(Constants.EVENT)) {
				messageBodyPart = new MimeBodyPart();
				/*
				 * MailImages event = mailImagesRepo.findByFileName(Constants.EVENT); DataSource
				 * eventDataSource = new FileDataSource(new File(event.getFileName())); byte[]
				 * eventFile = event.getImage(); OutputStream eventSourceOS =
				 * eventDataSource.getOutputStream(); eventSourceOS.write(eventFile);
				 * messageBodyPart.setDataHandler(new DataHandler(eventDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<event>");
				 */
				final String eventfileName = "Images/event.png";
				ClassLoader eventclassLoader = getClass().getClassLoader();
				InputStream eventfile = eventclassLoader.getResourceAsStream(eventfileName);
				byte[] eventbytes = eventfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(eventbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<event>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.BABYBOY)) {
				// new baby boy
				messageBodyPart = new MimeBodyPart();
				/*
				 * MailImages babyBoy = mailImagesRepo.findByFileName(Constants.BABYBOY);
				 * DataSource babyBoyDataSource = new FileDataSource(new
				 * File(babyBoy.getFileName())); byte[] babyBoyFile = babyBoy.getImage();
				 * OutputStream eventSourceOS = babyBoyDataSource.getOutputStream();
				 * eventSourceOS.write(babyBoyFile); messageBodyPart.setDataHandler(new
				 * DataHandler(babyBoyDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<babyBoy>");
				 */
				final String babyBoyfileName = "Images/babyBoy.png";
				ClassLoader babyBoyclassLoader = getClass().getClassLoader();
				InputStream babyBoyfile = babyBoyclassLoader.getResourceAsStream(babyBoyfileName);
				byte[] babyBoybytes = babyBoyfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(babyBoybytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<babyBoy>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.BABYGIRL)) {
				// new baby girl
				messageBodyPart = new MimeBodyPart();
				/*
				 * MailImages babyGirl = mailImagesRepo.findByFileName(Constants.BABYGIRL);
				 * DataSource babyGirlDataSource = new FileDataSource(new
				 * File(babyGirl.getFileName())); byte[] babyGirlFile = babyGirl.getImage();
				 * OutputStream eventSourceOS = babyGirlDataSource.getOutputStream();
				 * eventSourceOS.write(babyGirlFile); messageBodyPart.setDataHandler(new
				 * DataHandler(babyGirlDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<babyGirl>");
				 */
				final String babyGirlfileName = "Images/babyGirl.png";
				ClassLoader babyGirlclassLoader = getClass().getClassLoader();
				InputStream babyGirlfile = babyGirlclassLoader.getResourceAsStream(babyGirlfileName);
				byte[] babyGirlbytes = babyGirlfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(babyGirlbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<babyGirl>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.TRAINING)) {
				// Training
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages training = mailImagesRepo.findByFileName(Constants.TRAINING);
				 * DataSource trainingDataSource = new FileDataSource(new
				 * File(training.getFileName())); byte[] trainingFile = training.getImage();
				 * OutputStream eventSourceOS = trainingDataSource.getOutputStream();
				 * eventSourceOS.write(trainingFile); messageBodyPart.setDataHandler(new
				 * DataHandler(trainingDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<opportunity>");
				 */
				final String trainingfileName = "Images/training.png";
				ClassLoader trainingclassLoader = getClass().getClassLoader();
				InputStream trainingfile = trainingclassLoader.getResourceAsStream(trainingfileName);
				byte[] trainingbytes = trainingfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(trainingbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<opportunity>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.PROMOTION)) {
				// Promotion
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages promotion = mailImagesRepo.findByFileName(Constants.PROMOTION);
				 * DataSource promotionDataSource = new FileDataSource(new
				 * File(promotion.getFileName())); byte[] promotionFile = promotion.getImage();
				 * OutputStream eventSourceOS = promotionDataSource.getOutputStream();
				 * eventSourceOS.write(promotionFile); messageBodyPart.setDataHandler(new
				 * DataHandler(promotionDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<promotion>");
				 */
				final String promotionfileName = "Images/promotion.png";
				ClassLoader promotionclassLoader = getClass().getClassLoader();
				InputStream promotionfile = promotionclassLoader.getResourceAsStream(promotionfileName);
				byte[] promotionbytes = promotionfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(promotionbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<promotion>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase("productLaunch")) {
				// product launch
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages productLaunch = mailImagesRepo.findByFileName("productLaunch");
				 * DataSource productLaunchDataSource = new FileDataSource(new
				 * File(productLaunch.getFileName())); byte[] productLaunchFile =
				 * productLaunch.getImage(); OutputStream eventSourceOS =
				 * productLaunchDataSource.getOutputStream();
				 * eventSourceOS.write(productLaunchFile); messageBodyPart.setDataHandler(new
				 * DataHandler(productLaunchDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<rollout>");
				 */
				final String productLaunchfileName = "Images/productLaunch.png";
				ClassLoader productLaunchclassLoader = getClass().getClassLoader();
				InputStream productLaunchfile = productLaunchclassLoader.getResourceAsStream(productLaunchfileName);
				byte[] productLaunchbytes = productLaunchfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(productLaunchbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<rollout>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.TEAMAPPRECIALS)) {
				// teamAppreciation
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages teamApprecials =
				 * mailImagesRepo.findByFileName(Constants.TEAMAPPRECIALS); DataSource
				 * teamApprecialsDataSource = new FileDataSource(new
				 * File(teamApprecials.getFileName())); byte[] teamApprecialsLaunchFile =
				 * teamApprecials.getImage(); OutputStream teamApprecialsSourceOS =
				 * teamApprecialsDataSource.getOutputStream();
				 * teamApprecialsSourceOS.write(teamApprecialsLaunchFile);
				 * messageBodyPart.setDataHandler(new DataHandler(teamApprecialsDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<teamAppreciation>");
				 */
				final String teamApprecialsfileName = "Images/teamApprecials.png";
				ClassLoader teamApprecialsclassLoader = getClass().getClassLoader();
				InputStream teamApprecialsfile = teamApprecialsclassLoader.getResourceAsStream(teamApprecialsfileName);
				byte[] teamApprecialsbytes = teamApprecialsfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(teamApprecialsbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<teamAppreciation>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.HOLIDAY)) {
				// teamAppreciation
				messageBodyPart = new MimeBodyPart();
				/*
				 * MailImages holiday = mailImagesRepo.findByFileName(Constants.HOLIDAY);
				 * DataSource holidayDataSource = new FileDataSource(new
				 * File(holiday.getFileName())); byte[] holidayLaunchFile = holiday.getImage();
				 * OutputStream holidaySourceOS = holidayDataSource.getOutputStream();
				 * holidaySourceOS.write(holidayLaunchFile); messageBodyPart.setDataHandler(new
				 * DataHandler(holidayDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<holiday>");
				 */
				final String holidayfileName = "Images/holiday.png";
				ClassLoader holidayclassLoader = getClass().getClassLoader();
				InputStream holidayfile = holidayclassLoader.getResourceAsStream(holidayfileName);
				byte[] holidaybytes = holidayfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(holidaybytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<holiday>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			} else if (msgg.equalsIgnoreCase(Constants.EMPLOYEE_OF_MONTH)) {
				// teamAppreciation
				messageBodyPart = new MimeBodyPart();
				/*
				 * MailImages employeeOfMonth =
				 * mailImagesRepo.findByFileName(Constants.EMPLOYEE_OF_MONTH); DataSource
				 * employeeOfMonthDataSource = new FileDataSource(new
				 * File(employeeOfMonth.getFileName())); byte[] employeeOfMonthLaunchFile =
				 * employeeOfMonth.getImage(); OutputStream employeeOfMonthSourceOS =
				 * employeeOfMonthDataSource.getOutputStream();
				 * employeeOfMonthSourceOS.write(employeeOfMonthLaunchFile);
				 * messageBodyPart.setDataHandler(new DataHandler(employeeOfMonthDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<employeeOfMonth>");
				 */
				final String employeeOfMonthfileName = "Images/employeeOfMonth.png";
				ClassLoader employeeOfMonthclassLoader = getClass().getClassLoader();
				InputStream employeeOfMonthfile = employeeOfMonthclassLoader
						.getResourceAsStream(employeeOfMonthfileName);
				byte[] employeeOfMonthbytes = employeeOfMonthfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(employeeOfMonthbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<employeeOfMonth>");

				multipart.addBodyPart(messageBodyPart);
				// put everything together
				message.setContent(multipart);
			}
			helper.setTo(request.getTo());
			helper.setSubject(request.getSubject());
			helper.setFrom(new InternetAddress(request.getFrom()));
			sender.send(message);
			logger.info("Mail sent succesfully");
			response.setMessage("mail send to  " + request.getTo());
			response.setStatus("TRUE");

		} catch (MessagingException | IOException | TemplateException e) {
			logger.error("Error While sending mail{} ", e.getMessage());
			response.setMessage("Mail Sending failure " + e.getMessage());
			response.setStatus("FALSE");
		}

		return response;
	}

	/**
	 * Sending Scheduled Occation Mails
	 */
	public ResponseDTO sendOccationEmail(MailDTO request, Map<String, Object> model) {

		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			helper.setTo(request.getTo());
			helper.setSubject(request.getSubject());
			helper.setFrom(new InternetAddress(fromMail));
			MimeMultipart multipart = new MimeMultipart(Constants.RELATED);
			Map<String, Object> m = model;
			String msgg = model.get(Constants.MSG).toString();

			if (msgg.equalsIgnoreCase(Constants.HAPPY_BIRTHDAY)
					|| msgg.equalsIgnoreCase(Constants.ADVANCE_BIRTHDAY_WISHES)) {
				Template t1 = config.getTemplate("BirthdayWishes.html");
				String html = FreeMarkerTemplateUtils.processTemplateIntoString(t1, m);
				BodyPart messageBodyPart = new MimeBodyPart();
				messageBodyPart.setContent(html, "text/html");
				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(request.getCompanyId());
				if (!companyImages.isEmpty()) {
					for (ProfileImage image : companyImages) {
						if (!image.getImageName().contains("_")) {
							S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
							InputStream in = new BufferedInputStream(s3File.getObjectContent());
							byte[] bytes = in.readAllBytes();
							messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
							messageBodyPart.addHeader("Content-ID", "<logo>");
						}
					}
				} else {
					final String fileName = "Images/ostafflogo.png";
					ClassLoader classLoader = getClass().getClassLoader();
					InputStream file = classLoader.getResourceAsStream(fileName);
					byte[] bytes = file.readAllBytes();
					messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
					messageBodyPart.addHeader("Content-ID", "<logo>");
				}
				/*
				 * MailImages logo = mailImagesRepo.findByFileName(Constants.ONPASSIVE_LOGO);
				 * DataSource logoDataSource = new FileDataSource(new File(logo.getFileName()));
				 * byte[] file = logo.getImage(); OutputStream sourceOS =
				 * logoDataSource.getOutputStream(); sourceOS.write(file);
				 * messageBodyPart.setDataHandler(new DataHandler(logoDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				/*
				 * final String fileName = "Images/onpassiveLogo.png"; ClassLoader classLoader =
				 * getClass().getClassLoader(); InputStream file =
				 * classLoader.getResourceAsStream(fileName); byte[] bytes =
				 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
				 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages birthday = mailImagesRepo.findByFileName(Constants.BIRTHDAY);
				 * DataSource birthdayDataSource = new FileDataSource(new
				 * File(birthday.getFileName())); byte[] birthdayFile = birthday.getImage();
				 * OutputStream birthdaySourceOS = birthdayDataSource.getOutputStream();
				 * birthdaySourceOS.write(birthdayFile); messageBodyPart.setDataHandler(new
				 * DataHandler(birthdayDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<birthday>");
				 */
				final String BirthdayfileName = "Images/Birthday.png";
				ClassLoader BirthdayclassLoader = getClass().getClassLoader();
				InputStream Birthdayfile = BirthdayclassLoader.getResourceAsStream(BirthdayfileName);
				byte[] Birthdaybytes = Birthdayfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(Birthdaybytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<birthday>");

				multipart.addBodyPart(messageBodyPart);
				message.setContent(multipart);
				sender.send(message);
				logger.debug("Mail sent succesfully");
			} else if (msgg.equalsIgnoreCase(Constants.HAPPY_MARRIAGEDAY)
					|| msgg.equalsIgnoreCase(Constants.ADVANCE_MARRIAGEDAY_ANNIVERSARY_WISHES)) {

				Template t1 = config.getTemplate("wedding_day.html");
				String html = FreeMarkerTemplateUtils.processTemplateIntoString(t1, m);
				BodyPart messageBodyPart = new MimeBodyPart();
				messageBodyPart.setContent(html, "text/html");
				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(request.getCompanyId());
				if (!companyImages.isEmpty()) {
					for (ProfileImage image : companyImages) {
						if (!image.getImageName().contains("_")) {
							S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
							InputStream in = new BufferedInputStream(s3File.getObjectContent());
							byte[] bytes = in.readAllBytes();
							messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
							messageBodyPart.addHeader("Content-ID", "<logo>");
						}
					}
				} else {
					final String fileName = "Images/ostafflogo.png";
					ClassLoader classLoader = getClass().getClassLoader();
					InputStream file = classLoader.getResourceAsStream(fileName);
					byte[] bytes = file.readAllBytes();
					messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
					messageBodyPart.addHeader("Content-ID", "<logo>");
				}

				/*
				 * MailImages logo = mailImagesRepo.findByFileName(Constants.ONPASSIVE_LOGO);
				 * DataSource logoDataSource = new FileDataSource(new File(logo.getFileName()));
				 * byte[] file = logo.getImage(); OutputStream sourceOS =
				 * logoDataSource.getOutputStream(); sourceOS.write(file);
				 * messageBodyPart.setDataHandler(new DataHandler(logoDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				/*
				 * final String fileName = "Images/onpassiveLogo.png"; ClassLoader classLoader =
				 * getClass().getClassLoader(); InputStream file =
				 * classLoader.getResourceAsStream(fileName); byte[] bytes =
				 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
				 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages weddingTop = mailImagesRepo.findByFileName(Constants.WEDDING_TOP);
				 * DataSource weddingTopDataSource = new FileDataSource(new
				 * File(weddingTop.getFileName())); byte[] weddingTopFile =
				 * weddingTop.getImage(); OutputStream weddingTopSourceOS =
				 * weddingTopDataSource.getOutputStream();
				 * weddingTopSourceOS.write(weddingTopFile); messageBodyPart.setDataHandler(new
				 * DataHandler(weddingTopDataSource)); messageBodyPart.addHeader("Content-ID",
				 * "<weddingTop>");
				 */

				final String weddingTopfileName = "Images/weddingTop.png";
				ClassLoader weddingTopclassLoader = getClass().getClassLoader();
				InputStream weddingTopfile = weddingTopclassLoader.getResourceAsStream(weddingTopfileName);
				byte[] weddingTopbytes = weddingTopfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(weddingTopbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<weddingTop>");

				multipart.addBodyPart(messageBodyPart);
				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages weddingBottom =
				 * mailImagesRepo.findByFileName(Constants.WEDDING_BOTTOM); DataSource
				 * weddingBottomDataSource = new FileDataSource(new
				 * File(weddingBottom.getFileName())); byte[] weddingBottomFile =
				 * weddingBottom.getImage(); OutputStream weddingBottomSourceOS =
				 * weddingBottomDataSource.getOutputStream();
				 * weddingBottomSourceOS.write(weddingBottomFile);
				 * messageBodyPart.setDataHandler(new DataHandler(weddingBottomDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<weddingButtom>");
				 */
				final String weddingBottomfileName = "Images/weddingBottom.png";
				ClassLoader weddingBottomclassLoader = getClass().getClassLoader();
				InputStream weddingBottomfile = weddingBottomclassLoader.getResourceAsStream(weddingBottomfileName);
				byte[] weddingBottombytes = weddingBottomfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(weddingBottombytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<weddingButtom>");

				multipart.addBodyPart(messageBodyPart);
				message.setContent(multipart);
				sender.send(message);
				logger.debug("Mail sent Succesfully");
			} else if (msgg.equalsIgnoreCase(Constants.HAPPY_JOINNINGDAY)
					|| msgg.equalsIgnoreCase(Constants.ADVANCE_JOINNINGDAY_WISHES)) {
				Template t1 = config.getTemplate("employee_onboard.html");
				String html = FreeMarkerTemplateUtils.processTemplateIntoString(t1, m);
				BodyPart messageBodyPart = new MimeBodyPart();
				messageBodyPart.setContent(html, "text/html");
				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(request.getCompanyId());
				if (!companyImages.isEmpty()) {
					for (ProfileImage image : companyImages) {
						if (!image.getImageName().contains("_")) {
							S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
							InputStream in = new BufferedInputStream(s3File.getObjectContent());
							byte[] bytes = in.readAllBytes();
							messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
							messageBodyPart.addHeader("Content-ID", "<logo>");
						}
					}
				} else {
					final String fileName = "Images/ostafflogo.png";
					ClassLoader classLoader = getClass().getClassLoader();
					InputStream file = classLoader.getResourceAsStream(fileName);
					byte[] bytes = file.readAllBytes();
					messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
					messageBodyPart.addHeader("Content-ID", "<logo>");
				}
				/*
				 * MailImages logo = mailImagesRepo.findByFileName(Constants.ONPASSIVE_LOGO);
				 * DataSource logoDataSource = new FileDataSource(new File(logo.getFileName()));
				 * byte[] file = logo.getImage(); OutputStream sourceOS =
				 * logoDataSource.getOutputStream(); sourceOS.write(file);
				 * messageBodyPart.setDataHandler(new DataHandler(logoDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				/*
				 * final String fileName = "Images/empOnboarding.png"; ClassLoader classLoader =
				 * getClass().getClassLoader(); InputStream file =
				 * classLoader.getResourceAsStream(fileName); byte[] bytes =
				 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
				 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
				 */

				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();

				/*
				 * MailImages empOnboarding =
				 * mailImagesRepo.findByFileName(Constants.EMP_ONBOARDING); DataSource
				 * empOnboardingDataSource = new FileDataSource(new
				 * File(empOnboarding.getFileName())); byte[] empOnboardingFile =
				 * empOnboarding.getImage(); OutputStream empOnboardingSourceOS =
				 * empOnboardingDataSource.getOutputStream();
				 * empOnboardingSourceOS.write(empOnboardingFile);
				 * messageBodyPart.setDataHandler(new DataHandler(empOnboardingDataSource));
				 * messageBodyPart.addHeader("Content-ID", "<onboard>");
				 */
				final String empOnboardingfileName = "Images/empOnboarding.png";
				ClassLoader empOnboardingclassLoader = getClass().getClassLoader();
				InputStream empOnboardingfile = empOnboardingclassLoader.getResourceAsStream(empOnboardingfileName);
				byte[] empOnboardingbytes = empOnboardingfile.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(empOnboardingbytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<onboard>");

				multipart.addBodyPart(messageBodyPart);
				message.setContent(multipart);
				sender.send(message);
				logger.info("Mail sent Succesfully");
			}
			logger.info("mail:{}{} ", msgg.equalsIgnoreCase("Happy MarriageDay"), msgg);
			response.setMessage("mail send to " + request.getTo());
			response.setStatus("TRUE");
		} catch (MessagingException | IOException | TemplateException e) {
			response.setMessage("Mail Sending failure " + e.getMessage());
			response.setStatus("FALSE");
		}
		return response;
	}

	public ResponseDTO sendEmail(MailDTO request, Map<String, Object> model) {
		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template t = config.getTemplate(request.getTemplate());
			Map<String, Object> m = model;
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);
			BodyPart messageBodyPart = new MimeBodyPart();
			MimeMultipart multipart = new MimeMultipart("related");
			messageBodyPart.setContent(html, "text/html");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();

			List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(request.getCompanyId());
			if (!companyImages.isEmpty()) {
				for (ProfileImage image : companyImages) {
					if (!image.getImageName().contains("_")) {
						S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
						InputStream in = new BufferedInputStream(s3File.getObjectContent());
						byte[] bytes = in.readAllBytes();
						messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
						messageBodyPart.addHeader("Content-ID", "<logo>");
					}
				}
			} else {
				final String fileName = "Images/ostafflogo.png";
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream file = classLoader.getResourceAsStream(fileName);
				byte[] bytes = file.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<logo>");
			}

			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			helper.setTo(request.getTo());
			helper.setText(html, true);
			helper.setSubject(request.getSubject());
			helper.setFrom(new InternetAddress(fromMail));
			helper.setText(html, true);
			sender.send(message);
			logger.debug("Mail sent Succesfully");
			response.setMessage("mail send to : " + request.getTo());
			response.setStatus("TRUE");

		} catch (Exception e) {
			response.setMessage("Mail Sending failure : " + e.getMessage());
			logger.error("Error While sending mail:{}", e.getMessage());
			response.setStatus("FALSE");
		}

		return response;
	}

	/*	*//**
			 * Sending Mail for forgot password
			 * 
			 * @throws MessagingException
			 *//*
				 * @TrackExecutionTime public void sendForgotMail(String toEmail, String
				 * subject, String message,String link) { try {
				 * 
				 * MimeMessage msg = sender.createMimeMessage(); MimeMultipart multipart = new
				 * MimeMultipart(Constants.RELATED); MimeMessageHelper helper = new
				 * MimeMessageHelper(msg, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
				 * StandardCharsets.UTF_8.name()); helper.setTo(toEmail);
				 * helper.setSubject(subject); helper.setText(message); helper.setFrom("HR");
				 * BodyPart messageBodyPart = new MimeBodyPart();
				 * messageBodyPart.setContent(link, "text/html");
				 * messageBodyPart.addHeader("Content-ID", "<ForgotPassword>");
				 * multipart.addBodyPart(messageBodyPart); msg.setContent(multipart);
				 * sender.send(msg); logger.info("Mail sent Succesfully"); } catch (Exception e)
				 * { e.printStackTrace(); } }
				 */

	/**
	 * generating random password
	 * 
	 * @param companyId
	 */
	public ResponseDTO sendForgotMail(String toEmail, String token, String userName, String companyId) {

		System.out.println("===========sendForgotMail================" + token);
		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template t = config.getTemplate("forgot_password.html");
			Map<String, Object> m = new HashMap<>();
			String tokenAppend = resetPwdLink.concat(token);
			m.put("user", userName);
			m.put("url", tokenAppend);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);
			BodyPart messageBodyPart = new MimeBodyPart();
			MimeMultipart multipart = new MimeMultipart("related");
			messageBodyPart.setContent(html, "text/html");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();

			List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(companyId);
			if (!companyImages.isEmpty()) {
				for (ProfileImage image : companyImages) {
					if (!image.getImageName().contains("_")) {
						S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
						InputStream in = new BufferedInputStream(s3File.getObjectContent());
						byte[] bytes = in.readAllBytes();
						messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
						messageBodyPart.addHeader("Content-ID", "<logo>");
					}
				}
			} else {
				final String fileName = "Images/ostafflogo.png";
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream file = classLoader.getResourceAsStream(fileName);
				byte[] bytes = file.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<logo>");
			}
			/*
			 * final String fileName = "Images/ostafflogo.png"; ClassLoader classLoader =
			 * getClass().getClassLoader(); InputStream file =
			 * classLoader.getResourceAsStream(fileName); byte[] bytes =
			 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
			 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
			 */

			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			helper.setTo(toEmail);
			helper.setText(html, true);
			helper.setSubject("Reset Password Link");
			helper.setFrom(new InternetAddress(fromMail));
			helper.setText(html, true);
			sender.send(message);
			logger.debug("Mail sent Succesfully");
			response.setMessage("mail send to : " + toEmail);
			response.setStatus("TRUE");

		} catch (Exception e) {
			response.setMessage("Mail Sending failure : " + e.getMessage());
			logger.error("Error While sending mail:{}", e.getMessage());
			response.setStatus("FALSE");
		}

		return response;
	}

	public String generateCommonLangPassword() {
		String upperCaseLetters = RandomStringUtils.random(2, 65, 90, true, true);
		String lowerCaseLetters = RandomStringUtils.random(2, 97, 122, true, true);
		String numbers = RandomStringUtils.randomNumeric(2);
		String specialChar = RandomStringUtils.random(2, 33, 47, false, false);
		String totalChars = RandomStringUtils.randomAlphanumeric(2);
		String combinedChars = upperCaseLetters.concat(lowerCaseLetters).concat(numbers).concat(specialChar)
				.concat(totalChars);
		List<Character> pwdChars = combinedChars.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
		Collections.shuffle(pwdChars);
		String password = pwdChars.stream().collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
				.toString();
		return password;
	}

	// @TrackExecutionTime
	public ResponseDTO sendPdfEmail(Employee employee, ByteArrayInputStream bos) throws TemplateNotFoundException,
			MalformedTemplateNameException, ParseException, IOException, TemplateException {

		MailDTO mail = new MailDTO();
		Calendar calendar = Calendar.getInstance();
		String month = null;

		int year = calendar.get(Calendar.YEAR);
		Optional<Employee> emp = employeeRepo.findById(employee.getId());
		if (emp.isPresent()) {
			String companyId = emp.get().getCompany().getId();
			Optional<PaySchedule> optPaySchedule = payScheduleRepository.findByCompanyId(companyId);
			if (optPaySchedule.isPresent()) {
				if (optPaySchedule.get().getPayDay().equalsIgnoreCase(Constants.LAST_DAY)) {
					month = getMonthForInt(calendar.get(Calendar.MONTH));
				} else if (optPaySchedule.get().getPayDay().equalsIgnoreCase(Constants.SELECTED_DAY)) {
					month = getMonthForInt(calendar.get(Calendar.MONTH) - 1);
				}
			}
			mail.setFrom("hrms");
			mail.setTo(employee.getOfficalMail());
			mail.setSubject("Payslip for the month of " + month + " " + year + ".");
		}
		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED, "UTF-8");
			DataSource source = new javax.mail.util.ByteArrayDataSource(bos, "apllication/pdf");
			helper.addAttachment("Payslip.pdf", source);
			helper.setTo(mail.getTo());
			helper.setSubject(mail.getSubject());
			helper.setFrom(mail.getFrom());

			VelocityEngine velocityEngine = new VelocityEngine();
			velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
			velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
			velocityEngine.init();

			org.apache.velocity.Template template = velocityEngine.getTemplate("index.vm");

			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put(Constants.NAME, employee.getFirstName() + " " + employee.getLastName());
			velocityContext.put(Constants.MONTH, month);
			velocityContext.put(Constants.YEAR, year);
			velocityContext.put(Constants.COMP_NAME, employee.getCompany().getName());

			StringWriter writer = new StringWriter();
			template.merge(velocityContext, writer);

			helper.setText(writer.toString());

			sender.send(message);

			logger.info("Successfully sended payslip:" + employee.getOfficalMail());

			response.setMessage("mail send to : " + mail.getTo());
			response.setStatus("True");

		} catch (MessagingException e) {
			response.setMessage(Constants.MAIL_SENDING_FAILURE + e.getMessage());
			response.setStatus("false");
		}

		return response;
	}

	public String getMonthForInt(int num) {
		String month = "wrong";
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (num >= 0 && num <= 11) {
			month = months[num];
		}
		return month;
	}

	public void sendUserSignUpMail(MailDTO request, Map<String, Object> model) {
		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try { // set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template t = config.getTemplate(request.getTemplate());
			Map<String, Object> m = model;
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);
			BodyPart messageBodyPart = new MimeBodyPart();
			MimeMultipart multipart = new MimeMultipart(Constants.RELATED);
			messageBodyPart.setContent(html, "text/html");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();

			/*
			 * MailImages findByFileName =
			 * mailImagesRepo.findByFileName(Constants.OSTAFF_LOGO); DataSource dataSource =
			 * new FileDataSource(new File(findByFileName.getFileName())); byte[] file =
			 * findByFileName.getImage(); OutputStream sourceOS =
			 * dataSource.getOutputStream(); sourceOS.write(file);
			 * messageBodyPart.setDataHandler(new DataHandler(dataSource));
			 * messageBodyPart.addHeader("Content-ID", "<logo>");
			 */
			final String fileName = "Images/ostafflogo.png";
			ClassLoader classLoader = getClass().getClassLoader();
			InputStream file = classLoader.getResourceAsStream(fileName);
			byte[] bytes = file.readAllBytes();
			messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
			messageBodyPart.addHeader("Content-ID", "<logo>");

			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			helper.setTo(request.getTo());
			helper.setText(html, true);
			helper.setSubject(request.getSubject());
			helper.setFrom(new InternetAddress(fromMail));
			helper.setText(html, true);
			sender.send(message);
			logger.info("Mail sent Succesfully");
			response.setMessage("mail send to : " + request.getTo());
			response.setStatus("TRUE");

		} catch (Exception e) {
			response.setMessage(Constants.MAIL_SENDING_FAILURE + e.getMessage());
			logger.error("Error While sending mail:{}", e.getMessage());
			response.setStatus("FALSE");
		}

	}

	/**
	 * Sending Mail for forgot password
	 *//*
		 * @TrackExecutionTime public void sendUserSignUpMail(String toEmail, String
		 * subject, String message) {
		 * 
		 * SimpleMailMessage msg = new SimpleMailMessage(); msg.setTo(toEmail);
		 * msg.setSubject(subject); msg.setText(message); msg.setFrom(fromMail);
		 * sender.send(msg); logger.info("Mail sent Succesfully"); }
		 */

	public void sendForgotMailConform(String officalMail, String string2, String companyId) {

		ResponseDTO response = new ResponseDTO();
		MimeMessage message = sender.createMimeMessage();
		try { // set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template t = config.getTemplate("forgot_Password_conform.html");
			Map<String, Object> m = new HashMap<>();
			m.put("massege", string2);
			m.put("url", loginUrl);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);
			BodyPart messageBodyPart = new MimeBodyPart();
			MimeMultipart multipart = new MimeMultipart(Constants.RELATED);
			messageBodyPart.setContent(html, "text/html");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();

			List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(companyId);
			if (!companyImages.isEmpty()) {
				for (ProfileImage image : companyImages) {
					if (!image.getImageName().contains("_")) {
						S3Object s3File = s3util.getS3File(image.getImageName(), foldername);
						InputStream in = new BufferedInputStream(s3File.getObjectContent());
						byte[] bytes = in.readAllBytes();
						messageBodyPart.setDataHandler(new DataHandler(bytes, image.getContentType()));
						messageBodyPart.addHeader("Content-ID", "<logo>");
					}
				}
			} else {
				final String fileName = "Images/ostafflogo.png";
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream file = classLoader.getResourceAsStream(fileName);
				byte[] bytes = file.readAllBytes();
				messageBodyPart.setDataHandler(new DataHandler(bytes, "image/png"));
				messageBodyPart.addHeader("Content-ID", "<logo>");
			}
			/*
			 * final String fileName = "Images/ostafflogo.png"; ClassLoader classLoader =
			 * getClass().getClassLoader(); InputStream file =
			 * classLoader.getResourceAsStream(fileName); byte[] bytes =
			 * file.readAllBytes(); messageBodyPart.setDataHandler(new DataHandler(bytes,
			 * "image/png")); messageBodyPart.addHeader("Content-ID", "<logo>");
			 */

			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			helper.setTo(officalMail);
			helper.setText(html, true);
			helper.setSubject("Reset Password Confirmation");
			helper.setFrom(new InternetAddress(fromMail));
			helper.setText(html, true);
			sender.send(message);
			logger.info("Mail sent Succesfully");
			response.setMessage("mail send to " + officalMail);
			response.setStatus("TRUE");

		} catch (Exception e) {
			response.setMessage(Constants.MAIL_SENDING_FAILURE + e.getMessage());
			logger.error("Error While sending mail:{}", e.getMessage());
			response.setStatus("FALSE");
		}

	}
}
