package com.hrms.admin.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.entity.AcademicDetails;
import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.BankDetails;
import com.hrms.admin.entity.BankDetailsErrorRecords;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.Department;
import com.hrms.admin.entity.Designation;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.EmergencyContactDetails;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.EmploymentType;
import com.hrms.admin.entity.PersonalDetails;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetails;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;
import com.hrms.admin.entity.Skill;
import com.hrms.admin.entity.State;
import com.hrms.admin.repository.AcademicDetailsRepository;
import com.hrms.admin.repository.AcadmicDetailsErrorRecordsRepository;
import com.hrms.admin.repository.BankDetailsErrorRecordsRepository;
import com.hrms.admin.repository.BankRepository;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.repository.EmergencyContactDetailErrorRecordsRepository;
import com.hrms.admin.repository.EmergencyContactDetailsRepository;
import com.hrms.admin.repository.EmployeeErrorRecordsRepository;
import com.hrms.admin.repository.EmployeeMailErrorRecordsRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.EmploymentTypeRepository;
import com.hrms.admin.repository.PersonalDetailsErrorRecordsRepository;
import com.hrms.admin.repository.PersonalDetailsRepository;
import com.hrms.admin.repository.ProfessionalDetailsErrorRecordsRepository;
import com.hrms.admin.repository.ProfessionalDetailsRepository;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.repository.StateRepository;
import com.hrms.admin.service.BranchService;
import com.hrms.admin.service.CompanyService;
import com.hrms.admin.service.DepartmentService;
import com.hrms.admin.service.DesignationService;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.service.SkillService;

@Component
public class EmployeeDataUploadUtil {
	private static final Logger logger = LoggerFactory.getLogger(EmployeeDataUploadUtil.class);
	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private BankRepository bankRepo;

	@Autowired
	private ProfessionalDetailsRepository prRepo;

	@Autowired
	private FieldsValidation validate;

	@Autowired
	private BankDetailsErrorRecordsRepository bankErrorRepo;

	@Autowired
	private ProfessionalDetailsErrorRecordsRepository pdrRepo;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private BranchService branchService;

	@Autowired
	private DepartmentService deptService;

	@Autowired
	private DesignationService designationService;
	@Autowired
	private SkillService skillService;

	@Autowired
	private ConversionUtils cutils;

	@Autowired
	private EmployeeErrorRecordsRepository eerRepo;

	@Autowired
	private EmployeeMailErrorRecordsRepository mailerrorRepo;

	@Autowired
	private RolesRepository rolesRepo;

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private StateRepository stateRepo;

	@Autowired
	private CityRepository cityRepo;

	@Autowired
	private AcademicDetailsRepository acdRepo;

	@Autowired
	private AcadmicDetailsErrorRecordsRepository acdeRepo;

	@Autowired
	private EmergencyContactDetailErrorRecordsRepository ecdeRepo;

	@Autowired
	private EmergencyContactDetailsRepository ecdRepo;

	@Autowired
	private PersonalDetailsRepository pdRepo;

	@Autowired
	private PersonalDetailsErrorRecordsRepository pdeRepo;

	@Autowired
	private EmployeeService service;

	@Autowired
	private EmploymentTypeRepository employmentTypeRepo;

	/**
	 * 
	 * @param file
	 * @return save employee basic info in data base
	 */
	public List<Map<String, Integer>> readOnBoardEmployeeDataFromExecl(MultipartFile file) {
		logger.info("read On Board Employee Data From Execl is Strating");
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<Employee> employees = new ArrayList<>();
		List<EmployeeErrorRecords> initialRecords = new ArrayList<>();// read form excel sheet
		List<EmployeeErrorRecords> empErrorList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
			if (row.getCell(0) != null) {
				errorRecords.setFirstName(row.getCell(0).getStringCellValue());
			}

			if (row.getCell(1) != null) {
				errorRecords.setMiddleName(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null) {
				errorRecords.setLastName(row.getCell(2).getStringCellValue());
			}

			if (row.getCell(3) != null) {
				errorRecords.setEmail(row.getCell(3).getStringCellValue());
			}

			if (row.getCell(4) != null) {
				if (row.getCell(4).getCellType() == CellType.NUMERIC) {
					errorRecords.setUserName(NumberToTextConverter.toText(row.getCell(4).getNumericCellValue()));
				} else if (row.getCell(4).getCellType() == CellType.STRING) {
					errorRecords.setUserName(row.getCell(4).getStringCellValue());
				}
			}
			if (row.getCell(5) != null) {
				errorRecords.setDateOfBirth(row.getCell(5).getDateCellValue());
			}
			if (row.getCell(6) != null) {
				errorRecords.setMaritalStatus(row.getCell(6).getStringCellValue());
			}
			if (row.getCell(7) != null) {
				errorRecords.setMarriageDay(row.getCell(7).getDateCellValue());
			}
			if (row.getCell(8) != null) {
				errorRecords.setGender(row.getCell(8).getStringCellValue());
			}

			if (row.getCell(9) != null) {
				if (row.getCell(9).getCellType() == CellType.NUMERIC) {
					errorRecords.setContactNo(NumberToTextConverter.toText(row.getCell(9).getNumericCellValue()));
				} else if (row.getCell(9).getCellType() == CellType.STRING) {
					errorRecords.setContactNo(row.getCell(9).getStringCellValue());
				}
//				errorRecords.setContactNo(NumberToTextConverter.toText(row.getCell(9).getNumericCellValue()));
			}

			if (row.getCell(10) != null /* && row.getCell(10).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(10).getCellType() == CellType.NUMERIC) {
					errorRecords
							.setAlternateContactNo(NumberToTextConverter.toText(row.getCell(10).getNumericCellValue()));
				} else if (row.getCell(10).getCellType() == CellType.STRING) {
					errorRecords.setAlternateContactNo(row.getCell(10).getStringCellValue());
				}
//				errorRecords.setAlternateContactNo(NumberToTextConverter.toText(row.getCell(10).getNumericCellValue()));
			}

			if (row.getCell(11) != null /* && row.getCell(11).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(11).getCellType() == CellType.NUMERIC) {
					errorRecords.setAadharCard(NumberToTextConverter.toText(row.getCell(11).getNumericCellValue()));
				} else if (row.getCell(11).getCellType() == CellType.STRING) {
					errorRecords.setAadharCard(row.getCell(11).getStringCellValue());
				}
//				errorRecords.setAadharCard(NumberToTextConverter.toText(row.getCell(11).getNumericCellValue()));
			}

			if (row.getCell(12) != null) {
				errorRecords.setPanCard(row.getCell(12).getStringCellValue());
			}
			if (row.getCell(13) != null) {
				errorRecords.setVoterID(row.getCell(13).getStringCellValue());
			}

			if (row.getCell(14) != null) {
				errorRecords.setPassportNo(row.getCell(14).getStringCellValue());
			}
			if (row.getCell(15) != null) {
				errorRecords.setJoiningDate(row.getCell(15).getDateCellValue());
			}
			if (row.getCell(16) != null) {
				errorRecords.setBloodGroup(row.getCell(16).getStringCellValue());
			}

			if (row.getCell(17) != null) {
				errorRecords.setPermanantAddress(row.getCell(17).getStringCellValue());
			}
			if (row.getCell(18) != null) {
				errorRecords.setPermanantLandmark(row.getCell(18).getStringCellValue());
			}
			if (row.getCell(19) != null) {
				errorRecords.setPermanantStreet(row.getCell(19).getStringCellValue());
			}
			if (row.getCell(20) != null) {
				errorRecords.setPermanantCity(row.getCell(20).getStringCellValue());
			}
			if (row.getCell(21) != null) {
				errorRecords.setPermanantDistrict(row.getCell(21).getStringCellValue());
			}
			if (row.getCell(22) != null) {
				errorRecords.setPermanantState(row.getCell(22).getStringCellValue());
			}
			if (row.getCell(23) != null) {
				errorRecords.setPermanantCountry(row.getCell(23).getStringCellValue());
			}
			if (row.getCell(24) != null /* && row.getCell(24).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(24).getCellType() == CellType.NUMERIC) {
					errorRecords
							.setPermanantPincode(NumberToTextConverter.toText(row.getCell(24).getNumericCellValue()));
				} else if (row.getCell(24).getCellType() == CellType.STRING) {
					errorRecords.setPermanantPincode(row.getCell(24).getStringCellValue());
				}
//				errorRecords.setPermanantPincode(NumberToTextConverter.toText(row.getCell(24).getNumericCellValue()));
			}

			if (row.getCell(25) != null) {
				errorRecords.setTemporaryAddress(row.getCell(25).getStringCellValue());
			}
			if (row.getCell(26) != null) {
				errorRecords.setTemporaryLandmark(row.getCell(26).getStringCellValue());
			}
			if (row.getCell(27) != null) {
				errorRecords.setTemporaryStreet(row.getCell(27).getStringCellValue());
			}
			if (row.getCell(28) != null) {
				errorRecords.setTemporaryCity(row.getCell(28).getStringCellValue());
			}
			if (row.getCell(29) != null) {
				errorRecords.setTemporaryDistrict(row.getCell(29).getStringCellValue());
			}
			if (row.getCell(30) != null) {
				errorRecords.setTemporaryState(row.getCell(30).getStringCellValue());
			}
			if (row.getCell(31) != null) {
				errorRecords.setTemporaryCountry(row.getCell(31).getStringCellValue());
			}
			if (row.getCell(32) != null && row.getCell(32).getCellType() == CellType.NUMERIC) {
				if (row.getCell(32).getCellType() == CellType.NUMERIC) {
					errorRecords
							.setTemporaryPincode(NumberToTextConverter.toText(row.getCell(32).getNumericCellValue()));
				} else if (row.getCell(32).getCellType() == CellType.STRING) {
					errorRecords.setTemporaryPincode(row.getCell(32).getStringCellValue());
				}
//				errorRecords.setTemporaryPincode(NumberToTextConverter.toText(row.getCell(32).getNumericCellValue()));
			}
			/*
			 * if (row.getCell(33) != null) {
			 * errorRecords.setPersonDetails1(row.getCell(33).getStringCellValue()); } if
			 * (row.getCell(34) != null) {
			 * errorRecords.setPd1Relation(row.getCell(34).getStringCellValue()); } if
			 * (row.getCell(35) != null && row.getCell(35).getCellType() == CellType.NUMERIC
			 * ) { if (row.getCell(35).getCellType() == CellType.NUMERIC) { errorRecords
			 * .setPd1ContactNumber(NumberToTextConverter.toText(row.getCell(35).
			 * getNumericCellValue())); } else if (row.getCell(35).getCellType() ==
			 * CellType.STRING) {
			 * errorRecords.setPd1ContactNumber(row.getCell(35).getStringCellValue()); } //
			 * errorRecords.setPd1ContactNumber(NumberToTextConverter.toText(row.getCell(35)
			 * .getNumericCellValue())); }
			 * 
			 * if (row.getCell(36) != null && row.getCell(36).getCellType() ==
			 * CellType.NUMERIC ) { if (row.getCell(36).getCellType() == CellType.NUMERIC) {
			 * errorRecords.setPd1AaltContactNumber(
			 * NumberToTextConverter.toText(row.getCell(36).getNumericCellValue())); } else
			 * if (row.getCell(36).getCellType() == CellType.STRING) {
			 * errorRecords.setPd1AaltContactNumber(row.getCell(36).getStringCellValue()); }
			 * // errorRecords //
			 * .setPd1AaltContactNumber(NumberToTextConverter.toText(row.getCell(36).
			 * getNumericCellValue())); } if (row.getCell(37) != null) {
			 * errorRecords.setPersonDetails2(row.getCell(37).getStringCellValue()); } if
			 * (row.getCell(38) != null) {
			 * errorRecords.setPd2Relation(row.getCell(38).getStringCellValue()); } if
			 * (row.getCell(39) != null && row.getCell(39).getCellType() == CellType.NUMERIC
			 * ) { if (row.getCell(39).getCellType() == CellType.NUMERIC) { errorRecords
			 * .setPd2ContactNumber(NumberToTextConverter.toText(row.getCell(39).
			 * getNumericCellValue())); } else if (row.getCell(39).getCellType() ==
			 * CellType.STRING) {
			 * errorRecords.setPd2ContactNumber(row.getCell(39).getStringCellValue()); } //
			 * errorRecords.setPd2ContactNumber(NumberToTextConverter.toText(row.getCell(39)
			 * .getNumericCellValue())); } if (row.getCell(40) != null &&
			 * row.getCell(40).getCellType() == CellType.NUMERIC ) { if
			 * (row.getCell(40).getCellType() == CellType.NUMERIC) {
			 * errorRecords.setPd1AaltContactNumber(
			 * NumberToTextConverter.toText(row.getCell(40).getNumericCellValue())); } else
			 * if (row.getCell(40).getCellType() == CellType.STRING) {
			 * errorRecords.setPd1AaltContactNumber(row.getCell(40).getStringCellValue()); }
			 * // errorRecords //
			 * .setPd2AaltContactNumber(NumberToTextConverter.toText(row.getCell(40).
			 * getNumericCellValue())); }
			 */

			if (row.getCell(33) != null) {
				errorRecords.setCompanyName(row.getCell(33).getStringCellValue());
			}

			if (row.getCell(34) != null) {
				errorRecords.setBranchName(row.getCell(34).getStringCellValue());
			}

			if (row.getCell(35) != null) {
				errorRecords.setDepartmentName(row.getCell(35).getStringCellValue());
			}
			if (row.getCell(36) != null) {
				errorRecords.setDesignationName(row.getCell(36).getStringCellValue());
			}
			if (row.getCell(37) != null) {
				errorRecords.setSkillsList(row.getCell(37).getStringCellValue());
			}
			if (row.getCell(38) != null) {
				errorRecords.setSecondarySkillsList(row.getCell(38).getStringCellValue());
			}
			if (row.getCell(39) != null) {
				errorRecords.setManagar(row.getCell(39).getStringCellValue());
			}
			if (row.getCell(40) != null) {
				errorRecords.setRoles(row.getCell(40).getStringCellValue());
			}
			if (row.getCell(41) != null) {
				errorRecords.setEmploymentType(row.getCell(41).getStringCellValue());
			}
			if (row.getCell(42) != null) {
				errorRecords.setEmpTypeStartDate(row.getCell(42).getDateCellValue());
			}

			if (row.getCell(43) != null) {
				errorRecords.setEmpTypeEndDate(row.getCell(43).getDateCellValue());
			}

			initialRecords.add(errorRecords);
		}
		for (EmployeeErrorRecords record : initialRecords) {
			if (record.getFirstName() == null || record.getLastName() == null || record.getEmail() == null
					|| record.getUserName() == null || record.getDateOfBirth() == null
					|| record.getMaritalStatus() == null || record.getGender() == null || record.getContactNo() == null
					|| record.getAadharCard() == null || record.getPanCard() == null || record.getJoiningDate() == null
					|| record.getBloodGroup() == null || record.getPermanantAddress() == null
					|| record.getPermanantLandmark() == null || record.getPermanantStreet() == null
					|| record.getPermanantCity() == null || record.getPermanantDistrict() == null
					|| record.getPermanantState() == null || record.getPermanantCountry() == null
					|| record.getPermanantPincode() == null || record.getTemporaryAddress() == null
					|| record.getTemporaryLandmark() == null || record.getTemporaryStreet() == null
					|| record.getTemporaryCity() == null || record.getTemporaryDistrict() == null
					|| record.getTemporaryState() == null || record.getTemporaryCountry() == null
					|| record.getTemporaryPincode() == null || record.getCompanyName() == null
					|| record.getBranchName() == null || record.getDepartmentName() == null
					|| record.getSkillsList() == null /*
														 * || record.getPersonDetails1() == null ||
														 * record.getPd1Relation() == null ||
														 * record.getPd1ContactNumber() == null ||
														 * record.getPersonDetails2() == null || record.getPd2Relation()
														 * == null || record.getPd2ContactNumber() == null
														 */ || record.getManagar() == null || record.getRoles() == null
					|| record.getEmploymentType() == null || record.getEmpTypeStartDate() == null) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				empErrorList.add(errorRecords);
				continue;
			}
			if (record.getContactNo().trim().equals("0") || record.getAadharCard().equals("0")
					|| record.getPermanantPincode().trim().equals("0")
					|| record.getTemporaryPincode().trim().equals("0")
			/*
			 * || record.getPd1ContactNumber().trim().equals("0") ||
			 * record.getPd2ContactNumber().trim().equals("0")
			 */) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				empErrorList.add(errorRecords);
				continue;
			}

			boolean isflag = validate.validateNameWithLength(record.getFirstName());
			if (Boolean.FALSE.equals(isflag)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setFirstName(record.getFirstName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validateNameWithLength(record.getLastName());
			if (Boolean.FALSE.equals(isflag1)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setFirstName(record.getFirstName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateEmail(record.getEmail());
			if (Boolean.FALSE.equals(isflag2)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmail(record.getEmail().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag3 = validate.validateUserName(record.getUserName());
			if (Boolean.FALSE.equals(isflag3)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setUserName(record.getUserName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag4 = validate.validateName(record.getMaritalStatus());
			if (Boolean.FALSE.equals(isflag4)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setMaritalStatus(record.getMaritalStatus().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag5 = validate.validateName(record.getGender());
			if (Boolean.FALSE.equals(isflag5)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setGender(record.getGender().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag6 = validate.validatePhoneNumber(record.getContactNo());
			if (Boolean.FALSE.equals(isflag6)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactNo(record.getContactNo().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag7 = validate.validateAadher(record.getAadharCard());
			if (Boolean.FALSE.equals(isflag7)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setAadharCard(record.getAadharCard().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag8 = validate.validatePanAndVoter(record.getPanCard());
			if (Boolean.FALSE.equals(isflag8)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPanCard(record.getPanCard().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag10 = validate.validateBloodGroupName(record.getBloodGroup());
			if (Boolean.FALSE.equals(isflag10)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setBloodGroup(record.getBloodGroup().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag11 = validate.validateMixedWordsWithSpaceWithSplChar(record.getPermanantAddress());
			if (Boolean.FALSE.equals(isflag11)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantAddress(record.getPermanantAddress().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag12 = validate.validateName(record.getPermanantLandmark());
			if (Boolean.FALSE.equals(isflag12)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantLandmark(record.getPermanantLandmark().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag13 = validate.validateMixedWordsWithSpaceWithSplChar(record.getPermanantStreet());
			if (Boolean.FALSE.equals(isflag13)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setAadharCard(record.getAadharCard().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag14 = validate.validateName(record.getPermanantCity());
			if (Boolean.FALSE.equals(isflag14)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantCity(record.getPermanantCity().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag15 = validate.validateName(record.getPermanantDistrict());
			if (Boolean.FALSE.equals(isflag15)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantDistrict(record.getPermanantDistrict().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag16 = validate.validateName(record.getPermanantState());
			if (Boolean.FALSE.equals(isflag16)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantState(record.getPermanantState().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag17 = validate.validateName(record.getPermanantCountry());
			if (Boolean.FALSE.equals(isflag17)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantCountry(record.getPermanantCountry().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag18 = validate.validatePincode(record.getPermanantPincode());
			if (Boolean.FALSE.equals(isflag18)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantPincode(record.getPermanantPincode().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
//			boolean isflag19 = validate.validateMixedWordsWithSpaceWithSplChar(record.getPermanantAddress());
//			if (Boolean.FALSE.equals(isflag19)) {
//				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
//				BeanUtils.copyProperties(record, errorRecords);
//				errorRecords.setPermanantAddress(record.getPermanantAddress().concat("*"));
//				empErrorList.add(errorRecords);
//				continue;
//			}
			boolean isflag20 = validate.validateMixedWordsWithSpaceWithSplChar(record.getTemporaryAddress());
			if (Boolean.FALSE.equals(isflag20)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryAddress(record.getTemporaryAddress().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag21 = validate.validateMixedWordsWithSpaceWithSplChar(record.getTemporaryStreet());
			if (Boolean.FALSE.equals(isflag21)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryStreet(record.getTemporaryStreet().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag22 = validate.validateName(record.getTemporaryCity());
			if (Boolean.FALSE.equals(isflag22)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryCity(record.getTemporaryCity().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag23 = validate.validateName(record.getTemporaryDistrict());
			if (Boolean.FALSE.equals(isflag23)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryDistrict(record.getTemporaryDistrict().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag24 = validate.validateName(record.getTemporaryState());
			if (Boolean.FALSE.equals(isflag24)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryState(record.getTemporaryState().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag25 = validate.validateName(record.getTemporaryCountry());
			if (Boolean.FALSE.equals(isflag25)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryCountry(record.getTemporaryCountry().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag26 = validate.validatePincode(record.getTemporaryPincode());
			if (Boolean.FALSE.equals(isflag26)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryPincode(record.getTemporaryPincode().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			boolean isflag32 = validate.validateName(record.getCompanyName());
			if (Boolean.FALSE.equals(isflag32)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setCompanyName(record.getCompanyName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag33 = validate.validateName(record.getBranchName());
			if (Boolean.FALSE.equals(isflag33)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setBranchName(record.getBranchName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag34 = validate.validateName(record.getDepartmentName());
			if (Boolean.FALSE.equals(isflag34)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setDepartmentName(record.getDepartmentName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			boolean isflag35 = validate.validateName(record.getDesignationName());
			if (Boolean.FALSE.equals(isflag35)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantPincode(record.getPermanantPincode().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			/*
			 * boolean isflag41 = validate.validateName(record.getPersonDetails1()); if
			 * (Boolean.FALSE.equals(isflag41)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPersonDetails1(record.getPersonDetails1().concat("*"));
			 * empErrorList.add(errorRecords); continue; } boolean isflag42 =
			 * validate.validateName(record.getPd1Relation()); if
			 * (Boolean.FALSE.equals(isflag42)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPd1Relation(record.getPd1Relation().concat("*"));
			 * empErrorList.add(errorRecords); continue; } boolean isflag43 =
			 * validate.validatePhoneNumber(record.getPd1ContactNumber()); if
			 * (Boolean.FALSE.equals(isflag43)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPd1ContactNumber(record.getPd1ContactNumber().concat("*"));
			 * empErrorList.add(errorRecords); continue; } boolean isflag45 =
			 * validate.validateName(record.getPersonDetails2()); if
			 * (Boolean.FALSE.equals(isflag45)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPersonDetails2(record.getPersonDetails2().concat("*"));
			 * empErrorList.add(errorRecords); continue; } boolean isflag46 =
			 * validate.validateName(record.getPd2Relation()); if
			 * (Boolean.FALSE.equals(isflag46)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPd2Relation(record.getPd2Relation().concat("*"));
			 * empErrorList.add(errorRecords); continue; } boolean isflag47 =
			 * validate.validatePhoneNumber(record.getPd2ContactNumber()); if
			 * (Boolean.FALSE.equals(isflag47)) { EmployeeErrorRecords errorRecords = new
			 * EmployeeErrorRecords(); BeanUtils.copyProperties(record, errorRecords);
			 * errorRecords.setPd2ContactNumber(record.getPd2ContactNumber().concat("*"));
			 * empErrorList.add(errorRecords); continue; }
			 */boolean isflag48 = validate.validateName(record.getEmploymentType());
			if (Boolean.FALSE.equals(isflag48)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmploymentType(record.getEmploymentType().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
					|| Boolean.FALSE.equals(isflag3) || Boolean.FALSE.equals(isflag4) || Boolean.FALSE.equals(isflag5)
					|| Boolean.FALSE.equals(isflag6) || Boolean.FALSE.equals(isflag7) || Boolean.FALSE.equals(isflag8)
					|| Boolean.FALSE.equals(isflag10) || Boolean.FALSE.equals(isflag11)
					|| Boolean.FALSE.equals(isflag12) || Boolean.FALSE.equals(isflag13)
					|| Boolean.FALSE.equals(isflag14) || Boolean.FALSE.equals(isflag15)
					|| Boolean.FALSE.equals(isflag16) || Boolean.FALSE.equals(isflag17)
					|| Boolean.FALSE.equals(isflag18) || /*
															 * Boolean.FALSE.equals(isflag19) ||
															 */ Boolean.FALSE.equals(isflag20)
					|| Boolean.FALSE.equals(isflag21) || Boolean.FALSE.equals(isflag22)
					|| Boolean.FALSE.equals(isflag23) || Boolean.FALSE.equals(isflag24)
					|| Boolean.FALSE.equals(isflag25) || Boolean.FALSE.equals(isflag26)
					|| Boolean.FALSE.equals(isflag32) || Boolean.FALSE.equals(isflag33)
					|| Boolean.FALSE.equals(isflag34) || Boolean.FALSE.equals(isflag35)
					/*
					 * || Boolean.FALSE.equals(isflag41) || Boolean.FALSE.equals(isflag42) ||
					 * Boolean.FALSE.equals(isflag43) || Boolean.FALSE.equals(isflag45) ||
					 * Boolean.FALSE.equals(isflag46) || Boolean.FALSE.equals(isflag47)
					 */
					|| Boolean.FALSE.equals(isflag48)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				if (record.getVoterID() != null) {
					boolean isflag9 = validate.validatePanAndVoter(record.getVoterID());
					if (Boolean.FALSE.equals(isflag9)) {
						errorRecords.setVoterID(record.getVoterID().concat("*"));
					}
				}
				if (record.getAlternateContactNo() != null) {
					boolean isflag31 = validate.validatePhoneNumber(record.getAlternateContactNo());
					if (Boolean.FALSE.equals(isflag31)) {
						errorRecords.setAlternateContactNo(record.getAlternateContactNo().concat("*"));
					}
				}

				BeanUtils.copyProperties(record, errorRecords);
				empErrorList.add(errorRecords);
				continue;
			}
			Company company = companyService.findByCompanyName(record.getCompanyName());
			if (Objects.isNull(company)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setCompanyName(record.getCompanyName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			Branch branch = branchService.findByBranchName(record.getBranchName(), company.getId());
			if (Objects.isNull(branch)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setBranchName(record.getBranchName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			Department dept = deptService.findByName(record.getDepartmentName(), company.getId(), branch.getId());
			if (Objects.isNull(dept)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setDepartmentName(record.getDepartmentName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			Designation designation = designationService.findByDesignationName(record.getDesignationName(),
					company.getId(), branch.getId(), dept.getId());
			if (Objects.isNull(designation)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setDesignationName(record.getDesignationName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			Optional<Employee> manager = employeeRepo.findByName(record.getManagar(), company.getId());
			if (!manager.isPresent()) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setManagar(record.getManagar().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			List<String> skillList = cutils.stringToListArray(record.getSkillsList());
			for (String skillname : skillList) {
				Skill skill = skillService.findByName(skillname, company.getId());
				if (Objects.isNull(skill)) {
					EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
					BeanUtils.copyProperties(record, errorRecords);
					errorRecords.setSkillsList(record.getSkillsList().concat("*"));
					empErrorList.add(errorRecords);
					continue;
				}
			}
			if (record.getSecondarySkillsList() != null) {
				List<String> secondaryskilllist = cutils.stringToListArray(record.getSecondarySkillsList());
				for (String skillname : secondaryskilllist) {
					Skill skill = skillService.findByName(skillname, company.getId());
					if (Objects.isNull(skill)) {
						EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
						BeanUtils.copyProperties(record, errorRecords);
						errorRecords.setSecondarySkillsList(record.getSecondarySkillsList().concat("*"));
						empErrorList.add(errorRecords);
						continue;
					}
				}
			}
			EmployeeRoles role = rolesRepo.findRoleByCompany(record.getRoles(), company.getId());
			if (Objects.isNull(role)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setRoles(record.getRoles().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			Country findByCountryName = countryRepo.findByCountryName(record.getPermanantCountry());
			if (Objects.isNull(findByCountryName)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantCountry(record.getPermanantCountry().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			State findByStateName = stateRepo.findByStateName(record.getPermanantState());
			if (Objects.isNull(findByStateName)) {
				/*
				 * State state = new State(); state.setStateName(record.getPermanantState());
				 * state.setCountryId(findByCountryName.getCountryId());
				 * state.setStateId(stateRepo.getLastStateId() + 1L); stateRepo.save(state);
				 */

				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantState(record.getPermanantState().concat("*"));
				empErrorList.add(errorRecords);

			}
			/*
			 * if (Objects.isNull(findByStateName)) { findByStateName =
			 * stateRepo.findByStateName(record.getPermanantState()); }
			 */
			City findByCityName = cityRepo.findByCityName(record.getPermanantCity(), findByStateName.getStateId());
			if (Objects.isNull(findByCityName)) {
				/*
				 * City city = new City(); city.setCityName(record.getPermanantCity());
				 * city.setStateId(findByStateName.getStateId());
				 * city.setCityId(cityRepo.getLastCityId() + 1L); cityRepo.save(city);
				 */

				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPermanantCity(record.getPermanantCity().concat("*"));
				empErrorList.add(errorRecords);

			}

			Country findByCountryName1 = countryRepo.findByCountryName(record.getTemporaryCountry());
			if (Objects.isNull(findByCountryName1)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryCountry(record.getTemporaryCountry().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}

			State findByStateName1 = stateRepo.findByStateName(record.getTemporaryState());
			if (Objects.isNull(findByStateName1)) {
				/*
				 * State state = new State(); state.setStateName(record.getTemporaryState());
				 * state.setCountryId(findByCountryName.getCountryId());
				 * state.setStateId(stateRepo.getLastStateId() + 1L); stateRepo.save(state);
				 */

				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryState(record.getTemporaryState().concat("*"));
				empErrorList.add(errorRecords);

			}
			/*
			 * if (Objects.isNull(findByStateName1)) { findByStateName1 =
			 * stateRepo.findByStateName(record.getPermanantState()); }
			 */
			City findByCityName1 = cityRepo.findByCityName(record.getTemporaryCity(), findByStateName1.getStateId());
			if (Objects.isNull(findByCityName1)) {
				/*
				 * City city = new City(); city.setCityName(record.getTemporaryCity());
				 * city.setStateId(findByStateName.getStateId());
				 * city.setCityId(cityRepo.getLastCityId() + 1L); cityRepo.save(city);
				 */

				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setTemporaryCity(record.getTemporaryCity().concat("*"));
				empErrorList.add(errorRecords);

			}

			Long validateEmployeeEmail = service.validateEmployeeEmail(record.getEmail());
			if (validateEmployeeEmail != 0L) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmail(record.getEmail().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			Long validateEmployeeContact = service.validateEmployeeContact(record.getContactNo());
			if (validateEmployeeContact != 0L) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactNo(record.getContactNo().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			Long validateEmployeeUser = service.validateEmployeeUserNmae(record.getUserName());
			if (validateEmployeeUser != 0L) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setUserName(record.getUserName().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			EmploymentType findByEmploymentTypeName = employmentTypeRepo
					.findByEmploymentTypeName(record.getEmploymentType());
			if (Objects.isNull(findByEmploymentTypeName)) {
				EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmploymentType(record.getEmploymentType().concat("*"));
				empErrorList.add(errorRecords);
				continue;
			}
			Company company1 = companyService.findByCompanyName(record.getCompanyName());

			if (!Objects.isNull(company1)) {
				String companyName = company1.getName();
				if (record.getCompanyName().equals(companyName)) {
					List<Long> count = employeeRepo.getEmployeeSaveCountList(company1.getId(), record.getEmail(),
							record.getUserName(), record.getContactNo());
					if (!count.isEmpty()) {
						EmployeeErrorRecords errorRecords = new EmployeeErrorRecords();
						BeanUtils.copyProperties(record, errorRecords);
						errorRecords.setEmail(record.getEmail().concat("*"));
						errorRecords.setUserName(record.getUserName().concat("*"));
						errorRecords.setContactNo(record.getContactNo().concat("*"));
						empErrorList.add(errorRecords);
						continue;
					}
				}
			}

			if (record.getFirstName() != null || record.getLastName() != null || record.getEmail() != null
					|| record.getUserName() != null || record.getDateOfBirth() == null
					|| record.getMaritalStatus() != null || record.getGender() != null || record.getContactNo() != null
					|| record.getAadharCard() != null || record.getPanCard() != null || record.getJoiningDate() == null
					|| record.getBloodGroup() != null || record.getPermanantAddress() != null
					|| record.getPermanantLandmark() != null || record.getPermanantStreet() != null
					|| record.getPermanantCity() != null || record.getPermanantDistrict() != null
					|| record.getPermanantState() != null || record.getPermanantCountry() != null
					|| record.getPermanantPincode() != null || record.getTemporaryAddress() != null
					|| record.getTemporaryLandmark() != null || record.getTemporaryStreet() != null
					|| record.getTemporaryCity() != null || record.getTemporaryDistrict() != null
					|| record.getTemporaryState() != null || record.getTemporaryCountry() != null
					|| record.getTemporaryPincode() != null || record.getCompanyName() != null
					|| record.getBranchName() != null || record.getDepartmentName() != null
					|| record.getSkillsList() != null /*
														 * || record.getPersonDetails1() != null ||
														 * record.getPd1Relation() != null ||
														 * record.getPd1ContactNumber() != null ||
														 * record.getPersonDetails2() != null || record.getPd2Relation()
														 * != null || record.getPd2ContactNumber() != null
														 */ || record.getManagar() != null || record.getRoles() != null
					|| record.getEmploymentType() != null || record.getEmpTypeStartDate() != null) {

				Employee employee = new Employee();

				employee.setFirstName(record.getFirstName());
				employee.setMiddleName(record.getMiddleName());
				employee.setLastName(record.getLastName());
				employee.setEmail(record.getEmail());
				employee.setUserName(record.getUserName());
				employee.setDateOfBirth(record.getDateOfBirth());
				employee.setMaritalStatus(record.getMaritalStatus().toLowerCase());
				employee.setMarriageDay(record.getMarriageDay());
				employee.setGender(record.getGender().toLowerCase());
				employee.setContactNo(record.getContactNo());
				employee.setAlternateContactNo(record.getAlternateContactNo());
				employee.setAadharCard(record.getAadharCard());
				employee.setPanCard(record.getPanCard());
				employee.setVoterID(record.getVoterID());
				employee.setPassport(record.getPassportNo());
				employee.setJoiningDate(record.getJoiningDate());
				employee.setBloodGroup(validate.validateBloodGroup(record.getBloodGroup()));

				List<Address> addrlist = new ArrayList<>();
				Address permentAddress = new Address();

				permentAddress.setAddress(record.getPermanantAddress());
				permentAddress.setLandmark(record.getPermanantLandmark());
				permentAddress.setStreet(record.getPermanantStreet());
				Country findByCountryName2 = countryRepo.findByCountryName(record.getPermanantCountry());
				if (!Objects.isNull(findByCountryName2)) {
					permentAddress.setCountry(findByCountryName2.getCountryId());
				}
				State findByStateName2 = stateRepo.findByStateName(record.getPermanantState());
				if (!Objects.isNull(findByStateName2)) {
					permentAddress.setState(findByStateName2.getStateId());
				}
				City findByCityName2 = cityRepo.findByCityName(record.getPermanantCity(), findByStateName.getStateId());
				if (!Objects.isNull(findByCityName2)) {
					permentAddress.setCity(findByCityName2.getCityId());
				}
				permentAddress.setDistrict(record.getPermanantDistrict());
				permentAddress.setPincode(record.getPermanantPincode());
				permentAddress.setType(Constants.PERMANENT);
				addrlist.add(permentAddress);

				Address temporaryAddress = new Address();

				temporaryAddress.setAddress(record.getTemporaryAddress());
				temporaryAddress.setLandmark(record.getTemporaryLandmark());
				temporaryAddress.setStreet(record.getTemporaryStreet());
				Country findByCountryName3 = countryRepo.findByCountryName(record.getTemporaryCountry());
				if (!Objects.isNull(findByCountryName3)) {
					temporaryAddress.setCountry(findByCountryName3.getCountryId());
				}

				State findByStateName3 = stateRepo.findByStateName(record.getTemporaryState());
				if (!Objects.isNull(findByStateName3)) {
					temporaryAddress.setState(findByStateName3.getStateId());
				}

				City findByCityName3 = cityRepo.findByCityName(record.getTemporaryCity(),
						findByStateName1.getStateId());
				if (!Objects.isNull(findByCityName3)) {
					temporaryAddress.setCity(findByCityName3.getCityId());
				}
				temporaryAddress.setDistrict(record.getTemporaryDistrict());
				temporaryAddress.setPincode(record.getTemporaryPincode());
				temporaryAddress.setType(Constants.TEMPORARY);
				addrlist.add(temporaryAddress);
				employee.setAddress(addrlist);
				/*
				 * List<PersonalDetails> epdlist = new ArrayList<>();
				 * 
				 * PersonalDetails pd1 = new PersonalDetails();
				 * pd1.setPersonName(record.getPersonDetails1());
				 * pd1.setRelation(record.getPd1Relation().toLowerCase());
				 * pd1.setContactNumber(record.getPd1ContactNumber());
				 * pd1.setAltContactNumber(record.getPd1AaltContactNumber()); epdlist.add(pd1);
				 * 
				 * PersonalDetails pd2 = new PersonalDetails();
				 * pd2.setPersonName(record.getPersonDetails2());
				 * pd2.setRelation(record.getPd2Relation().toLowerCase());
				 * pd2.setContactNumber(record.getPd2ContactNumber());
				 * pd2.setAltContactNumber(record.getPd2AaltContactNumber()); epdlist.add(pd2);
				 * employee.setPersonalDetails(epdlist);
				 */
				employee.setIsApprove(Boolean.FALSE);
				employee.setIsActive(Boolean.FALSE);
				employee.setIsDelete(Boolean.FALSE);
				employee.setIsExit(Boolean.FALSE);
				Company company2 = companyService.findByCompanyName(record.getCompanyName());
				employee.setCompany(company2);
				Branch branch1 = branchService.findByBranchName(record.getBranchName(), company2.getId());
				employee.setBranch(branch1);
				Department dept1 = deptService.findByName(record.getDepartmentName(), company2.getId(), branch.getId());
				employee.setDepartment(dept);
				Designation designation1 = designationService.findByDesignationName(record.getDesignationName(),
						company2.getId(), branch1.getId(), dept1.getId());
				employee.setDesignation(designation1);
				Optional<Employee> manager1 = employeeRepo.findByName(record.getManagar(), company2.getId());
				if (manager1.isPresent()) {
					Employee managernew = manager1.get();
					employee.setManager(managernew);
				}
				List<String> skillList1 = cutils.stringToListArray(record.getSkillsList());
				List<Long> list = new ArrayList<>();
				for (String skillname : skillList1) {
					Skill skill = skillService.findByName(skillname, company2.getId());
					list.add(skill.getId());
				}
				employee.setPrimarySkills(list.toString());
				if (record.getSecondarySkillsList() != null) {
					List<String> secondryskillList1 = cutils.stringToListArray(record.getSecondarySkillsList());
					List<Long> list1 = new ArrayList<>();
					for (String skillname : secondryskillList1) {
						Skill skill = skillService.findByName(skillname, company2.getId());
						list1.add(skill.getId());
					}
					employee.setSecondarySkills(list1.toString());
				}
//				employee.setSkills(list);
				Set<EmployeeRoles> rlist = new HashSet<>();
				EmployeeRoles role1 = rolesRepo.findRoleByCompany(record.getRoles(), company2.getId());
				if (!Objects.isNull(role1)) {
					rlist.add(role1);
				}
				employee.setRoles(rlist);
				EmploymentType findByEmploymentType = employmentTypeRepo
						.findByEmploymentTypeName(record.getEmploymentType());
				if (!Objects.isNull(findByEmploymentType)) {
					employee.setEmploymentTypeId(findByEmploymentType.getEmploymentTypeId());
				}
				employee.setEmpTypeStartDate(record.getEmpTypeStartDate());
				if (record.getEmpTypeEndDate() != null) {
					employee.setEmpTypeEndDate(record.getEmpTypeEndDate());
				}
				employees.add(employee);
				logger.info("read On Board Employee valid Data add to list");
			}
		}

		List<EmployeeErrorRecords> BasicInfoErrorList = eerRepo.saveAll(empErrorList);// inserting in error table
		List<Employee> BasicInfoSuccessList = employeeRepo.saveAll(employees);

		logger.info("read OnBoard Employee valid Data is save to Db");
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> mapSuccess = new HashedMap<>();
		mapSuccess.put(Constants.SUCCESS, BasicInfoSuccessList.size());
		Map<String, Integer> mapFailure = new HashedMap<>();
		mapFailure.put(Constants.FAILURE, BasicInfoErrorList.size());
		resultList.add(0, mapSuccess);
		resultList.add(1, mapFailure);
		logger.info("Sucess count:{} and Failure count:{}", BasicInfoSuccessList.size(), BasicInfoErrorList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @param companyId
	 * @return save employee EducationalDetails in data base
	 */

	public List<Map<String, Integer>> readEmployeeEducationalDetailsDataFromExecl(MultipartFile file,
			String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<AcademicDetails> edlist = new ArrayList<>();
		List<AcadmicDetailsErrorRecords> initialRecords = new ArrayList<>();
		List<AcadmicDetailsErrorRecords> edeList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeId(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setQualification(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null) {
				errorRecords.setInstituteName(row.getCell(2).getStringCellValue());
			}
			if (row.getCell(3) != null /* && row.getCell(3).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(3).getCellType() == CellType.NUMERIC) {
					errorRecords.setYearOfPassing(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
				} else if (row.getCell(3).getCellType() == CellType.STRING) {
					errorRecords.setYearOfPassing(row.getCell(3).getStringCellValue());
				}
//				errorRecords.setYearOfPassing(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
			}
			if (row.getCell(4) != null) {
				errorRecords.setType(row.getCell(4).getStringCellValue());
			}

			if (row.getCell(5) != null/* && row.getCell(5).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(5).getCellType() == CellType.NUMERIC) {
					errorRecords.setPercentage(NumberToTextConverter.toText(row.getCell(5).getNumericCellValue()));
				} else if (row.getCell(5).getCellType() == CellType.STRING) {
					errorRecords.setPercentage(row.getCell(5).getStringCellValue());
				}
//				errorRecords.setPercentage(NumberToTextConverter.toText(row.getCell(5).getNumericCellValue()));
			}
			if (row.getCell(6) != null) {
				errorRecords.setIsDefault(row.getCell(6).getStringCellValue());
			}

			initialRecords.add(errorRecords);
			logger.info("read Employee Professional Details Data From Execl is Ending" + " ::");
		}

		for (AcadmicDetailsErrorRecords record : initialRecords) {
			if (record.getEmployeeId().trim().equals("") || record.getQualification() == null
					|| record.getInstituteName() == null || record.getYearOfPassing() == null
					|| record.getType() == null || record.getPercentage() == null || record.getIsDefault() == null) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				edeList.add(errorRecords);
				continue;
			}

			if (record.getEmployeeId().trim().equals("0") || record.getYearOfPassing().trim().equals("0")
					|| record.getPercentage().trim().equals("0")) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				edeList.add(errorRecords);
				continue;
			}

			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()), companyId);
			if (!emp.isPresent()) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeId(record.getEmployeeId().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag = validate.validateMixedWordsWithSpaceWithSplChar(record.getQualification());
			if (Boolean.FALSE.equals(isflag)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setQualification(record.getQualification().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validateMixedWordsWithSpaceWithSplChar(record.getInstituteName());
			if (Boolean.FALSE.equals(isflag1)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setInstituteName(record.getInstituteName().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateNumber(record.getYearOfPassing());
			if (Boolean.FALSE.equals(isflag2)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setYearOfPassing(record.getYearOfPassing().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag3 = validate.validateName(record.getType());
			if (Boolean.FALSE.equals(isflag3)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setType(record.getType().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag4 = validate.validateNumber(record.getPercentage());
			if (Boolean.FALSE.equals(isflag4)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPercentage(record.getPercentage().concat("*"));
				edeList.add(errorRecords);
				continue;
			}
			boolean isflag5 = validate.validateIsDefault(record.getIsDefault());
			if (Boolean.FALSE.equals(isflag5)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setIsDefault(record.getIsDefault().concat("*"));
				edeList.add(errorRecords);
				continue;
			}

			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
					|| Boolean.FALSE.equals(isflag3) || Boolean.FALSE.equals(isflag4)
					|| Boolean.FALSE.equals(isflag5)) {
				AcadmicDetailsErrorRecords errorRecords = new AcadmicDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				edeList.add(errorRecords);
				continue;
			}
			if ((record.getEmployeeId() != null) || (record.getQualification() != null)
					|| (record.getInstituteName() != null) || (record.getYearOfPassing() != null)
					|| (record.getType() != null) || (record.getPercentage() != null)
					|| (record.getIsDefault() != null)) {

				Optional<Employee> empObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()),
						companyId);
				if (empObj.isPresent()) {
					Employee employee = empObj.get();
					List<AcademicDetails> list = acdRepo.findByEmployee(employee.getId());
					if (!list.isEmpty()) {
						acdRepo.deleteAll(list);
					}
					AcademicDetails ad = new AcademicDetails();
					ad.setQualification(record.getQualification());
					ad.setInstituteName(record.getInstituteName());
					ad.setYearOfPassing(record.getYearOfPassing());
					ad.setType(record.getType());
					ad.setPercentage(record.getPercentage());
					if (Constants.YES.equalsIgnoreCase(record.getIsDefault().trim())) {
						ad.setIsDefault(Boolean.TRUE);
					} else {
						ad.setIsDefault(Boolean.FALSE);
					}
					ad.setEmployee(employee);
					edlist.add(ad);
				}
				logger.info("Valid data object adding to list");
			}
		}

		List<AcademicDetails> successList = acdRepo.saveAll(edlist);
		List<AcadmicDetailsErrorRecords> failureList = acdeRepo.saveAll(edeList);
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, successList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("sucess count:{} and failure count:{}", successList.size(), failureList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @param companyId
	 * @return save employee EmergencyContactDetails in data base
	 */

	public List<Map<String, Integer>> readEmployeeEmergencyContactDetailsDataFromExecl(MultipartFile file,
			String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<EmergencyContactDetails> pdlist = new ArrayList<>();
		List<EmergencyContactDetailErrorRecords> initialRecords = new ArrayList<>();
		List<EmergencyContactDetailErrorRecords> pdeList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeId(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setContactPerson(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null /* && row.getCell(2).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(2).getCellType() == CellType.NUMERIC) {
					errorRecords.setContactNumber(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
				} else if (row.getCell(2).getCellType() == CellType.STRING) {
					errorRecords.setContactNumber(row.getCell(2).getStringCellValue());
				}
//				errorRecords.setContactNumber(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
			}

			if (row.getCell(3) != null/* && row.getCell(3).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(3).getCellType() == CellType.NUMERIC) {
					errorRecords
							.setAltContactNumber(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
				} else if (row.getCell(3).getCellType() == CellType.STRING) {
					errorRecords.setAltContactNumber(row.getCell(3).getStringCellValue());
				}
//				errorRecords.setAltContactNumber(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
			}

			if (row.getCell(4) != null) {
				errorRecords.setRelation(row.getCell(4).getStringCellValue());
			}

			if (row.getCell(5) != null) {
				errorRecords.setIsDefault(row.getCell(5).getStringCellValue());
			}
			initialRecords.add(errorRecords);
			logger.info("read Employee Professional Details Data From Execl is Ending" + " ::");
		}

		for (EmergencyContactDetailErrorRecords record : initialRecords) {
			if (record.getEmployeeId().trim().equals("") || record.getContactPerson() == null
					|| record.getContactNumber() == null || record.getRelation() == null) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			if (record.getEmployeeId().trim().equals("0") || record.getContactNumber().trim().equals("0")) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()), companyId);
			if (!emp.isPresent()) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeId(record.getEmployeeId().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag = validate.validateName(record.getContactPerson());
			if (Boolean.FALSE.equals(isflag)) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactPerson(record.getContactPerson().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validatePhoneNumber(record.getContactNumber());
			if (Boolean.FALSE.equals(isflag1)) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactNumber(record.getContactNumber().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateName(record.getRelation());
			if (Boolean.FALSE.equals(isflag2)) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setRelation(record.getRelation().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag3 = validate.validateIsDefault(record.getIsDefault());
			if (Boolean.FALSE.equals(isflag3)) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setIsDefault(record.getIsDefault().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
					|| Boolean.FALSE.equals(isflag3)) {
				EmergencyContactDetailErrorRecords errorRecords = new EmergencyContactDetailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}
			if ((record.getEmployeeId() != null) || (record.getContactPerson() != null)
					|| (record.getContactNumber() != null) || (record.getRelation() != null)) {

				Optional<Employee> empObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()),
						companyId);
				if (empObj.isPresent()) {
					Employee employee = empObj.get();
					List<EmergencyContactDetails> list = ecdRepo.findByEmployee(employee.getId());
					if (!list.isEmpty()) {
						ecdRepo.deleteAll(list);
					}
					EmergencyContactDetails ecd = new EmergencyContactDetails();
					ecd.setContactPerson(record.getContactPerson());
					ecd.setContactNumber(record.getContactNumber());
					ecd.setRelation(record.getRelation());
					if (record.getAltContactNumber() != null) {
						ecd.setAltContactNumber(record.getAltContactNumber());
					}
					if (Constants.YES.equalsIgnoreCase(record.getIsDefault().trim())) {
						ecd.setIsDefault(Boolean.TRUE);
					} else {
						ecd.setIsDefault(Boolean.FALSE);
					}

					ecd.setEmployee(employee);
					pdlist.add(ecd);
				}
				logger.info("Valid data object adding to list");
			}
		}

		List<EmergencyContactDetails> successList = ecdRepo.saveAll(pdlist);
		List<EmergencyContactDetailErrorRecords> failureList = ecdeRepo.saveAll(pdeList);
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, successList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("sucess count:{} and failure count:{}", successList.size(), failureList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @param companyId
	 * @return save employee Personal Contact Details in data base
	 */

	public List<Map<String, Integer>> readEmployeePersonalDetailsDataFromExecl(MultipartFile file, String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<PersonalDetails> pdlist = new ArrayList<>();
		List<PersonalDetailsErrorRecords> initialRecords = new ArrayList<>();
		List<PersonalDetailsErrorRecords> pdeList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeId(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setContactPerson(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null /* && row.getCell(2).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(2).getCellType() == CellType.NUMERIC) {
					errorRecords.setContactNumber(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
				} else if (row.getCell(2).getCellType() == CellType.STRING) {
					errorRecords.setContactNumber(row.getCell(2).getStringCellValue());
				}
//				errorRecords.setContactNumber(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
			}

			if (row.getCell(3) != null/* && row.getCell(3).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(3).getCellType() == CellType.NUMERIC) {
					errorRecords
							.setAltContactNumber(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
				} else if (row.getCell(3).getCellType() == CellType.STRING) {
					errorRecords.setAltContactNumber(row.getCell(3).getStringCellValue());
				}
//				errorRecords.setAltContactNumber(NumberToTextConverter.toText(row.getCell(3).getNumericCellValue()));
			}

			if (row.getCell(4) != null) {
				errorRecords.setRelation(row.getCell(4).getStringCellValue());
			}
			if (row.getCell(5) != null) {
				errorRecords.setIsDefault(row.getCell(5).getStringCellValue());
			}

			initialRecords.add(errorRecords);
			logger.info("read Employee Personal Details Data From Execl is Ending" + " ::");
		}

		for (PersonalDetailsErrorRecords record : initialRecords) {
			if (record.getEmployeeId().trim().equals("") || record.getContactPerson() == null
					|| record.getContactNumber() == null || record.getRelation() == null
					|| record.getIsDefault() == null) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			if (record.getEmployeeId().trim().equals("0") || record.getContactNumber().trim().equals("0")) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()), companyId);
			if (!emp.isPresent()) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeId(record.getEmployeeId().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag = validate.validateName(record.getContactPerson());
			if (Boolean.FALSE.equals(isflag)) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactPerson(record.getContactPerson().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validatePhoneNumber(record.getContactNumber());
			if (Boolean.FALSE.equals(isflag1)) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setContactNumber(record.getContactNumber().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateName(record.getRelation());
			if (Boolean.FALSE.equals(isflag2)) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setRelation(record.getRelation().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag3 = validate.validateIsDefault(record.getIsDefault());
			if (Boolean.FALSE.equals(isflag3)) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setIsDefault(record.getIsDefault().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}

			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
					|| Boolean.FALSE.equals(isflag3)) {
				PersonalDetailsErrorRecords errorRecords = new PersonalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}
			if ((record.getEmployeeId() != null) || (record.getContactPerson() != null)
					|| (record.getContactNumber() != null) || (record.getRelation() != null)
					|| (record.getIsDefault() != null)) {

				Optional<Employee> empObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()),
						companyId);
				if (empObj.isPresent()) {
					Employee employee = empObj.get();
					List<PersonalDetails> list = pdRepo.findByEmployee(employee.getId());
					if (!list.isEmpty()) {
						pdRepo.deleteAll(list);
					}
					PersonalDetails pd = new PersonalDetails();
					pd.setPersonName(record.getContactPerson());
					pd.setContactNumber(record.getContactNumber());
					pd.setRelation(record.getRelation());
					if (record.getAltContactNumber() != null) {
						pd.setAltContactNumber(record.getAltContactNumber());
					}
					if (Constants.YES.equalsIgnoreCase(record.getIsDefault().trim())) {
						pd.setIsDefault(Boolean.TRUE);
					} else {
						pd.setIsDefault(Boolean.FALSE);
					}

					pd.setEmployee(employee);
					pdlist.add(pd);
				}
				logger.info("Valid data object adding to list");
			}
		}

		List<PersonalDetails> successList = pdRepo.saveAll(pdlist);
		List<PersonalDetailsErrorRecords> failureList = pdeRepo.saveAll(pdeList);
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, successList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("sucess count:{} and failure count:{}", successList.size(), failureList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @param companyId
	 * @return save employee ProfessionalDetails in data base
	 */

	public List<Map<String, Integer>> readEmployeeProfessionalDetailsDataFromExecl(MultipartFile file,
			String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<ProfessionalDetails> pdlist = new ArrayList<>();
		List<ProfessionalDetailsErrorRecords> initialRecords = new ArrayList<>();
		List<ProfessionalDetailsErrorRecords> pdeList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeId(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setCompanyName(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null) {
				errorRecords.setJoiningDate(row.getCell(2).getDateCellValue());
			}
			if (row.getCell(3) != null) {
				errorRecords.setRelievingDate(row.getCell(3).getDateCellValue());
			}
			if (row.getCell(4) != null/* && row.getCell(4).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(4).getCellType() == CellType.NUMERIC) {
					errorRecords.setExperience(NumberToTextConverter.toText(row.getCell(4).getNumericCellValue()));
				} else if (row.getCell(4).getCellType() == CellType.STRING) {
					errorRecords.setExperience(row.getCell(4).getStringCellValue());
				}
//				errorRecords.setExperience(NumberToTextConverter.toText(row.getCell(4).getNumericCellValue()));
			}

			if (row.getCell(5) != null) {
				errorRecords.setClient(row.getCell(5).getStringCellValue());
			}
			if (row.getCell(6) != null) {
				errorRecords.setIsDefault(row.getCell(6).getStringCellValue());
			}

			initialRecords.add(errorRecords);
			logger.info("read Employee Professional Details Data From Execl is Ending" + " ::");
		}

		for (ProfessionalDetailsErrorRecords record : initialRecords) {
			if (record.getEmployeeId().trim().equals("") || record.getCompanyName() == null
					|| record.getJoiningDate() == null || record.getRelievingDate() == null
					|| record.getExperience() == null) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}
			if (record.getCompanyName().trim().equals("")) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			if (record.getEmployeeId().trim().equals("0") || record.getExperience().trim().equals("0")) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				pdeList.add(errorRecords);
				continue;
			}

			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()), companyId);
			if (!emp.isPresent()) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeId(record.getEmployeeId().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag = validate.validateName(record.getCompanyName());
			if (Boolean.FALSE.equals(isflag)) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setCompanyName(record.getCompanyName().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validateDecimalValue(String.valueOf(record.getExperience()));
			if (Boolean.FALSE.equals(isflag1)) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setExperience(record.getExperience().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateIsDefault(record.getIsDefault());
			if (Boolean.FALSE.equals(isflag2)) {
				ProfessionalDetailsErrorRecords errorRecords = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setIsDefault(record.getIsDefault().concat("*"));
				pdeList.add(errorRecords);
				continue;
			}
			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)) {
				ProfessionalDetailsErrorRecords errorRecordsobj = new ProfessionalDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecordsobj);
				pdeList.add(errorRecordsobj);
				continue;
			}
			if ((record.getEmployeeId() != null) || (record.getCompanyName() != null)
					|| (record.getJoiningDate() != null) || (record.getRelievingDate() != null)
					|| (record.getExperience() != null)) {

				Optional<Employee> empObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()),
						companyId);
				if (empObj.isPresent()) {
					Employee employee = empObj.get();
					List<ProfessionalDetails> list = prRepo.findByEmployee(Long.parseLong(record.getEmployeeId()));
					if (!list.isEmpty()) {
						prRepo.deleteAll(list);
					}
					ProfessionalDetails pd = new ProfessionalDetails();
					pd.setEmployee(employee);
					pd.setCompanyName(record.getCompanyName());
					pd.setJoiningDate(record.getJoiningDate());
					pd.setRelievingDate(record.getRelievingDate());
					pd.setExperience(record.getExperience());
					pd.setClient(record.getClient());
					if (Constants.YES.equalsIgnoreCase(record.getIsDefault().trim())) {
						pd.setIsDefault(Boolean.TRUE);
					} else {
						pd.setIsDefault(Boolean.FALSE);
					}

					pdlist.add(pd);
				}
				logger.info("Valid data object adding to list");
			}
		}

		List<ProfessionalDetails> successList = prRepo.saveAll(pdlist);
		List<ProfessionalDetailsErrorRecords> failureList = pdrRepo.saveAll(pdeList);
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, successList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("sucess count:{} and failure count:{}", successList.size(), failureList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @param companyId
	 * @return save employee OfficeMailIds in data base
	 */
	public List<Map<String, Integer>> readEmployeeOfficeMailIdsFromExecl(MultipartFile file, String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<Employee> employeesList = new ArrayList<>();
		List<EmployeeMailErrorRecords> initialRecords = new ArrayList<>();
		List<EmployeeMailErrorRecords> mailErrorList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			EmployeeMailErrorRecords errorRecords = new EmployeeMailErrorRecords();

			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeId(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setOfficalMailId(row.getCell(1).getStringCellValue());
			}

			initialRecords.add(errorRecords);
		}
		for (EmployeeMailErrorRecords record : initialRecords) {
			if (record.getOfficalMailId().equals("") || record.getEmployeeId().equals("")) {
				EmployeeMailErrorRecords errorRecords = new EmployeeMailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				mailErrorList.add(errorRecords);
				continue;
			}
			boolean isflag = validate.validateEmail(record.getOfficalMailId());
			if (Boolean.FALSE.equals(isflag)) {
				EmployeeMailErrorRecords errorRecords = new EmployeeMailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setOfficalMailId(record.getOfficalMailId().concat("*"));
				mailErrorList.add(errorRecords);
				continue;
			}

			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()), companyId);
			if (!emp.isPresent()) {
				EmployeeMailErrorRecords errorRecords = new EmployeeMailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeId(record.getEmployeeId().concat("*"));
				mailErrorList.add(errorRecords);
				continue;
			}
			Long count = employeeRepo.getEmployeeOfficalEmail(record.getOfficalMailId());
			if (count != 0L) {
				EmployeeMailErrorRecords errorRecords = new EmployeeMailErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setOfficalMailId(record.getOfficalMailId().concat("*"));
				mailErrorList.add(errorRecords);
				continue;
			}
			if ((record.getOfficalMailId() != null) || (record.getEmployeeId() != null)) {
				Optional<Employee> employeeObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeId()),
						companyId);
				if (employeeObj.isPresent()) {
					Employee employee = employeeObj.get();
					employee.setOfficalMail(record.getOfficalMailId());
					employeesList.add(employee);
				}
				logger.info("valid Data adding to the list");

			}
		}

		List<Employee> sucsessList = employeeRepo.saveAll(employeesList);
		List<EmployeeMailErrorRecords> failureList = mailerrorRepo.saveAll(mailErrorList);
		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, sucsessList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("Sucess count:{} and failure count:{}", sucsessList.size(), failureList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @return save employee OfficeUseData in data base
	 */

	public List<Map<String, Integer>> readEmployeeOfficeUseDataFromExecl(MultipartFile file, String companyId) {
		Workbook wb = getWorkBook(file);
		Sheet sheet = wb.getSheetAt(0);
		List<Employee> employeeslist = new ArrayList<>();
		List<BankDetails> bankDetailsList = new ArrayList<>();
		List<BankDetailsErrorRecords> initialRecords = new ArrayList<>();
		List<BankDetailsErrorRecords> bankDetailsErrorList = new ArrayList<>();
		Iterator<Row> rows = sheet.iterator();
		rows.next();
		while (rows.hasNext()) {
			Row row = rows.next();
			BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
			if (row.getCell(0) != null) {
				String empId = null;
				if (row.getCell(0).getCellType() == CellType.NUMERIC) {
					empId = NumberToTextConverter.toText(row.getCell(0).getNumericCellValue());
				} else if (row.getCell(0).getCellType() == CellType.STRING) {
					empId = row.getCell(0).getStringCellValue();
				}
				errorRecords.setEmployeeID(empId);
			}
			if (row.getCell(1) != null) {
				errorRecords.setAccountHolderName(row.getCell(1).getStringCellValue());
			}
			if (row.getCell(2) != null /* && row.getCell(2).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(2).getCellType() == CellType.NUMERIC) {
					errorRecords.setAccountNo(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
				} else if (row.getCell(2).getCellType() == CellType.STRING) {
					errorRecords.setAccountNo(row.getCell(2).getStringCellValue());
				}
//				errorRecords.setAccountNo(NumberToTextConverter.toText(row.getCell(2).getNumericCellValue()));
			}

			if (row.getCell(3) != null) {
				errorRecords.setBankName(row.getCell(3).getStringCellValue());
			}
			if (row.getCell(4) != null) {
				errorRecords.setIfscCode(row.getCell(4).getStringCellValue());
			}
			if (row.getCell(5) != null) {
				errorRecords.setBranchName(row.getCell(5).getStringCellValue());
			}

			if (row.getCell(6) != null /* && row.getCell(6).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(6).getCellType() == CellType.NUMERIC) {
					errorRecords.setCtc(NumberToTextConverter.toText(row.getCell(6).getNumericCellValue()));
				} else if (row.getCell(6).getCellType() == CellType.STRING) {
					errorRecords.setCtc(row.getCell(6).getStringCellValue());
				}
//				errorRecords.setCtc(NumberToTextConverter.toText(row.getCell(6).getNumericCellValue()));
			}

			if (row.getCell(7) != null/* && row.getCell(7).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(7).getCellType() == CellType.NUMERIC) {
					errorRecords.setUanNumber(NumberToTextConverter.toText(row.getCell(7).getNumericCellValue()));
				} else if (row.getCell(7).getCellType() == CellType.STRING) {
					errorRecords.setUanNumber(row.getCell(7).getStringCellValue());
				}
//				errorRecords.setUanNumber(NumberToTextConverter.toText(row.getCell(7).getNumericCellValue()));
			}
			if (row.getCell(8) != null/* && row.getCell(8).getCellType() == CellType.STRING */) {
				if (row.getCell(36).getCellType() == CellType.NUMERIC) {
					errorRecords.setPfNumber(NumberToTextConverter.toText(row.getCell(36).getNumericCellValue()));
				} else if (row.getCell(36).getCellType() == CellType.STRING) {
					errorRecords.setPfNumber(row.getCell(36).getStringCellValue());
				}
				errorRecords.setPfNumber(row.getCell(8).getStringCellValue());
			}

			if (row.getCell(9) != null/* && row.getCell(9).getCellType() == CellType.NUMERIC */) {
				if (row.getCell(9).getCellType() == CellType.NUMERIC) {
					errorRecords.setEsicNumber(NumberToTextConverter.toText(row.getCell(9).getNumericCellValue()));
				} else if (row.getCell(9).getCellType() == CellType.STRING) {
					errorRecords.setEsicNumber(row.getCell(9).getStringCellValue());
				}
//				errorRecords.setEsicNumber(NumberToTextConverter.toText(row.getCell(9).getNumericCellValue()));
			}
			initialRecords.add(errorRecords);
			logger.info("read Employee Office Use Data From Execl is Ending" + " ::");
		}
		for (BankDetailsErrorRecords record : initialRecords) {

			if (record.getAccountHolderName() == null || record.getAccountNo() == null || record.getBankName() == null
					|| record.getIfscCode() == null || record.getBranchName() == null || record.getCtc() == null
					|| record.getUanNumber() == null || record.getPfNumber() == null
					|| record.getEsicNumber() == null) {

				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				bankDetailsErrorList.add(errorRecords);
				continue;
			}

			if (record.getEmployeeID().trim().equals("0") || record.getEsicNumber().trim().equals("0")
					|| record.getAccountNo().trim().equals("0") || record.getUanNumber().trim().equals("0")) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				bankDetailsErrorList.add(errorRecords);
				continue;
			}

			if (record.getAccountNo() == null) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				bankDetailsErrorList.add(errorRecords);
				continue;
			}

			boolean isflag9 = validate.validateNumber(record.getPfNumber());
			if (Boolean.FALSE.equals(isflag9)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPfNumber(record.getPfNumber().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}

			boolean isflag = validate.validateName(record.getAccountHolderName());
			if (Boolean.FALSE.equals(isflag)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setAccountHolderName(record.getAccountHolderName().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag1 = validate.validateNumber(record.getAccountNo());
			if (Boolean.FALSE.equals(isflag1)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setAccountNo(record.getAccountNo().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag2 = validate.validateName(record.getBankName());
			if (Boolean.FALSE.equals(isflag2)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setBankName(record.getBankName().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag3 = validate.validateMixedWords(record.getIfscCode());
			if (Boolean.FALSE.equals(isflag3)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setIfscCode(record.getIfscCode().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag4 = validate.validateName(record.getBranchName());
			if (Boolean.FALSE.equals(isflag4)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setBranchName(record.getBranchName().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag5 = validate.validateNumber(String.valueOf(record.getCtc()));
			if (Boolean.FALSE.equals(isflag5)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setCtc(record.getCtc().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag6 = validate.validateNumber(String.valueOf(record.getUanNumber()));
			if (Boolean.FALSE.equals(isflag6)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setUanNumber(record.getUanNumber().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag7 = validate.pfNumber(record.getPfNumber());
			if (Boolean.FALSE.equals(isflag7)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setPfNumber(record.getPfNumber().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			boolean isflag8 = validate.validateNumber(String.valueOf(record.getEsicNumber()));
			if (Boolean.FALSE.equals(isflag8)) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEsicNumber(record.getEsicNumber().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			if (Boolean.FALSE.equals(isflag) || Boolean.FALSE.equals(isflag1) || Boolean.FALSE.equals(isflag2)
					|| Boolean.FALSE.equals(isflag3) || Boolean.FALSE.equals(isflag4) || Boolean.FALSE.equals(isflag5)
					|| Boolean.FALSE.equals(isflag6) || Boolean.FALSE.equals(isflag7)
					|| Boolean.FALSE.equals(isflag8)) {

				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				bankDetailsErrorList.add(errorRecords);
				continue;
			}
			Optional<Employee> emp = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeID()), companyId);
			if (!emp.isPresent()) {
				BankDetailsErrorRecords errorRecords = new BankDetailsErrorRecords();
				BeanUtils.copyProperties(record, errorRecords);
				errorRecords.setEmployeeID(record.getEmployeeID().concat("*"));
				bankDetailsErrorList.add(errorRecords);
				continue;
			}

			if ((record.getEmployeeID() != null) || (record.getAccountHolderName() != null)
					|| (record.getAccountNo() != null) || (record.getBankName() != null)
					|| (record.getIfscCode() != null) || (record.getBranchName() != null)
					|| (record.getCtc() != null)) {
				BankDetails bank = new BankDetails();
				Optional<Employee> empObj = employeeRepo.findByIdByCompany(Long.parseLong(record.getEmployeeID()),
						companyId);
				BankDetails bankdetail = bankRepo.findByEmployee(Long.parseLong(record.getEmployeeID()));

				if (!Objects.isNull(bankdetail)) {
					if (bankdetail.getEmployee().getId().equals(Long.parseLong(record.getEmployeeID()))
							&& empObj.isPresent()) {
						Employee employeenew = empObj.get();
						bankdetail.setEmployee(employeenew);
						bankdetail.setAccountHolderName(record.getAccountHolderName());
						bankdetail.setAccountNo(record.getAccountNo());
						bankdetail.setBankName(record.getBankName());
						bankdetail.setIfscCode(record.getIfscCode());
						bankdetail.setBranchName(record.getBranchName());
						bankdetail.setUanNumber(record.getUanNumber());
						bankdetail.setPfNumber(record.getPfNumber());
						bankdetail.setEsicNumber(record.getEsicNumber());
						bankDetailsList.add(bankdetail);
					}
				} else {
					bank.setEmployee(emp.get());
					bank.setAccountHolderName(record.getAccountHolderName());
					bank.setAccountNo(record.getAccountNo());
					bank.setBankName(record.getBankName());
					bank.setIfscCode(record.getIfscCode());
					bank.setBranchName(record.getBranchName());
					bank.setUanNumber(record.getUanNumber());
					bank.setPfNumber(record.getPfNumber());
					bank.setEsicNumber(record.getEsicNumber());
					bankDetailsList.add(bank);
				}

				Optional<Employee> employeeObj = employeeRepo.findById(Long.parseLong(record.getEmployeeID()));
				if (employeeObj.isPresent()) {
					Employee employee = employeeObj.get();
					employee.setCtc(Double.parseDouble(record.getCtc()));
					employeeslist.add(employee);

				}

				logger.info("valid data add to the list ::");
			}
		}
		List<BankDetails> successList = bankRepo.saveAll(bankDetailsList);
		List<BankDetailsErrorRecords> failureList = bankErrorRepo.saveAll(bankDetailsErrorList);
		employeeRepo.saveAll(employeeslist);

		List<Map<String, Integer>> resultList = new ArrayList<>();
		Map<String, Integer> successMap = new HashedMap<>();
		successMap.put(Constants.SUCCESS, successList.size());
		Map<String, Integer> failureMap = new HashedMap<>();
		failureMap.put(Constants.FAILURE, failureList.size());
		resultList.add(0, successMap);
		resultList.add(1, failureMap);
		logger.info("Sucess count:{}  and failure count:{}", successList.size(), resultList.size());
		return resultList;
	}

	/**
	 * 
	 * @param file
	 * @return check file extension
	 */
	public Workbook getWorkBook(MultipartFile file) {
		Workbook wb = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		try {
			if (extension.equalsIgnoreCase(Constants.XLSX)) {
				wb = new XSSFWorkbook(file.getInputStream());
			} else if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
				wb = new HSSFWorkbook(file.getInputStream());
			}
		} catch (Exception e) {
			logger.info("Error in finding the workbook");
		}
		return wb;
	}

}
