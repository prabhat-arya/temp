package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.ICsvBeanWriter;

import com.hrms.admin.dto.BankDTO;
import com.hrms.admin.dto.EmployeeBranchDTO;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeProfileDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmployeeRolesDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.FileNamesListDTO;
import com.hrms.admin.dto.ManagerDTO;
import com.hrms.admin.dto.OfficeUseOnlyDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.Employee;

public interface EmployeeService {

	// deactivate and approval
	public List<EntityDTO> updateEmployeeByStatus(Long id, String status);

	//public List<Employee> appliedList();

	public List<EmployeeDTO> getEmployeeById(Long id);

	public List<EntityDTO> approveById(Long id);

	public List<EntityDTO> updateEmployeeProject(EmployeeDTO model, Long id);

	public List<EntityDTO> deleteEmployeeFile(Long id, Long fileId);

	public List<EntityDTO> addResourceToEmployee(EmployeeDTO model, Long id);

	public Map<String, Object> getAllEmployeePage(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,Long employmentTypeId,String companyId);

	public List<EntityDTO> updateEmployeePolicies(EmployeeDTO model, Long id);

	public List<EmployeeBranchDTO> getEmployeeByBranchId(Long branchId,String comapnyId);

	public List<EmployeeInfoDTO> listOfEmployee(String compnayId);

	public List<EntityDTO> softDeleteEmployee(Long id);

	public List<EntityDTO> saveEmployeeInfo(EmployeeInfoDTO employee);

	public List<EntityDTO> updateEmplyeeInfo(Long id, EmployeeInfoDTO employeedto);

	public List<EntityDTO> updateEmployeeFiles(Long id, MultipartFile[] files, MultipartFile image,List<FileNamesListDTO> fileNameList) throws Exception;

	public boolean validate(EmployeeInfoDTO model, boolean isSave);

	public Long getAllEmpCountBasedOnBranch(Long branchId,String comapnyId);

	public List<EntityDTO> updateEmplyeeOfficeUseDetails(Long id, OfficeUseOnlyDTO model);

	public EmployeeProfileDTO getEmployeeProfileDetails(Long id);

	public List<EntityDTO> updateEmployeeProfileDetails(Long id, EmployeeProfileDTO dto);

	public List<Map<String, Integer>> saveEmpDatafromUploadedfile(MultipartFile file);

	public List<Map<String, Integer>> saveEmpProfessionalDetailsDatafromUploadedfile(MultipartFile file, String companyId);

	public List<Map<String, Integer>> saveEmpOfficeUseDataDatafromUploadedfile(MultipartFile file,String companyId)
			throws IllegalAccessException;

	public Map<String, Object> getAllEmployeeBankDetailsPage(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public List<Map<String, Integer>> saveEmpMailIdsfromUploadedfile(MultipartFile file, String companyId) throws IllegalAccessException;

	public List<EmployeeProjectsDTO> getEmployeeProjects(Long id);

	public ICsvBeanWriter createEmployeeDataCSVFIle(HttpServletResponse response,String companyId);

	public List<ManagerDTO> getManagers(Long deptId, Long designationId,String companyId);

	//public List<EmployeeOrgDTO> getManagerSubordinate(Long id);

	public List<EmployeeRolesDTO> getAllRoles(String companyId);

	public List<String> getAllUsers(String companyId);

	public List<BankDTO> getBankDeatils(Long empId);

	public List<Map<String, Integer>> saveEmpEducationalDetailsfromUploadedfile(MultipartFile file, String companyId);

	public List<Map<String, Integer>> saveEmpEmergencyContactDetailsfromUploadedfile(MultipartFile file, String companyId);
	
	public Long validateEmployeeEmail(String email);

	public Long validateEmployeeContact(String contact);

	public Long validateEmployeeUserNmae(String userName);

	public Long validateEmployeeOfficalEmail(String email);

//	public List<EntityDTO> updateAllEmpStatusToApprove(String companyId);

//	public void approveThroughMail();
	
	public List<Map<String, Integer>> saveAllEmpDatafromUploadedfile(MultipartFile file);
//	public boolean validateacadimicYear(EmployeeInfoDTO model);

	public List<ResourceItemsDTO> getEmployeAssets(Long data);

	public List<EntityDTO> updateAllEmpStatusToApproveWithEmpIds(List<Employee> empIds);

	public List<Map<String, Integer>> saveEmpPersonalDetailsfromUploadedfile(MultipartFile file,
			String companyId);
}
