package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.hrms.admin.dto.EmployeeExitMgmtDTO;
import com.hrms.admin.dto.EmployeeExitMgmtShowDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.QuestionsDTO;
import com.hrms.admin.dto.ResignationDTO;
import com.hrms.admin.entity.Resignation;

public interface EmployeeExitService {

	public List<EntityDTO> saveAndUpdateEmployeeExit(EmployeeExitMgmtDTO model);

	public EmployeeExitMgmtShowDTO findExitFormByEmployeeId(Long employeeId, String companyId);

	public List<EmployeeExitMgmtDTO> getAllEmpExitDetails(String companyId);

	public List<EntityDTO> deleteEmployeeExitRecordByExitId(Long employeeExitId);

	public Map<String, Object> getAllEmpExitDetails(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId);

	public List<EntityDTO> saveSubjectiveAndObjectiveQuestion(QuestionsDTO model, String companyId);

	public Long validateQuestionPostCall(String question, String companyId);

	public Long validateQuestionPutCall(String question, String companyId, Long qId);
	

	public QuestionsDTO getAllExitRecordQuestions(String companyId);

	public List<EntityDTO> saveEmployeeResignation(@Valid ResignationDTO model);

	public ResignationDTO findResignedEmpByEmployee(Long employeeId);
	
	public Map<String, Object> getAllEmpResignationDetails(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String companyId, Long managerId);

	public List<EntityDTO> updateEmployeeResignation(@Valid ResignationDTO model);
	
	public String getResignationStatus(Long data);

	public List<EntityDTO> revokeEmployeeResignation(@Valid ResignationDTO model);

	public Resignation getResignationSubmitted(Long empId);

	void exitStatusTrue();

	public List<EntityDTO> updateResigAfterRevokeApply(@Valid ResignationDTO model);

}
