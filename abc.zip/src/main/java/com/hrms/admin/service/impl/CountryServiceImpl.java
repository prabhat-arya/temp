package com.hrms.admin.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.entity.Country;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService {

	@Autowired
	private CountryRepository countryRepository;

	@Override
	public List<Country> findAll() {
		return countryRepository.findAll();
	}

	@Override
	public Country findCountry(Long id) {
		Country country = null;
		Optional<Country> findByCountryId = countryRepository.findById(id);
		if (findByCountryId.isPresent()) {
			country = findByCountryId.get();
		}
		return country;
	}

	public List<Country> readCountriesDataFromJson() {
		List<Country> list=new ArrayList<>();
		final String fileName = "Images/countryList.json";
		ClassLoader classLoader = getClass().getClassLoader();
		try (InputStream is = classLoader.getResourceAsStream(fileName)) {
			ObjectMapper mapper = new ObjectMapper();
			 list = Arrays.asList(mapper.readValue(is, Country[].class));
			if (list != null && list.isEmpty()) {
				return list;
			}
		} catch (Exception e) {
			throw new com.hrms.admin.exceptions.FileNotFoundException("Country List not found");
		}
		return list;
	}
}