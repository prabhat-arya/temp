package com.hrms.admin.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.CompanyDTO;
import com.hrms.admin.dto.CompanyRegisterDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Company;

public interface CompanyService {

	public List<CompanyDTO> save(CompanyDTO model);

	public CompanyDTO getById(String id);

//	public boolean deleteCompany(String id);

	public List<EntityDTO> updateCompany(CompanyDTO model);

	public Map<String, Object> getAllCompany(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,

			String orderBy, String isActive,String companyId);

	public List<CompanyDTO> AllCompany(String companyId);

	public List<EntityDTO> softDeleteCompany(Long id);

	// for validation
	public boolean validate(CompanyDTO model, boolean isSave);

	public List<EntityDTO> updateCompanyByStatus(Long id, String status);

	public Company findByCompanyName(String companyName);


	public List<EntityDTO> saveCompanyImage(MultipartFile file, String id) throws IOException;

	public List<EntityDTO> multipleCompanyDelete(List<Long> ids);

	public Map<String, String> companyRegister(CompanyRegisterDTO model);

	public boolean validateCompanyRegister(CompanyRegisterDTO model, boolean isSave);

	public boolean validateCompanyEmail(CompanyRegisterDTO model, boolean isSave);

	public boolean validateCompanyUserName(CompanyRegisterDTO model, boolean isSave);

	public boolean validateCompanyContactNo(CompanyRegisterDTO model, boolean isSave);

	public boolean validateCompanyName(CompanyRegisterDTO model, boolean isSave);
}
