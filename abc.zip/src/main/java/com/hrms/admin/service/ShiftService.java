package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ShiftDTO;

public interface ShiftService {
public List<EntityDTO> save(ShiftDTO model) throws Exception;
	
	public ShiftDTO getById(Long id,String companyId) throws Exception;

	public List<EntityDTO> updateShift(ShiftDTO model, Long id) throws Exception;
	
	//public List<ShiftDTO> getByBranchId(Long id);
	
	public List<ShiftDTO> findAll(String companyId);
	
	public List<EntityDTO> softDeleteShift(Long id);
	
	//for validation
	public boolean validate(ShiftDTO model, boolean isSave);
	
	public List<EntityDTO> updateShiftByStatus(Long id , String status);
	
	public Map<String, Object> getAllShift(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId);
}

