package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PolicyDTO;

public interface PolicyService {

	public List<EntityDTO> save(PolicyDTO model, MultipartFile file) throws Exception;

//	public List<EntityDTO> update(Long id, PolicyDTO policydto, MultipartFile file) throws Exception;

	public List<PolicyDTO> getAllPolicy(String companyId);

	public PolicyDTO getPolicyById(Long id, String companyId);

	//public boolean deletePolicy(Long id);
	
	public Map<String, Object> getAllPolicy(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy,String isActive, String companyId);
	
	public List<EntityDTO> softDeletePolicy(Long id);
	
	public boolean validate(PolicyDTO model, boolean isSave);
	
	public List<EntityDTO> updatePolicyByStatus(Long id , String status);

	// public boolean deletePolicy(Long id);

//	public DocumentDetails getDocument(String id) throws IllegalStateException, IOException;

	public PolicyDTO getPolicyByName(String name,String companyId);
}
