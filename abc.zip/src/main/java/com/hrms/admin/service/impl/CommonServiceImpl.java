package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.CertificateTypeDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmploymentTypeDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ProjectEmployeeListDTO;
import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.entity.BankDetailsErrorRecords;
import com.hrms.admin.entity.CertificateType;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;
import com.hrms.admin.entity.Project;
import com.hrms.admin.repository.AcadmicDetailsErrorRecordsRepository;
import com.hrms.admin.repository.BankDetailsErrorRecordsRepository;
import com.hrms.admin.repository.CertificateTypeRepository;
import com.hrms.admin.repository.EmergencyContactDetailErrorRecordsRepository;
import com.hrms.admin.repository.EmployeeErrorRecordsRepository;
import com.hrms.admin.repository.EmployeeMailErrorRecordsRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.EmploymentTypeRepository;
import com.hrms.admin.repository.PersonalDetailsErrorRecordsRepository;
import com.hrms.admin.repository.PersonalDetailsRepository;
import com.hrms.admin.repository.ProfessionalDetailsErrorRecordsRepository;
import com.hrms.admin.repository.ProfessionalDetailsRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.service.CommonService;

@Service
public class CommonServiceImpl implements CommonService {

	private static final Logger logger = LoggerFactory.getLogger(CommonServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private ProjectRepository proRepo;

//	@Autowired
//	private ProjectService projectService;

	@Autowired
	private BankDetailsErrorRecordsRepository repo;

	@Autowired
	private ProfessionalDetailsErrorRecordsRepository pRepo;

	@Autowired
	private EmployeeErrorRecordsRepository empRepo;

	@Autowired
	private EmployeeMailErrorRecordsRepository mailIdErrorRepo;

	@Autowired
	private AcadmicDetailsErrorRecordsRepository acdeRepo;

	@Autowired
	private EmergencyContactDetailErrorRecordsRepository ecdeRepo;

	@Autowired
	private CertificateTypeRepository certificateRepo;

	@Autowired
	private EmploymentTypeRepository employmentTypeRepo;

	@Autowired
	private PersonalDetailsErrorRecordsRepository pdeRepo;

	/**
	 * Returns all managerHierarchey based on manager id
	 *
	 * @param id-managerId
	 * @return - AttendanceInfo
	 */
	@Override
	public List<ProjectDTO> managerHierarchy(Long id) {
		List<ProjectDTO> list = new ArrayList<>();
		Optional<Employee> optionalEntity = employeeRepo.findById(id);
		if (!optionalEntity.isPresent()) {
			return list;
		}
		Employee employee = optionalEntity.get();
		for (Project project : employee.getProjects()) {
			ProjectDTO projectdto = new ProjectDTO();
			projectdto.setName(project.getName());
			projectdto.setId(project.getId());
			List<ProjectEmployeeListDTO> empprolist = new ArrayList<>();
			for (Employee employee1 : project.getEmployee()) {
				ProjectEmployeeListDTO dto = new ProjectEmployeeListDTO();
				dto.setId(employee1.getId());
				dto.setFirstName(employee1.getFirstName());
				dto.setLastName(employee1.getLastName());
				dto.setEmail(employee1.getEmail());
				dto.setContactNo(employee1.getContactNo());
				dto.setDepartmentId(employee1.getDepartment().getId());
				dto.setDepartmentName(employee1.getDepartment().getName());
				dto.setDesignationId(employee1.getDesignation().getId());
				dto.setDesignationName(employee1.getDesignation().getDesignation());
				empprolist.add(dto);
			}
			projectdto.setEmployeeDtoList(empprolist);
			list.add(projectdto);
		}
		logger.info("All Projects based on Manager Id:{}", id);
		return list;
	}

	/**
	 * Returns all bank error records from BankError Records on current date
	 *
	 * @return - ErrorRecords
	 */
	@Override
	public List<BankDetailsErrorRecords> excelReportAllErrorBankDetails() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<BankDetailsErrorRecords> allErrorDetails = repo.getTodayaddedEmployeeBankErrorRecords(username);
		logger.info("All Error Employee Bank Details List on current date");
		return allErrorDetails;
	}

	/**
	 * Returns all professional error records from ProfessionalDetails Records on
	 * current date
	 *
	 * @return - ErrorRecords
	 */
	@Override
	public List<ProfessionalDetailsErrorRecords> excelReportAllErrorProfessionalDetailsError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<ProfessionalDetailsErrorRecords> allErrorDetails = pRepo.getTodayaddedEmployeepdErrorRecords(username);
		logger.info("All Error Employee Professional Details List on current date:{}", allErrorDetails);
		return allErrorDetails;
	}

	/**
	 * Returns all employee basic info error records from employeeError Records on
	 * current date
	 *
	 * @return - ErrorRecords
	 */
	@Override
	public List<EmployeeErrorRecords> excelReportAllErrorEmployeeDetailsError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<EmployeeErrorRecords> allErrorDetails = empRepo.getTodayaddedEmployeeErrorRecords(username);
		logger.info("All Error Employee Details List on current date:{}", allErrorDetails);
		return allErrorDetails;
	}

	/**
	 * Returns all employee success records from ProfessionalDetails Records on
	 * current date
	 *
	 * @return - successRecord
	 */
	@Override
	public List<Employee> excelReportAllSuccessEmployeeDetails(String companyId) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<Employee> allsuccessDetails = employeeRepo.getTodayaddedEmployess(username, companyId);
		logger.info("Success Employee Details List on current date:{}", allsuccessDetails);
		return allsuccessDetails;
	}

	/**
	 * Returns all employee error mailId records from employeeError Records on
	 * current date
	 *
	 * @return - errorRecords
	 */
	@Override
	public List<EmployeeMailErrorRecords> excelReportAllErrorEmployeeMailIdError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<EmployeeMailErrorRecords> allErrorDetails = mailIdErrorRepo
				.getTodayaddedEmployeemailErrorRecords(username);
		logger.info("Error Employee MailId List on current date:{}", allErrorDetails);
		return allErrorDetails;
	}

	/**
	 * this method is used for reusable methods for some api's(reusable method for
	 * getter and setter fields)
	 *
	 * @return - AttendanceInfo
	 */
	public AttendanceInfoDTO copyPropertites(AttendanceInfo info) {
		AttendanceInfoDTO dto = new AttendanceInfoDTO();
		dto.setEmpId(info.getEmployee().getId());
		dto.setEmployee(info.getEmployee().getFirstName() + " " + info.getEmployee().getLastName());
		dto.setShiftId(info.getShift().getId());
		dto.setShift(info.getShift().getShiftName());
		dto.setDate(info.getDate());
		dto.setInTime(info.getInTime());
		dto.setOutTime(info.getOutTime());
		dto.setNoOfHrs(info.getNoOfHrs());
		dto.setAttndsPercentage(info.getAttndsPercentage());
		dto.setReason(info.getReason());
		return dto;
	}

	/**
	 * Returns all projects based on companyId
	 * 
	 * @author {RAMESH RENDLA}
	 * @param id-companyId
	 * @return - Project
	 */
	@Override
	public List<EmployeeProjectsDTO> projectsBasedOnCompany(String companyId) {
		List<EmployeeProjectsDTO> list = new ArrayList<>();
		List<Project> projctLists = proRepo.findByCompany(companyId);
		if (projctLists.isEmpty()) {
			return list;
		}
		List<EmployeeProjectsDTO> models = new ArrayList<>();
		for (Project project : projctLists) {
			EmployeeProjectsDTO model = new EmployeeProjectsDTO();
			model.setProjectId(project.getId());
			model.setProjectName(project.getName());
			model.setProjectDescription(project.getDescription());
			models.add(model);
		}
		return models;
	}

	/**
	 * Returns all projects based on managerId
	 * 
	 * @author {RAMESH RENDLA}
	 * @param id-managerId
	 * @return - Project
	 */
	@Override
	public List<EmployeeProjectsDTO> projectsListBasedOnManger(Long managerId, String companyId) {
		List<EmployeeProjectsDTO> list = new ArrayList<>();
		List<Project> optionalEntity = proRepo.getProjectListByEmpId(managerId, companyId);
		if (optionalEntity.isEmpty()) {
			return list;
		}
		List<EmployeeProjectsDTO> models = new ArrayList<>();
		for (Project project : optionalEntity) {
			EmployeeProjectsDTO model = new EmployeeProjectsDTO();
			model.setProjectId(project.getId());
			model.setProjectName(project.getName());
			model.setProjectDescription(project.getDescription());
			models.add(model);
		}
		return models;
	}

	/**
	 * Returns all professional error records from ProfessionalDetails Records on
	 * current date
	 *
	 * @return - ErrorRecords
	 */
	@Override
	public List<AcadmicDetailsErrorRecords> excelReportAllErrorEducationalDetailsError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<AcadmicDetailsErrorRecords> allErrorDetails = acdeRepo.getTodayaddedEmployeeadErrorRecords(username);
		logger.info("All Error Employee Professional Details List on current date:{}", allErrorDetails);
		return allErrorDetails;
	}

	@Override
	public List<EmergencyContactDetailErrorRecords> excelReportAllErrorEmergencyContactDetailsError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<EmergencyContactDetailErrorRecords> allErrorDetails = ecdeRepo
				.getTodayaddedEmployeeecdErrorRecords(username);
		logger.info("All Error Employee Professional Details List on current date:{}", allErrorDetails);
		return allErrorDetails;

	}

	@Override
	public List<CertificateTypeDTO> getCertificateTypeList() {
		return certificateRepo.getAllCertificateTypeList();

	}

	@Override
	public CertificateType saveCertificateType(CertificateTypeDTO model) {
		CertificateType entity = new CertificateType();
		entity.setCertificateName(model.getCertificateName());
		return certificateRepo.save(entity);
	}

	@Override
	public List<EmploymentTypeDTO> getEmploymentTypeList() {
		return employmentTypeRepo.getAllEmploymentTypeList();
	}
	
	@Override
	public boolean validateCertificateType(CertificateTypeDTO model) {
		Long count = certificateRepo.getCertificateName(model.getCertificateName());
		logger.info("Check Duplicate CertificateTyp Records" + " : ", count);
		return count > 0;
	}

	@Override
	public List<PersonalDetailsErrorRecords> excelReportAllErrorPersonalContactDetailsError() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<PersonalDetailsErrorRecords> allErrorDetails = pdeRepo.getTodayaddedEmployeeecdErrorRecords(username);
		logger.info("All Error Employee personal Details List on current date:{}", allErrorDetails);
		return allErrorDetails;
	}
}