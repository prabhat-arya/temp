package com.hrms.admin.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.HolidayDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Holiday;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.HolidayRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.service.HolidayService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.ImageUtils;
import com.hrms.admin.util.S3ServiceUtil;

@Service
public class HolidayServiceImpl implements HolidayService {

	private static Logger logger = LoggerFactory.getLogger(HolidayServiceImpl.class);

	@Autowired
	private HolidayRepository repo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private BranchRepository branchRepo;

	/*
	 * @Autowired private SequenceGeneratorUtil seqGeneratorService;
	 * 
	 * @Autowired private CompanyProfileImageRepository companyProfileImageRepo;
	 */
	@Autowired
	private ImageUtils imageUtils;

	@Value("${file.s3UploadImg}")
	private String folderpath;

	@Autowired
	private S3ServiceUtil s3ServiceUtil;

	@Value("${aws.bucket.imagefolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@Autowired
	private ProfileImageRepository profileRepo;

	/**
	 * Returns true when new holiday is store in database
	 * 
	 * @param model - new holiday data
	 * @return - boolean
	 * @throws IOException
	 */
	@Override
	public List<EntityDTO> save(HolidayDTO model, MultipartFile file) throws IOException {
		Holiday entity = new Holiday();
		List<EntityDTO> list = new ArrayList<>();

		entity.setName(model.getName());
		entity.setDate(model.getDate());
		Company company;
		Optional<Company> companyId = companyRepo.findById(model.getCompanyId());
		if (companyId.isPresent()) {
			company = companyId.get();
			entity.setCompany(company);
		}

		Branch branch;
		Optional<Branch> branchId = branchRepo.findById(model.getBranchId());
		if (branchId.isPresent()) {
			branch = branchId.get();
			entity.setBranch(branch);
		}
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		boolean flag = Boolean.FALSE;
		if (!Objects.isNull(file)) {
			Path path = Paths.get(folderpath + Constants.SUFFIX + file.getOriginalFilename());
			byte[] bytes = file.getBytes();
			Files.write(path, bytes);
			String uri = path.toString();
			imageUtils.resize(uri, 100, 100, FilenameUtils.getExtension(file.getOriginalFilename()),
					file.getOriginalFilename());
			MultipartFile file1 = imageUtils.file(file.getOriginalFilename(), file.getContentType());
			String filename = file.getOriginalFilename();
			flag = s3ServiceUtil.uploadFileInFolder(file1, foldername, filename);
			if (flag == true) {
				ProfileImage image = new ProfileImage();
				image.setImageName(filename);
				image.setImageurl(s3ServiceUtil.generateFileUrl(filename, foldername));
				image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
				ProfileImage holidayImage = profileRepo.save(image);
				entity.setAttechementId(holidayImage.getId());
			}
			/*
			 * CompanyProfileImage companyImage1 = new CompanyProfileImage();
			 * companyImage1.setId(seqGeneratorService.generateSequence(CompanyProfileImage.
			 * SEQUENCE_NAME)); companyImage1.setImage(file1.getBytes());
			 * companyImage1.setContantType(file1.getContentType());
			 * companyImage1.setFileName(file1.getOriginalFilename()); CompanyProfileImage
			 * image = companyProfileImageRepo.insert(companyImage1); if
			 * (!Objects.isNull(image)) { entity.setAttechementId(image.getId()); }
			 */
		}
		Holiday h = repo.save(entity);
		logger.info("Holiday is added in to database");
		EntityDTO dto = new EntityDTO();
		dto.setId(h.getId());
		dto.setName(h.getName());
		list.add(dto);
		return list;

	}

	/**
	 * Returns true when existing holiday data is store in database
	 * 
	 * @param model - new holiday data
	 * @param id    - holiday Id
	 * @return - boolean
	 * @throws IOException
	 */
	@Override
	public List<EntityDTO> updateHoliday(HolidayDTO model, MultipartFile file) throws IOException {
		Optional<Holiday> findById = repo.findById(model.getId());
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Holiday oldHoliday = findById.get();
			oldHoliday.setId(model.getId());
			oldHoliday.setName(model.getName());
			oldHoliday.setDate(model.getDate());

			Company company;
			Optional<Company> companyId = companyRepo.findById(model.getCompanyId());
			if (companyId.isPresent()) {
				company = companyId.get();
				oldHoliday.setCompany(company);
			}
			Branch branch;
			Optional<Branch> branchId = branchRepo.findById(model.getBranchId());
			if (branchId.isPresent()) {
				branch = branchId.get();
				oldHoliday.setBranch(branch);
			}
			boolean flag = Boolean.FALSE;
			if (!Objects.isNull(file)) {
				Path path = Paths.get(folderpath + Constants.SUFFIX + file.getOriginalFilename());
				byte[] bytes = file.getBytes();
				Files.write(path, bytes);
				String uri = path.toString();
				imageUtils.resize(uri, 100, 100, FilenameUtils.getExtension(file.getOriginalFilename()),
						file.getOriginalFilename());
				MultipartFile file1 = imageUtils.file(file.getOriginalFilename(), file.getContentType());
				String filename = file.getOriginalFilename();
				if (oldHoliday.getAttechementId() != null) {
					Optional<ProfileImage> profile = profileRepo.findById(oldHoliday.getAttechementId());
					if (profile.isPresent()) {
						s3ServiceUtil.deleteFileFromFolder(profile.get().getImageName(), foldername);
						profileRepo.deleteById(profile.get().getId());
					}
				}
				flag = s3ServiceUtil.uploadFileInFolder(file1, foldername, filename);
				if (flag == true) {
					ProfileImage image = new ProfileImage();
					image.setImageName(filename);
					image.setImageurl(s3ServiceUtil.generateFileUrl(filename, foldername));
					image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
					ProfileImage holidayImage = profileRepo.save(image);
					oldHoliday.setAttechementId(holidayImage.getId());
				}
				/*
				 * CompanyProfileImage companyImage1 = new CompanyProfileImage();
				 * companyImage1.setId(seqGeneratorService.generateSequence(CompanyProfileImage.
				 * SEQUENCE_NAME)); companyImage1.setImage(file1.getBytes());
				 * companyImage1.setContantType(file1.getContentType());
				 * companyImage1.setFileName(file1.getOriginalFilename()); CompanyProfileImage
				 * image = companyProfileImageRepo.insert(companyImage1); if
				 * (!Objects.isNull(image)) { oldHoliday.setAttechementId(image.getId()); }
				 */
			}
			Holiday h = repo.save(oldHoliday);
			logger.info("Holiday record is updated in database with id:{}", model.getId());
			EntityDTO dto = new EntityDTO();
			dto.setId(h.getId());
			dto.setName(h.getName());
			list.add(dto);
			return list;
		}
		return list;
	}

	/**
	 * Returns Holiday data when Holiday data is available in database by id
	 * 
	 * @param id - Holiday Id
	 * @return - HolidayModel
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public HolidayDTO getById(Long id, String companyId) {

		Optional<Holiday> optionalEntity = repo.findHolidaysByCompanyId(id, companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Holiday entity = optionalEntity.get();
		HolidayDTO model = new HolidayDTO();
		model.setId(entity.getId());
		model.setBranchId(entity.getBranch().getId());
		model.setCompanyId(entity.getCompany().getId());
		model.setName(entity.getName());
		model.setDate(entity.getDate());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		model.setIsActive(entity.getIsActive());
		model.setIsDelete(entity.getIsDelete());
		if (entity.getAttechementId() != null) {
			Optional<ProfileImage> findById = profileRepo.findById(entity.getAttechementId());
			if (findById.isPresent()) {
				ProfileImage cimage = findById.get();
				ProfileImageDTO imageDto = new ProfileImageDTO();
				imageDto.setFileType(cimage.getFileType());
				imageDto.setId(cimage.getId());
				imageDto.setImageName(cimage.getImageName());
				imageDto.setImageurl(cimage.getImageurl());
				model.setImage(imageDto);
			}
			/*
			 * Optional<CompanyProfileImage> image =
			 * companyProfileImageRepo.findById(entity.getAttechementId()); if
			 * (image.isPresent()) { CompanyProfileImage companyProfileImage = image.get();
			 * 
			 * CompanyProfileImageDTO compProfileDto = new CompanyProfileImageDTO();
			 * compProfileDto.setContantType(companyProfileImage.getContantType());
			 * compProfileDto.setImagedata(companyProfileImage.getImage());
			 * compProfileDto.setImageName(companyProfileImage.getFileName()); String
			 * fileTypeName = companyProfileImage.getContantType(); String[] parts =
			 * fileTypeName.split("(?=/)"); String part = parts[1]; String fileType =
			 * part.replace('/', '.'); compProfileDto.setFileType(fileType.toUpperCase());
			 * model.setImage(compProfileDto); }
			 */ }
		logger.info("Holiday found with Id:{}", id);
		return model;
	}

	/**
	 * Returns true when Holiday data is deleted from database by id
	 * 
	 * @param id - Holiday id
	 * @return - boolean
	 */
	@Override
	public boolean deleteHoliday(Long id) {
		repo.deleteById(id);
		logger.info("Holiday record is deleted from database ");
		return true;
	}

	/**
	 * @param Holiday Entity
	 * @return - page size
	 */
	public Map<String, Object> mapData(Page<Holiday> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<HolidayDTO> holidayModels = pagedResult.stream().map(entity -> {
			HolidayDTO model = new HolidayDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDate(entity.getDate());
			Company cmp = new Company();
			model.setCompanyId(cmp.getId());
			Branch branch = new Branch();
			model.setBranchId(branch.getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchName(entity.getBranch().getName());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			if (entity.getAttechementId() != null) {
				Optional<ProfileImage> findById = profileRepo.findById(entity.getAttechementId());
				if (findById.isPresent()) {
					ProfileImage cimage = findById.get();
					ProfileImageDTO imageDto = new ProfileImageDTO();
					imageDto.setFileType(cimage.getFileType());
					imageDto.setId(cimage.getId());
					imageDto.setImageName(cimage.getImageName());
					imageDto.setImageurl(cimage.getImageurl());
					model.setImage(imageDto);
				}
				/*
				 * Optional<CompanyProfileImage> image =
				 * companyProfileImageRepo.findById(entity.getAttechementId()); if
				 * (image.isPresent()) { CompanyProfileImage companyProfileImage = image.get();
				 * 
				 * CompanyProfileImageDTO compProfileDto = new CompanyProfileImageDTO();
				 * compProfileDto.setContantType(companyProfileImage.getContantType());
				 * compProfileDto.setImagedata(companyProfileImage.getImage());
				 * compProfileDto.setImageName(companyProfileImage.getFileName()); String
				 * fileTypeName = companyProfileImage.getContantType(); String[] parts =
				 * fileTypeName.split("(?=/)"); String part = parts[1]; String fileType =
				 * part.replace('/', '.'); compProfileDto.setFileType(fileType.toUpperCase());
				 * model.setImage(compProfileDto); }
				 */
			}
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, holidayModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("Holiday map object is created for Paging");
		return response;
	}

	/**
	 * @param pageIndex,
	 * @param pageSize,sortBy,
	 * @param searchKey,
	 * @param orderBy,
	 * @param status
	 * @return - page size
	 */
	@Override
	public Map<String, Object> getAllHoliday(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Holiday> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = repo.allHolidayPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = repo.holidayPage(searchKey, companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * @param Holidays id,
	 * @param String,
	 * @return - if record is updateHolidayByStatus based on Holiday id
	 */

	@Override
	public List<EntityDTO> updateHolidayByStatus(Long id, String status) {
		Optional<Holiday> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Holiday holiday = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			holiday.setIsActive(Boolean.TRUE);
			Holiday e = repo.save(holiday);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getName());
			list.add(dto);
			logger.info("Holiday is Activated in to database with Id:{}", id);
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			holiday.setIsActive(Boolean.FALSE);
			Holiday e = repo.save(holiday);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getName());
			list.add(dto);
			logger.info("Holiday is Deactivated in to database with Id:{}", id);
			return list;
		}
		logger.info("Holiday is  failed to Activat or Deactivate in database with Id:{}", id);
		return list;
	}

	/**
	 * @param id -HolidayId,
	 * @return - change value from database isDisable is true
	 */

	@Override
	public List<EntityDTO> softDeleteHoliday(Long id) {
		Optional<Holiday> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Holiday holiday = findById.get();
		holiday.setIsActive(Boolean.FALSE);
		holiday.setIsDelete(Boolean.TRUE);
		Holiday h = repo.save(holiday);
		logger.info("Holiday is SoftDeleted in to database Id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(h.getId());
		dto.setName(h.getName());
		list.add(dto);
		return list;
	}

	/**
	 * @param HolidayDTO,
	 * @param boolean     value,
	 * @return - if record exit return true or if record not exit return false
	 */

	@Override
	public boolean validate(HolidayDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getHolidayCountSave(model.getBranchId(), model.getName(), model.getCompanyId());
		else
			count = repo.getHolidayCountUpdate(model.getCompanyId(), model.getBranchId(), model.getName(),
					model.getId());
		return count > 0;
	}

	/**
	 * @param branchId,
	 * @return - return List of Holidays based on Branch
	 */

	@Override
	@Cacheable(value = "getAllHolidayListBasedOnBranch", unless = "#result == null", key = "#branchId")
	public List<HolidayDTO> getAllHolidayListBasedOnBranch(Long branchId, String companyId) {
		List<Holiday> a = repo.getAllHolidayListByBranch(branchId, companyId);
		List<HolidayDTO> models = a.stream().map(entity -> {
			HolidayDTO model = new HolidayDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDate(entity.getDate());
			Calendar c = Calendar.getInstance();
			c.setTime(entity.getDate());
			String dayWeekText = new SimpleDateFormat("EEEE").format(entity.getDate());
			model.setDay(dayWeekText);
			if (entity.getAttechementId() != null) {
				Optional<ProfileImage> findById = profileRepo.findById(entity.getAttechementId());
				if (findById.isPresent()) {
					ProfileImage cimage = findById.get();
					ProfileImageDTO imageDto = new ProfileImageDTO();
					imageDto.setFileType(cimage.getFileType());
					imageDto.setId(cimage.getId());
					imageDto.setImageName(cimage.getImageName());
					imageDto.setImageurl(cimage.getImageurl());
					model.setImage(imageDto);
				}
				/*
				 * Optional<CompanyProfileImage> image =
				 * companyProfileImageRepo.findById(entity.getAttechementId()); if
				 * (image.isPresent()) { CompanyProfileImage companyProfileImage = image.get();
				 * 
				 * CompanyProfileImageDTO compProfileDto = new CompanyProfileImageDTO();
				 * compProfileDto.setContantType(companyProfileImage.getContantType());
				 * compProfileDto.setImagedata(companyProfileImage.getImage());
				 * compProfileDto.setImageName(companyProfileImage.getFileName()); String
				 * fileTypeName = companyProfileImage.getContantType(); String[] parts =
				 * fileTypeName.split("(?=/)"); String part = parts[1]; String fileType =
				 * part.replace('/', '.'); compProfileDto.setFileType(fileType.toUpperCase());
				 * model.setImage(compProfileDto); }
				 */
			} else {
				new ProfileImageDTO();
			}
			/*
			 * model.setCompanyId(entity.getCompany().getId());
			 * model.setCompanyName(entity.getCompany().getName());
			 * model.setBranchId(entity.getBranch().getId());
			 * model.setBranchName(entity.getBranch().getName());
			 * model.setIsActive(entity.getIsActive());
			 * model.setIsDelete(entity.getIsDelete());
			 */
			return model;
		}).collect(Collectors.toList());
		return models;

	}

}
