package com.hrms.admin.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ExitFeedbackDTO;
import com.hrms.admin.dto.FeedBackFromFileDetailsDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeExitMgmt;
import com.hrms.admin.entity.ExitFeedback;
import com.hrms.admin.entity.FeedBackFromFileDetails;
import com.hrms.admin.entity.Resignation;
import com.hrms.admin.repository.EmployeeExitMgmtRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ExitFeedbackRepository;
import com.hrms.admin.repository.FeedBackFromFileDetailsRepository;
import com.hrms.admin.repository.ResignationRepository;
import com.hrms.admin.service.ExitFeedbackService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.ConversionUtils;
import com.hrms.admin.util.S3ServiceUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExitFeedbackImpl implements ExitFeedbackService {

	@Autowired
	private ExitFeedbackRepository exitFeedbackRepository;

	@Autowired
	private FeedBackFromFileDetailsRepository feedBackFromFileDetailsRepo;

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired 
	private ResignationRepository resignationRepo;

	@Autowired
	private ConversionUtils conversionUtils;
	/*
	 * @Autowired private GridFsTemplate gridFsTemplate;
	 * 
	 * @Autowired private GridFsOperations operations;
	 */

	@Autowired
	private S3ServiceUtil s3ServiceUtil;

	@Value("${aws.bucket.feedbackfilesfolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@PostConstruct
	public void init() {
		String name = s3ServiceUtil.createFolder(foldername);
		log.info("folder created in s3 bucket foldername ::{}", name);
	}

	@Autowired
	private EmployeeExitMgmtRepository employeeExitMgmtRepository;
	ObjectMapper mapper = new ObjectMapper();
//	private static final log log = logFactory.getlog(ExitFeedbackImpl.class);

	@Override
	public List<EntityDTO> saveExitFeedback(MultipartFile[] files, String data) {
		List<EntityDTO> list = new ArrayList<>();
		ExitFeedbackDTO model = new ExitFeedbackDTO();
		try {
			model = mapper.readValue(data, ExitFeedbackDTO.class);
			ExitFeedback exitFeedback = new ExitFeedback();
			ExitFeedback exitFeedbackbyId = exitFeedbackRepository.findByFeedbackId(model.getFeedbackId());
			if (!Objects.isNull(exitFeedbackbyId)) {
				exitFeedbackbyId.setEmployeeExitMgmtId(model.getEmployeeExitMgmtId());
				exitFeedbackbyId.setFeedback(model.getFeedback());
				exitFeedbackbyId.setSignature(model.getSignature());
				if (!model.getSubmission().equals("[]")) {
					exitFeedbackbyId.setSubmission(model.getSubmission().toString());
				}
				exitFeedbackbyId.setSubmitDate(model.getSubmitDate());
				exitFeedbackbyId.setDepartment(model.getDepartment());
				exitFeedbackbyId.setDesignation(model.getDesignation());
				if (model.getIsSubmit().equals("1")) {
					exitFeedbackbyId.setStatus(Constants.COMPLETED);
					exitFeedbackbyId.setIsSubmit(Boolean.TRUE);
				} else {
					exitFeedbackbyId.setStatus(Constants.IN_PROGRASS);
					exitFeedbackbyId.setIsSubmit(Boolean.FALSE);
					Optional<EmployeeExitMgmt> employeeExitMgmt = employeeExitMgmtRepository
							.findById(model.getEmployeeExitMgmtId());
					EmployeeExitMgmt empexit;
					if (employeeExitMgmt.isPresent()) {
						empexit = employeeExitMgmt.get();
						empexit.setStatus(Constants.IN_PROGRASS);
						employeeExitMgmtRepository.save(empexit);
					}
				}

				if (!Objects.isNull(files)) {
					uploadFeedBackFiles(files, exitFeedbackbyId);
				}
				ExitFeedback exitSave = exitFeedbackRepository.save(exitFeedbackbyId);
				List<ExitFeedback> findByEmployeeExitMgmtId = exitFeedbackRepository
						.findByEmployeeExitMgmtId(exitSave.getEmployeeExitMgmtId());
				int size = findByEmployeeExitMgmtId.size();
				int count = 0;
				for (ExitFeedback feedback : findByEmployeeExitMgmtId) {
					if (feedback.getStatus().equals(Constants.COMPLETED)) {
						count++;
					}
				}
				if (size == count) {
					Optional<EmployeeExitMgmt> employeeExitMgmt = employeeExitMgmtRepository
							.findById(model.getEmployeeExitMgmtId());
					EmployeeExitMgmt empexit;
					if (employeeExitMgmt.isPresent()) {
						empexit = employeeExitMgmt.get();
						empexit.setStatus(Constants.APPROVED);
						employeeExitMgmtRepository.save(empexit);
//						Employee emp = employeeRepository.getOne(empexit.getEmployeeId());
//						emp.setIsExit(Boolean.TRUE);
//						employeeRepository.save(emp);
						Resignation resignation = resignationRepo.getByEmployee(empexit.getEmployeeId());
						resignation.setStatus(Constants.COMPLETED);
						resignationRepo.save(resignation);
					}
				}
				EntityDTO dto = new EntityDTO();
				dto.setId(exitSave.getFeedbackId());
				list.add(dto);
				log.info("Feedback is Saved in DB");
				return list;

			} else {
				exitFeedback.setEmployeeExitMgmtId(model.getEmployeeExitMgmtId());
				exitFeedback.setFeedback(model.getFeedback());
				exitFeedback.setSignature(model.getSignature());
				if (!model.getSubmission().equals("[]")) {
					exitFeedback.setSubmission(model.getSubmission().toString());
				}
				exitFeedback.setSubmitDate(model.getSubmitDate());
				exitFeedback.setDepartment(model.getDepartment());
				exitFeedback.setDesignation(model.getDesignation());
				if (model.getIsSubmit().equals("1")) {
					exitFeedback.setStatus(Constants.COMPLETED);
					exitFeedback.setIsSubmit(Boolean.TRUE);
				} else {
					exitFeedback.setStatus(Constants.IN_PROGRASS);
					exitFeedback.setIsSubmit(Boolean.FALSE);
					Optional<EmployeeExitMgmt> employeeExitMgmt = employeeExitMgmtRepository
							.findById(model.getEmployeeExitMgmtId());
					EmployeeExitMgmt empexit;
					if (employeeExitMgmt.isPresent()) {
						empexit = employeeExitMgmt.get();
						empexit.setStatus(Constants.IN_PROGRASS);
						employeeExitMgmtRepository.save(empexit);
					}
				}

				ExitFeedback exitSave = exitFeedbackRepository.save(exitFeedback);
				if (!Objects.isNull(files)) {
					uploadFeedBackFiles(files, exitSave);
				}
				List<ExitFeedback> findByEmployeeExitMgmtId = exitFeedbackRepository
						.findByEmployeeExitMgmtId(exitSave.getEmployeeExitMgmtId());
				int size = findByEmployeeExitMgmtId.size();
				int count = 0;
				for (ExitFeedback feedback : findByEmployeeExitMgmtId) {
					if (feedback.getStatus().equals(Constants.COMPLETED)) {
						count++;
					}
				}
				if (size == count) {
					Optional<EmployeeExitMgmt> employeeExitMgmt = employeeExitMgmtRepository
							.findById(model.getEmployeeExitMgmtId());
					EmployeeExitMgmt empexit;
					if (employeeExitMgmt.isPresent()) {
						empexit = employeeExitMgmt.get();
						empexit.setStatus(Constants.APPROVED);
						employeeExitMgmtRepository.save(empexit);
//						Employee emp = employeeRepository.getOne(empexit.getEmployeeId());
//						emp.setIsExit(Boolean.TRUE);
//						employeeRepository.save(emp);
						Resignation resignation = resignationRepo.getByEmployee(empexit.getEmployeeId());
						resignation.setStatus(Constants.COMPLETED);
						resignationRepo.save(resignation);
					}
				}
				EntityDTO dto = new EntityDTO();
				dto.setId(exitSave.getFeedbackId());
				list.add(dto);
				log.info("Feedback is Saved in DB");
				return list;
			}
		} catch (Exception e) {
			return list;
		}

	}

	@Override
	@Cacheable(value = "getExitFeedbackBasedOnExitIdCache", unless = "#result.size() == 0", key = "#exitId")
	public List<ExitFeedbackDTO> getExitFeedbackBasedOnExitId(Long exitId) {
		EmployeeExitMgmt employeeExitMgmt = new EmployeeExitMgmt();
		List<ExitFeedbackDTO> exitFeedbackDTOList = new ArrayList<>();
		employeeExitMgmt.setEmployeeExitId(exitId);
		List<ExitFeedback> exitFeedbackList = exitFeedbackRepository.findByEmployeeExitMgmtId(exitId);

		for (ExitFeedback exitFeedback : exitFeedbackList) {

			ExitFeedbackDTO exitFeedbackDTO = new ExitFeedbackDTO();
			exitFeedbackDTO.setFeedback(exitFeedback.getFeedback());
			exitFeedbackDTO.setExitId(exitId);
			exitFeedbackDTO.setFeedbackId(exitFeedback.getFeedbackId());
			exitFeedbackDTO.setSignature(exitFeedback.getSignature());
			exitFeedbackDTO.setSubmission(conversionUtils.ListConversion(exitFeedback.getSubmission()));
			exitFeedbackDTO.setSubmitDate(exitFeedback.getSubmitDate());
			exitFeedbackDTO.setDepartment(exitFeedback.getDepartment());
			exitFeedbackDTO.setDesignation(exitFeedback.getDesignation());
			if (exitFeedback.getIsSubmit().equals(Boolean.TRUE)) {
				exitFeedbackDTO.setIsSubmit("1");
			} else {
				exitFeedbackDTO.setIsSubmit("0");
			}
			exitFeedbackDTO.setStatus(exitFeedback.getStatus());
			List<FeedBackFromFileDetailsDTO> list = findByExitFeedBackRef(exitFeedback);

			exitFeedbackDTO.setFeedBackFromFileDetails(list);
			exitFeedbackDTOList.add(exitFeedbackDTO);
		}
		log.info("ExitFeedback found Based On ExitId");
		return exitFeedbackDTOList;
	}

	// refactor method of above method
	private List<FeedBackFromFileDetailsDTO> findByExitFeedBackRef(ExitFeedback exitFeedback) {
		List<FeedBackFromFileDetails> findByExitFeedback = feedBackFromFileDetailsRepo
				.findByExitFeedback(exitFeedback.getFeedbackId());

		List<FeedBackFromFileDetailsDTO> list = new ArrayList<>();
		for (FeedBackFromFileDetails feedBackFromFileDetails : findByExitFeedback) {
			FeedBackFromFileDetailsDTO dto = new FeedBackFromFileDetailsDTO();
			dto.setId(feedBackFromFileDetails.getId());
			dto.setName(feedBackFromFileDetails.getName());
			dto.setFilePath(feedBackFromFileDetails.getFilePath());
			dto.setFileType(feedBackFromFileDetails.getFileType());
			list.add(dto);
		}
		return list;
	}

	@Override
	@Cacheable(value = "getExitFeedbackBasedOnFeedbackIdCache", unless = "#result == null", key = "#feedBackId")
	public ExitFeedbackDTO getExitFeedbackBasedOnFeedbackId(Long feedBackId) {

		ExitFeedback exitFeedback = exitFeedbackRepository.findByFeedbackId(feedBackId);
		if (Objects.isNull(exitFeedback)) {
			log.info("feedbackId is not present");
			return null;
		}
		ExitFeedbackDTO exitFeedbackDTO = new ExitFeedbackDTO();
		exitFeedbackDTO.setFeedback(exitFeedback.getFeedback());
		exitFeedbackDTO.setExitId(exitFeedback.getEmployeeExitMgmtId());
		exitFeedbackDTO.setFeedbackId(exitFeedback.getFeedbackId());
		exitFeedbackDTO.setSignature(exitFeedback.getSignature());
		exitFeedbackDTO.setSubmission(conversionUtils.ListConversion(exitFeedback.getSubmission()));
		exitFeedbackDTO.setSubmitDate(exitFeedback.getSubmitDate());
		exitFeedbackDTO.setDepartment(exitFeedback.getDepartment());
		exitFeedbackDTO.setDesignation(exitFeedback.getDesignation());
		exitFeedbackDTO.setStatus(exitFeedback.getStatus());
		if (exitFeedback.getIsSubmit().equals(Boolean.TRUE)) {
			exitFeedbackDTO.setIsSubmit("1");
		} else {
			exitFeedbackDTO.setIsSubmit("0");
		}

		List<FeedBackFromFileDetails> findByExitFeedback = feedBackFromFileDetailsRepo
				.findByExitFeedback(exitFeedback.getFeedbackId());

		List<FeedBackFromFileDetailsDTO> list = new ArrayList<>();
		for (FeedBackFromFileDetails feedBackFromFileDetails : findByExitFeedback) {
			FeedBackFromFileDetailsDTO dto = new FeedBackFromFileDetailsDTO();
			dto.setId(feedBackFromFileDetails.getId());
			dto.setName(feedBackFromFileDetails.getName());
			dto.setFilePath(feedBackFromFileDetails.getFilePath());
			dto.setFileType(feedBackFromFileDetails.getFileType());
			list.add(dto);
		}

		exitFeedbackDTO.setFeedBackFromFileDetails(list);
		log.info("feedbackId is found");
		return exitFeedbackDTO;
	}

	@Override
	@Cacheable(value = "getExitFeedbackBasedOnEmployeeIdCache", unless = "#result.size() == 0", key = "#employeeId")
	public List<ExitFeedbackDTO> getExitFeedbackBasedOnEmployeeId(Long employeeId) {
		EmployeeExitMgmt employeeExitForm = employeeExitMgmtRepository.findByEmployeeId(employeeId);
		List<ExitFeedbackDTO> list = new ArrayList<>();
		if (employeeExitForm == null) {
			log.info("ExitFeedback is not present bases on Id:{}", employeeId);
			return list;
		}
		Long exitId = employeeExitForm.getEmployeeExitId();
		List<ExitFeedbackDTO> exitFeedbackBasedOnExitId = getExitFeedbackBasedOnExitId(exitId);
		log.info("ExitFeedback is  present bases on Id:{}", employeeId);
		return exitFeedbackBasedOnExitId;
	}

	@Override
	public Boolean uploadFeedBackFiles(MultipartFile[] files, ExitFeedback exitFeedback) throws IOException {
		Boolean isflag = false;
		Boolean isflag1 = true;
		Boolean flag = false;
		List<FeedBackFromFileDetails> filesList = new ArrayList<>();
		String folderName = foldername + Constants.SUFFIX + exitFeedback.getFeedbackId();
		s3ServiceUtil.createFolder(folderName);
		// storing files details in database
		for (MultipartFile file : files) {
			flag = s3ServiceUtil.uploadFileInFolder(file, folderName, file.getOriginalFilename());
			if (flag.equals(Boolean.TRUE)) {
				FeedBackFromFileDetails document = new FeedBackFromFileDetails();
				document.setName(file.getOriginalFilename());
				document.setExitFeedback(exitFeedback);
				document.setFilePath(s3ServiceUtil.generateFileUrl(file.getOriginalFilename(), folderName));
				document.setContantType(file.getContentType());
				document.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
				filesList.add(document);
			}
		}

		/*
		 * DBObject metaData = new BasicDBObject(); metaData.put(Constants.TYPE,
		 * Constants.FILE); metaData.put(Constants.TITLE, file.getOriginalFilename());
		 * ObjectId fileId = gridFsTemplate.store(file.getInputStream(),
		 * file.getOriginalFilename(), file.getContentType(), metaData); if (fileId !=
		 * null) { FeedBackFromFileDetails document = new FeedBackFromFileDetails();
		 * document.setName(file.getOriginalFilename());
		 * document.setExitFeedback(exitFeedback);
		 * document.setFilePath(fileId.toString());
		 * document.setContantType(file.getContentType()); document.setFileType("." +
		 * FilenameUtils.getExtension(file.getOriginalFilename()));
		 * filesList.add(document); }
		 */
//		}
		List<FeedBackFromFileDetails> saveAll = feedBackFromFileDetailsRepo.saveAll(filesList);
		if (!saveAll.isEmpty()) {
			return isflag1;
		} else {
			return isflag;
		}

	}

	@Override
	public List<EntityDTO> deleteFeedBackFile(Long fileId) {
		List<EntityDTO> list = new ArrayList<>();
		boolean flag = Boolean.FALSE;
		Optional<FeedBackFromFileDetails> findById = feedBackFromFileDetailsRepo.findById(fileId);
		if (!findById.isPresent()) {
			return list;
		}
		FeedBackFromFileDetails file = findById.get();
		String folderName = foldername + Constants.SUFFIX + file.getExitFeedback().getFeedbackId();
		if (!Objects.isNull(file)) {
			flag = s3ServiceUtil.deleteFileFromFolder(file.getName(), folderName);
			if (flag == true) {
				feedBackFromFileDetailsRepo.deleteById(fileId);
			}
			/*
			 * gridFsTemplate.delete(new
			 * Query(Criteria.where("_id").is(file.getFilePath())));
			 * feedBackFromFileDetailsRepo.deleteById(fileId);
			 */
		}
		EntityDTO dto = new EntityDTO();
		dto.setId(fileId);
		list.add(dto);
		return list;
	}

	@Override
	public ExitFeedbackDTO deleteExitFeedbackBasedOnFeedbackId(Long feedBackId) {

		ExitFeedback exitFeedback = exitFeedbackRepository.findByFeedbackId(feedBackId);
		if (Objects.isNull(exitFeedback)) {
			log.info("feedbackId not found with the id: {}", feedBackId);
			return null;
		}
		boolean flag = Boolean.FALSE;
		List<FeedBackFromFileDetails> findByExitFeedback = feedBackFromFileDetailsRepo.findByExitFeedback(feedBackId);
		if (!findByExitFeedback.isEmpty()) {
			for (FeedBackFromFileDetails entity : findByExitFeedback) {
				String folderName = foldername + Constants.SUFFIX + entity.getExitFeedback().getFeedbackId();
				flag = s3ServiceUtil.deleteFileFromFolder(entity.getName(), folderName);
				if (flag == true) {
					feedBackFromFileDetailsRepo.deleteById(entity.getId());
				}
				/*
				 * gridFsTemplate.delete(new
				 * Query(Criteria.where("_id").is(entity.getFilePath())));
				 * feedBackFromFileDetailsRepo.deleteById(entity.getId());
				 */ }
		}
		exitFeedbackRepository.deleteById(feedBackId);
		log.info("Feedback is deleted based on Id: {}", feedBackId);
		return new ExitFeedbackDTO();
	}

	/*
	 * @Override public DocumentDetails previewFeedBackDocument(String fileId) {
	 * GridFSFile file = gridFsTemplate.findOne(new
	 * Query(Criteria.where("_id").is(fileId))); DocumentDetails document = new
	 * DocumentDetails();
	 * document.setTitle(file.getMetadata().get("title").toString()); try {
	 * document.setStream(operations.getResource(file).getInputStream());
	 * FeedBackFromFileDetails findByFilePath =
	 * feedBackFromFileDetailsRepo.findByFilePath(fileId);
	 * document.setContantType(findByFilePath.getContantType()); return document; }
	 * catch (Exception e) { return null; } }
	 */

	@Override
	@Cacheable(value = "findAllExitFeedBacksCache", unless = "#result.size() == 0")
	public List<ExitFeedback> findAllExitFeedBacks(String companyId) {
		List<ExitFeedback> list = new ArrayList<>();
		List<ExitFeedback> exitFeedBacks = exitFeedbackRepository.findAllExitFeedBack(companyId);
		if (exitFeedBacks.isEmpty()) {
			log.info("ExitfeedBack is not found");
			return list;
		}
		for (ExitFeedback exitFeedback : exitFeedBacks) {
			list.add(exitFeedback);
		}

		log.info("All Exit FeedBack is found");
		return list;
	}
}
