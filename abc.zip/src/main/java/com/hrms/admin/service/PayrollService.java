package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PayrollCaluclateDTO;
import com.hrms.admin.payroll.dto.DeductionsDTO;
import com.hrms.admin.payroll.dto.EarningsDTO;
import com.hrms.admin.payroll.dto.PayCalculateViewDTO;
import com.hrms.admin.payroll.dto.PayScheduleDTO;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;
import com.hrms.admin.payroll.dto.PayrollRequestDTO;
import com.hrms.admin.payroll.dto.PayslipGenerationDTO;
import com.hrms.admin.payroll.dto.PayslipGenerationDTO1;
import com.hrms.admin.role.dto.EmployeeIdsDTO;

public interface PayrollService {

	// public PayrollGenerateDTO payrollDeduction(PayrollGenerateDTO payrollDto);

	public PayslipGenerationDTO payrollGeneration(PayrollRequestDTO payrollDto, Long branchId,String companyId) throws Exception;

	public List<PayrollEmpListDTO> getEmployeeIds(String companyId);

	public PayCalculateViewDTO payRollCalculation(PayrollCaluclateDTO payCalculateViewDTO, Long branchId,
			String companyId);

	public boolean validate(EarningsDTO model, boolean isSave, String companyId);

	public List<EntityDTO> save(EarningsDTO model, Long id, String companyId) throws Exception;

	public List<EarningsDTO> allEarnings(String compnayId);

	public boolean validate(DeductionsDTO model, boolean isSave, String companyId);

	public List<EntityDTO> save(DeductionsDTO model, Long id, String companyId);

	public List<DeductionsDTO> allDeductions(String companyId);

	public List<EmployeeDTO> generatePayslipOnEveryMonth();
	
	public Map<Long, String> generatePayslipByCompany(String companyId);

	public List<EntityDTO> updateEarning(@Valid EarningsDTO model, Long id);

	public List<EntityDTO> updateDeduction(@Valid DeductionsDTO model, Long id);

	public List<EntityDTO> softDeleteEarnings(Long id);

	public List<EntityDTO> softDeleteDeduction(Long id);

	public Map<String, Object> getAllEarningsByPage(int pageIndex, int pageSize, String sortBy, String searchKey,
			String orderBy, String status, String companyId);

	public Map<String, Object> getAllDeductionsByPage(int pageIndex, int pageSize, String sortBy, String searchKey,
			String orderBy, String status, String comapnyId);

	public void employeePayslip(EmployeeIdsDTO employeeIdsDTO);

	public boolean validate(PayScheduleDTO payScheduleDTO, boolean isSave, String companyId);

	public List<EntityDTO> createPaySchedule(PayScheduleDTO payScheduleDTO, String companyId);

	public PayScheduleDTO getPayScheduleByBranchId(Long branchId);

	public List<EntityDTO> payScheduleUpdate(@Valid PayScheduleDTO model, Long id);

	public void downloadPdf(Long empId, String date);

	public EarningsDTO getById(Long id);

	public DeductionsDTO getDeductionsById(Long id);

	public List<EntityDTO> deductionStatusUpdate(Long id);

	public List<EntityDTO> earningsStatusUpdate(Long id);

	public PayslipGenerationDTO1 payrollGeneration1(PayrollRequestDTO payrollDto, Long branchId) throws Exception;

	public void downloadPaySlip(Long salaryComponentId);

}
