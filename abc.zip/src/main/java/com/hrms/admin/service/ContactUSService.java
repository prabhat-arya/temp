package com.hrms.admin.service;

import com.hrms.admin.dto.ContactUSDTO;
import com.hrms.admin.dto.EntityDTO;

public interface ContactUSService {
	
	public EntityDTO save(ContactUSDTO model);

}
