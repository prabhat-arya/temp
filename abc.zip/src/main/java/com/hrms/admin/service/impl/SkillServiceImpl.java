package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.SkillDTO;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Skill;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.SkillRepository;
import com.hrms.admin.service.SkillService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to perform DB operation on Skills Record
 * 
 * @author {Prabhat}
 *
 */
@Service
public class SkillServiceImpl implements SkillService {

	private static final Logger logger = LoggerFactory.getLogger(SkillServiceImpl.class);

	@Autowired
	private SkillRepository skillRepo;

	@Autowired
	private CompanyRepository companyRepo;
	/**
	 * Returns true when new skill is store in database
	 * 
	 * @param model - new skill data
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> save(SkillDTO model) {
		Skill entity = new Skill();
		entity.setSkillSet(model.getSkillSet());
		entity.setDescription(model.getDescription());
		Company company;
		Optional<Company> companyId = companyRepo.findById(model.getCompanyId());
		if (companyId.isPresent()) {
			company=companyId.get();
			entity.setCompany(company);		
		}
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		Skill savedSkill = skillRepo.save(entity);
		logger.info("Skill Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(savedSkill.getId());
		dto.setName(savedSkill.getSkillSet());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	/**
	 * Returns true when existing skill data is store in database
	 * 
	 * @param model - new skill data
	 * @param id    - skill Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateSkill(SkillDTO model, Long id) {

		Optional<Skill> findById = skillRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Skill oldSkill = findById.get();
			logger.info("Skill record is found from database with id:{}",id);
			oldSkill.setId(id);
			oldSkill.setSkillSet(model.getSkillSet());
			oldSkill.setDescription(model.getDescription());
			Company company;
			Optional<Company> companyId = companyRepo.findById(model.getCompanyId());
			if (companyId.isPresent()) {
				company=companyId.get();
				oldSkill.setCompany(company);
			}
			Skill updated = skillRepo.save(oldSkill);
			logger.info("Skill record is updated in to database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(updated.getId());
			dto.setName(updated.getSkillSet());
			list.add(dto);
			return list;
		} else {
			return list;
		}
	}

	/**
	 * Returns Skill data when Skill data is available in database by id
	 * 
	 * @param id - skill Id
	 * @return - SkillResponse
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public SkillDTO getSkillByCompanyId(Long id,String companyId) {
		Optional<Skill> optionalEntity = skillRepo.findSkillByCompanyId(id,companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Skill skillEntity = optionalEntity.get();
		SkillDTO model = new SkillDTO();
		model.setId(skillEntity.getId());
		model.setSkillSet(skillEntity.getSkillSet());
		model.setDescription(skillEntity.getDescription());		
		model.setCompanyId(skillEntity.getCompany().getId());
		model.setCompanyName(skillEntity.getCompany().getName());
		model.setIsActive(skillEntity.getIsActive());
		model.setIsDelete(skillEntity.getIsDelete());
		BeanUtils.copyProperties(skillEntity, model);
		logger.info("Skill found in DB with Id:{}",id);
		return model;
	}

	/**
	 * Returns All Skills data when skill data is available in database
	 * 
	 * @param id
	 * 
	 * @return - List of Skill
	 */
	@Override
	@Cacheable(value = "getAllSkill", unless = "#result == null", key = "#id")
	public List<SkillDTO> getAllSkill(String id) {

		List<Skill> skillEntity = skillRepo.findByCompany(id);
		logger.info(" Skill Records are found from Database:{}",skillEntity.size());
		List<SkillDTO> models = skillEntity.stream().map(entity -> {
			SkillDTO model = new SkillDTO();
			model.setId(entity.getId());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setSkillSet(entity.getSkillSet());
			model.setDescription(entity.getDescription());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * Returns true when skill data is deleted from database by id
	 * 
	 * @param id - skill id
	 * @return - boolean
	 */

	public static Map<String, Object> mapData(Page<SkillDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<SkillDTO> skillModels = pagedResult.stream().map(skillEntity -> {
			SkillDTO model = new SkillDTO();
			model.setId(skillEntity.getId());
			model.setSkillSet(skillEntity.getSkillSet());
			model.setDescription(skillEntity.getDescription());
			Company company = new Company();
			model.setCompanyId(company.getId());
			model.setCompanyName(skillEntity.getCompanyName());
			model.setIsActive(skillEntity.getIsActive());
			model.setIsDelete(skillEntity.getIsDelete());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, skillModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	@Override
	public Map<String, Object> getAllSkill(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId) {
	
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<SkillDTO> pagedResult = null;
		Boolean status = true;
		
		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = skillRepo.allSkillPage(searchKey, companyId,paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = skillRepo.skillPage(searchKey,companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Skill Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
		
	}

	@Override
	public List<EntityDTO> updateSkillByStatus(Long id, String status) {
		Optional<Skill> findById = skillRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		} else {
			Skill a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Skill e = skillRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getSkillSet());
				list.add(dto);
				logger.info("Skill is activated in to database with Id:{}", id);
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Skill e = skillRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getSkillSet());
				list.add(dto);
				logger.info("Skill is deactivated in to database with Id:{}", id);
			}
		}
		return list;
	}

	@Override
	public boolean validate(SkillDTO leaveType, boolean isSave) {
		Long count;
		if (isSave)
			count = skillRepo.getSkillCountSave(leaveType.getSkillSet(), leaveType.getCompanyId());
		else
			count = skillRepo.getSkillCountUpdate(leaveType.getCompanyId(), leaveType.getSkillSet(), leaveType.getId());
		return count > 0;
	}

	public List<EntityDTO> softDeleteSkill(Long id) {
		Optional<Skill> findById = skillRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if(!findById.isPresent()) {
			return list;
		}
		Skill skill = findById.get();
		skill.setIsActive(Boolean.FALSE);
		skill.setIsDelete(Boolean.TRUE);
		Skill p = skillRepo.save(skill);
		logger.info("Skill is SoftDeleted in to database with Id:{}",id);
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getSkillSet());
		list.add(dto);
		return list;
	}

	@Override
	public Skill findByName(String skillName, String companyId) {
		return skillRepo.findBySkillSet(skillName, companyId);
	}

}