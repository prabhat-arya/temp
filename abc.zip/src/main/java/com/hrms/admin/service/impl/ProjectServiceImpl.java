package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ProjectEmployeeListDTO;
import com.hrms.admin.dto.ProjectPieChartDTO;
import com.hrms.admin.dto.ProjectReleaseDTO;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Project;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.service.ProjectService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;

/**
 * Contains method to perform DB operation on Project Record
 * 
 * @author {MD Atif}
 *
 */

@Service
public class ProjectServiceImpl implements ProjectService {

	private static Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

	@Autowired
	private ProjectRepository projectrepo;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private CompanyRepository companyRepo;
//	@Autowired
//	private DepartmentRepository deptRepo;

	/**
	 * Returns true when new Project is store in database
	 * 
	 * @param model - new project data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(ProjectDTO model) {
		Project entity = new Project();
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		Optional<Company> optional = companyRepo.findById(model.getCompanyId());
		if (!optional.isPresent()) {
			return null;
		}
		Company company = optional.get();
		entity.setCompany(company);
		entity.setStatus(model.getStatus());
		entity.setClientName(model.getClientName());
		entity.setRemarks(model.getRemarks());
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		entity.setStartDate(model.getStartDate());
		entity.setEndDate(model.getEndDate());
		entity.setEstimatedHours(model.getEstimatedHours());
		Project p = projectrepo.save(entity);
		logger.info("Project Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;

	}

	/**
	 * Returns All Project data when project data is available in database
	 * 
	 * @return - List of Project
	 */
	@Override
	@Cacheable(value = "getAllProject", unless = "#result == null", key = "#id")
	public List<ProjectDTO> getAllProject(String id) {
		List<Project> optionalEntity = projectrepo.findByCompany(id);
		List<ProjectDTO> models = new ArrayList<>();
		for (Project project : optionalEntity) {
			ProjectDTO model = new ProjectDTO();
			model.setId(project.getId());
			model.setName(project.getName());
			model.setDescription(project.getDescription());
			if (project.getCompany() != null) {
				model.setCompanyId(project.getCompany().getId());
				model.setCompanyName(project.getCompany().getName());
			}
			model.setClientName(project.getClientName());
			model.setIsDelete(project.getIsDelete());
			model.setIsActive(project.getIsActive());
			model.setStartDate(project.getStartDate());
			model.setEndDate(project.getEndDate());
			model.setEstimatedHours(project.getEstimatedHours());
			models.add(model);
		}
		return models;
	}

	/**
	 * Returns Project data when project data is available in database by id
	 * 
	 * @param id - project Id
	 * @return - ProjectResponse
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public ProjectDTO getById(Long id, String companyId) {
		Optional<Project> optionalEntity = projectrepo.findProjectByCompanyId(id, companyId);
		if (!optionalEntity.isPresent()) {
			logger.info("Project is not found in DB with Id:{}", id);
			return null;
		}
		Project entity = optionalEntity.get();
		ProjectDTO model = new ProjectDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompany().getId());
		model.setCompanyName(entity.getCompany().getName());
		model.setStatus(entity.getStatus());
		model.setRemarks(entity.getRemarks());
		model.setIsDelete(entity.getIsDelete());
		model.setIsActive(entity.getIsActive());
		model.setClientName(entity.getClientName());
		model.setStartDate(entity.getStartDate());
		model.setEndDate(entity.getEndDate());
		model.setEstimatedHours(entity.getEstimatedHours());
		logger.info("Project found with Id:{}", id);
		return model;
	}

	/**
	 * Returns true when project data is deleted from database by id
	 * 
	 * @param id - project id
	 * @return - boolean
	 */
	@Override
	public boolean deleteProject(Long id) {
		projectrepo.deleteById(id);
		logger.info("Project record is deleted from database");
		return true;

	}

	/**
	 * Returns true when existing project data is store in database
	 * 
	 * @param model - new project data
	 * @param id    - project Id
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> updateProject(ProjectDTO model, Long id) {
		Optional<Project> findById = projectrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Project oldProject = findById.get();
			logger.info("Project record is found from database with id:{}", id);
			oldProject.setId(id);
			oldProject.setName(model.getName());
			oldProject.setDescription(model.getDescription());
			Optional<Company> company = companyRepo.findById(model.getCompanyId());
			if (!company.isPresent()) {
				return list;
			}
			oldProject.setCompany(company.get());
			oldProject.setStartDate(model.getStartDate());
			oldProject.setStatus(model.getStatus());
			oldProject.setRemarks(model.getRemarks());
			oldProject.setClientName(model.getClientName());
			oldProject.setEndDate(model.getEndDate());
			oldProject.setEstimatedHours(model.getEstimatedHours());
			Project p = projectrepo.save(oldProject);
			logger.info("Project record is updated in database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(p.getId());
			dto.setName(p.getName());
			list.add(dto);
			return list;
		} else {
			return list;

		}
	}

	public static Map<String, Object> mapData(Page<ProjectDTO> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<ProjectDTO> projectModels = pagedResult.stream().map(entity -> {
			ProjectDTO model = new ProjectDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompanyName());
			model.setClientName(entity.getClientName());
			model.setDescription(entity.getDescription());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setStatus(entity.getStatus());
			model.setRemarks(entity.getRemarks());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setEstimatedHours(entity.getEstimatedHours());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, projectModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	@Override
	@Cacheable(value = "findAllEmployeeByProjId", unless = "#result == null", key = "#id")
	public ProjectDTO findAllEmployeeByProjId(Long id, String companyId) {
		Project project = null;
		if (projectrepo.findById(id).isPresent()) {
			Optional<Project> findById = projectrepo.findProjectByCompanyId(id, companyId);
			if (findById.isPresent()) {
				project = findById.get();
			}
			if (project != null) {
				ProjectDTO projectDTO = new ProjectDTO();
				projectDTO.setId(project.getId());
				projectDTO.setDescription(project.getDescription());
				projectDTO.setName(project.getName());
				projectDTO.setCompanyId(project.getCompany().getId());
				projectDTO.setCompanyName(project.getCompany().getName());
				projectDTO.setStatus(project.getStatus());
				projectDTO.setRemarks(project.getRemarks());
				projectDTO.setIsDelete(project.getIsDelete());
				projectDTO.setClientName(project.getClientName());
				projectDTO.setStartDate(project.getStartDate());
				projectDTO.setEndDate(project.getEndDate());
				projectDTO.setEstimatedHours(project.getEstimatedHours());
				List<ProjectEmployeeListDTO> list = new ArrayList<>();

				for (Employee employee : project.getEmployee()) {
					ProjectEmployeeListDTO dto = new ProjectEmployeeListDTO();
					dto.setId(employee.getId());
					dto.setFirstName(employee.getFirstName());
					dto.setLastName(employee.getLastName());
					dto.setEmail(employee.getEmail());
					dto.setContactNo(employee.getContactNo());
					dto.setDepartmentId(employee.getDepartment().getId());
					dto.setDepartmentName(employee.getDepartment().getName());
					dto.setDesignationId(employee.getDesignation().getId());
					dto.setDesignationName(employee.getDesignation().getDesignation());
					list.add(dto);
				}

				projectDTO.setEmployeeDtoList(list);
				logger.info("Find all Employees based on project Id:{}", id);
				return projectDTO;
			}
		}
		logger.info("failed to find all Employees in DB based on project Id:{}", id);
		return null;
	}

	@Override
	public Map<String, Object> getAllProject(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<ProjectDTO> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = projectrepo.allProjectPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = projectrepo.projectPage(searchKey, companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	// for duplicate check validation
	@Override
	public boolean validate(ProjectDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = projectrepo.getProjectCount(model.getCompanyId(), model.getName());
		else
			count = projectrepo.getProjectCountForUpdate(model.getCompanyId(), model.getName(), model.getId());
		return count > 0;
	}

	public List<EntityDTO> softDeleteProject(Long id) {
		Optional<Project> findById = projectrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Project project = findById.get();
		project.setIsActive(Boolean.FALSE);
		project.setIsDelete(Boolean.TRUE);
		Project p = projectrepo.save(project);
		logger.info("Project is SoftDeleted in database Id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getName());
		list.add(dto);
		return list;

	}

	public List<EntityDTO> updateProjectByStatus(Long id, String status) {
		Optional<Project> findById = projectrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		} else {

			Project a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Project e = projectrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Project is activated in database with Id:{}", id);
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Project e = projectrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Project is deactivated in database with Id:{}", id);
			}
		}
		logger.info("Project failed to deactivate or activated in database with Id:{}", id);
		return list;
	}

	/*
	 * @Override
	 * 
	 * @Cacheable(value = "getAllProjectCountBasedOnBranch", unless =
	 * "#result == null", key = "#branchId") public Long
	 * getAllProjectCountBasedOnBranch(Long branchId) {
	 * logger.info("project count found based on branchId:{}",branchId);
	 * List<Project> list = projectrepo.findByBranchId(branchId); return (long)
	 * list.size(); }
	 */

	@Override
	public boolean projectReleaseAnnounce(ProjectReleaseDTO model) {
		Boolean flag = Boolean.FALSE;
		MailDTO request = new MailDTO();
		request.setSubject("We are rolling out something big on" + "" + model.getReleaseDate());
		request.setTemplate("rollout.html");
		request.setFrom(Constants.HR);
		Map<String, Object> model1 = new HashMap<>();
		model1.put(Constants.DATE, model.getReleaseDate());
		model1.put(Constants.NAME, model.getName());
		model1.put(Constants.MSG, "productLaunch");
		List<Employee> findAll = employeeRepo.findAll();
		for (Employee employee2 : findAll) {
			request.setTo(employee2.getEmail());
			emailServiceUtil.sendNotificationEmail(request, model1);
			logger.info("project release mail send to:{}", employee2.getEmail());
		}
		flag = Boolean.TRUE;
		return flag;
	}

	/*
	 * @Override public List<ProjectDTO> getAllProjectBasedOnBranch(Long branchId) {
	 * List<Project> allProject = projectrepo.findByBranchId(branchId);
	 * logger.info("Project Records are found from Database:{}",allProject.size());
	 * List<ProjectDTO> models = allProject.stream().map(entity -> { ProjectDTO
	 * model = new ProjectDTO(); model.setId(entity.getId());
	 * model.setName(entity.getName());
	 * model.setDescription(entity.getDescription());
	 * model.setIsDelete(entity.getIsDelete());
	 * model.setIsActive(entity.getIsActive());
	 * model.setClientName(entity.getClientName());
	 * model.setStartDate(entity.getStartDate());
	 * model.setEndDate(entity.getEndDate());
	 * model.setEstimatedHours(entity.getEstimatedHours()); return model;
	 * }).collect(Collectors.toList()); return models; }
	 */
	/**
	 * @author {RAMESH RENDLA} Based on Company id Project list
	 */
	@Override
	public Set<ProjectPieChartDTO> getAllProjectPieChart(String companyId, Long projectId) {

		Optional<Project> findById = projectrepo.findProjectByCompanyId(projectId, companyId);
		List<Employee> employee = null;
		if (findById.isPresent()) {
			employee = findById.get().getEmployee();
		}
		Set<ProjectPieChartDTO> list = new HashSet<>();
		for (Employee emp : employee) {
			int val = 0;
			Set<Employee> emplist = new HashSet<>();
			for (Employee emp1 : employee) {
				if (emp.getDepartment().getId().equals(emp1.getDepartment().getId())) {
					emplist.add(emp1);
				}
				val = emplist.size();
			}
			ProjectPieChartDTO dto = new ProjectPieChartDTO();
			dto.setEmpCount(val);
			dto.setName(emp.getDepartment().getName());
			list.add(dto);
		}
		return list;

	}
	/*
	 * List<Project> projects = projectrepo.findByCompanyEmployees(companyId); //
	 * List<String> projectNameInPiechart = //
	 * projectrepo.projectNameInPiechart(companyId); List<Map<String, String>> list
	 * = new ArrayList<>(); for (Project Projects : projects) {
	 * 
	 * for(Employee emp : Projects.getEmployee()) { emp.get }
	 * 
	 * Map<String, String> map = new HashMap<>(); map.put(Constants.NAME,
	 * Projects.getName()); String valueOf =
	 * String.valueOf(Projects.getEmployee().size()); map.put("empCount", valueOf);
	 * list.add(map); }
	 * 
	 * List<Map<String, Long>> list = new ArrayList<>(); Map<String, Long> map = new
	 * HashMap<>(); Optional<Project> projectbj = projectrepo.findById(projectId);
	 * if (projectbj.isPresent()) { Project project = projectbj.get(); for (Employee
	 * employee : project.getEmployee()) { for (Employee employee1 :
	 * project.getEmployee()) {
	 * 
	 * if
	 * (employee.getDepartment().getId().equals(employee1.getDepartment().getId()))
	 * {
	 * 
	 * List<Long> empIdForDept =
	 * projectrepo.findDeptCount(employee.getDepartment().getId()); for(Long empId :
	 * empIdForDept) { if(empId == p) } map.put(employee.getDepartment().getName(),
	 * 0); } } } } list.add(map); return list; }
	 * 
	 *//**
		 * @author {RAMESH RENDLA}
		 * 
		 *         Based on manager id project list
		 */

	/*
	 * @Override
	 * 
	 * @TrackExecutionTime public List<Map<String, String>>
	 * getProjectsListDonatChartUnderManager(Long managerId) { List<Map<String,
	 * String>> list = new ArrayList<>(); List<String> projectNameByEmpId =
	 * projectrepo.getProjectNameByEmpId(managerId); for (String string :
	 * projectNameByEmpId) { Map<String, String> map = new HashMap<>();
	 * map.put(Constants.NAME, string); list.add(map); }
	 * 
	 * return list; }
	 * 
	 */ /**
		 * @author {RAMESH RENDLA}
		 * 
		 *         Based on manager id project list
		 */
	@Override
	public Set<ProjectPieChartDTO> getProjectsListDonatChartUnderManager(Long managerId, Long projectId,
			String companyId) {
		Optional<Project> findById = projectrepo.findProjectByCompanyId(projectId, companyId);
		List<Employee> employee = null;
		if (findById.isPresent()) {
			employee = findById.get().getEmployee();
		}
		Set<ProjectPieChartDTO> list = new HashSet<>();
		for (Employee emp : employee) {
			int val = 0;
			Set<Employee> emplist = new HashSet<>();
			for (Employee emp1 : employee) {
				if (emp.getDepartment().getId().equals(emp1.getDepartment().getId())) {
					emplist.add(emp1);
				}
				val = emplist.size();
			}
			ProjectPieChartDTO dto = new ProjectPieChartDTO();
			dto.setEmpCount(val);
			dto.setName(emp.getDepartment().getName());
			list.add(dto);
		}
		return list;
		/*
		 * List<Map<String, String>> list = new ArrayList<>(); // List<String>
		 * projectNameByEmpId = // projectrepo.getProjectNameByEmpId(managerId);
		 * List<Project> projects =
		 * projectrepo.projectsListBasedOnManagerEmployee(managerId); for (Project
		 * Projects : projects) { Map<String, String> map = new HashMap<>();
		 * map.put(Constants.NAME, Projects.getName()); String valueOf =
		 * String.valueOf(Projects.getEmployee().size()); map.put("empCount", valueOf);
		 * list.add(map); } return list;
		 */ }

}
