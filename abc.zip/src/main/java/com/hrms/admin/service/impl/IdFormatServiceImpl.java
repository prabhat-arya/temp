package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.IdFormatDTO;
import com.hrms.admin.entity.IdFormat;
import com.hrms.admin.repository.IdFormatnRepository;
import com.hrms.admin.service.IdFormatService;

@Service
public class IdFormatServiceImpl implements IdFormatService {
	private static final Logger logger = LoggerFactory.getLogger(IdFormatServiceImpl.class);

	@Autowired
	private IdFormatnRepository repository;

	@Override
	public List<EntityDTO> saveIdFormat(IdFormatDTO model) {
		IdFormat entity = new IdFormat();
		entity.setCompName(model.getCompName());
		logger.info(" IdFormat model is converted in to IdFormat entity");
		IdFormat save = repository.save(entity);
		logger.info("IdFormat Added into database" + ":", entity);
		EntityDTO dto = new EntityDTO();
		BeanUtils.copyProperties(save, dto);
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	public boolean deleteIdFormat(Long customEmpId) {
		repository.deleteById(customEmpId);
		logger.info(" IdFormat record is deleted from database ");
		return true;
	}

	@Override
	public List<EntityDTO> updateIdFormat(IdFormatDTO model, Long customEmpId) {
		Optional<IdFormat> findById = repository.findById(customEmpId);
		IdFormat idformat = null;
		if (findById.isPresent()) {
			idformat = findById.get();
			logger.info(" IdFormat record is found from database with id" + ":", customEmpId);
			idformat.setCompName(model.getCompName());
		}
		IdFormat save = repository.save(idformat);
		logger.info(" IdFormat record is updated in to database with id" + ":", customEmpId);
		EntityDTO dto = new EntityDTO();
		BeanUtils.copyProperties(save, dto);
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	public IdFormatDTO findByIdFormat(Long customEmpId) {
		Optional<IdFormat> findById = repository.findById(customEmpId);
		IdFormatDTO dto = null;
		if (findById.isPresent()) {
			IdFormat customEmpIDGeneration = findById.get();
			dto = new IdFormatDTO();
			dto.setCustomEmpId(customEmpIDGeneration.getCustomEmpId());
			dto.setCompName(customEmpIDGeneration.getCompName());
			return dto;
		}
		logger.info("IdFormat found with"+":", customEmpId);
		return null;
	}
}
