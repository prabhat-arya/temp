package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.AttendanceDTO;
import com.hrms.admin.dto.EntityDTO;

public interface AttendanceService {
	
	
	public List<EntityDTO> save(AttendanceDTO model);

	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy,String isActive, String companyId);
	
	public AttendanceDTO getById(Long id);

	public boolean deleteAttendnace(Long id);

	public List<EntityDTO> updateAttendnace(AttendanceDTO model);
	
	public List<AttendanceDTO> getCompanyId(String id);
	
	public List<EntityDTO> softDeleteAttendance(Long id);
	
	//for validation
	public boolean validate(AttendanceDTO model, boolean isSave);
	
	public List<EntityDTO> updateAttendanceByStatus(Long id , String status);
	 
}
