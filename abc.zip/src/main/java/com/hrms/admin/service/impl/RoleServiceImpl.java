/*package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrms.admin.entity.AccessList;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.Menu;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;
import com.hrms.admin.repository.AccessListRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.role.dto.AccessListDTO;
import com.hrms.admin.role.dto.EmpRoleDTO;
import com.hrms.admin.role.dto.EmployeeRoleDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.role.dto.RoleAccessDTO;
import com.hrms.admin.service.RoleService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.MenuUtility;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RolesRepository roleRepo;

	@Autowired
	private MenuRepository menuRepo;

	@Autowired
	private EmployeeRepository empRepo;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private AccessListRepository accessListRepo;

	@Autowired
	private MenuUtility menuUtility;

	private static final Logger logger = LoggerFactory.getLogger(DepartmentServiceImpl.class);

	//-- Create Role
	@Override
	public EmployeeRoles createRole(RoleAccessDTO empRole) {

		Set<AccessListDTO> menus = empRole.getMenus();
		Set<AccessList> accLists = new HashSet<>();
		for (AccessListDTO accessListDTO : menus) {
			AccessList accessList = new AccessList();
			Menu dbMenu = menuRepo.findByMenuId(accessListDTO.getMenuId());
			accessList.setMenu(dbMenu);
			accessList.setCreate(accessListDTO.getCreate());
			accessList.setDelete(accessListDTO.getDelete());
			accessList.setEdit(accessListDTO.getEdit());
			accessList.setView(accessListDTO.getView());
			accessListRepo.save(accessList);
			accLists.add(accessList);
		}
		EmployeeRoles employeeRoles = new EmployeeRoles();
		employeeRoles.setRoleName(empRole.getRoleName());
		employeeRoles.setAccessList(accLists);
		employeeRoles.setIsActive(true);
		employeeRoles.setIsDelete(false);
		roleRepo.save(employeeRoles);
		return employeeRoles; 
	}
	*/

	//-- Adding User To Role
	/*	@Transactional
	@Override
	public EmpRoleDTO addUserToRole(Long roleId, Long empId){

		Optional<Employee> findById = empRepo.findById(empId);
		EmpRoleDTO empRoleDTO = new EmpRoleDTO();
		if(findById.isPresent()) {
			Employee employee = findById.get();
			Set<EmployeeRoles> roles = employee.getRoles();
			EmployeeRoles empRole = roleRepo.getOne(roleId);
			//Set<EmployeeRoles> empRoles = new HashSet<>();
			roles.add(empRole);
			employee.setRoles(roles);
			Employee emp = entityManager.merge(employee);
			if(emp != null) {

				empRoleDTO.setRoleId(roleId);
				empRoleDTO.setRoleName(empRole.getRoleName());
				return empRoleDTO;
			}else {

				empRoleDTO.setRoleId(0l);;
				empRoleDTO.setRoleName("");
				return empRoleDTO;
			}
		}else {

			empRoleDTO.setRoleId(0l);;
			empRoleDTO.setRoleName("");
			return empRoleDTO;
		}
	}
	 */
	//-- Delete User From Role
/*	@Override
	public boolean deleteUserFromRole(EmployeeRoleDTO empRoleDto){

		String SQL = "DELETE FROM USER_GROUPS WHERE EMP_ID = ? AND GROUP_ID" ;

		int update = jdbcTemplate.update(SQL, empRoleDto.getEmpId(), empRoleDto.getRoleId());
		if(update > 0 ) {
			return true;
		}else {
			return false;
		}

	}

	//-- Get All Roles With Pagination
	@Override
	public Map<String, Object> getAllRoles(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive) {
		Pageable paging = null;

		Page<EmployeeRoles> pagedResult = null;
		if (isActive.trim().equals("") || isActive.equals(null)) {
			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				pagedResult = roleRepo.findAllSearchWithPagination(searchKey, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPagination(searchKey, paging);
			}
		} else if (isActive.equals("1")) {
			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				pagedResult = roleRepo.findAllSearchWithPaginationActiveRecords(searchKey, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPaginationActiveRecords(searchKey, paging);
			}

		} else {

			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				// Page<Attendance> pagedResult = attRepo.findAll(paging);
				pagedResult = roleRepo.findAllSearchWithPaginationInActiveRecord(searchKey, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPaginationInActiveRecord(searchKey, paging);
			}
		}
		if (pagedResult.hasContent()) {
			logger.info("For Role Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	//--Get All Menus
	@Override
	public List<MenuSortingDTO> getAllMenus() {

		List<Menu> menuDbList = menuRepo.findAll();
		List<Menu> parentMenu = new ArrayList<>();
		List<Menu> childMenus = new ArrayList<>();
		for (Menu menu : menuDbList) {
			if(menu.getIsParent() == 1 && menu.getIsParent() != 0) {
				parentMenu.add(menu);
			}else {
				childMenus.add(menu);
			}
		}

		List<MenuSortingDTO> menuList = new ArrayList<>();

		for (Menu menu : parentMenu) {

			//MenuSortingDTO sortedMenu = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId());
			MenuSortingDTO sortedMenu = new MenuSortingDTO();
			sortedMenu.setId(menu.getMenuId());
			sortedMenu.setMenuTitle(menu.getMenuTitle());

			List<MenuSortingDTO> childs = new ArrayList<>();
			for (Menu childMenu : childMenus) {
				MenuSortingDTO childMenu1 = new MenuSortingDTO();
				if (menu.getMenuId() == childMenu.getParentId()) {
					//childMenu1 = new MenuSortingDTO(childMenu.getMenuTitle(), childMenu.getMenuIcon(), childMenu.getMenuPath(), childMenu.getMenuId());
					childMenu1.setId(childMenu.getMenuId());
					childMenu1.setMenuTitle(childMenu.getMenuTitle());
					childs.add(childMenu1);
				}
				sortedMenu.setChilds(childs);
			}
			menuList.add(sortedMenu);
		}
		Collections.sort(menuList);
		return menuList;
	}

	//--Get All Roles Without Pagination
	@Override
	public List<EmpRoleDTO> getAllRoles() {

		List<EmployeeRoles> roleList = roleRepo.findAll();
		List<EmpRoleDTO> roleListDto = new ArrayList<>();

		for (EmployeeRoles empRoles : roleList) {

			EmpRoleDTO empRoleDTO = new EmpRoleDTO();
			empRoleDTO.setRoleId(empRoles.getRoleId());
			empRoleDTO.setRoleName(empRoles.getRoleName());
			roleListDto.add(empRoleDTO);
		}
		return roleListDto;
	}

	//--Role View By Id
	@Override
	public EmployeeRoleDTO  roleGetById(Long roleId) {

		EmployeeRoles employeeRoles = roleRepo.findById(roleId).get();
		EmployeeRoleDTO empRoleDTO = new EmployeeRoleDTO();
		empRoleDTO.setEmpId(employeeRoles.getRoleId());
		empRoleDTO.setRoleName(employeeRoles.getRoleName());
		//Set<Menu> menus = employeeRoles.getMenus();
		Set<Menu> menus = new HashSet<>();
		Set<AccessList> accessLists = employeeRoles.getAccessList();
		for (AccessList accessList : accessLists) {
			Menu menu = accessList.getMenu();
			menus.add(menu);
		}
		List<MenuSortingDTO> menusList = menuUtility.getMenuList(menus);

		for (AccessList accessList : accessLists) {
			for (MenuSortingDTO menuSortingDTO : menusList) {
				if(menuSortingDTO.getChilds() != null && !menuSortingDTO.getChilds().isEmpty()) {
					for (MenuSortingDTO childMenusSorting : menuSortingDTO.getChilds()) {

						childMenusSorting.setCreate(accessList.getCreate());
						childMenusSorting.setDelete(accessList.getDelete());
						childMenusSorting.setEdit(accessList.getEdit());
						childMenusSorting.setView(accessList.getView());

					}
				}
				if(menuSortingDTO.getChilds() == null || menuSortingDTO.getChilds().size() == 0) {

					menuSortingDTO.setCreate(accessList.getCreate());
					menuSortingDTO.setDelete(accessList.getDelete());
					menuSortingDTO.setEdit(accessList.getEdit());
					menuSortingDTO.setView(accessList.getView());

				}
			}
		}
		empRoleDTO.setMenuSorting(menusList);
		return empRoleDTO;
	}

	//-- Utility Method for Mapping Data
	public  Map<String, Object> mapData(Page<EmployeeRoles> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeRoleDTO> deptModels = pagedResult.stream().map(roleEntity -> {
			
			EmployeeRoleDTO empRoleDTO = new EmployeeRoleDTO();
			empRoleDTO.setRoleId(roleEntity.getRoleId());
			empRoleDTO.setRoleName(roleEntity.getRoleName());
			//Set<Menu> menus = employeeRoles.getMenus();
			Set<Menu> menus = new HashSet<>();
			Set<MenuSortingDTO> childMenuSortingDTO = new HashSet<>();
			Set<MenuSortingDTO> parentdMenuSortingDTOTemp = new HashSet<>();
			List<MenuSortingDTO> parentdMenuSortingDTO = new ArrayList<>();
			Set<AccessList> accessLists = roleEntity.getAccessList();
			for (AccessList accessList : accessLists) {
				Menu menu = accessList.getMenu();
				if(menu.getIsParent() == 0) {
					
					MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
					AccessListDTO accessListDTO = new AccessListDTO();
					accessListDTO.setCreate(accessList.getCreate());
					accessListDTO.setDelete(accessList.getDelete());
					accessListDTO.setEdit(accessList.getEdit());
					accessListDTO.setView(accessList.getView());
					menuSortingDTO.setAccessList(accessListDTO);
					Menu dbMenu = menuRepo.findById(menuSortingDTO.getParentId()).get();
					MenuSortingDTO menuSortingDTO2 = new MenuSortingDTO(dbMenu.getMenuTitle(), dbMenu.getMenuIcon(), dbMenu.getMenuPath(), dbMenu.getMenuId(), dbMenu.getParentId());
					parentdMenuSortingDTOTemp.add(menuSortingDTO2);
					childMenuSortingDTO.add(menuSortingDTO);
				}else if(menu.getIsParent() != 0) {
					
					MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
					AccessListDTO accessListDTO = new AccessListDTO();
					accessListDTO.setCreate(accessList.getCreate());
					accessListDTO.setDelete(accessList.getDelete());
					accessListDTO.setEdit(accessList.getEdit());
					accessListDTO.setView(accessList.getView());
					menuSortingDTO.setAccessList(accessListDTO);
					parentdMenuSortingDTOTemp.add(menuSortingDTO);

				}
				menus.add(menu);
			}
			for (MenuSortingDTO menu : parentdMenuSortingDTOTemp) {

				List<MenuSortingDTO> childs = new ArrayList<>();
				for (MenuSortingDTO childMenu : childMenuSortingDTO) {

					if (menu.getId() == childMenu.getParentId()) {
						
						childs.add(childMenu);
					}
				}
				menu.setChilds(childs);
				parentdMenuSortingDTO.add(menu);
			}
			
			//New Code End Here
			Collections.sort(parentdMenuSortingDTO);
			empRoleDTO.setMenuSorting(parentdMenuSortingDTO);
			return empRoleDTO;


*/
//Old code...
/*			
			model.setRoleId(roleEntity.getRoleId());
			model.setRoleName(roleEntity.getRoleName());
			Set<Menu> menus = new HashSet<>();
			Set<AccessList> accessLists = roleEntity.getAccessList();
			for (AccessList accessList : accessLists) {
				Menu menu = accessList.getMenu();
				menus.add(menu);
			}
			List<MenuSortingDTO> menusList = menuUtility.getMenuList(menus);

			for (AccessList accessList : accessLists) {
				for (MenuSortingDTO menuSortingDto : menusList) {

					List<MenuSortingDTO> dbChildsDbMenuSortingDTO = new ArrayList<>();
					if(menuSortingDto.getChilds() != null && !menuSortingDto.getChilds().isEmpty()) {
						List<MenuSortingDTO> childs = menuSortingDto.getChilds();
						MenuSortingDTO dbMenuSortingDTO = null;
						for (MenuSortingDTO childMenuSortingDto : childs) {

							if(childMenuSortingDto.getId() == accessList.getMenu().getMenuId()) {
								dbMenuSortingDTO = childMenuSortingDto;
							}
						}
						AccessListDTO accessListDTO = new AccessListDTO();
						accessListDTO.setCreate(accessList.getCreate());
						accessListDTO.setDelete(accessList.getDelete());
						accessListDTO.setEdit(accessList.getEdit());
						accessListDTO.setView(accessList.getView());
						dbMenuSortingDTO.setAccessList(accessListDTO);
						dbChildsDbMenuSortingDTO.add(dbMenuSortingDTO);
					}
					menuSortingDto.setChilds(dbChildsDbMenuSortingDTO);
					if(menuSortingDto.getChilds() == null || menuSortingDto.getChilds().size() == 0) {

						AccessListDTO accessListDTO = new AccessListDTO();
						accessListDTO.setCreate(accessList.getCreate());
						accessListDTO.setDelete(accessList.getDelete());
						accessListDTO.setEdit(accessList.getEdit());
						accessListDTO.setView(accessList.getView());
						menuSortingDto.setAccessList(accessListDTO);
					}
				}
			}
			model.setMenuSorting(menusList);
			return model;
			*/
			/*
		}).collect(Collectors.toList());

		response.put(Constants.DATA, deptModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Department map object is created for Paging");
		return response;
	}

	@Transactional
	@Override
	public EmployeeRoleDTO addUserListToRole(EmpRoleDTO empRoleDto) {

		List<Long> empIds = empRoleDto.getEmpId();
		EmployeeRoleDTO employeeRoleDTO = new EmployeeRoleDTO();
		for (Long empId : empIds) {

			Employee employee = empRepo.findById(empId).get();
			Set<EmployeeRoles> roles = employee.getRoles();
			EmployeeRoles employeeRoles = roleRepo.findById(empRoleDto.getRoleId()).get();
			roles.add(employeeRoles);
			employee.setRoles(roles);
			employeeRoleDTO.setRoleId(empRoleDto.getRoleId());
			employeeRoleDTO.setRoleName(employeeRoles.getRoleName());

			List<Long> empIdList = getEmpIds(employeeRoles.getRoleId());
			List<PayrollEmpListDTO> empList = getEmpList(empIdList);
			employeeRoleDTO.setEmpList(empList);
			entityManager.merge(employee);
		}


		return employeeRoleDTO;
	}

	public List<Long> getEmpIds(Long roleId){

		String SQL_QUERY = "SELECT EMP_ID FROM USER_GROUPS WHERE GROUP_ID = ?";
		List<Long> queryForList = jdbcTemplate.queryForList(SQL_QUERY, Long.class, roleId);
		return queryForList;
	}

	public List<PayrollEmpListDTO> getEmpList(List<Long> empIds){

		List<PayrollEmpListDTO> payrollEmpList = new ArrayList<>();
		for (Long empId : empIds) {
			PayrollEmpListDTO payrollEmpListDTO = new PayrollEmpListDTO();
			Employee employee = empRepo.findById(empId).get();
			payrollEmpListDTO.setEmployeeId(employee.getId());
			payrollEmpListDTO.setFirstName(employee.getFirstName());
			payrollEmpListDTO.setLastName(null);
			payrollEmpList.add(payrollEmpListDTO);
		}
		return payrollEmpList;
	}

	public List<MenuSortingDTO> getRoles(List<String> roles) {

		String dbRole = roles.get(0);
		
		EmployeeRoles employeeRoles = roleRepo.findByRoleName(dbRole).get();
		EmployeeRoleDTO empRoleDTO = new EmployeeRoleDTO();
		empRoleDTO.setRoleId(employeeRoles.getRoleId());
		empRoleDTO.setRoleName(employeeRoles.getRoleName());
		//Set<Menu> menus = employeeRoles.getMenus();
		Set<Menu> menus = new HashSet<>();
		Set<MenuSortingDTO> childMenuSortingDTO = new HashSet<>();
		Set<MenuSortingDTO> parentdMenuSortingDTOTemp = new HashSet<>();
		List<MenuSortingDTO> parentdMenuSortingDTO = new ArrayList<>();
		Set<AccessList> accessLists = employeeRoles.getAccessList();
		for (AccessList accessList : accessLists) {
			Menu menu = accessList.getMenu();
			if(menu.getIsParent() == 0) {
				
				MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
				menuSortingDTO.setCreate(accessList.getCreate());
				menuSortingDTO.setDelete(accessList.getDelete());
				menuSortingDTO.setEdit(accessList.getEdit());
				menuSortingDTO.setView(accessList.getView());
				Menu dbMenu = menuRepo.findById(menuSortingDTO.getParentId()).get();
				MenuSortingDTO menuSortingDTO2 = new MenuSortingDTO(dbMenu.getMenuTitle(), dbMenu.getMenuIcon(), dbMenu.getMenuPath(), dbMenu.getMenuId(), dbMenu.getParentId());
				parentdMenuSortingDTOTemp.add(menuSortingDTO2);
				childMenuSortingDTO.add(menuSortingDTO);
			}else if(menu.getIsParent() != 0) {
				
				MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
				menuSortingDTO.setCreate(accessList.getCreate());
				menuSortingDTO.setDelete(accessList.getDelete());
				menuSortingDTO.setEdit(accessList.getEdit());
				menuSortingDTO.setView(accessList.getView());
				parentdMenuSortingDTOTemp.add(menuSortingDTO);

			}
			menus.add(menu);
		}
		for (MenuSortingDTO menu : parentdMenuSortingDTOTemp) {

			List<MenuSortingDTO> childs = new ArrayList<>();
			for (MenuSortingDTO childMenu : childMenuSortingDTO) {

				if (menu.getId() == childMenu.getParentId()) {
					
					childs.add(childMenu);
				}
			}
			Collections.sort(childs);
			menu.setChilds(childs);
			parentdMenuSortingDTO.add(menu);
		}
		
		//New Code End Here
		Collections.sort(parentdMenuSortingDTO);
		empRoleDTO.setMenuSorting(parentdMenuSortingDTO);

		//EmployeeRoleDTO roleGetById = getRoleViewId(employeeRoles.getRoleId());
		
		List<MenuSortingDTO> menuSorting = empRoleDTO.getMenuSorting();
		Collections.sort(menuSorting);
		return menuSorting;
	}

	public EmployeeRoleDTO getRoleViewId(Long roleId){

		//new Code Start From Here
		EmployeeRoles employeeRoles = roleRepo.findById(roleId).get();
		EmployeeRoleDTO empRoleDTO = new EmployeeRoleDTO();
		empRoleDTO.setRoleId(employeeRoles.getRoleId());
		empRoleDTO.setRoleName(employeeRoles.getRoleName());
		//Set<Menu> menus = employeeRoles.getMenus();
		Set<Menu> menus = new HashSet<>();
		Set<MenuSortingDTO> childMenuSortingDTO = new HashSet<>();
		Set<MenuSortingDTO> parentdMenuSortingDTOTemp = new HashSet<>();
		List<MenuSortingDTO> parentdMenuSortingDTO = new ArrayList<>();
		Set<AccessList> accessLists = employeeRoles.getAccessList();
		for (AccessList accessList : accessLists) {
			Menu menu = accessList.getMenu();
			if(menu.getIsParent() == 0) {
				
				MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
				AccessListDTO accessListDTO = new AccessListDTO();
				accessListDTO.setCreate(accessList.getCreate());
				accessListDTO.setDelete(accessList.getDelete());
				accessListDTO.setEdit(accessList.getEdit());
				accessListDTO.setView(accessList.getView());
				menuSortingDTO.setAccessList(accessListDTO);
				Menu dbMenu = menuRepo.findById(menuSortingDTO.getParentId()).get();
				MenuSortingDTO menuSortingDTO2 = new MenuSortingDTO(dbMenu.getMenuTitle(), dbMenu.getMenuIcon(), dbMenu.getMenuPath(), dbMenu.getMenuId(), dbMenu.getParentId());
				parentdMenuSortingDTOTemp.add(menuSortingDTO2);
				childMenuSortingDTO.add(menuSortingDTO);
			}else if(menu.getIsParent() != 0) {
				
				MenuSortingDTO menuSortingDTO = new MenuSortingDTO(menu.getMenuTitle(), menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId(), menu.getParentId());
				AccessListDTO accessListDTO = new AccessListDTO();
				accessListDTO.setCreate(accessList.getCreate());
				accessListDTO.setDelete(accessList.getDelete());
				accessListDTO.setEdit(accessList.getEdit());
				accessListDTO.setView(accessList.getView());
				menuSortingDTO.setAccessList(accessListDTO);
				parentdMenuSortingDTOTemp.add(menuSortingDTO);

			}
			menus.add(menu);
		}
		for (MenuSortingDTO menu : parentdMenuSortingDTOTemp) {

			List<MenuSortingDTO> childs = new ArrayList<>();
			for (MenuSortingDTO childMenu : childMenuSortingDTO) {

				if (menu.getId() == childMenu.getParentId()) {
					
					childs.add(childMenu);
				}
			}
			menu.setChilds(childs);
			parentdMenuSortingDTO.add(menu);
		}
		
		//New Code End Here
		Collections.sort(parentdMenuSortingDTO);
		empRoleDTO.setMenuSorting(parentdMenuSortingDTO);
		return empRoleDTO;
	}
	
	public EmployeeRoles update(EmployeeRoleDTO empRoleDTO) {
		
		EmployeeRoles employeeRoles = roleRepo.findById(empRoleDTO.getRoleId()).get();
		List<MenuSortingDTO> menuSorting = empRoleDTO.getMenuSorting();
		Set<AccessList> accessLists = employeeRoles.getAccessList();

		for (MenuSortingDTO menuSortingDTO : menuSorting) {
			
			for (AccessList accessList : accessLists) {
				
				if(menuSortingDTO.getMenuTitle().equalsIgnoreCase(accessList.getMenu().getMenuTitle())) {
					
					accessList.setCreate(menuSortingDTO.getCreate());
					accessList.setDelete(menuSortingDTO.getDelete());
					accessList.setEdit(menuSortingDTO.getEdit());
					accessList.setView(menuSortingDTO.getView());
					
				}else {
					
					AccessList newAccessList = new AccessList();
					Menu menu = menuRepo.findByMenuTitle(accessList.getMenu().getMenuTitle());
					//Menu menu = menuRepo.findById(menuSortingDTO.getId()).get();
					
					newAccessList.setCreate(menuSortingDTO.getCreate());
					newAccessList.setDelete(menuSortingDTO.getDelete());
					newAccessList.setEdit(menuSortingDTO.getEdit());
					newAccessList.setView(menuSortingDTO.getView());
					newAccessList.setMenu(menu);
					
				}
				accessListRepo.save(accessList);
			}
		}
		employeeRoles.setAccessList(accessLists);
		EmployeeRoles save = roleRepo.save(employeeRoles);
		return save;
	}
}
*/
