package com.hrms.admin.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.Valid;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PayrollCaluclateDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.AnnualLeaves;
import com.hrms.admin.entity.BankDetails;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.Deductions;
import com.hrms.admin.entity.Earnings;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Holiday;
import com.hrms.admin.entity.PaySchedule;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.SalaryComponents;
import com.hrms.admin.entity.State;
import com.hrms.admin.entity.WeekDays;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.payroll.dto.DeductionsDTO;
import com.hrms.admin.payroll.dto.EarningsDTO;
import com.hrms.admin.payroll.dto.PayCalculateViewDTO;
import com.hrms.admin.payroll.dto.PayScheduleDTO;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;
import com.hrms.admin.payroll.dto.PayrollRequestDTO;
import com.hrms.admin.payroll.dto.PayslipGenerationDTO;
import com.hrms.admin.payroll.dto.PayslipGenerationDTO1;
import com.hrms.admin.repository.AddressRepository;
import com.hrms.admin.repository.AnnualLeavesRepository;
import com.hrms.admin.repository.AttendanceInfoRepository;
import com.hrms.admin.repository.BankRepository;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.repository.DeductionsRepository;
import com.hrms.admin.repository.EarningsRepository;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.HolidayRepository;
import com.hrms.admin.repository.PayScheduleRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.SalaryComponentsRepository;
import com.hrms.admin.repository.StateRepository;
import com.hrms.admin.repository.WeekDaysRepository;
import com.hrms.admin.role.dto.EmployeeIdsDTO;
import com.hrms.admin.service.PayrollService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.NumberToWordsConverter;
import com.hrms.admin.util.PayrollConstants;
import com.hrms.admin.util.PayrollUtility;
import com.hrms.admin.util.StringToDateUtility;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PayrollServiceImpl implements PayrollService {

	private static final Logger logger = LoggerFactory.getLogger(PayrollServiceImpl.class);

	@Autowired
	private EmployeeRepository empRepo;

	@Autowired
	private PayrollUtility payRollUtility;

	@Autowired
	private EarningsRepository earningsRepository;

	@Autowired
	private DeductionsRepository deductionsRepository;

	@Autowired
	private BranchRepository branchRepository;

	@Autowired
	StringToDateUtility stringToDateUtility;

	@Autowired
	BankRepository bankRepository;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private SalaryComponentsRepository salaryComponentsRepository;

	@Autowired
	private AnnualLeavesRepository annualLeavesRepository;

	@Autowired
	private EmpLeaveRepository empLeaveRepository;

	@Autowired
	PayScheduleRepository payScheduleRepository;

	@Autowired
	WeekDaysRepository weekDaysRepository;

	@Autowired
	AttendanceInfoRepository attendanceInfoRepository;

	@Autowired
	HolidayRepository holidayRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	private StringToDateUtility dateUtil;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private CityRepository cityRepo;

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private StateRepository stateRepo;

	@Autowired
	private ProfileImageRepository profileImageRepo;

	private static String file = System.getProperty("user.home") + "\\Downloads/Payslip.pdf";

	@Override
	@Cacheable(value = "payRollCalculation", unless = "#result == null", key = "#companyId")
	public PayCalculateViewDTO payRollCalculation(PayrollCaluclateDTO payrollDto, Long branchId, String companyId) {

		return payRollUtility.calculateView(payrollDto.getEmpCTC(), branchId, companyId);

	}

	int lop = 0;
	int effectiveworkingDays = 0;
	Double basic = 0.0;
	Double actualCtcForCurrentMonth = 0.0;
	int daysInMonth = 0;
	int effWorkDays = 0;

	// @Cacheable(value = "payrollGeneration", unless = "#result == null", key =
	// "#branchId")
	public PayslipGenerationDTO payrollGeneration(PayrollRequestDTO payrollRequestDto, Long branchId, String companyId)
			throws Exception {

		Double totalEarnings = 0.0;
		Double totalDeductions = 0.0;

		Employee employee = null;
		Optional<PaySchedule> optPaySchedule = payScheduleRepository.findByBranchId(branchId);
		PaySchedule paySchedule = null;
		if (optPaySchedule.isPresent()) {
			paySchedule = optPaySchedule.get();
		}
		LocalDate localDate = LocalDate.now();
		Optional<Employee> optEmp = empRepo.findById(payrollRequestDto.getEmployeeId());
		if (optEmp.isPresent()) {
			employee = optEmp.get();
		}

		String date = null;
		int mm = 0;
		if (paySchedule.getPayDay().equalsIgnoreCase(Constants.SELECTED_DAY)) {
			mm = localDate.getMonth().getValue() - 1;
		} else if (paySchedule.getPayDay().equalsIgnoreCase(Constants.LAST_DAY)) {
			mm = localDate.getMonth().getValue();
		}

		if (localDate.getMonth().getValue() < 10) {
			date = localDate.getYear() + "-0" + (mm);
		} else {
			date = localDate.getYear() + "-" + (mm);
		}

		// emp monthly salary
		Double ctc = employee.getCtc() / 12;
		// emp annualLeave based on emp id
		List<AnnualLeaves> annualLeavesList = annualLeavesRepository
				.findByEmployeeId(payrollRequestDto.getEmployeeId());
		Long availableLeaves = 0l;
		for (AnnualLeaves annualLeave : annualLeavesList) {
			availableLeaves = availableLeaves + annualLeave.getAvailableLeaves();
		}
		Integer attCount = attendanceInfoRepository.findByEmpIdAndMonth(employee.getId(), date);
		int totalTookLeaves = 0;

		List<EmpLeave> empLeaveList = empLeaveRepository.findByEmployeeId(employee.getId());

		int leaveApprovedCount = 0;
		for (EmpLeave empLeave : empLeaveList) {
			if (empLeave.getStatus().equals(Constants.APPROVED)) {

				Date startDate = empLeave.getStartDate();
				DateTime datetime1 = new DateTime(startDate);
				int currentMonth1 = Integer.parseInt(datetime1.toString("MM"));

				if (currentMonth1 == localDate.getMonthValue() - 1) {

					leaveApprovedCount = leaveApprovedCount + 1;
				}
			}
		}

		int empWorkingAndLeave = attCount + leaveApprovedCount;

		PayslipGenerationDTO payslipGenerationDTO = new PayslipGenerationDTO();

		BankDetails bankDetails = bankRepository.findByEmployee(employee.getId());

		String holidayDate = localDate.getYear() + "-" + localDate.getMonth().getValue();
		if (localDate.getMonth().getValue() < 10) {
			date = localDate.getYear() + "-0" + (mm);
		} else {
			date = localDate.getYear() + "-" + (mm);
		}
		List<Holiday> allHolidayListBasedOnBranch = holidayRepository.getAllHolidayListBasedOnBranch(branchId);
		int holidayscount = 0;
		for (Holiday holiday : allHolidayListBasedOnBranch) {

			if (stringToDateUtility.dateToString(holiday.getDate()).startsWith(date)) {
				holidayscount = holidayscount + 1;
			}
		}

		YearMonth yearMonthObject = YearMonth.of(localDate.getYear(), mm);
		daysInMonth = yearMonthObject.lengthOfMonth(); // 28
		Date joiningDate = employee.getJoiningDate();
		DateTime joindateJoda = new DateTime(joiningDate);
		String joinDate = joindateJoda.toString("YYYY") + "-" + joindateJoda.toString("MM");

		if (joinDate.equals(date)) {
			String joindateToString = stringToDateUtility.dateToString(joiningDate);
			LocalDate joinDate2 = LocalDate.parse(joindateToString);
			int joiningDttoMonthEnd = daysInMonth - (joinDate2.getDayOfMonth() - 1);
			List<Holiday> newEmpHolidays = holidayRepository.getAllHolidayListBasedOnBranch(branchId);
			int joiningDtholidayscount = 0;
			for (Holiday holiday : newEmpHolidays) {

				if (stringToDateUtility.dateToString(holiday.getDate()).startsWith(joinDate)) {
					DateTime holidateJoda = new DateTime(joiningDate);
					DateTime date2 = new DateTime(holiday.getDate());
					if (date2.getDayOfMonth() >= holidateJoda.getDayOfMonth()) {
						joiningDtholidayscount = joiningDtholidayscount + 1;
					}

				}
			}

			effectiveworkingDays = (empWorkingAndLeave + joiningDtholidayscount);
			lop = joiningDttoMonthEnd - effectiveworkingDays;

		} else {

			effectiveworkingDays = (empWorkingAndLeave + holidayscount);
			lop = daysInMonth - effectiveworkingDays;
		}

		Double perDaySalary = ctc / 30;

		if (localDate.getMonth().getValue() - 1 == 2) {
			if ((localDate.getYear() % 4 == 0) && (localDate.getYear() % 100 != 0)
					|| (localDate.getYear() % 400 == 0)) {
				effectiveworkingDays = effectiveworkingDays + 1;
				effWorkDays = effectiveworkingDays - 1;
			} else {
				effectiveworkingDays = effectiveworkingDays + 2;
				effWorkDays = effectiveworkingDays - 2;
			}
		}

		if (effectiveworkingDays > 30) {
			actualCtcForCurrentMonth = perDaySalary * 30;
		} else {
			actualCtcForCurrentMonth = perDaySalary * effectiveworkingDays;
		}

		// organization logic need to be implement after confirmation from PO & PM

		Map<String, String> genericMap = new HashMap<>();
		Map<String, Double> earningMap = new HashMap<>();
		Map<String, Double> deductionMap = new HashMap<>();

		genericMap.put(PayrollConstants.NAME, employee.getFirstName());
		genericMap.put(PayrollConstants.JOIN_DATE, dateUtil.changeDateFormat(employee.getJoiningDate()));
		genericMap.put(PayrollConstants.DESIGNATION, employee.getDesignation().getDesignation());
		genericMap.put(PayrollConstants.DEPARTMENT, employee.getDepartment().getName());
		genericMap.put(PayrollConstants.LOCATION, employee.getBranch().getName());
		genericMap.put(PayrollConstants.DAYS_IN_MONTH, String.valueOf(daysInMonth));
		if (localDate.getMonth().getValue() - 1 == 2) {
			genericMap.put(PayrollConstants.EFFECTIVE_WORKING_DAYS, String.valueOf(effWorkDays));
		} else {
			genericMap.put(PayrollConstants.EFFECTIVE_WORKING_DAYS, String.valueOf(effectiveworkingDays));
		}

		genericMap.put(PayrollConstants.BANK_NAME, bankDetails.getBankName());
		genericMap.put(PayrollConstants.BANK_ACCOUNT_NO, bankDetails.getAccountNo());
		genericMap.put(PayrollConstants.PFNO, bankDetails.getPfNumber());
		genericMap.put(PayrollConstants.PFUAN, bankDetails.getUanNumber());
		genericMap.put(PayrollConstants.ESI_NO, bankDetails.getEsicNumber());
		genericMap.put(PayrollConstants.PAN_NO, employee.getPanCard());
		genericMap.put(PayrollConstants.LOP, String.valueOf(lop));

		genericMap.put(PayrollConstants.EARNINGS, PayrollConstants.ACTUAL);
		genericMap.put(PayrollConstants.DEDUCTIONS, PayrollConstants.ACTUAL);

		Double totalExclusiveAmount = 0.0;
		// Earnings
//		List<Earnings> earningDetails = earningsRepository.getAllFields(branchId);

		List<Earnings> earningDetails = earningsRepository.getAllFields(companyId);
		for (Earnings earnings : earningDetails) {
			if (Boolean.TRUE.equals(earnings.getStatus())) {

				if (earnings.getCalculationType().contains(Constants.GROSS)) {
					basic = actualCtcForCurrentMonth * (earnings.getPercentageOfGrossSalary() / 100.0);
					totalEarnings = totalEarnings + (basic);
					earningMap.put(earnings.getEarningName().replaceAll("\\s", ""), PayrollUtility.round(basic, 2));
				} else if (earnings.getCalculationType().contains(Constants.BASIC)) {
					totalEarnings = totalEarnings + (basic * (earnings.getPercentageOfBasic() / 100.0));
					earningMap.put(earnings.getEarningName().replaceAll("\\s", ""),
							PayrollUtility.round((basic * (earnings.getPercentageOfBasic() / 100.0)), 2));

				} else {
					if (Boolean.FALSE.equals(earnings.getExclusiveOfNetSalary())) {
						totalEarnings = totalEarnings + earnings.getFlatAmount();
						earningMap.put(earnings.getEarningName().replaceAll("\\s", ""), earnings.getFlatAmount());

					} else {
						earningMap.put(earnings.getEarningName().replaceAll("\\s", ""), earnings.getFlatAmount());
						totalExclusiveAmount = totalExclusiveAmount + earnings.getFlatAmount();
					}
				}
			}
		}

//		List<Deductions> deductionsDetails = deductionsRepository.getAllFields(branchId);
		List<Deductions> deductionsDetails = deductionsRepository.getAllFields(companyId);
		for (Deductions deductions : deductionsDetails) {
			if (Boolean.TRUE.equals(deductions.getStatus())) {

				if (deductions.getCalculationType().contains(Constants.BASIC)) {
					totalDeductions = totalDeductions + (basic * (deductions.getPercentageOfBasic() / 100.0));
					deductionMap.put(deductions.getDeductionName().replaceAll("\\s", ""),
							PayrollUtility.round((basic * (deductions.getPercentageOfBasic() / 100.0)), 2));

				} else {
					deductionMap.put(deductions.getDeductionName().replaceAll("\\s", ""), deductions.getFlatAmount());
					totalDeductions = totalDeductions + deductions.getFlatAmount();
				}

			}
		}

		Double specialAllowance = 0.0;

		specialAllowance = actualCtcForCurrentMonth - totalEarnings;
		if (specialAllowance < 0) {
			specialAllowance = 0.0;
		}
		totalEarnings = totalEarnings + specialAllowance + totalExclusiveAmount;

		if (specialAllowance > 0) {
			earningMap.put(PayrollConstants.SPECIAL_ALLOWANCE, specialAllowance);
		}
		payslipGenerationDTO.setPayslipFields(genericMap);
		payslipGenerationDTO.setEarningMap(earningMap);
		payslipGenerationDTO.setDeductionMap(deductionMap);

		payslipGenerationDTO.setTotalEarnings(Double.parseDouble(String.valueOf(Math.round(totalEarnings))));
		payslipGenerationDTO.setTotalDeductions(Double.parseDouble(String.valueOf(Math.round(totalDeductions))));
		payslipGenerationDTO.setNetPay(Double.parseDouble(String.valueOf(Math.round(totalEarnings - totalDeductions))));
		payslipGenerationDTO.setSpecialAllowance(PayrollUtility.round(specialAllowance, 2));

		return payslipGenerationDTO;

	}

	@Cacheable(value = "getEmployeeIds", unless = "#result.size() == 0")
	public List<PayrollEmpListDTO> getEmployeeIds(String companyId) {

		List<EmployeeInfoDTO> allEmployee = empRepo.findEmp(companyId);
		ArrayList<PayrollEmpListDTO> empList = new ArrayList<>();

		for (EmployeeInfoDTO employee : allEmployee) {

			if (Boolean.TRUE.equals(employee.getIsActive())) {

				PayrollEmpListDTO payrollEmpListDTO = new PayrollEmpListDTO();
				payrollEmpListDTO.setEmployeeId(employee.getId());
				payrollEmpListDTO.setFirstName(employee.getFirstName());
				payrollEmpListDTO.setLastName(employee.getLastName());
				payrollEmpListDTO.setUserName(employee.getUserName());
				empList.add(payrollEmpListDTO);
			}
		}
		return empList;
	}

	@Override
	public List<EmployeeDTO> generatePayslipOnEveryMonth() {

		List<Employee> allEmployee = empRepo.getAllActiveEmployees();
		List<EmployeeDTO> empList = new ArrayList<>();

		for (Employee employee : allEmployee) {

			if (Boolean.TRUE.equals(employee.getIsActive())) {

				try {
					mailSend(employee);

				} catch (Exception e) {
				}
			}
		}
		return empList;
	}

	@Override
	public Map<Long, String> generatePayslipByCompany(String companyId) {

		List<Employee> allEmployee = empRepo.getAllEmpPaySlipByCompId(companyId);
		logger.info(allEmployee.size() + " Employee Find by companyId:: " + companyId);
		Map<Long, String> paySlipGeneratedEmp = new HashMap<>();

		for (Employee employee : allEmployee) {
			try {
				mailSend(employee);
				paySlipGeneratedEmp.put(employee.getId(), employee.getFirstName() + " " + employee.getLastName());
				logger.info("PaySlip generate d for Employee:: " + employee.getId(),
						employee.getFirstName() + " " + employee.getLastName());
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(" mail sending failed ::{} ", e);
			}
		}
		return paySlipGeneratedEmp;
	}

	public ResponseDTO mailSend(Employee employee) throws Exception {
		PayrollRequestDTO payrollRequestDTO = new PayrollRequestDTO();
		payrollRequestDTO.setEmployeeId(employee.getId());
		payrollRequestDTO.setEmpCTC(employee.getCtc());
		LocalDate localDate = LocalDate.now();
		String date = null;
		if (localDate.getMonth().getValue() < 10) {
			date = "0" + (localDate.getMonth().getValue() - 1) + "/" + localDate.getYear();
		} else {
			date = localDate.getMonth().getValue() - 1 + "/" + localDate.getYear();
		}
		String holidayDate = localDate.getYear() + "-" + localDate.getMonth().getValue();
		payrollRequestDTO.setDate(date);
		Long branchId = employee.getBranch().getId();
		PayslipGenerationDTO payrollGeneration = payrollGeneration(payrollRequestDTO, branchId,
				employee.getCompany().getId());
		Optional<PaySchedule> optPaySchedule = payScheduleRepository.findByBranchId(branchId);
		List<Holiday> allHolidayListBasedOnBranch = holidayRepository.getAllHolidayListBasedOnBranch(branchId);
		int holidayscount = 0;
		for (Holiday holiday : allHolidayListBasedOnBranch) {

			if (stringToDateUtility.dateToString(holiday.getDate()).startsWith(holidayDate)) {
				holidayscount = holidayscount + 1;
			}
		}
		PaySchedule paySchedule = null;
		if (optPaySchedule.isPresent()) {
			paySchedule = optPaySchedule.get();
		}
		Map<String, Double> earningMap = new HashMap<>();
		Map<String, Double> deductionMap = new HashMap<>();

//		List<Earnings> earningDetails = earningsRepository.getAllFields(branchId);
		List<Earnings> earningDetails = earningsRepository.getAllFields(employee.getCompany().getId());
		for (Earnings earnings : earningDetails) {
			if (Boolean.TRUE.equals(earnings.getStatus())) {

				if (earnings.getCalculationType().contains(Constants.GROSS)) {
					basic = actualCtcForCurrentMonth * (earnings.getPercentageOfGrossSalary() / 100.0);

					if (Boolean.TRUE.equals(earnings.getExclusiveOfNetSalary())) {
						earningMap.put(earnings.getEarningName() + "(" + Constants.EXCLUSIVE + ")",
								PayrollUtility.round(basic, 2));
					} else {
						earningMap.put(earnings.getEarningName(), PayrollUtility.round(basic, 2));
					}
				} else if (earnings.getCalculationType().contains(Constants.BASIC)) {
					if (Boolean.TRUE.equals(earnings.getExclusiveOfNetSalary())) {
						earningMap.put(earnings.getEarningName() + "(" + Constants.EXCLUSIVE + ")",
								PayrollUtility.round((basic * (earnings.getPercentageOfBasic() / 100.0)), 2));
					} else {
						earningMap.put(earnings.getEarningName(),
								PayrollUtility.round((basic * (earnings.getPercentageOfBasic() / 100.0)), 2));
					}

				} else {
					if (Boolean.TRUE.equals(earnings.getExclusiveOfNetSalary())) {
						earningMap.put(earnings.getEarningName() + "(" + Constants.EXCLUSIVE + ")",
								earnings.getFlatAmount());
					} else {
						earningMap.put(earnings.getEarningName(), earnings.getFlatAmount());
					}

				}
			}
		}

//		List<Deductions> deductionsDetails = deductionsRepository.getAllFields(branchId);
		List<Deductions> deductionsDetails = deductionsRepository.getAllFields(employee.getCompany().getId());
		for (Deductions deductions : deductionsDetails) {
			if (Boolean.TRUE.equals(deductions.getStatus())) {

				if (deductions.getCalculationType().contains(Constants.BASIC)) {
					deductionMap.put(deductions.getDeductionName(),
							PayrollUtility.round((basic * (deductions.getPercentageOfBasic() / 100.0)), 2));

				} else {
					deductionMap.put(deductions.getDeductionName(), deductions.getFlatAmount());
				}

			}
		}

		if (payrollGeneration.getSpecialAllowance() > 0) {
			earningMap.put("Special Allowance", payrollGeneration.getSpecialAllowance());
		}
		BankDetails bankDetails = bankRepository.findByEmployee(employee.getId());
		Map<String, String> genericMap = new HashMap<>();
		genericMap.put(PayrollConstants.NAME, employee.getFirstName());
		genericMap.put(PayrollConstants.JOIN__DATE, dateUtil.changeDateFormat(employee.getJoiningDate()));
		genericMap.put(PayrollConstants.DESIGNATION, employee.getDesignation().getDesignation());
		genericMap.put(PayrollConstants.DEPARTMENT, employee.getDepartment().getName());
		genericMap.put(PayrollConstants.LOCATION, employee.getBranch().getName());
		genericMap.put(PayrollConstants.DAYS__IN__MONTH, String.valueOf(daysInMonth));
		if (localDate.getMonth().getValue() - 1 == 2) {
			genericMap.put(PayrollConstants.EFFECTIVE__WORKING__DAYS, String.valueOf(effWorkDays));
		} else {
			genericMap.put(PayrollConstants.EFFECTIVE__WORKING__DAYS, String.valueOf(effectiveworkingDays));
		}

		genericMap.put(PayrollConstants.BANK__NAME, bankDetails.getBankName());
		genericMap.put(PayrollConstants.BANK__ACCOUNT__NO, bankDetails.getAccountNo());
		genericMap.put(PayrollConstants.PF_NO, bankDetails.getPfNumber());
		genericMap.put(PayrollConstants.PF_UAN, bankDetails.getUanNumber());
		genericMap.put(PayrollConstants.ESI__NO, bankDetails.getEsicNumber());
		genericMap.put(PayrollConstants.PAN__NO, employee.getPanCard());
		genericMap.put(PayrollConstants.LOP, String.valueOf(lop));

		genericMap.put(PayrollConstants.TOTAL_EARNINGS_INR, String.valueOf(payrollGeneration.getTotalEarnings()));
		genericMap.put(PayrollConstants.TOTAL_DEDUCTIONS_INR, String.valueOf(payrollGeneration.getTotalDeductions()));
		genericMap.put(PayrollConstants.NET_PAY_FOR_THE_MONTH, String.valueOf(payrollGeneration.getNetPay()));

		SalaryComponents components = new SalaryComponents();
		ObjectMapper mapper = new ObjectMapper();

		String jsonResult = mapper.writeValueAsString(earningMap);

		String jsonResult1 = mapper.writeValueAsString(genericMap);

		String jsonResult2 = mapper.writeValueAsString(deductionMap);

		components.setEarningJsonData(jsonResult);
		components.setDeductionJsonData(jsonResult2);
		components.setEmployee(employee);
		components.setEmployeeJsonData(jsonResult1);

		if (paySchedule.getPayDay().equalsIgnoreCase(Constants.SELECTED_DAY)) {
			components.setPaySlipOfMonth(date);
		} else if (paySchedule.getPayDay().equalsIgnoreCase(Constants.LAST_DAY)) {
			if (localDate.getMonth().getValue() < 10) {
				date = "0" + (localDate.getMonth().getValue()) + "/" + localDate.getYear();
				components.setPaySlipOfMonth(date);
			} else {
				date = localDate.getMonth().getValue() + "/" + localDate.getYear();
				components.setPaySlipOfMonth(date);
			}
		}
//		components.setPaySlipOfMonth(date);
		salaryComponentsRepository.save(components);

		// Create document
		Document document = new Document();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		PdfWriter writer = PdfWriter.getInstance(document, baos);

		pdfGenerateUtil(employee.getId(), date, document, writer);

		document.close();
		writer.close();
		return emailServiceUtil.sendPdfEmail(employee, new ByteArrayInputStream(baos.toByteArray()));

	}

	/**
	 * @param employee
	 * @param date
	 * @param document
	 * @param writer
	 * @throws BadElementException
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws DocumentException
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 */
	private void pdfGenerateUtil(Long empId, String date, Document document, PdfWriter writer)
			throws BadElementException, MalformedURLException, IOException, DocumentException, JsonProcessingException,
			JsonMappingException {
		document.setPageSize(PageSize._11X17);
		document.setMarginMirroring(true);
		document.open();

		PdfContentByte canvas = writer.getDirectContent();
		// Rectangle rect = new Rectangle(20, 780, 780, 1200);
		Rectangle rect = new Rectangle(20, 680, 780, 1200);
		rect.setBorder(Rectangle.BOX);
		rect.setBorderWidth(1);
		canvas.rectangle(rect);

		// Font styles
		Font fontbasic = new Font(FontFamily.TIMES_ROMAN, 12, Font.NORMAL);
		Font fontBold = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
		Font headFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD);
		Font mainHeadFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD);

		Optional<Employee> emp = empRepo.findById(empId);
		String compId = null;
		if (emp.isPresent()) {
			compId = emp.get().getCompany().getId();
		}
		// Load image
		Image img = null;
		List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(compId);
		if (!companyImages.isEmpty()) {
			for (ProfileImage image : companyImages) {
				if (!image.getImageName().contains("_")) {
					img = Image.getInstance(image.getImageurl());
				}
			}
		} else {
			img = Image.getInstance("classpath:Images/ostafflogo.png");
		}
		img.setAbsolutePosition(25, 1155);
		img.scaleAbsolute(130, 40);
		img.setBorderWidth(35);
		img.setScaleToFitHeight(true);
		canvas.addImage(img);

		Calendar calendar = Calendar.getInstance();

		int year = calendar.get(Calendar.YEAR);

//		String month = emailServiceUtil.getMonthForInt(calendar.get(Calendar.MONTH) - 1);

		Optional<Company> company = companyRepo.findById(compId);
		Paragraph head1 = null;
		if (company.isPresent()) {
			head1 = new Paragraph(new Phrase(company.get().getName(), mainHeadFont));
		}

		Address addr = company.get().getAddress();
		Address address = addressRepo.getOne(addr.getId());
		City city = cityRepo.getOne(address.getCity());
		Country country = countryRepo.getOne(address.getCountry());
		State state = stateRepo.getOne(address.getState());
		Paragraph head2 = new Paragraph(new Phrase(address.getLandmark() + ", " + address.getStreet() + ", "
				+ address.getAddress() + ", " + city.getCityName() + ", " + address.getDistrict() + ", "
				+ state.getStateName() + "-" + address.getPincode() + " " + country.getCountryName(), fontbasic));

		Optional<PaySchedule> optPaySchedule = payScheduleRepository.findByCompanyId(company.get().getId());
		;
		String month = null;
		if (optPaySchedule.isPresent()) {
			if (optPaySchedule.get().getPayDay().equalsIgnoreCase(Constants.LAST_DAY)) {
				month = emailServiceUtil.getMonthForInt(calendar.get(Calendar.MONTH));
			} else if (optPaySchedule.get().getPayDay().equalsIgnoreCase(Constants.SELECTED_DAY)) {
				month = emailServiceUtil.getMonthForInt(calendar.get(Calendar.MONTH) - 1);
			}
		}

		Paragraph head3 = new Paragraph(new Phrase("Payslip for the month of " + month + " " + year + ".", headFont));

		head1.setAlignment(Element.ALIGN_CENTER);
		head2.setAlignment(Element.ALIGN_CENTER);
		head3.setAlignment(Element.ALIGN_CENTER);

		document.add(head1);
		document.add(head2);
		document.add(head3);

		float[] table1 = { 800F, 400F, 800F, 400F };
		PdfPTable empBankTbl = new PdfPTable(table1);
		empBankTbl.setSpacingBefore(5);
		empBankTbl.setSpacingAfter(5);
		empBankTbl.getDefaultCell().setBorder(0);
		empBankTbl.setWidthPercentage(100);

		List<SalaryComponents> salaryComponentList = salaryComponentsRepository.findByPaySlipOfMonth2(empId, date);
		SalaryComponents salaryComponents = salaryComponentList.get(0);
		ObjectMapper objectMapper = new ObjectMapper();

		JsonNode map = objectMapper.readTree(salaryComponents.getEmployeeJsonData());
		// 1st row cells

		PdfPCell cell1 = new PdfPCell(new Phrase(Constants.EMP_NAME, fontBold));
		PdfPCell cell2 = new PdfPCell(new Phrase(map.get("Name").asText()));

		PdfPCell cell3 = new PdfPCell(new Phrase(Constants.BANK_NAME, fontBold));
		PdfPCell cell4 = new PdfPCell(new Phrase(map.get("Bank Name").asText()));

		cell1.setBorder(5);
		cell2.setBorder(9);
		cell3.setBorder(5);
		cell4.setBorder(9);

		empBankTbl.addCell(cell1);
		empBankTbl.addCell(cell2);
		empBankTbl.addCell(cell3);
		empBankTbl.addCell(cell4);

		// 2nd row cells
		PdfPCell cell5 = new PdfPCell(new Phrase(Constants.JOIN_DATE, fontBold));
		PdfPCell cell6 = new PdfPCell(new Phrase(map.get(PayrollConstants.JOIN__DATE).asText()));
		PdfPCell cell7 = new PdfPCell(new Phrase(Constants.BANK_ACCOUNT_NO, fontBold));
		PdfPCell cell8 = new PdfPCell(new Phrase(map.get(PayrollConstants.BANK__ACCOUNT__NO).asText()));

		cell5.setBorder(4);
		cell6.setBorder(0);
		cell7.setBorder(4);
		cell8.setBorder(8);

		empBankTbl.addCell(cell5);
		empBankTbl.addCell(cell6);
		empBankTbl.addCell(cell7);
		empBankTbl.addCell(cell8);

		// 3rd row cells
		PdfPCell cell9 = new PdfPCell(new Phrase(Constants.DESIGNATION, fontBold));
		PdfPCell cell10 = new PdfPCell(new Phrase(map.get(PayrollConstants.DESIGNATION).asText()));
		PdfPCell cell11 = new PdfPCell(new Phrase(Constants.PF_NO, fontBold));
		PdfPCell cell12;
		if (map.get(PayrollConstants.PF_NO) != null) {
			cell12 = new PdfPCell(new Phrase(map.get(PayrollConstants.PF_NO).asText()));
		} else {
			cell12 = new PdfPCell(new Phrase("-"));
		}
		cell9.setBorder(4);
		cell10.setBorder(0);
		cell11.setBorder(4);
		cell12.setBorder(8);

		empBankTbl.addCell(cell9);
		empBankTbl.addCell(cell10);
		empBankTbl.addCell(cell11);
		empBankTbl.addCell(cell12);

		// 4th row cells
		PdfPCell cell13 = new PdfPCell(new Phrase(Constants.DEPARTMENT, fontBold));
		PdfPCell cell14 = new PdfPCell(new Phrase(map.get(PayrollConstants.DEPARTMENT).asText()));
		PdfPCell cell15 = new PdfPCell(new Phrase(Constants.PF_UAN, fontBold));
		PdfPCell cell16;
		if (map.get(PayrollConstants.PF_UAN) != null) {
			cell16 = new PdfPCell(new Phrase(map.get(PayrollConstants.PF_UAN).asText()));
		} else {
			cell16 = new PdfPCell(new Phrase("-"));
		}

		cell13.setBorder(4);
		cell14.setBorder(0);
		cell15.setBorder(4);
		cell16.setBorder(8);

		empBankTbl.addCell(cell13);
		empBankTbl.addCell(cell14);
		empBankTbl.addCell(cell15);
		empBankTbl.addCell(cell16);

		// 5th row cells
		PdfPCell cell17 = new PdfPCell(new Phrase(Constants.LOCATION, fontBold));
		PdfPCell cell18 = new PdfPCell(new Phrase(map.get(PayrollConstants.LOCATION).asText()));
		PdfPCell cell19 = new PdfPCell(new Phrase(Constants.ESI_NO, fontBold));
		PdfPCell cell20;
		if (map.get(PayrollConstants.ESI__NO) != null) {
			cell20 = new PdfPCell(new Phrase(map.get(PayrollConstants.ESI__NO).asText()));
		} else {
			cell20 = new PdfPCell(new Phrase("-"));
		}

		cell17.setBorder(4);
		cell18.setBorder(0);
		cell19.setBorder(4);
		cell20.setBorder(8);

		empBankTbl.addCell(cell17);
		empBankTbl.addCell(cell18);
		empBankTbl.addCell(cell19);
		empBankTbl.addCell(cell20);

		// 6th row cells
		PdfPCell cell21 = new PdfPCell(new Phrase(Constants.EFFECTIVE_WORK_DAYS, fontBold));
		PdfPCell cell22 = new PdfPCell(new Phrase(map.get(PayrollConstants.EFFECTIVE__WORKING__DAYS).asText()));
		PdfPCell cell23 = new PdfPCell(new Phrase(Constants.PAN_NO, fontBold));
		PdfPCell cell24;
		if (map.get(PayrollConstants.PAN__NO) != null) {
			cell24 = new PdfPCell(new Phrase(map.get(PayrollConstants.PAN__NO).asText()));
		} else {
			cell24 = new PdfPCell(new Phrase("-"));
		}

		cell21.setBorder(4);
		cell22.setBorder(8);
		cell23.setBorder(4);
		cell24.setBorder(8);

		empBankTbl.addCell(cell21);
		empBankTbl.addCell(cell22);
		empBankTbl.addCell(cell23);
		empBankTbl.addCell(cell24);

		// 7th row cells
		PdfPCell cell25 = new PdfPCell(new Phrase(Constants.DAYS_IN_MONTH, fontBold));
		PdfPCell cell26 = new PdfPCell(new Phrase(map.get(PayrollConstants.DAYS__IN__MONTH).asText()));

		cell25.setBorder(6);
		cell26.setBorder(10);

		empBankTbl.addCell(cell25);
		empBankTbl.addCell(cell26);

		PdfPCell cell27 = new PdfPCell(new Phrase(Constants.LOP, fontBold));
		PdfPCell cell28 = new PdfPCell(new Phrase(map.get(PayrollConstants.LOP).asText()));
		PdfPCell cell2222 = new PdfPCell(new Phrase(""));
		PdfPCell cell223 = new PdfPCell(new Phrase(""));

		cell27.setBorder(6);
		cell28.setBorder(10);
		cell2222.setBorder(6);
		cell223.setBorder(10);
		empBankTbl.addCell(cell27);
		empBankTbl.addCell(cell28);
		empBankTbl.addCell(cell2222);
		empBankTbl.addCell(cell223);
		document.add(empBankTbl);

		// Second table
		float[] table2 = { 800F, 400F, 800F, 400F };
		PdfPTable earDedTbl = new PdfPTable(table2);
		earDedTbl.setSpacingBefore(5);
		earDedTbl.setSpacingAfter(5);
		earDedTbl.getDefaultCell().setBorder(0);
		earDedTbl.setWidthPercentage(100);

		PdfPCell cell111 = new PdfPCell(new Phrase(Constants.EARNINGS, fontBold));
		PdfPCell cell222 = new PdfPCell(new Phrase(Constants.ACTUAL));
		PdfPCell cell333 = new PdfPCell(new Phrase(Constants.DEDUCTIONS, fontBold));
		PdfPCell cell444 = new PdfPCell(new Phrase(Constants.ACTUAL));

		cell111.setBorder(5);
		cell111.setBorderWidthBottom(1f);
		cell222.setBorder(9);
		cell222.setBorderWidthBottom(1f);
		cell222.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell222.setPaddingRight(20.0f);
		cell333.setBorder(5);
		cell333.setBorderWidthBottom(1f);
		cell444.setBorder(9);
		cell444.setBorderWidthBottom(1f);
		cell444.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell444.setPaddingRight(20.0f);

		earDedTbl.addCell(cell111);
		earDedTbl.addCell(cell222);
		earDedTbl.addCell(cell333);
		earDedTbl.addCell(cell444);

		JsonNode jsonNode = objectMapper.readTree(salaryComponents.getEarningJsonData());

		Iterator<Entry<String, JsonNode>> fields = jsonNode.fields();

		JsonNode jsonNodeData = objectMapper.readTree(salaryComponents.getDeductionJsonData());

		Iterator<Entry<String, JsonNode>> fieldsData = jsonNodeData.fields();

		int totalEarnings1 = 0;
		int totalDeductions1 = 0;
		while (fields.hasNext()) {
			Entry<String, JsonNode> fields2 = fields.next();
			String key = fields2.getKey();

			JsonNode value = fields2.getValue();

			PdfPCell earDedCell5 = new PdfPCell(new Phrase(key, fontBold));
			String formattedValue = PayrollUtility.formattedValue(Double.parseDouble(value.asText()));
			PdfPCell earDedCell6 = new PdfPCell(new Phrase(formattedValue));

			earDedCell5.setBorder(4);
			earDedCell6.setBorder(0);
			earDedCell6.setHorizontalAlignment(Element.ALIGN_RIGHT);

			earDedTbl.addCell(earDedCell5);
			earDedTbl.addCell(earDedCell6);

			if (fieldsData.hasNext()) {
				while (fieldsData.hasNext()) {

					Entry<String, JsonNode> next = fieldsData.next();

					String key1 = next.getKey();

					JsonNode value1 = next.getValue();

					PdfPCell earDedCell51 = new PdfPCell(new Phrase(key1, fontBold));
					String formattedValue1 = PayrollUtility.formattedValue(Double.parseDouble(value1.asText()));
					PdfPCell earDedCell61 = new PdfPCell(new Phrase(formattedValue1));

					earDedCell51.setBorder(4);
					earDedCell61.setBorder(0);
					earDedCell61.setBorderWidthRight(0.3f);
					earDedCell61.setHorizontalAlignment(Element.ALIGN_RIGHT);

					earDedTbl.addCell(earDedCell51);
					earDedTbl.addCell(earDedCell61);

					break;

				}
			} else {
				PdfPCell earDedCell511 = new PdfPCell(new Phrase(""));
				PdfPCell earDedCell611 = new PdfPCell(new Phrase(""));

				earDedCell511.setBorder(4);
				earDedCell611.setBorder(0);
				earDedCell611.setBorderWidthRight(0.3f);

				earDedTbl.addCell(earDedCell511);
				earDedTbl.addCell(earDedCell611);
			}

		}

		totalEarnings1 = map.get(PayrollConstants.TOTAL_EARNINGS_INR).asInt();
		totalDeductions1 = map.get(PayrollConstants.TOTAL_DEDUCTIONS_INR).asInt();
		PdfPCell earDedCell29 = new PdfPCell(new Phrase(Constants.TOTAL_EARNINGS_INR, fontBold));
		PdfPCell earDedCell30 = new PdfPCell(new Phrase(PayrollUtility
				.formattedValue(Double.parseDouble(map.get(PayrollConstants.TOTAL_EARNINGS_INR).asText()))));
		PdfPCell earDedCell31 = new PdfPCell(new Phrase(Constants.TOTAL_DEDUCTIONS_INR, fontBold));
		PdfPCell earDedCell32 = new PdfPCell(new Phrase(PayrollUtility
				.formattedValue(Double.parseDouble(map.get(PayrollConstants.TOTAL_DEDUCTIONS_INR).asText()))));

		earDedCell29.setBorder(6);
		earDedCell29.setBorderWidthTop(1f);
		earDedCell30.setBorder(10);
		earDedCell30.setBorderWidthTop(1f);
		earDedCell30.setHorizontalAlignment(Element.ALIGN_RIGHT);

		earDedCell31.setBorder(6);
		earDedCell31.setBorderWidthTop(1f);
		earDedCell32.setBorder(10);
		earDedCell32.setBorderWidthTop(1f);
		earDedCell32.setHorizontalAlignment(Element.ALIGN_RIGHT);

		earDedTbl.addCell(earDedCell29);
		earDedTbl.addCell(earDedCell30);
		earDedTbl.addCell(earDedCell31);
		earDedTbl.addCell(earDedCell32);

		document.add(earDedTbl);

		// 3rd table
		float[] table = { 800F, 400F, 800F, 400F };
		PdfPTable bottomTbl = new PdfPTable(table);
		bottomTbl.setSpacingBefore(5);
		bottomTbl.setSpacingAfter(5);
		bottomTbl.getDefaultCell().setBorder(0);
		bottomTbl.setWidthPercentage(100);

		// 1st row cells
		PdfPCell btmTblCell1 = new PdfPCell(new Phrase(Constants.NET_PAY_FOR_THE_MONTH, fontbasic));
		String netValue = String.valueOf(totalEarnings1 - totalDeductions1);
		PdfPCell btmTblCell2 = new PdfPCell(new Phrase(PayrollUtility.formattedValue(Double.parseDouble(netValue))));
		PdfPCell btmTblCell3 = new PdfPCell(new Phrase(""));
		PdfPCell btmTblCell4 = new PdfPCell(new Phrase(""));

		btmTblCell1.setBorder(0);
		btmTblCell2.setBorder(0);
		btmTblCell3.setBorder(0);
		btmTblCell4.setBorder(0);

		bottomTbl.addCell(btmTblCell1);
		bottomTbl.addCell(btmTblCell2);
		bottomTbl.addCell(btmTblCell3);
		bottomTbl.addCell(btmTblCell4);
		document.add(bottomTbl);

		float[] table4 = { 30F };
		PdfPTable bottomTbl11 = new PdfPTable(table4);
		bottomTbl11.setSpacingBefore(5);
		bottomTbl11.setSpacingAfter(5);
		bottomTbl11.setWidthPercentage(100);
		bottomTbl11.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell btmTblCell5 = new PdfPCell(new Phrase(Constants.TOTAL_EARNINGS_MINUS_TOTAL_DEDUCTIONS, fontbasic));

		btmTblCell5.setBorder(0);
		bottomTbl11.addCell(btmTblCell5);
		document.add(bottomTbl11);

		float[] table5 = { 30F };
		PdfPTable bottomTbl2 = new PdfPTable(table5);
		bottomTbl2.setSpacingBefore(5);
		bottomTbl2.setSpacingAfter(5);
		bottomTbl2.setHorizontalAlignment(Element.ALIGN_LEFT);
		bottomTbl2.setWidthPercentage(50);

		String convertedString = "Rupees " + NumberToWordsConverter.convert(totalEarnings1 - totalDeductions1)
				+ " Only";
		PdfPCell btmTblCell9 = new PdfPCell(new Phrase(convertedString, fontbasic));
		btmTblCell9.setBorder(0);

		bottomTbl2.addCell(btmTblCell9);

		document.add(bottomTbl2);
		PdfPCell earDedCell511 = new PdfPCell(new Phrase(""));
		earDedCell511.setBorder(0);
		bottomTbl.addCell(earDedCell511);

		Paragraph p = new Paragraph(
				new Phrase("This is a system generated payslip and does not require signature.", fontbasic));
		p.setAlignment(Element.ALIGN_CENTER);
		p.setSpacingBefore(100);

		document.add(p);
	}

	@Override
	public boolean validate(EarningsDTO model, boolean isSave, String companyId) {
		Long count;
		if (isSave)
			count = earningsRepository.getEarningsCountSave(model.getEarningName(), companyId);
		else
			count = earningsRepository.getEarningsCountUpdate(model.getEarningName(), model.getId(), companyId);
		return count > 0;
	}

	@Override
	public List<EntityDTO> save(EarningsDTO model, Long id, String companyId) throws Exception {
		if (model.getCalculationType().contains(Constants.BASIC)) {
			List<Earnings> list = earningsRepository.findAll();

			if (list.isEmpty()) {
				throw new NotFoundException(
						"Sorry! You dont have option to create Percentage Of Basic, please create Basic first");
			}

		}

		Earnings entity = new Earnings();
		entity.setEarningType(model.getEarningType());
		entity.setEarningName(model.getEarningName());
		entity.setNameInPayslip(model.getNameInPayslip());
		entity.setCalculationType(model.getCalculationType());

		if (model.getCalculationType().contains(Constants.GROSS)) {
			entity.setPercentageOfGrossSalary(model.getPercentage());
		}

		else if (model.getCalculationType().contains(Constants.BASIC)) {
			entity.setPercentageOfBasic(model.getPercentage());
		} else {
			entity.setFlatAmount(model.getFlatAmount());
		}
		entity.setStatus(model.getStatus());
		entity.setIsDelete(Boolean.FALSE);
		if (model.getPayType().contains(Constants.INCLUSIVE)) {
			entity.setInclusiveOfNetSalary(true);
			entity.setExclusiveOfNetSalary(false);
		} else {
			entity.setExclusiveOfNetSalary(true);
			entity.setInclusiveOfNetSalary(false);
		}
		Branch branch = null;
		Optional<Branch> optBranch = branchRepository.findById(id);
		if (optBranch.isPresent()) {
			branch = optBranch.get();
		}
		entity.setBranch(branch);
		Company company = null;
		Optional<Company> optCompnay = companyRepo.findById(companyId);
		if (optCompnay.isPresent()) {
			company = optCompnay.get();
		}
		entity.setCompany(company);
		Earnings earningData = earningsRepository.save(entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(earningData.getId());
		dto.setName(earningData.getEarningName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	@Cacheable(value = "allEarnings", unless = "#result.size() == 0")
	public List<EarningsDTO> allEarnings(String companyId) {
		List<Earnings> allEarnings = earningsRepository.getAllEarnings(companyId);
		return allEarnings.stream().map(entity -> {
			EarningsDTO model = new EarningsDTO();
			model.setId(entity.getId());
			model.setEarningType(entity.getEarningType());
			model.setEarningName(entity.getEarningName());
			model.setNameInPayslip(entity.getNameInPayslip());
			model.setCalculationType(entity.getCalculationType());
			if (entity.getCalculationType().contains(Constants.GROSS)) {
				model.setPercentage(entity.getPercentageOfGrossSalary());
			} else if (entity.getCalculationType().contains(Constants.BASIC)) {
				model.setPercentage(entity.getPercentageOfBasic());
			} else {
				model.setFlatAmount(entity.getFlatAmount());
			}
			model.setInclusiveOfNetSalary(entity.getInclusiveOfNetSalary());
			model.setExclusiveOfNetSalary(entity.getExclusiveOfNetSalary());
			return model;
		}).collect(Collectors.toList());
	}

	@Override
	public boolean validate(DeductionsDTO model, boolean isSave, String companyId) {
		Long count;
		if (isSave)
			count = deductionsRepository.getDeductionsCountSave(model.getDeductionName(), companyId);
		else
			count = deductionsRepository.getDeductionsCountUpdate(model.getDeductionName(), model.getId(), companyId);
		return count > 0;
	}

	@Override
	public List<EntityDTO> save(DeductionsDTO model, Long id, String companyId) {
		Deductions entity = new Deductions();
		entity.setDeductionType(model.getDeductionType());
		entity.setDeductionName(model.getDeductionName());
		entity.setNameInPayslip(model.getNameInPayslip());
		entity.setFlatAmount(model.getFlatAmount());
		entity.setStatus(model.getStatus());
		entity.setIsDelete(Boolean.FALSE);
		entity.setCalculationType(model.getCalculationType());
		entity.setPercentageOfBasic(model.getPercentage());
		Branch branch = null;
		Optional<Branch> optBranch = branchRepository.findById(id);
		if (optBranch.isPresent()) {
			branch = optBranch.get();
		}
		entity.setBranch(branch);
		Company company = null;
		Optional<Company> optCompany = companyRepo.findById(companyId);
		if (optCompany.isPresent()) {
			company = optCompany.get();
		}
		entity.setCompany(company);
		Deductions deductionsData = deductionsRepository.save(entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(deductionsData.getId());
		dto.setName(deductionsData.getDeductionName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	@Cacheable(value = "allDeductions", unless = "#result.size() == 0")
	public List<DeductionsDTO> allDeductions(String companyId) {
		List<Deductions> deductionsList = deductionsRepository.findByCompany(companyId);
		return deductionsList.stream().map(entity -> {
			DeductionsDTO model = new DeductionsDTO();
			model.setId(entity.getId());
			model.setDeductionType(entity.getDeductionType());
			model.setDeductionName(entity.getDeductionName());
			model.setNameInPayslip(entity.getNameInPayslip());
			model.setCalculationType(entity.getCalculationType());
			model.setPercentage(entity.getPercentageOfBasic());
			model.setFlatAmount(entity.getFlatAmount());
			return model;
		}).collect(Collectors.toList());
	}

	@Override
	public List<EntityDTO> updateEarning(@Valid EarningsDTO model, Long id) {
		Optional<Earnings> findById = earningsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Earnings oldEarnings = findById.get();
			logger.info(" Earnings record is found from database with id,name:{} : {}", id,
					oldEarnings.getEarningName());
			oldEarnings.setEarningName(model.getEarningName());
			oldEarnings.setEarningType(model.getEarningType());
			oldEarnings.setCalculationType(model.getCalculationType());
			oldEarnings.setNameInPayslip(model.getNameInPayslip());
			if (model.getCalculationType().contains(Constants.GROSS)) {
				oldEarnings.setPercentageOfGrossSalary(model.getPercentage());
			} else if (model.getCalculationType().contains(Constants.BASIC)) {
				oldEarnings.setPercentageOfBasic(model.getPercentage());
			} else {
				oldEarnings.setFlatAmount(model.getFlatAmount());
			}

			oldEarnings.setStatus(model.getStatus());

			if (model.getPayType().contains(Constants.INCLUSIVE)) {
				oldEarnings.setInclusiveOfNetSalary(true);
				oldEarnings.setExclusiveOfNetSalary(false);
			} else {
				oldEarnings.setExclusiveOfNetSalary(true);
				oldEarnings.setInclusiveOfNetSalary(false);
			}

			Earnings earnings = earningsRepository.save(oldEarnings);

			logger.info("Earnings record is updated in to database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(earnings.getId());
			dto.setName(earnings.getEarningName());
			list.add(dto);
		}
		return list;
	}

	@Override
	public List<EntityDTO> updateDeduction(@Valid DeductionsDTO model, Long id) {
		Optional<Deductions> findById = deductionsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Deductions oldDeductions = findById.get();
			logger.info("Deductions record is found from database with id,name: {} : {}", id,
					oldDeductions.getDeductionName());
			oldDeductions.setDeductionName(model.getDeductionName());
			oldDeductions.setDeductionType(model.getDeductionType());
			oldDeductions.setCalculationType(model.getCalculationType());
			oldDeductions.setFlatAmount(model.getFlatAmount());
			oldDeductions.setNameInPayslip(model.getNameInPayslip());
			oldDeductions.setStatus(model.getStatus());
			oldDeductions.setPercentageOfBasic(model.getPercentage());
			Deductions deductions = deductionsRepository.save(oldDeductions);
			logger.info("Deductions record is updated in to database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(deductions.getId());
			dto.setName(deductions.getDeductionName());
			list.add(dto);
		}
		return list;
	}

	@Override
	public List<EntityDTO> softDeleteEarnings(Long id) {
		Optional<Earnings> findById = earningsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Earnings earnings = findById.get();
			earnings.setIsDelete(Boolean.TRUE);
			earnings.setStatus(false);
			Earnings e = earningsRepository.save(earnings);
			logger.info("Earnings ID and is SoftDeleted in to database:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getEarningName());
			list.add(dto);
		}
		return list;
	}

	@Override
	public List<EntityDTO> softDeleteDeduction(Long id) {
		Optional<Deductions> findById = deductionsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Deductions deductions = findById.get();
			deductions.setIsDelete(Boolean.TRUE);
			deductions.setStatus(false);
			Deductions d = deductionsRepository.save(deductions);
			logger.info("Deductions ID and is SoftDeleted in to database:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getDeductionName());
			list.add(dto);
		}
		return list;
	}

	@Override
	@Cacheable(value = "getAllEarningsByPage", unless = "#result.size() == 0")
	public Map<String, Object> getAllEarningsByPage(int pageIndex, int pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
		Page<Earnings> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive == null) {
			pagedResult = earningsRepository.allEarningsPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = earningsRepository.earningsPage(searchKey, status, companyId, paging);
		}
		if (pagedResult.hasContent() && pagedResult != null) {
			logger.info("For Earnings Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	private Map<String, Object> mapData(Page<Earnings> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<EarningsDTO> deptModels = pagedResult.stream().map(earningEntity -> {
			EarningsDTO model = new EarningsDTO();
			model.setId(earningEntity.getId());
			model.setEarningType(earningEntity.getEarningType());
			model.setEarningName(earningEntity.getEarningName());

			String calculationType = earningEntity.getCalculationType();
			if (Boolean.TRUE.equals(earningEntity.getInclusiveOfNetSalary())) {
				if (earningEntity.getCalculationType().contains(Constants.GROSS)) {
					calculationType = Constants.INCLUSIVE1 + "; " + earningEntity.getPercentageOfGrossSalary() + "% "
							+ "of Gross Salary";
				} else if (earningEntity.getCalculationType().contains(Constants.BASIC)) {
					calculationType = Constants.INCLUSIVE1 + "; " + earningEntity.getPercentageOfBasic() + "% "
							+ "of Basic";
				} else {
					calculationType = Constants.INCLUSIVE1 + "; " + Math.round(earningEntity.getFlatAmount()) + ".00 "
							+ "Flat Amount";
				}

			} else {
				if (earningEntity.getCalculationType().contains(Constants.GROSS)) {
					calculationType = Constants.EXCLUSIVE1 + "; "
							+ Math.round(earningEntity.getPercentageOfGrossSalary()) + "% " + "of Gross Salary";
				} else if (earningEntity.getCalculationType().contains(Constants.BASIC)) {
					calculationType = Constants.EXCLUSIVE1 + "; " + earningEntity.getPercentageOfBasic() + "% "
							+ "of Basic";
				} else {
					calculationType = Constants.EXCLUSIVE1 + "; " + Math.round(earningEntity.getFlatAmount()) + ".00 "
							+ "Flat Amount";
				}

			}
			model.setCalculationType(calculationType);
			model.setNameInPayslip(earningEntity.getNameInPayslip());
			if (earningEntity.getCalculationType().contains(Constants.GROSS)) {
				model.setPercentage(earningEntity.getPercentageOfGrossSalary());
			} else if (earningEntity.getCalculationType().contains(Constants.BASIC)) {
				model.setPercentage(earningEntity.getPercentageOfBasic());
			} else {
				model.setFlatAmount(earningEntity.getFlatAmount());
			}

			model.setStatus(earningEntity.getStatus());

			if (Boolean.TRUE.equals(earningEntity.getInclusiveOfNetSalary())) {
				model.setPayType(Constants.INCLUSIVE);
			} else {
				model.setPayType(Constants.EXCLUSIVE);
			}

			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, deptModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Earning map object is created for Paging");
		return response;
	}

	@Override
	@Cacheable(value = "getAllDeductionsByPage", unless = "#result.size() == 0")
	public Map<String, Object> getAllDeductionsByPage(int pageIndex, int pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
		Page<Deductions> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive == null) {
			pagedResult = deductionsRepository.allDeductionsPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = deductionsRepository.DeductionsPage(searchKey, status, companyId, paging);
		}
		if (pagedResult.hasContent() && pagedResult != null) {
			logger.info("For Deductions Records page is created");
			return mapDataDeduction(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	private Map<String, Object> mapDataDeduction(Page<Deductions> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<DeductionsDTO> deptModels = pagedResult.stream().map(deductionEntity -> {
			DeductionsDTO model = new DeductionsDTO();
			model.setId(deductionEntity.getId());
			model.setDeductionType(deductionEntity.getDeductionType());
			model.setDeductionName(deductionEntity.getDeductionName());
			model.setCalculationType(deductionEntity.getCalculationType());
			model.setNameInPayslip(deductionEntity.getNameInPayslip());
			model.setFlatAmount(deductionEntity.getFlatAmount());
			model.setStatus(deductionEntity.getStatus());
			model.setPercentage(deductionEntity.getPercentageOfBasic());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, deptModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Deductions map object is created for Paging");
		return response;
	}

	@Override
	public void employeePayslip(EmployeeIdsDTO employeeIdsDTO) {

		List<Employee> allEmployee = empRepo.findAllById(employeeIdsDTO.getEmpIds());

		for (Employee employee : allEmployee) {
			if (employee.getIsActive()) {

				try {
					mailSend(employee);

				} catch (Exception e) {
					logger.info("while getting employeePlayslip Error Occure:{}", e);
				}
			}
		}

	}

	@Override
	public boolean validate(PayScheduleDTO payScheduleDTO, boolean isSave, String companyId) {
		Long count;
		if (isSave)
			count = payScheduleRepository.getPayScheduleCountSave(payScheduleDTO.getPayDateSelected(), companyId);
		else
			count = payScheduleRepository.getPayScheduleCountUpdate(payScheduleDTO.getPayDateSelected(),
					payScheduleDTO.getId(), companyId);
		return count > 0;
	}

	@Override
	public List<EntityDTO> createPaySchedule(PayScheduleDTO payScheduleDTO, String companyId) {
		PaySchedule entity = new PaySchedule();
		entity.setDays(payScheduleDTO.getDaySelected());
		entity.setPayDay(payScheduleDTO.getPayday());
		entity.setWorkingDay(payScheduleDTO.getWorkingday());
		entity.setPayDaySelected(payScheduleDTO.getPayDateSelected());
		String[] arrWeekdays = payScheduleDTO.getCalenderWeek();
		WeekDays savedWeekDays = null;
		WeekDays weekDays = new WeekDays();
		for (String day1 : arrWeekdays) {

			switch (day1) {
			case Constants.MON:
				weekDays.setMonday(true);
				break;
			case Constants.TUE:
				weekDays.setTuesday(true);
				break;
			case Constants.WED:
				weekDays.setWednesday(true);
				break;
			case Constants.THU:
				weekDays.setThursday(true);
				break;
			case Constants.FRI:
				weekDays.setFriday(true);
				break;
			case Constants.SAT:
				weekDays.setSaturday(true);
				break;
			case Constants.SUN:
				weekDays.setSunday(true);
				break;
			}

		}

		savedWeekDays = weekDaysRepository.save(weekDays);
		Branch branch = null;
		Optional<Branch> optBranch = branchRepository.findById(payScheduleDTO.getBranchId());
		if (optBranch.isPresent()) {
			branch = optBranch.get();
		}
		entity.setBranch(branch);
		Company company = null;
		Optional<Company> optCompany = companyRepo.findById(companyId);
		if (optCompany.isPresent()) {
			company = optCompany.get();
		}
		entity.setCompany(company);
		entity.setWeekDays(savedWeekDays);
		entity.setCronExp("0 0 14 " + payScheduleDTO.getPayDateSelected() + " * *");
		PaySchedule paySchedule = payScheduleRepository.save(entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(paySchedule.getId());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	@Cacheable(value = "getPayScheduleByBranchId", unless = "#result == null", key = "#branchId")
	public PayScheduleDTO getPayScheduleByBranchId(Long branchId) {
		PayScheduleDTO model = null;
		Optional<PaySchedule> optionalEntity = payScheduleRepository.findByBranchId(branchId);
		if (optionalEntity.isPresent()) {
			PaySchedule entity = optionalEntity.get();
			model = new PayScheduleDTO();
			model.setDaySelected(entity.getDays());
			model.setPayday(entity.getPayDay());
			model.setPayDateSelected(entity.getPayDaySelected());
			model.setWorkingday(entity.getWorkingDay());
			model.setId(entity.getId());
			String[] arrWeekDays = new String[7];
			WeekDays weekDays = entity.getWeekDays();
			if (arrWeekDays[0] == null) {
				if (weekDays.getMonday() != null) {
					arrWeekDays[0] = Constants.MON;
				}
			}
			if (arrWeekDays[1] == null) {
				if (weekDays.getTuesday() != null) {
					arrWeekDays[1] = Constants.TUE;
				}
			}
			if (arrWeekDays[2] == null) {
				if (weekDays.getWednesday() != null) {
					arrWeekDays[2] = Constants.WED;
				}
			}
			if (arrWeekDays[3] == null) {
				if (weekDays.getThursday() != null) {
					arrWeekDays[3] = Constants.THU;
				}
			}
			if (arrWeekDays[4] == null) {
				if (weekDays.getFriday() != null) {
					arrWeekDays[4] = Constants.FRI;
				}
			}
			if (arrWeekDays[5] == null) {
				if (weekDays.getSaturday() != null) {
					arrWeekDays[5] = Constants.SAT;
				}
			}
			if (arrWeekDays[6] == null) {
				if (weekDays.getSunday() != null) {
					arrWeekDays[6] = Constants.SUN;
				}
			}

			List<String> list = new ArrayList<>();

			for (String s : arrWeekDays) {
				if (s != null && s.length() > 0) {
					list.add(s);
				}
			}

			arrWeekDays = list.toArray(new String[list.size()]);

			model.setCalenderWeek(arrWeekDays);
			model.setBranchId(entity.getBranch().getId());
			logger.info("Assets found with Id:{}", branchId);

		}
		return model;
	}

	@Override
	public List<EntityDTO> payScheduleUpdate(@Valid PayScheduleDTO model, Long id) {
		Optional<PaySchedule> optional = payScheduleRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (optional.isPresent()) {
			PaySchedule paySchedule = optional.get();
			logger.info(" PaySchedule record is found from database with id and name:{} : {}", id,
					+paySchedule.getBranch().getId());

			paySchedule.setDays(model.getDaySelected());
			paySchedule.setPayDay(model.getPayday());
			paySchedule.setWorkingDay(model.getWorkingday());
			paySchedule.setPayDaySelected(model.getPayDateSelected());

			String[] arrWeekdays = model.getCalenderWeek();
			WeekDays weekDays2 = null;
			Optional<WeekDays> optWeekDays = weekDaysRepository.findById(paySchedule.getWeekDays().getId());

			if (optWeekDays.isPresent()) {
				weekDays2 = optWeekDays.get();
				weekDays2.setFriday(Constants.NULL);
				weekDays2.setMonday(Constants.NULL);
				weekDays2.setSunday(Constants.NULL);
				weekDays2.setThursday(Constants.NULL);
				weekDays2.setSaturday(Constants.NULL);
				weekDays2.setTuesday(Constants.NULL);
				weekDays2.setWednesday(Constants.NULL);
				WeekDays weekDays = weekDaysRepository.save(weekDays2);
				for (String day : arrWeekdays) {

					switch (day) {
					case Constants.MON:
						weekDays.setMonday(true);
						break;
					case Constants.TUE:
						weekDays.setTuesday(true);
						break;
					case Constants.WED:
						weekDays.setWednesday(true);
						break;
					case Constants.THU:
						weekDays.setThursday(true);
						break;
					case Constants.FRI:
						weekDays.setFriday(true);
						break;
					case Constants.SAT:
						weekDays.setSaturday(true);
						break;
					case Constants.SUN:
						weekDays.setSunday(true);
						break;
					}

				}

				paySchedule.setWeekDays(weekDays2);
				weekDaysRepository.save(weekDays);

				PaySchedule savedPaySchedule = payScheduleRepository.save(paySchedule);

				logger.info(" PaySchedule record is updated in to database with id:{}", id);
				EntityDTO dto = new EntityDTO();
				dto.setId(savedPaySchedule.getId());
				list.add(dto);
			}
		}
		return list;
	}

	@Override
	public void downloadPdf(Long empId, String date) {

		try {
			Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
			document.open();
			pdfGenerateUtil(empId, date, document, writer);
			document.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public EarningsDTO getById(Long id) {
		Optional<Earnings> optionalEntity = earningsRepository.findById(id);
		EarningsDTO model = new EarningsDTO();
		if (optionalEntity.isPresent()) {
			Earnings entity = optionalEntity.get();

			model.setId(entity.getId());
			model.setEarningName(entity.getEarningName());
			model.setNameInPayslip(entity.getNameInPayslip());
			model.setEarningType(entity.getEarningType());
			model.setCalculationType(entity.getCalculationType());
			if (entity.getCalculationType().contains(Constants.BASIC)) {
				model.setPercentage(entity.getPercentageOfBasic());
			} else if (entity.getCalculationType().contains(Constants.GROSS)) {
				model.setPercentage(entity.getPercentageOfGrossSalary());
			} else {
				model.setFlatAmount(entity.getFlatAmount());
			}
			if (Boolean.TRUE.equals(entity.getInclusiveOfNetSalary())) {
				model.setPayType(Constants.INCLUSIVE);

			} else {
				model.setPayType(Constants.EXCLUSIVE);
			}
			model.setStatus(entity.getStatus());
			model.setBranchId(entity.getBranch().getId());

			logger.info("Earnings found with ID:{}", id);

		}
		return model;
	}

	@Override
	@Cacheable(value = "getDeductionsById", unless = "#result == null", key = "#id")
	public DeductionsDTO getDeductionsById(Long id) {
		Optional<Deductions> optionalEntity = deductionsRepository.findById(id);
		DeductionsDTO model = new DeductionsDTO();
		if (optionalEntity.isPresent()) {
			Deductions entity = optionalEntity.get();
			model.setId(entity.getId());
			model.setDeductionType(entity.getDeductionType());
			model.setDeductionName(entity.getDeductionName());
			model.setNameInPayslip(entity.getNameInPayslip());
			model.setCalculationType(entity.getCalculationType());
			if (entity.getCalculationType().contains(Constants.BASIC)) {
				model.setPercentage(entity.getPercentageOfBasic());
			} else {
				model.setFlatAmount(entity.getFlatAmount());
			}
			logger.info("Deductions found with Id:{}", id);
			model.setStatus(entity.getStatus());
			model.setBranchId(entity.getBranch().getId());

		}
		return model;

	}

	@Override
	public List<EntityDTO> deductionStatusUpdate(Long id) {
		Optional<Deductions> findById = deductionsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Deductions deductions = findById.get();
			if (Boolean.TRUE.equals(deductions.getStatus())) {
				deductions.setStatus(false);
			} else {
				deductions.setStatus(true);
			}

			Deductions d = deductionsRepository.save(deductions);
			logger.info("Deductions Id and status are updated with Id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getDeductionName());
			list.add(dto);
		}
		return list;
	}

	@Override
	public List<EntityDTO> earningsStatusUpdate(Long id) {
		Optional<Earnings> findById = earningsRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Earnings earnings = findById.get();
			if (Boolean.TRUE.equals(earnings.getStatus())) {
				earnings.setStatus(false);
			} else {
				earnings.setStatus(true);
			}

			Earnings d = earningsRepository.save(earnings);
			logger.info("Earnings ID and status are updated:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getEarningName());
			list.add(dto);
		}
		return list;
	}

	public PayslipGenerationDTO1 payrollGeneration1(PayrollRequestDTO payrollRequestDto, Long branchId)
			throws Exception {

		PayslipGenerationDTO1 payslipGenerationDTO1 = new PayslipGenerationDTO1();
		SalaryComponents salaryComponents = salaryComponentsRepository
				.findByPaySlipOfMonth(payrollRequestDto.getEmployeeId(), payrollRequestDto.getDate());

		Optional<Employee> emp = empRepo.findById(payrollRequestDto.getEmployeeId());
		String compId = null;
		if (emp.isPresent()) {
			compId = emp.get().getCompany().getId();
		}
		// Load image
		Image img = null;
		List<ProfileImage> companyImages = profileImageRepo.findByCompanyId(compId);
		if (!companyImages.isEmpty()) {
			for (ProfileImage image : companyImages) {
				if (!image.getImageName().contains("_")) {
					ProfileImageDTO imageDto = new ProfileImageDTO();
					imageDto.setImageName(image.getImageName());
					imageDto.setImageurl(image.getImageurl());
					imageDto.setFileType(image.getFileType());
					imageDto.setId(image.getId());
					payslipGenerationDTO1.setImage(imageDto);
				}
			}
		} else {
			payslipGenerationDTO1.setImage(new ProfileImageDTO());
		}
		Optional<Company> company = companyRepo.findById(compId);
		if (company.isEmpty()) {
			return null;
		}
		Address addr = company.get().getAddress();
		Address address = addressRepo.getOne(addr.getId());
		City city = cityRepo.getOne(address.getCity());
		Country country = countryRepo.getOne(address.getCountry());
		State state = stateRepo.getOne(address.getState());
		String addr1 = address.getAddress();

		/** Address validation */
		String addr2 = Stream.of(address.getStreet(), address.getLandmark(), city.getCityName(), address.getDistrict())
				.filter(s -> s != null && !s.isEmpty()).collect(Collectors.joining(", "));

		String addr3 = state.getStateName() + "-" + address.getPincode() + " " + country.getCountryName();
		payslipGenerationDTO1.setCompanyName(company.get().getName());
		payslipGenerationDTO1.setCompanyAddress1(addr1);
		payslipGenerationDTO1.setCompanyAddress2(addr2);
		payslipGenerationDTO1.setCompanyAddress3(addr3);

		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode map = objectMapper.readTree(salaryComponents.getEmployeeJsonData());

		Map<String, String> genericMap = new HashMap<>();
		genericMap.put(PayrollConstants.NAME, map.get(PayrollConstants.NAME).asText());
		genericMap.put(PayrollConstants.JOIN_DATE, map.get(PayrollConstants.JOIN__DATE).asText());
		genericMap.put(PayrollConstants.DESIGNATION, map.get(PayrollConstants.DESIGNATION).asText());
		genericMap.put(PayrollConstants.DEPARTMENT, map.get(PayrollConstants.DEPARTMENT).asText());
		genericMap.put(PayrollConstants.LOCATION, map.get(PayrollConstants.LOCATION).asText());
		genericMap.put(PayrollConstants.DAYS_IN_MONTH, map.get(PayrollConstants.DAYS__IN__MONTH).asText());
		genericMap.put(PayrollConstants.EFFECTIVE_WORKING_DAYS,
				map.get(PayrollConstants.EFFECTIVE__WORKING__DAYS).asText());

		genericMap.put(PayrollConstants.BANK_NAME, map.get(PayrollConstants.BANK__NAME).asText());
		genericMap.put(PayrollConstants.BANK_ACCOUNT_NO, map.get(PayrollConstants.BANK__ACCOUNT__NO).asText());
		if (map.get(PayrollConstants.PF_NO) != null) {
			genericMap.put(PayrollConstants.PFNO, map.get(PayrollConstants.PF_NO).asText());
		} else {
			genericMap.put(PayrollConstants.PFNO, "-");
		}
		if (map.get(PayrollConstants.PF_UAN) != null) {
			genericMap.put(PayrollConstants.PFUAN, map.get(PayrollConstants.PF_UAN).asText());
		} else {
			genericMap.put(PayrollConstants.PFUAN, "-");
		}
		if (map.get(PayrollConstants.ESI__NO) != null) {
			genericMap.put(PayrollConstants.ESI_NO, map.get(PayrollConstants.ESI__NO).asText());
		} else {
			genericMap.put(PayrollConstants.ESI_NO, "-");
		}
		if (map.get(PayrollConstants.PAN__NO) != null) {
			genericMap.put(PayrollConstants.PAN_NO, map.get(PayrollConstants.PAN__NO).asText());
		} else {
			genericMap.put(PayrollConstants.PAN_NO, "-");
		}

		genericMap.put(PayrollConstants.LOP, map.get(PayrollConstants.LOP).asText());

		genericMap.put(PayrollConstants.EARNINGS, PayrollConstants.ACTUAL);
		genericMap.put(PayrollConstants.DEDUCTIONS, PayrollConstants.ACTUAL);

		Map<String, String> earningMap = new HashMap<>();
		Map<String, String> deductionMap = new HashMap<>();

		JsonNode jsonNode = objectMapper.readTree(salaryComponents.getEarningJsonData());

		Iterator<Entry<String, JsonNode>> fields = jsonNode.fields();

		while (fields.hasNext()) {
			Entry<String, JsonNode> fields2 = fields.next();
			String key = fields2.getKey();

			JsonNode value = fields2.getValue();

			String formattedValue = PayrollUtility.formattedValue(Double.parseDouble(value.asText()));

			earningMap.put(key, formattedValue);

		}

		JsonNode jsonNode1 = objectMapper.readTree(salaryComponents.getDeductionJsonData());

		Iterator<Entry<String, JsonNode>> fields1 = jsonNode1.fields();

		while (fields1.hasNext()) {
			Entry<String, JsonNode> fields2 = fields1.next();
			String key = fields2.getKey();

			JsonNode value = fields2.getValue();

			String formattedValue = PayrollUtility.formattedValue(Double.parseDouble(value.asText()));

			deductionMap.put(key, formattedValue);

		}

		payslipGenerationDTO1.setPayslipFields(genericMap);
		payslipGenerationDTO1.setEarningMap(earningMap);
		payslipGenerationDTO1.setDeductionMap(deductionMap);

		String formattedTotalEarnings = PayrollUtility
				.formattedValue(Double.parseDouble(map.get(PayrollConstants.TOTAL_EARNINGS_INR).asText()));
		payslipGenerationDTO1.setTotalEarnings(formattedTotalEarnings);

		String formattedTotalDeductions = PayrollUtility
				.formattedValue(Double.parseDouble(map.get(PayrollConstants.TOTAL_DEDUCTIONS_INR).asText()));
		payslipGenerationDTO1.setTotalDeductions(formattedTotalDeductions);

		String formattedTotalNetPay = PayrollUtility
				.formattedValue(Double.parseDouble(map.get(PayrollConstants.NET_PAY_FOR_THE_MONTH).asText()));
		payslipGenerationDTO1.setNetPay(formattedTotalNetPay);

		return payslipGenerationDTO1;

	}

	@Override
	public void downloadPaySlip(Long salaryComponentId) {
		try {
			Optional<SalaryComponents> component = salaryComponentsRepository.findById(salaryComponentId);
			if (component.isPresent()) {
				SalaryComponents salaryObj = component.get();
				Document document = new Document();
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
				document.open();
				pdfGenerateUtil(salaryObj.getEmployee().getId(), salaryObj.getPaySlipOfMonth(), document, writer);
				String str = salaryObj.getEmployee().getId() + "," + salaryObj.getPaySlipOfMonth();
				document.close();
				logger.info("Payslip downloaded sucessfully for month woth employee Id:{}", str);
			}
		} catch (Exception e) {
			logger.info("Error while generating payslip:{}", e.getMessage());
			throw new NotFoundException(e.getMessage());
		}
	}
}
