package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.entity.Country;

public interface CountryService {
	
	public List<Country> findAll();

	public Country findCountry(Long id);

	public List<Country> readCountriesDataFromJson();

}
