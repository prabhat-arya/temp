package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.LeaveTypeDTO;

public interface LeaveTypeService {

	public List<EntityDTO> save(LeaveTypeDTO branch);

	public Map<String, Object> getAllLeaves(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String isActive, String companyId);

	public LeaveTypeDTO getById(Long id, String companyId);

	public List<EntityDTO> updateLeave(LeaveTypeDTO model, Long id);

	public List<LeaveTypeDTO> AllLeavesTypes(String companyId);

	public List<EntityDTO> updateLeaveTypeByStatus(Long id, String status);
	
	public List<EntityDTO> softDeleteLeaveType(Long id);

	public boolean validate(LeaveTypeDTO leaveType, boolean isSave);
}

