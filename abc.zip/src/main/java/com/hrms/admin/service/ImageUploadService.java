package com.hrms.admin.service;

public interface ImageUploadService {

}
