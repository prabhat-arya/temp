package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.IdFormatDTO;

public interface IdFormatService {

	public List<EntityDTO> saveIdFormat(IdFormatDTO model);
	
	public boolean deleteIdFormat(Long customEmpId);
	
	public List<EntityDTO> updateIdFormat(IdFormatDTO model,Long customEmpId);
	
	public IdFormatDTO findByIdFormat(Long customEmpId);
	
}
