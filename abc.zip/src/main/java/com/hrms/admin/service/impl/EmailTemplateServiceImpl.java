package com.hrms.admin.service.impl;

import java.io.IOException;
import java.security.Principal;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

import com.hrms.admin.dto.EmailTemplateDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.EmailTemplate;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.repository.EmailTemplateRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.service.EmailTemplateService;

@Service
public class EmailTemplateServiceImpl implements EmailTemplateService {

	private static Logger logger = LoggerFactory.getLogger(EmailTemplateServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepository;

//	@Autowired
//	private SequenceGeneratorUtil seqGeneratorService;

	@Autowired
	private EmailTemplateRepository emailTemplateRepo;

	@Override
	public List<EntityDTO> saveTemplate(EmailTemplateDTO emailTemplateDto, Principal principal, Long empId, String companyId)
			throws IOException, SerialException, SQLException {

		String empName = principal.getName();
		Optional<Employee> emp = employeeRepository.getByUserName(empName,companyId);
		if(emp.isPresent()) {
			emailTemplateDto.setFrom(emp.get().getOfficalMail());
		}
		EmailTemplate emailTemplate = new EmailTemplate();
	//	emailTemplate.setId(seqGeneratorService.generateSequence(EmailTemplate.SEQUENCE_NAME));
		emailTemplate.setFrom(emailTemplateDto.getFrom());
		emailTemplate.setSubject(emailTemplateDto.getSubject());
		byte[] buff = emailTemplateDto.getPlainText().getBytes();
		Blob blob = new SerialBlob(buff);
		
		
		emailTemplate.setPlainText(blob);
		emailTemplate.setTemplateName(emailTemplateDto.getTemplateName());
		emailTemplate.setEmpId(empId);

//		EmailTemplate insert = emailTemplateRepo.insert(emailTemplate);
		EmailTemplate insert = emailTemplateRepo.save(emailTemplate);

		EntityDTO dto = new EntityDTO();
		dto.setId(insert.getId());
		dto.setName(insert.getSubject());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);

		return list;

	}

	@Override	
	public EmailTemplateDTO getEmailTemplateByEmpId(Long empId, String templateName) throws SQLException {

		EmailTemplate emailTemp = emailTemplateRepo.findByEmpIdAndTemplateName(empId, templateName);
		if (emailTemp == null) {
			return null;
		}
		EmailTemplateDTO model = new EmailTemplateDTO();
		model.setId(emailTemp.getId());
		model.setFrom(emailTemp.getFrom());
		Blob blob = emailTemp.getPlainText();
		byte[] bdata = blob.getBytes(1, (int) blob.length());
		String s = new String(bdata);
		model.setPlainText(s);
		model.setSubject(emailTemp.getSubject());
		model.setTemplateName(emailTemp.getTemplateName());

		logger.info("Email Template found with EmployeeId:{}", empId);
		return model;

	}

	@Override
	public List<EntityDTO> updateByEmpId(EmailTemplateDTO model, Long empId, String templateName) throws SerialException, SQLException {
		EmailTemplate emailTemp1 = emailTemplateRepo.findByEmpIdAndTemplateName(empId, templateName);
		List<EntityDTO> list = new ArrayList<>();
		if (emailTemp1 != null) { 
			logger.info("Email Template is found from database with emplyeeId:{}",empId);
			emailTemp1.setFrom(model.getFrom());
			byte[] buff = model.getPlainText().getBytes();
			Blob blob = new SerialBlob(buff);
			emailTemp1.setPlainText(blob);
			emailTemp1.setSubject(model.getSubject());
			emailTemp1.setTemplateName(model.getTemplateName());
			EmailTemplate emailTe = emailTemplateRepo.save(emailTemp1);
			logger.info("Email Template is updated in database with employeeId:{}",empId);
			EntityDTO dto = new EntityDTO();
			dto.setId(emailTe.getId());
			dto.setName(emailTe.getSubject());
			list.add(dto);
			return list;
		}
		return list;
	}

}
