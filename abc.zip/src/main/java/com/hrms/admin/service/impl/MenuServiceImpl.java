package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Menu;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.service.MenuService;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuRepository menuRepo;
	
	@Override
	public MenuSortingDTO getByMenu(Long menuId) {
		Menu menus = menuRepo.findByMenuId(menuId);

		MenuSortingDTO sortedMenu = new MenuSortingDTO(menus.getMenuTitle(), menus.getMenuIcon(), menus.getMenuPath(), menus.getMenuId());
		List<Menu> childMenus = menuRepo.findAll();
		List<MenuSortingDTO> childs = new ArrayList<>();
		for (Menu childMenu : childMenus) {


			MenuSortingDTO childMenu1 = new MenuSortingDTO();
			if (menus.getMenuId().equals(childMenu.getParentId()) && menus.getMenuId() != 0) {
				childMenu1 = new MenuSortingDTO(childMenu.getMenuTitle(), childMenu.getMenuIcon(), childMenu.getMenuPath(), childMenu.getMenuId());
				childs.add(childMenu1);
			}
		}
		sortedMenu.setChilds(childs);
		return sortedMenu;
	}
	
	public List<MenuSortingDTO> getMenusByGroup(Set<Menu> menuSet) {
		
		List<MenuSortingDTO> parentMenu = new ArrayList<>();
		for (Menu menu : menuSet) {
			if(menu.getIsParent() == 1) {
				MenuSortingDTO parentMenuDto = new MenuSortingDTO();
				parentMenuDto.setMenuIcon(menu.getMenuIcon());
				parentMenuDto.setMenuPath(menu.getMenuPath());
				parentMenuDto.setMenuTitle(menu.getMenuTitle());
				parentMenuDto.setId(menu.getMenuId());
				parentMenu.add(parentMenuDto);
				
			}
		}
		for (MenuSortingDTO parentMenuDto : parentMenu) {
			
			List<MenuSortingDTO> childMenuDtoList = new ArrayList<>();
			for (Menu menu : menuSet) {
				
				MenuSortingDTO childMenuDto = new MenuSortingDTO();
				if(menu.getParentId().equals(parentMenuDto.getId())) {
					childMenuDto.setId(menu.getMenuId());
					childMenuDto.setMenuTitle(menu.getMenuTitle());
					childMenuDto.setMenuPath(menu.getMenuPath());
					childMenuDto.setMenuIcon(menu.getMenuIcon());
					childMenuDtoList.add(childMenuDto);
				}
				
			}
			parentMenuDto.setChilds(childMenuDtoList);
		}
		return parentMenu;
	}
	
	public List<MenuSortingDTO> removeDuplicates(List<MenuSortingDTO> menuDtoList) {
		
		Set<MenuSortingDTO> menuSet = new HashSet<>();
		List<MenuSortingDTO> menuList = new ArrayList<>();
		for (MenuSortingDTO menuSortingDTO : menuSet) {
			menuDtoList.add(menuSortingDTO);
		}
		for (MenuSortingDTO menuSortingDTO : menuSet) {
			menuList.add(menuSortingDTO);
		}
		return menuList;
	}
}
