package com.hrms.admin.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EmployeeOccasionDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.service.OccasionNotificationService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmployeeServiceUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OccasionNotificationServiceImpl implements OccasionNotificationService {

	
	@Autowired
	private EmployeeRepository repo;

	@Autowired
	private ProfileImageRepository profileRepo;

	@Autowired
	private EmployeeServiceUtil employeeServiceUtil;

	private static final long MILLIS_IN_A_DAY = (long) 1000 * 60 * 60 * 24;
	private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public List<EmployeeOccasionDTO> getOccasionNotification(String companyId) {
		List<EmployeeOccasionDTO> allOccasion = new ArrayList<>();
		List<EmployeeOccasionDTO> employeeOccasion = null;
		Date today = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(today);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if (dayOfWeek == 5) {
			// Today's Occasion
			employeeOccasion = empBirthday(today, Constants.BIRTHDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empMarriageDay(today, Constants.MARRIAGEDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empJoinningDay(today, Constants.JOINNINGDAY,companyId);
			allOccasion.addAll(employeeOccasion);

			// Saturday Occasion
			Date saturday = new Date(today.getTime() + MILLIS_IN_A_DAY);
			employeeOccasion = empBirthday(saturday, Constants.ADVANCE_BIRTHDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empMarriageDay(saturday, Constants.ADVANCE_MARRIAGEDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empJoinningDay(saturday, Constants.ADVANCE_JOINNINGDAY,companyId);
			allOccasion.addAll(employeeOccasion);

			// Sunday Occasion
			Date sunday = new Date(saturday.getTime() + MILLIS_IN_A_DAY);
			employeeOccasion = empBirthday(sunday, Constants.ADVANCE_BIRTHDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empMarriageDay(sunday, Constants.ADVANCE_MARRIAGEDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empJoinningDay(sunday, Constants.ADVANCE_JOINNINGDAY,companyId);
			allOccasion.addAll(employeeOccasion);

		} else {
			// Today's Occasion

			employeeOccasion = empBirthday(today, Constants.BIRTHDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empMarriageDay(today, Constants.MARRIAGEDAY,companyId);
			allOccasion.addAll(employeeOccasion);
			employeeOccasion = empJoinningDay(today, Constants.JOINNINGDAY,companyId);
			allOccasion.addAll(employeeOccasion);
		}
		return allOccasion;
	}

	List<EmployeeOccasionDTO> empBirthday(Date date2, String msg,String companyId) {
		List<EmployeeOccasionDTO> list = new ArrayList<>();
		List<Employee> findByBirthday = repo.findBirthday(date2,companyId);
		for (Employee employee : findByBirthday) {
			EmployeeOccasionDTO birthdayNotification = empOccasionNotificationResponse(employee, msg, date2);
			list.add(birthdayNotification);
		}
		return list;
	}

	List<EmployeeOccasionDTO> empMarriageDay(Date date2, String msg,String companyId) {
		List<EmployeeOccasionDTO> list = new ArrayList<>();
		List<Employee> empMarraigeDay = repo.findMarraigeDay(date2,companyId);
		for (Employee employee : empMarraigeDay) {
			EmployeeOccasionDTO marraigeDayNotification = empOccasionNotificationResponse(employee, msg, date2);
			list.add(marraigeDayNotification);
		}
		return list;
	}

	List<EmployeeOccasionDTO> empJoinningDay(Date date2, String msg,String companyId) {
		List<EmployeeOccasionDTO> list = new ArrayList<>();
		List<Employee> empJoinningDay = repo.findJoiningDay(date2,companyId);
		for (Employee employee : empJoinningDay) {
			EmployeeOccasionDTO joinningDayNotification = empOccasionNotificationResponse(employee, msg, date2);
			list.add(joinningDayNotification);
		}
		return list;
	}

	EmployeeOccasionDTO empOccasionNotificationResponse(Employee employee, String msg, Date date2) {

		EmployeeOccasionDTO empHasOccasion = new EmployeeOccasionDTO();
		empHasOccasion.setFirstName(employee.getFirstName());
		empHasOccasion.setLastName(employee.getLastName());
		empHasOccasion.setEmail(employee.getOfficalMail());
		empHasOccasion.setOccasionDay(dateFormat.format(date2));
		empHasOccasion.setOccasion(msg);

		List<ProfileImage> employeeImages = profileRepo.getEmployeeImages(employee.getId());
		if (!employeeImages.isEmpty()) {
			for (ProfileImage image : employeeImages) {
				if (image.getImageName().contains("100x100")) {
					String name = "100x100";
					ProfileImageDTO copyProfileImage = employeeServiceUtil.copyProfileImage(employee.getId(), name);
					empHasOccasion.setImage(copyProfileImage);
				} else {
					empHasOccasion.setImage(new ProfileImageDTO());
				}
			}
		}
		return empHasOccasion;
	}

	@Override
	@Cacheable(value = "getBirthDayNotification",unless = "#result.size() == 0")
	public List<EmployeeOccasionDTO> getBirthDayNotification(String companyId) {
		List<EmployeeOccasionDTO> allempOccasionon = getOccasionNotification(companyId);
		log.info("Employee birthday found in DataBase");
		List<EmployeeOccasionDTO> birthdayList = new ArrayList<>();
		for (EmployeeOccasionDTO employeeOccasionDTO : allempOccasionon) {
			String occasion = employeeOccasionDTO.getOccasion();
			if (occasion.equals(Constants.BIRTHDAY)) {
				birthdayList.add(employeeOccasionDTO);
			}
		}
		return birthdayList;
	}

	@Override
	@Cacheable(value = "getAllNotification",unless = "#result.size() == 0")
	public List<EmployeeOccasionDTO> getAllNotification(String companyId) {
		List<EmployeeOccasionDTO> allempOccasionon = getOccasionNotification(companyId);
		List<EmployeeOccasionDTO> list = new ArrayList<>();
		for (EmployeeOccasionDTO employeeOccasionDTO : allempOccasionon) {
			String occasion = employeeOccasionDTO.getOccasion();
			if (!occasion.equals(Constants.BIRTHDAY)) {
				list.add(employeeOccasionDTO);
			}
		}
		return list;

	}

}
