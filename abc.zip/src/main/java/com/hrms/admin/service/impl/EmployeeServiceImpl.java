package com.hrms.admin.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.hrms.admin.dto.BankDTO;
import com.hrms.admin.dto.EmployeeBankDTO;
import com.hrms.admin.dto.EmployeeBranchDTO;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeManagerDTO;
import com.hrms.admin.dto.EmployeeProfileDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmployeeRolesDTO;
import com.hrms.admin.dto.EmployeeTabularDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.FileNamesListDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.ManagerDTO;
import com.hrms.admin.dto.OfficeUseOnlyDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.Assets;
import com.hrms.admin.entity.BankDetails;
import com.hrms.admin.entity.Designation;
import com.hrms.admin.entity.EmergencyContactDetails;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeePromotional;
import com.hrms.admin.entity.FileDetails;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.entity.ProfessionalDetails;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.ResourceItems;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.fileuploaddownload.property.FileStorageProperties;
import com.hrms.admin.repository.AssetsRepository;
import com.hrms.admin.repository.BankRepository;
import com.hrms.admin.repository.Designationrepository;
import com.hrms.admin.repository.EmergencyContactDetailsRepository;
import com.hrms.admin.repository.EmployeePromotionalRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.FilesRepository;
import com.hrms.admin.repository.ProfessionalDetailsRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.repository.ResourceItemsRepository;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.util.AnnualLeavesUtil;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.EmployeeBulkUploadingUtil;
import com.hrms.admin.util.EmployeeDataUploadUtil;
import com.hrms.admin.util.EmployeeServiceUtil;
import com.hrms.admin.util.ImageUtils;
import com.hrms.admin.util.S3ServiceUtil;
import com.hrms.admin.util.StringToDateUtility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

//	private static final log log = logFactory.getlog(EmployeeServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private FilesRepository filerepo;

	@Autowired
	private EmployeeServiceUtil employeeServiceUtil;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private ResourceItemsRepository resourceItemsRepo;

	@Autowired
	private ProfileImageRepository profileRepo;

	@Autowired
	private AssetsRepository assetRepo;

	@Autowired
	private ImageUtils imageUtils;

	@Autowired
	private FileStorageProperties filepropertites;

	@Autowired
	private EmployeeDataUploadUtil empDataUploadutil;

	@Autowired
	private BankRepository bankRepo;

	@Autowired
	private PasswordEncoder encoder;
	@Autowired
	private AnnualLeavesUtil annualLeavesUtil;

	@Autowired
	private EmergencyContactDetailsRepository emergencyContactRepo;

	@Autowired
	private ProfessionalDetailsRepository profesionalRepo;

	@Autowired
	private EmployeePromotionalRepository promotionalRepo;
//	@Autowired
//	private PolicyRepository policyRepository;
	@Autowired
	private ProjectRepository projectRepo;
//
//	@Autowired
//	private GridFsTemplate gridFsTemplate;

	/*
	 * @Autowired private SequenceGeneratorUtil seqGeneratorService;
	 */
//	@Autowired
//	private EmployeeProfileImageRepository employeeProfileImageRepo;

	@Autowired
	private Designationrepository designationRepo;

	@Autowired
	private RolesRepository roleRepo;

	/*
	 * @Autowired private ShiftRepository shiftRepo;
	 * 
	 * @Autowired private AssignShiftRepository assihnShiftRepo;
	 */

	@Autowired
	private StringToDateUtility dateUtil;

	@Autowired
	private S3ServiceUtil s3serviceutil;

	@Autowired
	private EmployeeBulkUploadingUtil employeeBulkUploadingUtil;

	@Value("${file.s3UploadImg}")
	private String folderpath;

	@Value("${user.login.link}")
	private String userLoginLink;

	@Value("${aws.bucket}")
	private String bucketName;

	@Value("${cloud.dbname}")
	private String envName;

	@Value("${aws.bucket.employeefolder}")
	private String employeeFolderName;

	@PostConstruct
	public void init1() {
		String name = s3serviceutil.createFolder(employeeFolderName);
		log.info("folder created in s3 bucket ::{}", name);
	}

	@PostConstruct
	public void init() {
		Path fileStorageLocation = Paths.get(filepropertites.getS3UploadImg()).toAbsolutePath().normalize();
		try {
			Files.createDirectories(fileStorageLocation);
			log.info("folder created in application dir");
		} catch (Exception ex) {
			log.error(" Error while folder creating in application dir :{}", ex.getMessage());
			throw new RuntimeException("Could not create the directory where the uploaded files will be stored");
		}
	}

	/**
	 * @param employee id
	 * @return employee data
	 */
	@Override
	@Cacheable(value = "getEmployeeByIdCache", unless = "#result == null", key = "#id")
	public List<EmployeeDTO> getEmployeeById(Long id) {
		log.info("getEmployeeById method Stared");
		Optional<Employee> optionalEntity = employeeRepo.findById(id);
		List<EmployeeDTO> list = new ArrayList<>();
		if (!optionalEntity.isPresent()) {
			return list;
		}
		Employee employee = optionalEntity.get();
		EmployeeDTO employeedto = employeeServiceUtil.getEmployee(employee);
		log.info("Employee found with ID:{}", id);
		list.add(employeedto);
		return list;
	}

	/**
	 * @param employee id, Status
	 * @return status updated or not
	 */
	@Override
	public List<EntityDTO> updateEmployeeByStatus(Long id, String status) {
		EntityDTO dto = new EntityDTO();
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> findById = employeeRepo.findById(id);
		if (!findById.isPresent()) {
			return list;
		} else {
			Employee emp = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				emp.setIsActive(Boolean.TRUE);
				Employee e = employeeRepo.save(emp);
				dto.setId(e.getId());
				dto.setName(e.getFirstName());
				list.add(dto);
				log.info("Employee is activated in database with Id:{}", id);

			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				emp.setIsActive(Boolean.FALSE);
				Employee e = employeeRepo.save(emp);
				dto.setId(e.getId());
				dto.setName(e.getFirstName());
				list.add(dto);
				log.info("Employee is deactivated in database with Id:{}", id);
			}
		}
		log.info("Employee is failed to activated or deactivated in database with Id:{}", id);
		return list;
	}

	/*
	 * // list for who need to approve form admin
	 * 
	 * @Cacheable(value = "appliedListCache", unless = "#result.size() == 0") public
	 * List<Employee> appliedList() { log.info("Employee List found::"); return
	 * employeeRepo.findAllByIsApprove(Boolean.FALSE); }
	 */

	/**
	 * @param employeeid
	 * @return employee approved or not
	 */
	// approve employee by id
	public List<EntityDTO> approveById(Long id) {
		Optional<Employee> optional = employeeRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!optional.isPresent()) {
			return list;
		}
		Employee employee = optional.get();
		/*
		 * if (Boolean.TRUE.equals(employee.getIsApprove())) {
		 * employee.setIsActive(Boolean.TRUE); Employee employeesave =
		 * employeeRepo.save(employee); log.info("Employeeis already Approved:{}",
		 * employee.getId()); EntityDTO dto = new EntityDTO();
		 * dto.setId(employeesave.getId()); dto.setName(Constants.APPROVED);
		 * list.add(dto); return list; }
		 */
		String password = emailServiceUtil.generateCommonLangPassword();
		employee.setPassword(encoder.encode(password));
		employee.setIsActive(Boolean.TRUE);
		employee.setIsApprove(Boolean.TRUE);
		/*
		 * List<Policy> policyList =
		 * policyRepository.findByCompany(employee.getCompany().getId()); if
		 * (!policyList.isEmpty()) { employee.setPolicies(policyList); }
		 */
		Optional<Project> optionalProject = projectRepo.getProjectsList("Default Bench", employee.getCompany().getId());
		if (optionalProject.isPresent()) {
			Project project = optionalProject.get();
			List<Project> projectList = new ArrayList<>();
			projectList.add(project);
			employee.setProjects(projectList);
		}

//		Shift shift = shiftRepo.findByShiftName("General Shift", employee.getCompany().getId());
//		if (!Objects.isNull(shift)) {
//			AssignShift entity = new AssignShift();
//			entity.setEmployeeName(employee.getFirstName() + " " + employee.getLastName());
//			entity.setShift(shift);
//			entity.setShiftName(shift.getShiftName());
//			entity.setEmployee(employee);
//			if (optionalProject.isPresent()) {
//				Project p = optionalProject.get();
//				entity.setFromDate(p.getStartDate());
//				entity.setToDate(p.getEndDate());
//				entity.setProjectName(p.getName());
//				entity.setProjectId(p.getId());
//			}
//			entity.setManagerId(employee.getManager().getId());
//			entity.setIsDelete(Boolean.FALSE);
//			assihnShiftRepo.save(entity);
//		}

		Employee employeesavenew = employeeRepo.save(employee);
		annualLeavesUtil.addingAnnualLeaves(employeesavenew);
		annualLeavesUtil.addIntialLeavesForNewJoinee(employeesavenew.getId());
		log.info("policies in the company,Default project annual leaves added for the approved employee");

		EntityDTO dto = new EntityDTO();
		dto.setId(employeesavenew.getId());
		dto.setName(employeesavenew.getFirstName());
		list.add(dto);

		MailDTO request = new MailDTO();
		request.setTo(employee.getEmail());
		request.setSubject("Welcome to" + " " + employee.getCompany().getName());
		request.setName(employee.getFirstName());
		request.setTemplate(Constants.TEMPLATE_NAME);
		request.setFrom(Constants.MAIL_FROM);
		request.setCompanyId(employee.getCompany().getId());
		String url = (userLoginLink);
		Map<String, Object> model = new HashMap<>();
		String name = employee.getFirstName();
		model.put(Constants.TEMPPASS, password);
		model.put(Constants.USERNAME, employee.getUserName());
		model.put(Constants.URL, url);
		model.put(Constants.NAME, name);
		emailServiceUtil.sendEmail(request, model);
		log.info("Mail sended to the approved employee");
		return list;
	}

	/**
	 * @param employee id, file id
	 * @return file deleted or not
	 */
	@Override
	public List<EntityDTO> deleteEmployeeFile(Long id, Long fileId) {
		log.info("deleteEmployeeFile method started");
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> findById = employeeRepo.findById(id);
		if (!findById.isPresent()) {
			return list;
		}
		Employee employee = findById.get();
		Optional<FileDetails> findById2 = filerepo.findById(fileId);
		if (!findById2.isPresent()) {
			return list;
		}
		FileDetails file = findById2.get();
		if (!Objects.isNull(file)) {
			String folderName = employeeFolderName + Constants.SUFFIX + employee.getId();
			s3serviceutil.deleteFileFromFolder(file.getName(), folderName);
//			gridFsTemplate.delete(new Query(Criteria.where("_id").is(file.getFilePath())));
			filerepo.deleteById(fileId);
		}

		log.info("File Deleted in Data Base and S3 bucket with file Id:{}", fileId);

		EntityDTO dto = new EntityDTO();
		dto.setId(employee.getId());
		dto.setName(employee.getFirstName() + " " + employee.getLastName());
		list.add(dto);
		return list;
	}

	/**
	 * @param assets dto, employee id
	 * @return assets added or not to the particular employee
	 */
	@Override
	public List<EntityDTO> addResourceToEmployee(EmployeeDTO model, Long empId) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> empObj = employeeRepo.findById(empId);
		if (empObj.isPresent()) {
			Employee emp = empObj.get();
			List<ResourceItems> items = resourceItemsRepo.findAll();
			List<ResourceItems> findByEmployeeId = items.stream()
					.filter(c -> c.getEmployee().getId().equals(emp.getId())).collect(Collectors.toList());
			if (!findByEmployeeId.isEmpty()) {
				for (ResourceItems resources1 : findByEmployeeId) {
					resources1.setIsDelete(Boolean.TRUE);
					resourceItemsRepo.save(resources1);
				}
			}
			if (findByEmployeeId.isEmpty()) {
				List<ResourceItemsDTO> resourceItems2 = model.getResourceItems();
				for (ResourceItemsDTO dto : resourceItems2) {
					ResourceItems resourceItems1 = new ResourceItems();
					Optional<Assets> asset = assetRepo.findById(dto.getAssetId());
					if (!asset.isPresent()) {
						return list;
					}
					resourceItems1.setAsset(asset.get());
					resourceItems1.setValue(dto.getValue());
					resourceItems1.setEmployee(emp);
					resourceItems1.setIsDelete(Boolean.FALSE);
					resourceItemsRepo.save(resourceItems1);
				}
				emp.setPort(model.getPort());
				emp.setIpAddress(model.getIpAddress());
				Employee emp1 = employeeRepo.save(emp);
				EntityDTO dto = new EntityDTO();
				dto.setId(emp1.getId());
				dto.setName(emp1.getFirstName() + " " + emp1.getLastName());
				list.add(dto);
				return list;
			} else {
				for (ResourceItemsDTO rr : model.getResourceItems()) {
					Long modelAssetId2 = rr.getAssetId();
					ResourceItems resourceItems = new ResourceItems();
					for (ResourceItems resources : findByEmployeeId) {
						Long dbAssetId = resources.getAsset().getId();
						if (dbAssetId.equals(modelAssetId2)) {
							resourceItemsRepo.deleteById(resources.getId());
							Optional<Assets> asset = assetRepo.findById(rr.getAssetId());
							if (!asset.isPresent()) {
								return list;
							}
							resourceItems.setAsset(asset.get());
							resourceItems.setValue(rr.getValue());
							resourceItems.setEmployee(emp);
							resourceItems.setIsDelete(Boolean.FALSE);
							resourceItemsRepo.save(resourceItems);

						} else if (!dbAssetId.equals(modelAssetId2)) {
							Optional<Assets> asset = assetRepo.findById(rr.getAssetId());
							if (!asset.isPresent()) {
								return list;
							}
							resourceItems.setAsset(asset.get());
							resourceItems.setValue(rr.getValue());
							resourceItems.setEmployee(emp);
							resourceItems.setIsDelete(Boolean.FALSE);
							resourceItemsRepo.save(resourceItems);
						}
					}
				}
			}
			emp.setPort(model.getPort());
			emp.setIpAddress(model.getIpAddress());
			Employee emp1 = employeeRepo.save(emp);

			log.info("Resource allocated to employee in DB");
			EntityDTO dto = new EntityDTO();
			dto.setId(emp1.getId());
			dto.setName(emp1.getFirstName() + " " + emp1.getLastName());
			list.add(dto);
		}
		return list;

	}

	/**
	 * @param projectslist employee id
	 * @return projects added or not to the particular employee
	 */
	/** Update an Existing Employee with projects */
	@Transactional
	public List<EntityDTO> updateEmployeeProject(EmployeeDTO employeedto, Long id) {
		List<Project> projectlist = new ArrayList<>();
		List<EntityDTO> list = new ArrayList<>();
		EntityDTO dto = new EntityDTO();
		if (employeeRepo.findById(id).isPresent()) {
			Optional<Employee> employeeObj = employeeRepo.findById(id);
			if (employeeObj.isPresent()) {
				Employee employee = employeeObj.get();
				for (ProjectDTO projectdto : employeedto.getProjects()) {
					Project project = new Project();
					project.setId(projectdto.getId());
					project.setName(projectdto.getName());
					project.setDescription(projectdto.getDescription());
					projectlist.add(project);
				}
				employee.setProjects(projectlist);
				Employee savedEmployee = employeeRepo.save(employee);
				dto.setId(savedEmployee.getId());
				dto.setName(savedEmployee.getFirstName());
				list.add(dto);
				log.info("Employee is updated with projects:{}", id);
			}
		}
		return list;
	}

	/**
	 * @param pagination inputs
	 * @return employee page data
	 */
	@Override
	@Cacheable(value = "getAllEmployeePageCache", unless = "#result.size() == 0")
	public Map<String, Object> getAllEmployeePage(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, Long employmentTypeId, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Employee> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = employeeRepo.allEmployeePageList(searchKey, companyId, paging);
			if (employmentTypeId != null) {
				pagedResult = employeeRepo.allEmployeePageWithEmploymentType(searchKey, companyId, employmentTypeId,
						paging);
			}
		} else {
			if (isActive.equals("0")) {
				status = false;
				pagedResult = employeeRepo.employeePageList(searchKey, status, companyId, paging);
			}
			if (isActive.equals("1") && employmentTypeId == null) {
				status = true;
				pagedResult = employeeRepo.employeePageList(searchKey, status, companyId, paging);
			}
			if (isActive.equals("1") && employmentTypeId != null) {
				status = true;
				pagedResult = employeeRepo.employeePageWithEmploymentType(searchKey, status, companyId,
						employmentTypeId, paging);
			}

			if (isActive.equals("2")) {
				status = true;
				pagedResult = employeeRepo.employeePageIfIsExit(searchKey, status, companyId, paging);
			}
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	/**
	 * @param pagedResult
	 * @return employee data in page format
	 */
	public Map<String, Object> mapData(Page<Employee> pagedResult) {
		log.info("mapData method started");
		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeTabularDTO> employeeModels = pagedResult.stream().map(employee -> {
			EmployeeTabularDTO model = new EmployeeTabularDTO();
			model.setId(employee.getId());
			model.setFirstName(employee.getFirstName());
			model.setLastName(employee.getLastName());
			model.setOfficalMail(employee.getOfficalMail());
			model.setContactNo(employee.getContactNo());
			model.setDateOfBirth(employee.getDateOfBirth());
			model.setDesignationName(employee.getDesignation().getDesignation());
			model.setCompanyName(employee.getCompany().getName());
			model.setBranchName(employee.getBranch().getName());
			model.setDepartmentName(employee.getDepartment().getName());
			model.setReportingTo(employee.getManager().getFirstName() + " " + employee.getManager().getLastName());
			model.setPanCard(employee.getPanCard());
			model.setAadharCard(employee.getAadharCard());
			model.setBloodGroup(employee.getBloodGroup());
			model.setJoiningDate(employee.getJoiningDate());
			model.setUserName(employee.getUserName());
			EmergencyContactDetails emergencyDetails = emergencyContactRepo.basedOnEmployee(employee.getId());
			if (!Objects.isNull(emergencyDetails)) {
				model.setEmergencyContactNumber(emergencyDetails.getContactNumber());
				model.setEmergencyContactPerson(emergencyDetails.getContactPerson());
			}
			ProfessionalDetails profesional = profesionalRepo.basedOnEmployee(employee.getId());
			if (!Objects.isNull(profesional)) {
				model.setProfessionalCompanyName(profesional.getCompanyName());
				model.setProfessionalJoiningDate(profesional.getJoiningDate());
				model.setProfessionalDateOfRelieving(profesional.getRelievingDate());
				model.setProfessionalExperience(profesional.getExperience());
				model.setProfessionalClientName(profesional.getClient());
			}
			EmployeePromotional promotional = promotionalRepo.basedOnEmployee(employee.getId());
			if (!Objects.isNull(promotional)) {
				model.setEmpDesignation(promotional.getEmpDesignation());
				model.setPromotionStartDate(promotional.getPromotionStartDate());
			}
			String name = "100x100";
			ProfileImageDTO copyProfileImage = employeeServiceUtil.copyProfileImage(employee.getId(), name);
			model.setProfileImageUrl(copyProfileImage.getImageurl());
			model.setIsActive(employee.getIsActive());
			model.setIsApprove(employee.getIsApprove());
			model.setIsDelete(employee.getIsDelete());
			model.setIsExit(employee.getIsExit());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, employeeModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * @param policiesdto employee id
	 * @return policies added or not to the particular employee
	 */
	@Transactional
	public List<EntityDTO> updateEmployeePolicies(EmployeeDTO employeedto, Long id) {
		EntityDTO dto = new EntityDTO();
		List<EntityDTO> listresult = new ArrayList<>();
		List<Policy> plocylist = new ArrayList<>();
		Optional<Employee> findById = employeeRepo.findById(id);
		if (findById.isPresent()) {
			Employee employee = findById.get();
			for (PolicyDTO policydto : employeedto.getPolicies()) {
				Policy policy = new Policy();
				policy.setId(policydto.getId());
				policy.setName(policydto.getName());
				policy.setDescription(policydto.getDescription());
				plocylist.add(policy);
			}
			employee.setPolicies(plocylist);
			Employee savedEmployee = employeeRepo.save(employee);
			dto.setId(savedEmployee.getId());
			dto.setName(savedEmployee.getFirstName());
			listresult.add(dto);
		}
		return listresult;
	}

	/**
	 * @param branch id
	 * @return list employees in database with related branch
	 */
	@Override
	@Cacheable(value = "getEmployeeByBranchIdCache", unless = "#result.size() == 0", key = "#branchId")
	public List<EmployeeBranchDTO> getEmployeeByBranchId(Long branchId, String companyId) {
		log.info("getEmployeeByBranchId method started");
		List<EmployeeBranchDTO> findByCompanyIdAndBranchId = employeeRepo.findByBranchId(branchId, companyId);
		log.info("getEmployeeByBranchId method ended");
		return findByCompanyIdAndBranchId;
	}

	/**
	 * @return list employees in database
	 */
	@Override
	@Cacheable(value = "listOfEmployee", unless = "#result.size() == 0")
	public List<EmployeeInfoDTO> listOfEmployee(String companyId) {
		log.info("listOfEmployee method started");
		List<EmployeeInfoDTO> all = new ArrayList<>();
		/*
		 * Optional<Employee> findByUserName; Object principal =
		 * SecurityContextHolder.getContext().getAuthentication().getPrincipal(); String
		 * username = ((UserDetails) principal).getUsername(); if (username != null) {
		 * findByUserName = employeeRepo.findByUserName(username); if
		 * (findByUserName.isPresent())
		 */
//				all = employeeRepo.findEmp(findByUserName.get().getCompany().getId());
		all = employeeRepo.findEmp(companyId);
		return all;
		/*
		 * } else { all = employeeRepo.find(); return all; }
		 */

	}

	/**
	 * @param emp id
	 * @return success or failure massage
	 */
	public List<EntityDTO> softDeleteEmployee(Long id) {
		Optional<Employee> findById = employeeRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Employee employee = findById.get();
		employee.setIsActive(Boolean.FALSE);
		employee.setIsDelete(Boolean.TRUE);
		Employee p = employeeRepo.save(employee);
		log.info("Employee is SoftDeleted in database with id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getFirstName());
		list.add(dto);
		return list;
	}

	@Override
	public Long getAllEmpCountBasedOnBranch(Long branchId, String companyId) {
		return employeeRepo.getAllEmpCountBasedOnBranch(branchId, companyId);
	}

	/**
	 * @param emp id emp data
	 * @return success or failure massage
	 */
	@Override
	public List<EntityDTO> saveEmployeeInfo(EmployeeInfoDTO employeedto) {
		Employee employee1 = employeeServiceUtil.saveEmployee(employeedto);
		List<EntityDTO> list = new ArrayList<>();
		if (Objects.isNull(employee1)) {
			return list;
		}
		EntityDTO dto = new EntityDTO();
		dto.setId(employee1.getId());
		dto.setName(employee1.getFirstName() + " " + employee1.getLastName());
		list.add(dto);
		return list;
	}

	/**
	 * @param emp id emp data
	 * @return success or failure massage
	 */
	@Override
	public List<EntityDTO> updateEmplyeeInfo(Long id, EmployeeInfoDTO employeedto) {
		Employee employee = employeeServiceUtil.updateEmplyee(employeedto, id);
		List<EntityDTO> list = new ArrayList<>();
		if (Objects.isNull(employee)) {
			return list;
		}
		EntityDTO dto = new EntityDTO();
		dto.setId(employee.getId());
		dto.setName(employee.getFirstName() + " " + employee.getLastName());
		list.add(dto);
		log.info("Employee updated into database");
		return list;
	}

	/**
	 * @param employee documents,profile image,employee id
	 * @return upload success or failure massege
	 * @throws Exception
	 */
	@Override
	public List<EntityDTO> updateEmployeeFiles(Long id, MultipartFile[] files, MultipartFile image,
			List<FileNamesListDTO> fileJsonList) throws Exception {

		Optional<Employee> findById = employeeRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Employee employee = findById.get();
			String folderName = employeeFolderName + Constants.SUFFIX + employee.getId();
			s3serviceutil.createFolder(folderName);
			if (!Objects.isNull(files)) {
				// storing files details in database

				List<FileDetails> filesList = copyFilesData(employee, files, folderName, fileJsonList);
				filerepo.saveAll(filesList);
			}
			if (!Objects.isNull(image)) {
				String imageName = image.getOriginalFilename();
				imageName = FilenameUtils.removeExtension(imageName);
				imageName = imageName.replaceAll("[^a-zA-Z]", "");
				imageName = imageName + "." + FilenameUtils.getExtension(image.getOriginalFilename());
				String fileName = imageName.replace("." + FilenameUtils.getExtension(image.getOriginalFilename()), "");
				String imageName800x600 = fileName + "_" + "800x600" + "."
						+ FilenameUtils.getExtension(image.getOriginalFilename());
				String imageName100x100 = fileName + "_" + "100x100" + "."
						+ FilenameUtils.getExtension(image.getOriginalFilename());
				List<ProfileImage> profileList = profileRepo.getEmployeeImages(id);
				if (!profileList.isEmpty()) {
					for (ProfileImage profileImage : profileList) {
						s3serviceutil.deleteFileFromFolder(profileImage.getImageName(), folderName);
//						employeeProfileImageRepo.deleteById(profileImage.getImageurl());
						profileRepo.deleteById(profileImage.getId());
					}
				}

				byte[] bytes = image.getBytes();

				Path path = Paths.get(folderpath + Constants.SUFFIX + imageName);
				Files.write(path, bytes);
				String uri = path.toString();
				List<ProfileImage> profileImageList = new ArrayList<>();
				// for actual size image
				ProfileImage copyImageData = copyImageData(employee, imageName, image, folderName);
				profileImageList.add(copyImageData);

				// for 800 x600 size image
				imageUtils.resize(uri, 600, 800, FilenameUtils.getExtension(image.getOriginalFilename()),
						imageName800x600);
				MultipartFile file800x600 = imageUtils.file(imageName800x600, image.getContentType());
				ProfileImage employeeProfileImage800x600 = copyImageData(employee, imageName800x600, file800x600,
						folderName);
				profileImageList.add(employeeProfileImage800x600);

				// for 100 x100 size image
				imageUtils.resize(uri, 100, 100, FilenameUtils.getExtension(image.getOriginalFilename()),
						imageName100x100);
				MultipartFile file100x100 = imageUtils.file(imageName100x100, image.getContentType());
				ProfileImage employeeProfileImage100x100 = copyImageData(employee, imageName100x100, file100x100,
						folderName);
				profileImageList.add(employeeProfileImage100x100);

				imageUtils.deleteAllTempFiles();
				log.info("Employee ProfileImage added into s3 bucket" + " :: ", imageName);
				profileRepo.saveAll(profileImageList);
			}
			log.info("Employee Added into database");

			EntityDTO dto = new EntityDTO();
			dto.setId(employee.getId());
			dto.setName(employee.getFirstName() + " " + employee.getLastName());
			list.add(dto);
			return list;
		} else {
			return list;
		}
	}

	/**
	 * @return employee exist or not in database
	 */
	@Override
	public boolean validate(EmployeeInfoDTO model, boolean isSave) {
		log.info("validate method started");
		Long count;
		if (isSave) {
			count = employeeRepo.getEmployeeSaveCount(model.getCompanyId(), model.getUserName(), model.getEmail(),
					model.getContactNo());
		} else {
			count = employeeRepo.getEmployeeUpdadateCount(model.getCompanyId(), model.getUserName(), model.getEmail(),
					model.getContactNo(), model.getId());
		}
		log.info("validate method ended");
		return count > 0;
	}

	/**
	 * @param EmployeeInfoDTO employee data
	 * @return if academic year duplicated then it return true
	 */
//	@Override
//	public boolean validateacadimicYear(EmployeeInfoDTO model) {
//		log.info("validate method started");
//		List<AcademicDetailsDTO> academicDetails = model.getAcademicDetails();
//		List<String> years=new ArrayList<>();
//		Set<String> uniques = new HashSet<>();
//		for (AcademicDetailsDTO academicDetailsDTO: academicDetails) {
//			String yearOfPassing = academicDetailsDTO.getYearOfPassing();
//			years.add(yearOfPassing);
//		}
//		Set<String> collect = years.stream().filter(e -> !uniques.add(e)).collect(Collectors.toSet());
//		return collect.size() != 0;
//	}

	/**
	 * @param employee id employee data
	 * @return update success or failure massege
	 */
	@Override
	public List<EntityDTO> updateEmplyeeOfficeUseDetails(Long id, OfficeUseOnlyDTO model) {
		List<EntityDTO> list = employeeServiceUtil.saveEmployeeOfficeUseOnlyDetails(model, id);
		log.info("update Office details in Database");
		return list;
	}

	/**
	 * @param employee id
	 * @return employee info based on employee id
	 */
	@Override
	@Cacheable(value = "getEmployeeProfileDetailsCache", unless = "#result == null", key = "#id")
	public EmployeeProfileDTO getEmployeeProfileDetails(Long id) {
		EmployeeProfileDTO dto = employeeServiceUtil.getEmployeeProfileDetails(id);
		if (Objects.isNull(dto)) {
			return null;
		}
		return dto;
	}

	/**
	 * @param employee id employee data
	 * @return update success or failure massege
	 */
	@Override
	public List<EntityDTO> updateEmployeeProfileDetails(Long id, EmployeeProfileDTO dto) {
		List<EntityDTO> list = employeeServiceUtil.updateEmployeeProfileDetails(id, dto);
		return list;
	}

	/**
	 * @param Excel file
	 * @return success and failure count of uploaded records
	 */
	@Transactional
	public List<Map<String, Integer>> saveEmpDatafromUploadedfile(MultipartFile file) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readOnBoardEmployeeDataFromExecl(file);
		}
		return result;
	}

	/**
	 * @param Excel file
	 * @return success and failure count of uploaded records
	 */
	@Transactional
	public List<Map<String, Integer>> saveEmpProfessionalDetailsDatafromUploadedfile(MultipartFile file,
			String companyId) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeeProfessionalDetailsDataFromExecl(file, companyId);
		}
		return result;
	}

	/**
	 * @param Excel file
	 * @return success and failure count of uploaded records
	 */
	@Override
	@Transactional
	public List<Map<String, Integer>> saveEmpOfficeUseDataDatafromUploadedfile(MultipartFile file, String companyId)
			throws IllegalAccessException {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeeOfficeUseDataFromExecl(file, companyId);
		}
		return result;
	}

	/**
	 * @param take pagination api inputs
	 * @return call mapdata api to set data in required format
	 */
	@Cacheable(value = "getAllEmployeeBankDetailsPageCache", unless = "#result.size() == 0")
	public Map<String, Object> getAllEmployeeBankDetailsPage(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = null;
		if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			Page<Employee> pagedResult = employeeRepo.findAllEmployeeBankDetails(searchKey, companyId, paging);
			return bankMapData(pagedResult);
		} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			Page<Employee> pagedResult = employeeRepo.findAllEmployeeBankDetails(searchKey, companyId, paging);
			return bankMapData(pagedResult);
		}
		return new HashMap<String, Object>();

	}

	/**
	 * 
	 * @param pagedResult
	 * @return employee bank details in page format
	 */
	public Map<String, Object> bankMapData(Page<Employee> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeBankDTO> employeeModels = pagedResult.stream().map(employee -> {
			EmployeeBankDTO model = new EmployeeBankDTO();
			model.setId(employee.getId());
			model.setFirstName(employee.getFirstName());
			model.setLastName(employee.getLastName());
			model.setCtc(employee.getCtc());
			BankDetails bank = bankRepo.findByEmployee(employee.getId());
			if (!Objects.isNull(bank)) {
				BankDTO bankdto = new BankDTO();
				bankdto.setId(bank.getId());
				bankdto.setAccountHolderName(bank.getAccountHolderName());
				bankdto.setAccountNo(bank.getAccountNo());
				bankdto.setBankName(bank.getBankName());
				bankdto.setBranchName(bank.getBranchName());
				bankdto.setIfscCode(bank.getIfscCode());
				bankdto.setUanNumber(bank.getUanNumber());
				bankdto.setPfNumber(bank.getPfNumber());
				bankdto.setEsicNumber(bank.getEsicNumber());
				model.setBank(bankdto);
			}
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, employeeModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * @param Excel file
	 * @return success and failure count of uploaded records
	 */
	@Override
	@Transactional
	public List<Map<String, Integer>> saveEmpMailIdsfromUploadedfile(MultipartFile file, String companyId)
			throws IllegalAccessException {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeeOfficeMailIdsFromExecl(file, companyId);
		}
		return result;
	}

	/**
	 * @param employee id
	 * @return list projects assigned to employee
	 */
	@Override
	@Cacheable(value = "getEmployeeProjectsCache", unless = "#result.size() == 0", key = "#id")
	public List<EmployeeProjectsDTO> getEmployeeProjects(Long id) {
		Optional<Employee> employee = employeeRepo.findById(id);
		List<EmployeeProjectsDTO> list = new ArrayList<>();
		if (employee.isPresent()) {
			Employee emp = employee.get();
			if (!emp.getProjects().isEmpty()) {
				for (Project project : emp.getProjects()) {
					EmployeeProjectsDTO projectdto = new EmployeeProjectsDTO();
					projectdto.setProjectId(project.getId());
					projectdto.setProjectName(project.getName());
					list.add(projectdto);
				}
				log.info("employee projects found with name:{}", emp.getFirstName());
				return list;
			} else {
				list.add(new EmployeeProjectsDTO());
				log.info("employee not projects found with name:{}", emp.getFirstName());
				return list;
			}
		} else {
			log.info("employee not present in DB with id:{}", id);
			return list;
		}
	}

	/**
	 * @return list of employees report in csv format file
	 */
	public ICsvBeanWriter createEmployeeDataCSVFIle(HttpServletResponse response, String companyId) {
		try {
			List<EmployeeInfoDTO> listemploye = listOfEmployee(companyId);
			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Employee ID", " Employee Name", "Email", "User Name", "Date Of Birth",
					"Marital Status", "Contact Number", "Aadhar Card", "Pan Card", "Joining Date", "Blood Group",
					"Designation" };
			String[] nameMapping = { "id", "name", "officalMail", "userName", "csvDateOfBirth", "maritalStatus",
					"contactNo", "aadharCard", "panCard", "csvJoiningDate", "bloodGroup", "designationName" };
			csvWriter.writeHeader(csvHeader);
			for (EmployeeInfoDTO employee : listemploye) {
				employee.setName(employee.getFirstName().concat(" ").concat(employee.getLastName()));
				employee.setCsvDateOfBirth(dateUtil.changeDateFormat(employee.getDateOfBirth()));
				employee.setCsvJoiningDate(dateUtil.changeDateFormat(employee.getJoiningDate()));
				csvWriter.write(employee, nameMapping);
			}
			csvWriter.close();
			return csvWriter;
		} catch (Exception e) {
			throw new NotFoundException(Constants.FILE_GENERATE);
		}
	}

	/**
	 * @param department ID
	 * @return list managers in department
	 */
	@Override
	@Cacheable(value = "getManagersCache", unless = "#result.size() == 0")
	public List<ManagerDTO> getManagers(Long deptId, Long designationId, String companyId) {
		List<ManagerDTO> managerList = new ArrayList<>();
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		if (username != null) {
			Optional<Employee> findByUserName = employeeRepo.getByUserName(username, companyId);
			if (findByUserName.isPresent()) {
				List<Employee> empList = employeeRepo.findByDesignation("CEO",
						findByUserName.get().getCompany().getId());
				if (!empList.isEmpty()) {
					for (Employee findByDesignationid : empList) {
						ManagerDTO manager = new ManagerDTO();
						manager.setId(findByDesignationid.getId());
						manager.setMailId(findByDesignationid.getOfficalMail());
						manager.setName(findByDesignationid.getFirstName() + " "
								+ findByDesignationid.getDesignation().getDesignation() + " "
								+ findByDesignationid.getDesignation().getBand());
						managerList.add(manager);
					}
				}
			}
		}

		List<EmployeeManagerDTO> employeeList = employeeRepo.findByDepartmentId(deptId, companyId);
		for (EmployeeManagerDTO employee : employeeList) {
			Optional<Designation> designationObj = designationRepo.findById(designationId);
			if (designationObj.isPresent()) {
				Designation designation = designationObj.get();
				if (employee.getEmpDesignBand() != null && !employee.getEmpDesignBand().equals("")) {
					if (designation.getBand() == null) {
						managerList.add(copyManagerDTO(employee));
					} else if (designation.getBand() != null
							&& !designation.getBand().equals(employee.getEmpDesignBand())) {
						managerList.add(copyManagerDTO(employee));
					}
				}
			}
		}
		return managerList;
	}

	/**
	 * @param id
	 * @return list of employee under manager
	 *//*
		 * @Override public List<EmployeeOrgDTO> getManagerSubordinate(Long id) {
		 * log.info("getManagerSubordinate method started"); List<EmployeeOrgDTO> list =
		 * new ArrayList<>(); List<Employee> employee =
		 * employeeRepo.getManagerSubordinate(id); if (employee.isEmpty()) { return
		 * list; } list = employee.stream().map(entity -> { EmployeeOrgDTO model = new
		 * EmployeeOrgDTO(); model.setId(entity.getId());
		 * model.setName(entity.getFirstName());
		 * model.setEmail(entity.getOfficalMail());
		 * model.setDesignation(entity.getDesignation().getDesignation());
		 * model.setManagerId(entity.getManager().getId()); return model;
		 * }).collect(Collectors.toList());
		 * log.info("Manager with subordinates found with ID::{}", id); return list; }
		 */

	/**
	 * @return get all active roles
	 */
	@Override
	@Cacheable(value = "getAllRolesCache", unless = "#result.size() == 0")
	public List<EmployeeRolesDTO> getAllRoles(String companyId) {
		List<EmployeeRolesDTO> roleListDto = roleRepo.getAllRoles(companyId);
		return roleListDto;
	}

	/**
	 * 
	 * @param employee
	 * @return managerDto
	 */
	public ManagerDTO copyManagerDTO(EmployeeManagerDTO employee) {
		ManagerDTO manager = new ManagerDTO();
		manager.setId(employee.getEmpId());
		manager.setMailId(employee.getEmpOfficeMail());
		manager.setName(
				employee.getEmpFirstName() + " " + employee.getEmpDesignation() + " " + employee.getEmpDesignBand());
		return manager;
	}

	/**
	 * 
	 * @param employee
	 * @param imageName
	 * @param image
	 * @param folderName
	 * @return copy data profile image
	 */
	public ProfileImage copyImageData(Employee employee, String imageName, MultipartFile image, String folderName) {
		boolean flag = Boolean.FALSE;
		flag = s3serviceutil.uploadFileInFolder(image, folderName, imageName);
		ProfileImage profileImage = new ProfileImage();
		if (flag == true) {
			profileImage.setImageName(imageName);
			profileImage.setImageurl(s3serviceutil.generateFileUrl(imageName, folderName));
			profileImage.setFileType("." + FilenameUtils.getExtension(image.getOriginalFilename()));
			profileImage.setEmployee(employee);
			profileImage.setContentType(image.getContentType());
		}
		/*
		 * EmployeeProfileImage employeeProfileImage = new EmployeeProfileImage();
		 * employeeProfileImage.setId(seqGeneratorService.generateSequence(
		 * EmployeeProfileImage.SEQUENCE_NAME));
		 * employeeProfileImage.setImage(image.getBytes());
		 * employeeProfileImage.setContantType(image.getContentType());
		 * employeeProfileImage.setFileName(imageName); employeeProfileImage =
		 * employeeProfileImageRepo.insert(employeeProfileImage); ProfileImage
		 * profileImage = new ProfileImage(); if (employeeProfileImage.getId() != null)
		 * { profileImage.setImageName(imageName);
		 * profileImage.setImageurl(employeeProfileImage.getId());
		 * profileImage.setFileType("." +
		 * FilenameUtils.getExtension(image.getOriginalFilename()));
		 * profileImage.setEmployee(employee); }
		 */
		return profileImage;
	}

	/**
	 * 
	 * @param employee
	 * @param files
	 * @param folderName2
	 * @return list of file details
	 * @throws IOException
	 */
	public List<FileDetails> copyFilesData(Employee employee, MultipartFile[] files, String folderName,
			List<FileNamesListDTO> fileJsonList) throws IOException {
		List<FileDetails> filesList = new ArrayList<>();
		boolean flag = Boolean.FALSE;
//		String folderName = employeeFolderName + Constants.SUFFIX + employee.getUserName();
		for (MultipartFile file : files) {
			flag = s3serviceutil.uploadFileInFolder(file, folderName, file.getOriginalFilename());
			if (flag == true) {

				FileDetails document = new FileDetails();
				document.setName(file.getOriginalFilename());
				document.setEmployee(employee);
				document.setFilePath(s3serviceutil.generateFileUrl(file.getOriginalFilename(), folderName));
				document.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
				if (!fileJsonList.isEmpty()) {
					for (FileNamesListDTO list : fileJsonList) {
						if (list.getNameOfFile().equals(file.getOriginalFilename())) {
							document.setCertificate(list.getCertificate());
						}
					}
				}
				filesList.add(document);
			}
			/*
			 * DBObject metaData = new BasicDBObject(); metaData.put(Constants.TYPE,
			 * Constants.FILE); metaData.put(Constants.TITLE, file.getOriginalFilename());
			 * ObjectId fileId = gridFsTemplate.store(file.getInputStream(),
			 * file.getOriginalFilename(), file.getContentType(), metaData);
			 * 
			 * if (fileId != null) { FileDetails document = new FileDetails();
			 * document.setName(file.getOriginalFilename()); document.setEmployee(employee);
			 * document.setFilePath(fileId.toString()); document.setFileType("." +
			 * FilenameUtils.getExtension(file.getOriginalFilename()));
			 * filesList.add(document); }
			 */
		}
		return filesList;
	}

	/**
	 * @return all users in db
	 */
	@Override
	@Cacheable(value = "getAllUsers", unless = "#result.size() == 0")
	public List<String> getAllUsers(String companyId) {
		return employeeRepo.getAllUserNames(companyId);
	}

	/**
	 * @return employee bank info
	 */
	@Override
	public List<BankDTO> getBankDeatils(Long id) {
		List<BankDTO> list = new ArrayList<>();
		BankDetails bank = bankRepo.findByEmployee(id);
		BankDTO bankdto = new BankDTO();
		if (!Objects.isNull(bank)) {
			bankdto.setId(bank.getId());
			bankdto.setAccountHolderName(bank.getAccountHolderName());
			bankdto.setAccountNo(bank.getAccountNo());
			bankdto.setBankName(bank.getBankName());
			bankdto.setBranchName(bank.getBranchName());
			bankdto.setIfscCode(bank.getIfscCode());
			bankdto.setUanNumber(bank.getUanNumber());
			bankdto.setPfNumber(bank.getPfNumber());
			bankdto.setEsicNumber(bank.getEsicNumber());
			list.add(bankdto);
		}
		return list;
	}

	@Override
	public List<Map<String, Integer>> saveEmpEducationalDetailsfromUploadedfile(MultipartFile file, String companyId) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeeEducationalDetailsDataFromExecl(file, companyId);
		}
		return result;
	}

	@Override
	public List<Map<String, Integer>> saveEmpEmergencyContactDetailsfromUploadedfile(MultipartFile file,
			String companyId) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeeEmergencyContactDetailsDataFromExecl(file, companyId);
		}
		return result;
	}

	@Override
	public List<Map<String, Integer>> saveEmpPersonalDetailsfromUploadedfile(MultipartFile file, String companyId) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = empDataUploadutil.readEmployeePersonalDetailsDataFromExecl(file, companyId);
		}
		return result;
	}

	@Override
	public Long validateEmployeeEmail(String email) {
		return employeeRepo.getEmployeeEmail(email);
	}

	@Override
	public Long validateEmployeeContact(String contact) {
		return employeeRepo.getEmployeeContact(contact);
	}

	@Override
	public Long validateEmployeeUserNmae(String userName) {
		return employeeRepo.getEmployeeUserName(userName);
	}

	@Override
	public Long validateEmployeeOfficalEmail(String email) {
		return employeeRepo.getEmployeeOfficalEmail(email);
	}

	/*
	 * @Override public List<EntityDTO> updateAllEmpStatusToApprove(String
	 * companyId) {
	 * 
	 * List<EntityDTO> list = new ArrayList<>(); List<Employee> empList =
	 * employeeRepo.findAllByStatus(companyId); for (Employee emp : empList) {
	 * emp.setIsActive(Boolean.TRUE); emp.setIsApprove(Boolean.FALSE);
	 * employeeRepo.save(emp); EntityDTO dto = new EntityDTO();
	 * dto.setId(emp.getId()); dto.setName(emp.getFirstName()); list.add(dto);
	 * log.info("Employee is activated in database with Id:{}", emp.getId()); }
	 * return list; }
	 */

	@Override
	public List<EntityDTO> updateAllEmpStatusToApproveWithEmpIds(List<Employee> empIds) {
		for (Employee emp : empIds) {
			approveById(emp.getId());
			log.info("Employee is activated in database with Id:{}", emp);
		}
		List<EntityDTO> list = new ArrayList<>();
		EntityDTO dto = new EntityDTO();
		list.add(dto);
		return list;
	}

//	@Override
//	@Scheduled(cron = "0 0 11 * * *", zone = "IST")
//	public void approveThroughMail() {
//		List<Employee> empList = employeeRepo.findAllByStatusThroughMail();
//		for (Employee emp : empList) {
//			approveById(emp.getId());
//			log.info("Employee is activated in database with Id:{}", emp.getId());
//		}
//	}

	/**
	 * @param Excel file
	 * @return success and failure count of uploaded records
	 */
	@Transactional
	public List<Map<String, Integer>> saveAllEmpDatafromUploadedfile(MultipartFile file) {
		List<Map<String, Integer>> result = null;
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		if (extension.equalsIgnoreCase(Constants.FILE_EXTENSION_ONE)
				|| extension.equalsIgnoreCase(Constants.FILE_EXTENSION)) {
			result = employeeBulkUploadingUtil.readAllOnBoardEmployeeDataFromExecl(file);
		}
		return result;
	}

	@Override
	public List<ResourceItemsDTO> getEmployeAssets(Long data) {
		List<ResourceItems> items = resourceItemsRepo.findAll();
		List<ResourceItems> findByEmployeeId = items.stream().filter(c -> c.getEmployee().getId().equals(data))
				.filter(c -> c.getIsDelete().equals(Boolean.FALSE)).collect(Collectors.toList());
		List<ResourceItemsDTO> list = new ArrayList<>();
		for (ResourceItems rs : findByEmployeeId) {
			ResourceItemsDTO dto = new ResourceItemsDTO();
			dto.setId(rs.getId());
			dto.setName(rs.getAsset().getName());
			list.add(dto);
		}
		return list;
	}

}
