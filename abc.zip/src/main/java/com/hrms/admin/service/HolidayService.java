package com.hrms.admin.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.HolidayDTO;

public interface HolidayService {

	public List<EntityDTO>  save(HolidayDTO model,MultipartFile file) throws IOException;

	public HolidayDTO getById(Long id, String companyId);

	public boolean deleteHoliday(Long id);

	public List<EntityDTO> updateHoliday(HolidayDTO model,MultipartFile file) throws IOException;

	public Map<String, Object> getAllHoliday(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String isActive, String companyId);

	public List<EntityDTO> updateHolidayByStatus(Long id, String status);
	
	public List<EntityDTO> softDeleteHoliday(Long id);
	
	boolean validate(HolidayDTO holiday, boolean isSave);
	
	public List<HolidayDTO> getAllHolidayListBasedOnBranch(Long branchId, String companyId);
	
}
