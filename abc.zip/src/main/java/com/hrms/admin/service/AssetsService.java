package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.AssetsDTO;
import com.hrms.admin.dto.EntityDTO;

public interface AssetsService {

	public List<EntityDTO> save(AssetsDTO model);

	public List<EntityDTO> updateAssets(AssetsDTO model);

	public AssetsDTO getById(Long id, String companyId);

	public boolean deleteAssets(Long id);

	public List<AssetsDTO> AllAssets(String companyId);

	public List<EntityDTO> softDeleteAssets(Long id);

	public boolean validate(AssetsDTO assets, boolean isSave);

	Map<String, Object> getAllAssets(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String isActive, String companyId);

	public List<EntityDTO> updateAssetsByStatus(Long id, String status);

}
