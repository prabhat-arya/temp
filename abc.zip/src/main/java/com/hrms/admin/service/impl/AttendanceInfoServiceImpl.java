
package com.hrms.admin.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.core.appender.rolling.action.IfAccumulatedFileCount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.dto.AtteDataPieChartDTO;
import com.hrms.admin.dto.AttendPaginationDTO;
import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.BarChartDateWiseCountChildDTO;
import com.hrms.admin.dto.BarChartDateWiseCountDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PieChartRequestDTO;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.entity.AttendanceInfoErrorRecords;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.Shift;
import com.hrms.admin.fileuploaddownload.property.ExcelGenerator;
import com.hrms.admin.fileuploaddownload.property.PdfReportGenerator;
import com.hrms.admin.repository.AssignShiftRepository;
import com.hrms.admin.repository.AttendanceInfoErrorRecordsRepository;
import com.hrms.admin.repository.AttendanceInfoRepository;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.repository.ShiftRepository;
import com.hrms.admin.service.AttendanceInfoService;
import com.hrms.admin.util.CSVHelper;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.StringToDateUtility;

/**
 * Contains method to perform DB operation on AttendanceInfo Record
 * 
 * @author {Ramesh Rendla}
 *
 */

@Service
public class AttendanceInfoServiceImpl implements AttendanceInfoService {
	private static final Logger logger = LoggerFactory.getLogger(AttendanceInfoServiceImpl.class);

	@Autowired
	private StringToDateUtility util;

	@Autowired
	private AttendanceInfoRepository infoRepository;

	@Autowired
	private AttendanceInfoErrorRecordsRepository infoError;

	@Autowired
	private ShiftRepository shiftRepo;

	@Autowired
	private EmployeeRepository empRepo;

	@Autowired
	private CSVHelper csvHelper;

	@Autowired
	private EmpLeaveRepository empLeaveRepo;

	@Autowired
	private AssignShiftRepository assignshiftRepo;

	@Autowired
	private ProjectRepository proRepo;

	@Autowired
	private AttendanceInfoErrorRecordsRepository attErrorRecordrepo;

	@Autowired
	private PdfReportGenerator pdfReportGenerator;

	@Autowired
	private ExcelGenerator excelGenerator;

	/**
	 * Returns employee Manual attendance when AttendanceInfo data is available in
	 * database
	 * 
	 * @return - AttendanceInfo model
	 */
	@Override
	public List<EntityDTO> save(AttendanceInfoDTO model) {

		AttendanceInfo entity = new AttendanceInfo();
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> findById = empRepo.findById(model.getEmpId());
		Optional<Shift> actlHrs = shiftRepo.findById(model.getShiftId());
		if (!findById.isPresent()) {
			return list;
		}
		if (!actlHrs.isPresent()) {
			return list;
		}
		entity.setInTime(model.getInTime());
		entity.setOutTime(model.getOutTime());
		entity.setShiftId(model.getShiftId());
		entity.setDate(model.getDate());
		entity.setReason(model.getReason());
		entity.setBreakHrs(null);
		entity.setTotalHrs(null);
		entity.setEmployee(findById.get());
		String noOfHrs = util.calculateWorkingHours(model.getInTime(), model.getOutTime());
		entity.setNoOfHrs(noOfHrs);
		double percentage = util.attendsPersentage(actlHrs.get().getInTime(), actlHrs.get().getOutTime(), noOfHrs);
		if (percentage <= 100) {
			entity.setAttndsPercentage(util.roundTwoDecimalsInPercentage(percentage).longValue());
		} else {
			entity.setAttndsPercentage(100l);
		}
		entity.setShift(actlHrs.get());
		AttendanceInfo a = infoRepository.save(entity);
		logger.info("AttendanceInfo Added into database " + " : ", entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(a.getEmployee().getId());
		dto.setName(a.getEmployee().getFirstName() + " " + a.getEmployee().getLastName());
		list.add(dto);
		return list;
	}

	/**
	 * Returns employee attendance when AttendanceInfo data is available based on
	 * empId and date
	 * 
	 * @return - AttendanceInfo model
	 */
	@Override
	public AttendanceInfoDTO getEmployeeAttendance(Long empId, String date) {
		Optional<AttendanceInfo> findById = infoRepository.getEmployeeAttendanceOnDate(empId, date);
		if (!findById.isPresent()) {
			return null;
		}
		AttendanceInfoDTO models = copyPropertites(findById.get());
		logger.info("Found All Attendance Details " + " : ", findById);
		return models;
	}

	/**
	 * Update employee attendance when AttendanceInfo data is available based on
	 * empId and date
	 * 
	 * @return - AttendanceInfo model
	 */
	@Override
	public List<EntityDTO> updateEmployeeAttendance(AttendanceInfoDTO model) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<AttendanceInfo> findById = infoRepository.getEmployeeAttendanceOnDate(model.getEmpId(),
				model.getDate());
		if (findById.isPresent()) {
			AttendanceInfo oldEmployeeAtt = findById.get();
			oldEmployeeAtt.setInTime(model.getInTime());
			oldEmployeeAtt.setOutTime(model.getOutTime());
			String noOfHrs = util.calculateWorkingHours(model.getInTime(), model.getOutTime());
			oldEmployeeAtt.setNoOfHrs(noOfHrs);
			oldEmployeeAtt.setBreakHrs(model.getBreakHrs());
			AttendanceInfo save = infoRepository.save(oldEmployeeAtt);
			EntityDTO dto = new EntityDTO();
			dto.setId(save.getEmployee().getId());
			dto.setName(save.getEmployee().getFirstName() + " " + save.getEmployee().getLastName());
			list.add(dto);
			logger.info("Employee Attendace record is updated in database with id:{}", save.getEmployee().getId());
			return list;
		}
		return list;
	}

	/**
	 * delete employee attendance when AttendanceInfo data is available based on
	 * empId and date
	 * 
	 * @return - AttendanceInfo model
	 */
	@Override
	public boolean deleteEmployeeAttendance(AttendanceInfoDTO model) {
		Optional<AttendanceInfo> findById = infoRepository.getEmployeeAttendanceOnDate(model.getEmpId(),
				model.getDate());
		if (findById.isPresent()) {
			AttendanceInfo attendanceInfo = findById.get();
			infoRepository.delete(attendanceInfo);
			return true;
		}
		return false;
	}

	/**
	 * Returns all employee's attendance list when attendanceInfo data is available
	 * in database
	 * 
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	@Cacheable(value = "getAllAttendenceDetails", unless = "#result.size() == 0")
	public List<AttendanceInfoDTO> getAllAttendenceDetails(String companyId) {
		List<AttendanceInfo> attInfo = infoRepository.findAllEmployeeAttendance(companyId);
		List<AttendanceInfoDTO> models = attInfo.stream().map(entity -> {
			return copyPropertites(entity);
		}).collect(Collectors.toList());
		logger.info("Found All Attendance Details " + " : ", attInfo);
		return models;
	}

	/**
	 * Returns all employees attendance percentage shown in pieChart(present and
	 * absent percentage) when attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public AttPercentagePieChartDto attendancePercentagePieChart(String companyId) {
		Long allEmpCount = infoRepository.getAllEmployeecountPerDay(companyId);
		logger.info(" found AttendancePercentagePieChart  " + " : ", allEmpCount);
		if (allEmpCount == 0) {
			return null;
		}
		Long allPresentEmpCount = infoRepository.attendancePresentPercentagePieChart(companyId);
		Long allAbsentEmpCount = infoRepository.attendanceAbsentPercentagePieChart(companyId);
		Double presentEmpAttPercentage = (((double) allPresentEmpCount * 100) / (double) allEmpCount);
		Double absentEmpAttPercentage = (double) allAbsentEmpCount * 100 / allEmpCount;
		AttPercentagePieChartDto att = new AttPercentagePieChartDto();
		AtteDataPieChartDTO atteDatap = new AtteDataPieChartDTO();
		atteDatap.setName(Constants.PRESENT);
		atteDatap.setPercentage(util.roundTwoDecimalsInPercentage(presentEmpAttPercentage));
		AtteDataPieChartDTO atteDataa = new AtteDataPieChartDTO();
		atteDataa.setName(Constants.ABSENT);
		atteDataa.setPercentage(util.roundTwoDecimalsInPercentage(absentEmpAttPercentage));
		List<AtteDataPieChartDTO> attndata = new ArrayList<>();
		attndata.add(atteDatap);
		attndata.add(atteDataa);
		att.setData(attndata);
		return att;
	}

	/**
	 * Returns all employees attendance percentage shown in PieChart when
	 * attendanceInfo data is available in database based on empId
	 *
	 * @param id-empId
	 * @return - AttendanceInfo
	 */
	@Override
	public AttPercentagePieChartDto attendancePercentagePieChartByEmpid(Long empid, String companyId) {
		Long allEmpCount = infoRepository.getAllEmployeecountInMonthByEmpid(empid, companyId);
		logger.info("Attendance Percentage PieChart based on employee" + " : ", allEmpCount);
		if (allEmpCount == 0) {
			return null;
		}
		Long allPresentEmpCount = infoRepository.attendancePresentPercentagePieChartByEmpid(empid, companyId);
		if (allPresentEmpCount == null) {
			return null;
		}
		Long allEmpAbsentCount = infoRepository.attendanceAbsentPercentagePieChartByEmpid(empid, companyId);
		if (allEmpAbsentCount == null) {
			return null;
		}
		Double presentEmpAttPercentage = (((double) allPresentEmpCount * 100) / (double) allEmpCount);
		Double absentAttPercentage = (double) allEmpAbsentCount * 100 / allEmpCount;
		AttPercentagePieChartDto att = new AttPercentagePieChartDto();
		AtteDataPieChartDTO atteDatap = new AtteDataPieChartDTO();
		atteDatap.setName(Constants.PRESENT);
		logger.info("Number of Present Employees Attendance count PieChart based on EMPID" + " : ", allPresentEmpCount);
		atteDatap.setPercentage(util.roundTwoDecimalsInPercentage(presentEmpAttPercentage));

		AtteDataPieChartDTO atteDataa = new AtteDataPieChartDTO();
		atteDataa.setName(Constants.ABSENT);
		logger.info("Attendance Percentage PieChart based on EMPID");
		atteDataa.setPercentage(util.roundTwoDecimalsInPercentage(absentAttPercentage));

		List<AtteDataPieChartDTO> attndata = new ArrayList<>();
		attndata.add(atteDatap);
		attndata.add(atteDataa);
		att.setData(attndata);
		return att;
	}

	/**
	 * Returns all employees attendance percentage shown in PieChart when
	 * attendanceInfo data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@Override
	public AttPercentagePieChartDto getAllEmpAttPercentagePieChartByProjectId(Long id, String companyId) {
		Long total = 0l;
		String date = util.getYesterdayDateString();
		Optional<Project> project = proRepo.findProjectByCompanyId(id, companyId);
		if (project.isPresent()) {
			logger.info("Project data based on project id" + " : ", project);
			for (Employee emp : project.get().getEmployee()) {
				AttendanceInfo noOfHrs = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
				if (Objects.isNull(noOfHrs)) {
					continue;
				}
				LocalTime localTime = LocalTime.parse(noOfHrs.getNoOfHrs());
				Long millis = (long) (localTime.toSecondOfDay() * 1000);
				Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
				if (noOfhr != 0) {
					Long presentemp = assignshiftRepo.findShiftIdCount(emp.getId(), date, companyId);
					if (Objects.isNull(presentemp)) {
						continue;
					}
					total = presentemp + total;
				}
			}
		} else {
			return null;
		}

		if ((project.get().getEmployee()).isEmpty()) {
			return null;
		}
		Double presntPercentage = ((double) total * 100 / (double) project.get().getEmployee().size());
		Double absentPersentage = 100 - presntPercentage;
		AttPercentagePieChartDto att = new AttPercentagePieChartDto();
		AtteDataPieChartDTO atteDatap = new AtteDataPieChartDTO();
		atteDatap.setName(Constants.PRESENT);
		logger.info("Present Employee's Attendance Precentage based on ProjectId" + " : ", presntPercentage);
		atteDatap.setPercentage(util.roundTwoDecimalsInPercentage(presntPercentage));
		AtteDataPieChartDTO atteDataa = new AtteDataPieChartDTO();
		atteDataa.setName(Constants.ABSENT);
		logger.info("Absent Employee's Attendance Precentage based on ProjectId" + " : ", absentPersentage);
		atteDataa.setPercentage(util.roundTwoDecimalsInPercentage(absentPersentage));
		List<AtteDataPieChartDTO> attndata = new ArrayList<>();
		attndata.add(atteDatap);
		attndata.add(atteDataa);
		att.setData(attndata);
		return att;
	}

	/**
	 * Returns all Present employees attendance list when attendanceInfo data is
	 * available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllPresentListPieChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListPieChart(searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Present employee attendance list PieChart");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns all Absent employees attendance list when attendanceInfo data is
	 * available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllAbesntListPieChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListPieChart(searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Absent employee attendance list in PieChart");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns all employees attendance count for one week(present and absent count)
	 * show in barGraph when attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 * @throws ParseException
	 */
	@Override
	public BarChartDateWiseCountDTO employeeAttCountBarChart(PieChartRequestDTO pieChartDto, String companyId)
			throws ParseException {
		BarChartDateWiseCountDTO countParentDto = new BarChartDateWiseCountDTO();
		BarChartDateWiseCountChildDTO countChildDTO = new BarChartDateWiseCountChildDTO();
		BarChartDateWiseCountChildDTO countChildDTO2 = new BarChartDateWiseCountChildDTO();
		ArrayList<Long> pList = new ArrayList<>();
		List<Long> aList = new ArrayList<>();
		List<String> datelist = new ArrayList<>();
		if (pieChartDto.getFromDate() == null && pieChartDto.getToDate() == null) {
			datelist = util.getWeekDateString();
		} else {
			if (StringToDateUtility.stringToDate(pieChartDto.getToDate()) == null) {
				return null;
			}
			datelist = util.getInBetweenDates(StringToDateUtility.stringToDate(pieChartDto.getFromDate()),
					StringToDateUtility.stringToDate(pieChartDto.getToDate()));
		}
		logger.info(" found employee Attendance Count BarChart " + " : ", datelist);
		for (String date : datelist) {
			Long presents = infoRepository.getAllPresentEmpByBranchWithDate(date, companyId);
			pList.add(presents);
			Long absents = infoRepository.getAllAbsentEmpByBranchWithDate(date, companyId);
			aList.add(absents);
		}
		countParentDto.setDate(datelist);
		ArrayList<BarChartDateWiseCountChildDTO> childList = new ArrayList<>();
		countChildDTO.setName(Constants.PRESENT);
		logger.info("Present employee Attendance BarChart count" + " : ", pList);
		countChildDTO.setData(pList);
		countChildDTO2.setName(Constants.ABSENT);
		logger.info("Absent employee Attendance BarChart count" + " : ", aList);
		countChildDTO2.setData(aList);
		childList.add(countChildDTO);
		childList.add(countChildDTO2);
		countParentDto.setData(childList);
		return countParentDto;
	}

	/**
	 * Returns all employees attendance count shown in barGraph when attendanceInfo
	 * data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 * @throws ParseException
	 */
	@Override
	public BarChartDateWiseCountDTO allEmpAttCountProjectBarChart(PieChartRequestDTO pieChartDto, String companyId)
			throws ParseException {
		BarChartDateWiseCountDTO countParentDto = new BarChartDateWiseCountDTO();
		BarChartDateWiseCountChildDTO countChildDTO = new BarChartDateWiseCountChildDTO();
		BarChartDateWiseCountChildDTO countChildDTO2 = new BarChartDateWiseCountChildDTO();
		Optional<Project> project = proRepo.findProjectByCompanyId(pieChartDto.getProjectId(), companyId);
		if (!project.isPresent()) {
			return null;
		}

		List<Long> pList = new ArrayList<>();
		List<Long> aList = new ArrayList<>();
		Long size = (long) project.get().getEmployee().size();
		List<String> datelist = new ArrayList<>();
		if (pieChartDto.getFromDate() == null && pieChartDto.getToDate() == null) {
			datelist = util.getWeekDateString();
		} else {
			if (StringToDateUtility.stringToDate(pieChartDto.getToDate()) == null) {
				return null;
			}
			datelist = util.getInBetweenDates(StringToDateUtility.stringToDate(pieChartDto.getFromDate()),
					StringToDateUtility.stringToDate(pieChartDto.getToDate()));
		}
		logger.info("Employee Attendance List on date " + " : ", datelist);
		for (String date : datelist) {
			Long count = 0L;
			Long value = 0L;
			for (Employee emp : project.get().getEmployee()) {
				AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
				if (Objects.isNull(info)) {
					size--;
					continue;
				}
				LocalTime localTime = LocalTime.parse(info.getNoOfHrs());
				Long millis = (long) (localTime.toSecondOfDay() * 1000);
				Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
				if (noOfhr != 0) {
					count = count + 1;
				}
			}
			pList.add(count);
			value = size - count;
			aList.add(value);
			size = (long) project.get().getEmployee().size();
		}
		countParentDto.setDate(datelist);
		ArrayList<BarChartDateWiseCountChildDTO> childList = new ArrayList<>();
		countChildDTO.setName(Constants.PRESENT);
		logger.info("Present Employee's Attendance List based on ProjectId" + " : ", pList);
		countChildDTO.setData(pList);
		countChildDTO2.setName(Constants.ABSENT);
		logger.info("Present Employee's Attendance List based on ProjectId" + " : ", aList);
		countChildDTO2.setData(aList);
		childList.add(countChildDTO);
		childList.add(countChildDTO2);
		countParentDto.setData(childList);
		return countParentDto;
	}

	/**
	 * Returns all Present employees attendance list when attendanceInfo data is
	 * available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllPresentListBarChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListBarChart(searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Present Employee attendance list BarGraph");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns all Absent employees attendance list when attendanceInfo data is
	 * available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllAbsentListBarChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListBarChart(searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Absent Employee attendance list BarGraph");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}

	}

	/**
	 * Returns all employees attendance list in pagination when attendanceInfo data
	 * is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.allAttendancePage(searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employees Attendance list");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapData(Page<AttendanceInfoDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("Found All Employees Attendnace pagenation" + " : ", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModels = pagedResult.stream().map(attendanceInfoEntity -> {
			AttendanceInfoDTO model = new AttendanceInfoDTO();
			BeanUtils.copyProperties(attendanceInfoEntity, model);
			model.setEmployee(attendanceInfoEntity.getFirstName() + " " + attendanceInfoEntity.getLastName());
			model.setShift(attendanceInfoEntity.getShift());
			model.setEmpId(attendanceInfoEntity.getEmpId());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all employees attendance list generate in excel report when
	 * attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 * @throws Exception
	 */
	@Override
	public InputStreamResource getAllExcelReportAttendances(String companyId) throws Exception {
		List<AttendanceInfoDTO> list = getAllAttendenceDetails(companyId);
		ByteArrayInputStream in = excelGenerator.attendanceInfoToExcel(list);
		logger.info("All Emplooyee's Excel Report Attendance" + " : ", in);
		return new InputStreamResource(in);
	}

	/**
	 * Returns all employees attendance list generate in PDF report when
	 * attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 * @throws Exception
	 */
	@Override
	public InputStreamResource getAllpdfReportAttendances(String companyId) throws Exception {
		List<AttendanceInfoDTO> list = getAllAttendenceDetails(companyId);
		ByteArrayInputStream bis = pdfReportGenerator.attendanceReport(list, companyId);
		logger.info(" All Emplooyee's Pdf Report Attendance" + " : ", bis);
		return new InputStreamResource(bis);
	}

	@Override
	public String currentDateandTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDate = formatter.format(date);
		logger.info(" currentDateandTime  " + " : ", currentDate);
		return currentDate;
	}

	/**
	 * 
	 * @author {Benarji}
	 *
	 */
	/**
	 * Returns all employees error records list when attendanceInfoErrorRecords data
	 * is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public List<AttendanceInfoErrorRecords> getAllAttendanceErrorRecordList() {
		List<AttendanceInfoErrorRecords> attInfo = infoError.findAll();
		logger.info("All Attendance Error Records List " + " : ", attInfo);
		return attInfo;
	}

	/**
	 * this validation method is checking duplicates while saving the manual
	 * attendance
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public boolean validate(AttendanceInfoDTO model) {
		Long count = infoRepository.getAttendanceCount(model.getEmpId(), model.getDate());
		logger.info("Check Duplicate Attendance Records" + " : ", count);
		return count > 0;
	}

	/**
	 * Uploading the all employees attendance list in CSV File format when
	 * attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 *//*
		 * @Override public List<Map<String, Integer>> saveAttendanceCsv(MultipartFile
		 * file, String companyId) throws Exception { return
		 * csvHelper.csvToAttendanceInfo(file.getInputStream(), companyId); }
		 */

	/**
	 * Uploading the all employees attendance break history list in CSV File format
	 * when attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public List<Map<String, Integer>> attendanceBreakHistoryCsv(MultipartFile file, String companyId) throws Exception {
		return csvHelper.attendanceBreakHistoryCsv(file.getInputStream(), companyId);
	}

	/**
	 * Returns all employees attendance ErrorRecords list generate in CSV report
	 * when attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public ICsvBeanWriter getAllAttendanceErrorRecordListCsv(HttpServletResponse response) throws IOException {
		List<AttendanceInfoErrorRecords> allAttendenceDetails = getAllAttendanceErrorRecordList();
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "EMPID", "INTIME", "OUTTIME", "DATE" };
		String[] nameMapping = { "empId", "inTime", "outTime", "date" };
		csvWriter.writeHeader(csvHeader);
		for (AttendanceInfoErrorRecords att : allAttendenceDetails) {
			csvWriter.write(att, nameMapping);
		}
		logger.debug("csv Report for employees Attendance are generated :");
		csvWriter.close();
		return csvWriter;
	}

	/**
	 * Returns all employees attendance list generate in CSV report when
	 * attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 * @throws Exception
	 */
	@Override
	public ICsvBeanWriter getAllAttendenceDetailsCsv(HttpServletResponse response, String companyId) throws Exception {
		List<AttendanceInfoDTO> allAttendenceDetails = getAllAttendenceDetails(companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Shift", "In Time", "Out Time", "Date", "Total Hours",
				"Work Hours", "Break Hours", "Reason", "Attendance Percentage" };
		String[] nameMapping = { "empId", "employee", "shift", "csvInTime", "csvOutTime", "csvDate", "totalHrs",
				"noOfHrs", "breakHrs", "reason", "attndsPercentage" };
		csvWriter.writeHeader(csvHeader);
		for (AttendanceInfoDTO att : allAttendenceDetails) {

			att.setCsvDate(util.changeDateFormatFromString(att.getDate()));
			att.setCsvInTime(util.changeDateFormatFromStringDateAndTime(att.getInTime()));
			att.setCsvOutTime(util.changeDateFormatFromStringDateAndTime(att.getOutTime()));
			csvWriter.write(att, nameMapping);
		}
		logger.debug("csv Report for employees Attendance are generated :");
		csvWriter.close();
		return csvWriter;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in database based on empId in pagination
	 *
	 * @param id=empId
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAllAttendenceByEmpId(Long empid, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.findByEmpIds(empid, searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Employees Attendance list based on employee");
			return mapDataByEmpId(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapDataByEmpId(Page<AttendanceInfoDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("Found Employees Attendance list based on employee with pagenation" + " : ", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModels = pagedResult.stream().map(attendanceInfoEntity -> {
			return copyPropertitesDTO(attendanceInfoEntity);
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in database based on fromDate to toDate
	 *
	 * @param date- fromDate to toDate
	 * @return - AttendanceInfo
	 */
	@Override
	@Cacheable(value = "getEmpAttDetailsbetweenDates", unless = "#result.size() == 0")
	public List<AttendanceInfoDTO> getEmpAttDetailsbetweenDates(String fromDate, String toDate, String companyId) {
		List<AttendanceInfoDTO> models = null;
		List<AttendanceInfo> attInfo = infoRepository.getEmpAttDetailsBetweenDays(fromDate, toDate, companyId);
		logger.info(" found getEmpAttDetailsbetweenDates " + " : ", attInfo);
		models = attInfo.stream().map(entity -> {
			return copyPropertites(entity);
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in pagination in database based on fromDate to toDate
	 *
	 * @param date- fromDate to toDate
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getEmpAttDetailsbetweenDatesPaging(String fromDate, String toDate, Integer pageIndex,
			Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfo> pagedResult = null;
		pagedResult = infoRepository.getEmpAttDetailsBetweenDaysPaging(fromDate, toDate, searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list between Dates");
			return getEmpAttDetailsbetweenDatesPaging(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> getEmpAttDetailsbetweenDatesPaging(Page<AttendanceInfo> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("Found All Attendnace list between dates pagenation " + " : ", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModels = pagedResult.stream().map(attendanceInfoEntity -> {
			return copyPropertites(attendanceInfoEntity);
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in database based on empId and fromDate to toDate
	 * 
	 * @param id,date- empId and fromDate to toDate
	 * @return - AttendanceInfo
	 */
	@Override
	@Cacheable(value = "getAttendanceListBetweenDates", unless = "#result.size() == 0")
	public List<AttendanceInfoDTO> getAttendanceListBetweenDates(Long empid, String fromDate, String toDate,
			String companyId) {
		List<AttendanceInfo> empAttDetailsBetweenDaysEmpid = infoRepository.getEmpAttDetailsBetweenDaysEmpid(empid,
				fromDate, toDate);
		List<AttendanceInfoDTO> models = empAttDetailsBetweenDaysEmpid.stream().map(entity -> {
			return copyPropertites(entity);
		}).collect(Collectors.toList());
		logger.info(" found All Attendance Details " + " : ", empAttDetailsBetweenDaysEmpid);
		return models;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in database based on empId and fromDate to toDate in pagination
	 *
	 * @param id,date- empId and fromDate to toDate
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> getAttendanceListBetweenDatesPaging(Long empid, String fromDate, String toDate,
			Integer pageIndex, Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttDetailsBetweenDaysEmpidpaging(empid, fromDate, toDate, searchKey,
				companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list");
			return attendanceListBetweenDates(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> attendanceListBetweenDates(Page<AttendanceInfoDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("Found  All Employee Attendnace pagenation" + " : ", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModels = pagedResult.stream().map(attendanceInfoEntity -> {
			return copyPropertitesDTO(attendanceInfoEntity);
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all employees attendance list when attendanceInfo data is available
	 * in database based on shiftId and fromDate to toDate in pagination
	 *
	 * @param id,date- shiftId and fromDate to toDate
	 * @return - AttendanceInfo
	 */
	@Override
	@Cacheable(value = "getAllAttendanceListDateShiftPaging", unless = "#result.size() == 0")
	public Map<String, Object> getAllAttendanceListDateShiftPaging(String fromDate, String toDate, Long shiftId,
			Integer pageIndex, Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfo> pagedResult = null;
		pagedResult = infoRepository.getEmpAttDetailsBetweenDaysShiftPaging(shiftId, fromDate, toDate, searchKey,
				companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list");
			return getAllAttendanceListDateShiftPaging(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> getAllAttendanceListDateShiftPaging(Page<AttendanceInfo> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("Found  All Employee Attendnace list based on date pagenation" + " : ", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModels = pagedResult.stream().map(attendanceInfoEntity -> {
			return copyPropertites(attendanceInfoEntity);
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	@Override
	public Map<String, Object> getPresentAttendenceListByEmpIdInPieChart(Long empid, Integer pageIndex,
			Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getPresentAttendenceByEmpIdInPieChart(empid, searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list based on employee" + " : ", empid);
			return getAttendenceListByEmpIdInPieChartPaging(pagedResult, empid, companyId);
		} else {
			return new HashMap<>();
		}
	}

	@Override
	public Map<String, Object> getAbsentAttendenceListByEmpIdInPieChart(Long empid, Integer pageIndex, Integer pageSize,
			String sortBy, String searchKey, String orderBy, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getAbsentAttendenceListByEmpIdInPieChart(empid, searchKey, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list based on empid" + " : ", empid);
			return getAttendenceListByEmpIdInPieChartPaging(pagedResult, empid, companyId);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> getAttendenceListByEmpIdInPieChartPaging(Page<AttendanceInfoDTO> pagedResult, Long empid,
			String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info(" found get All Attendnace pagenation" + " : ", pagedResult);
		List<AttendanceInfoDTO> models = pagedResult.stream().map(entity -> {
			AttendanceInfoDTO model = copyPropertitesDTO(entity);
			List<EmpLeave> findByEmployeeId = empLeaveRepo.findByEmployeeId(empid);
			for (EmpLeave attendanceInfo : findByEmployeeId) {
				model.setStatus(attendanceInfo.getStatus());
			}
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, models);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all Present employees attendance List shown in PieChart when
	 * attendanceInfo data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> empPresentAttListByProjectPieChart(PaginationDTO pagingDto, String companyId) {

		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListPieChart(pagingDto.getSearchKey(), companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Present Employee Attendance List based on Project Id");
			return mapData(pagedResult, pagingDto.getProjectId(), companyId);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Pagination and sorting for present employees attendance list based on
	 * projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	public Map<String, Object> mapData(Page<AttendanceInfoDTO> pagedResult, Long projectId, String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> presentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			logger.info("Employee Attendance List based on Project Id");
			String date = util.getYesterdayDateString();
			for (Employee emp : project.get().getEmployee()) {
				AttendanceInfo entity = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
				if (Objects.isNull(entity)) {
					continue;
				}
				LocalTime localTime = LocalTime.parse(entity.getNoOfHrs());
				Long millis = (long) (localTime.toSecondOfDay() * 1000);
				Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
				if (noOfhr != 0) {
					AttendanceInfoDTO dto = copyPropertites(entity);
					presentList.add(dto);
				}
			}
		} else {
			return response;
		}
		response.put(Constants.DATA, presentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all Absent employees attendance List shown in PieChart when
	 * attendanceInfo data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> empAbsentAttListByProjectPieChart(PaginationDTO pagingDto, String companyId) {
		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListPieChart(pagingDto.getSearchKey(), companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Absent Employee Attendance List based on Project Id");
			return mapDataabsentPiechart(pagedResult, pagingDto.getProjectId(), companyId);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Pagination and sorting for Absent employees attendance list based on
	 * projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@SuppressWarnings("unused")
	public Map<String, Object> mapDataabsentPiechart(Page<AttendanceInfoDTO> pagedResult, Long projectId,
			String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> absentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			String date = util.getYesterdayDateString();
			for (AttendanceInfoDTO entity : pagedResult) {
				for (Employee emp : project.get().getEmployee()) {
					AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
					logger.info("Absent Employee Attendance List based on Project Id " + " : ", info);
					if (Objects.isNull(info)) {
						continue;
					}
					if (emp.getId().equals(entity.getEmpId()) && date.equals(entity.getDate())) {
						AttendanceInfoDTO dto = copyPropertites(info);
						if (dto == null) {
							return null;
						}
						absentList.add(dto);
					}
				}
			}
		} else {
			return response;
		}
		response.put(Constants.DATA, absentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all Present employees attendance List shown in barGraph when
	 * attendanceInfo data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> empPresentAttListByProjectBarChart(AttendPaginationDTO pagingDto, String companyId) {
		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListBarChart(pagingDto.getSearchKey(), companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Present Employee Attendance List based on Project");
			return mapDataPresentBarGraph(pagedResult, pagingDto.getProjectId(), companyId);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Pagination and sorting for Present employee attendance list based on
	 * projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	public Map<String, Object> mapDataPresentBarGraph(Page<AttendanceInfoDTO> pagedResult, Long projectId,
			String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> presentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			List<String> datelist = util.getWeekDateString();
			for (String date : datelist) {
				for (Employee emp : project.get().getEmployee()) {
					AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
					logger.info("Present Employee Attendance List based on Project Id shown in BarGraph " + " : ",
							info);
					if (Objects.isNull(info)) {
						continue;
					}
					LocalTime localTime = LocalTime.parse(info.getNoOfHrs());
					Long millis = (long) (localTime.toSecondOfDay() * 1000);
					Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
					if (noOfhr != 0) {
						AttendanceInfoDTO dto = copyPropertites(info);
						presentList.add(dto);
					}
				}
			}
		} else {
			return response;
		}
		response.put(Constants.DATA, presentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Returns all Absent employees attendance List shown in barGraph when
	 * attendanceInfo data is available in database based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	@Override
	public Map<String, Object> empabsentAttListByProjectBarChart(AttendPaginationDTO pagingDto, String companyId) {
		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListBarChart(pagingDto.getSearchKey(), companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Absent Employee Attendance List based on Project ");
			return mapDataabsentBarGraph(pagedResult, pagingDto.getProjectId(), companyId);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Pagination and sorting for Absent employee attendance list based on projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	public Map<String, Object> mapDataabsentBarGraph(Page<AttendanceInfoDTO> pagedResult, Long projectId,
			String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> absentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			List<String> datelist = util.getWeekDateString();
			for (String date : datelist) {
				for (Employee emp : project.get().getEmployee()) {
					AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
					logger.info("Present Employee Attendance List based on Project Id shown in BarGraph " + " : ",
							info);
					if (Objects.isNull(info)) {
						continue;
					}
					LocalTime localTime = LocalTime.parse(info.getNoOfHrs());
					Long millis = (long) (localTime.toSecondOfDay() * 1000);
					Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
					if (noOfhr == 0) {
						AttendanceInfoDTO dto = copyPropertites(info);
						absentList.add(dto);
					}
				}
			}
		}
		response.put(Constants.DATA, absentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * this method is used for reusable methods for some api's(reusable method for
	 * getter and setter fields)
	 *
	 * @return - AttendanceInfo
	 */
	public AttendanceInfoDTO copyPropertites(AttendanceInfo info) {
		AttendanceInfoDTO model = new AttendanceInfoDTO();
		model.setEmpId(info.getEmployee().getId());
		model.setEmployee(info.getEmployee().getFirstName() + " " + info.getEmployee().getLastName());
		model.setShiftId(info.getShift().getId());
		model.setShift(info.getShift().getShiftName());
		model.setInTime(info.getInTime());
		model.setOutTime(info.getOutTime());
		model.setDate(info.getDate());
		model.setReason(info.getReason());
		model.setNoOfHrs(info.getNoOfHrs());
		model.setAttndsPercentage(info.getAttndsPercentage());
		model.setReason(info.getReason());
		model.setBreakHrs(info.getBreakHrs());
		model.setTotalHrs(info.getTotalHrs());
		return model;
	}

	public AttendanceInfoDTO copyPropertitesDTO(AttendanceInfoDTO info) {
		AttendanceInfoDTO model = new AttendanceInfoDTO();
		model.setEmpId(info.getEmpId());
		model.setEmployee(info.getFirstName() + " " + info.getLastName());
		model.setShift(info.getShift());
		model.setInTime(info.getInTime());
		model.setOutTime(info.getOutTime());
		model.setDate(info.getDate());
		model.setReason(info.getReason());
		model.setNoOfHrs(info.getNoOfHrs());
		model.setBreakHrs(info.getBreakHrs());
		return model;
	}

	@Override
	public List<AttendanceInfoErrorRecords> excelReportAllErrorAttendanceInfoErrorRecords() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = ((UserDetails) principal).getUsername();
		List<AttendanceInfoErrorRecords> allErrorDetails = attErrorRecordrepo
				.getTodayaddedAttendanceInfoErrorRecords(username);
		logger.info("All Error Attendance Info Error Records List on current date  " + " : ", allErrorDetails);
		return allErrorDetails;
	}

	/**
	 * Returns all Present employees attendance list generate in CSV report when
	 * attendanceInfo data is available in database
	 *
	 * @return - AttendanceInfo
	 */
	@Override
	public ICsvBeanWriter getErrorAttRecordsListCsv(HttpServletResponse response) throws IOException {
		List<AttendanceInfoErrorRecords> infoErrorRecords = excelReportAllErrorAttendanceInfoErrorRecords();
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "EMPLOYEE ID", "IN TIME", "OUT TIME", "DATE" };
		String[] nameMapping = { "empId", "inTime", "outTime", "date" };
		csvWriter.writeHeader(csvHeader);
		for (AttendanceInfoErrorRecords att : infoErrorRecords) {
			csvWriter.write(att, nameMapping);
		}
		logger.debug("csv Report for Present employees Attendance are generated :");
		csvWriter.close();
		return csvWriter;

	}

	@Override
	public Map<String, Object> getPresentListBarChartOnDate(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String date, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListBarChartOnDate(searchKey, date, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Present Employee attendance list BarGraph");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	@Override
	public Map<String, Object> getAbsentListBarChartOnDate(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String date, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListBarChartOnDate(searchKey, date, companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("All Absent Employee attendance list BarGraph");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	@Override
	public Map<String, Object> presentEmployeeAttListByProjectBarChartOnDate(AttendPaginationDTO pagingDto,
			String companyId) {
		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttPresentListBarChartOnDate(pagingDto.getSearchKey(), pagingDto.getDate(),
				companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Present Employee Attendance List based on Project and date");
			return mapDataBarGraphbasedOndate(pagedResult, pagingDto.getDate(), pagingDto.getProjectId(), companyId);
		}

		return new HashMap<>();
	}

	@Override
	public Map<String, Object> empabsentAttListByProjectBarChartOnDate(AttendPaginationDTO pagingDto,
			String companyId) {
		Pageable paging = PageRequest.of(pagingDto.getPageIndex(), pagingDto.getPageSize());
		Page<AttendanceInfoDTO> pagedResult = null;
		pagedResult = infoRepository.getEmpAttAbsentListBarChartOnDate(pagingDto.getSearchKey(), pagingDto.getDate(),
				companyId, paging);
		if (pagedResult.hasContent()) {
			logger.info("Absent Employee Attendance List based on Project and date ");
			return mapDataAbsentBarGraphbasedOndate(pagedResult, pagingDto.getDate(), pagingDto.getProjectId(),
					companyId);
		}

		return new HashMap<>();
	}

	/**
	 * Pagination and sorting for Present employee attendance list based on
	 * projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	public Map<String, Object> mapDataBarGraphbasedOndate(Page<AttendanceInfoDTO> pagedResult, String date,
			Long projectId, String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> presentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			for (Employee emp : project.get().getEmployee()) {
				AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
				logger.info("Present Employee Attendance List based on Project Id shown in BarGraph " + " : ", info);
				if (Objects.isNull(info)) {
					continue;
				}
				LocalTime localTime = LocalTime.parse(info.getNoOfHrs());
				Long millis = (long) (localTime.toSecondOfDay() * 1000);
				Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
				if (noOfhr != 0) {
					AttendanceInfoDTO dto = copyPropertites(info);
					presentList.add(dto);
				}
			}
		} else {
			return response;
		}
		response.put(Constants.DATA, presentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Pagination and sorting for Present employee attendance list based on
	 * projectId
	 *
	 * @param id-projectId
	 * @return - AttendanceInfo
	 */
	public Map<String, Object> mapDataAbsentBarGraphbasedOndate(Page<AttendanceInfoDTO> pagedResult, String date,
			Long projectId, String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceInfoDTO> absentList = new ArrayList<>();
		Optional<Project> project = proRepo.findProjectByCompanyId(projectId, companyId);
		if (project.isPresent()) {
			for (Employee emp : project.get().getEmployee()) {
				AttendanceInfo info = infoRepository.getNoOfHrsPerEmpInProject(emp.getId(), date, companyId);
				logger.info("Absent Employee Attendance List based on Project Id shown in BarGraph " + " : ", info);
				if (Objects.isNull(info)) {
					continue;
				}
				LocalTime localTime = LocalTime.parse(info.getNoOfHrs());
				Long millis = (long) (localTime.toSecondOfDay() * 1000);
				Long noOfhr = (millis / (1000 * 60 * 60)) % 24;
				if (noOfhr == 0) {
					AttendanceInfoDTO dto = copyPropertites(info);
					absentList.add(dto);
				}
			}

		} else {
			return response;
		}
		response.put(Constants.DATA, absentList);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

}
