package com.hrms.admin.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AssignShiftDTO;
import com.hrms.admin.dto.ProjectShiftDTO;
import com.hrms.admin.dto.ShiftAssignDTO;
import com.hrms.admin.dto.ShiftEmployeeDTO;
import com.hrms.admin.dto.ShiftRequestDTO;
import com.hrms.admin.entity.AssignShift;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.Shift;
import com.hrms.admin.entity.ShiftRequest;
import com.hrms.admin.repository.AssignShiftRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.repository.ShiftRepository;
import com.hrms.admin.repository.ShiftRequestRepository;
import com.hrms.admin.service.AssignShiftService;
import com.hrms.admin.util.Constants;

@Service
public class AssignShiftServiceImpl implements AssignShiftService {

	private static final Logger logger = LoggerFactory.getLogger(AssignShiftServiceImpl.class);

	@Autowired
	private AssignShiftRepository repo;

	@Autowired
	private ShiftRepository shiftRepo;
	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	ProjectRepository projectRepo;

	@Autowired
	private ShiftRequestRepository shiftRequestRepository;

	@Override
	public ShiftAssignDTO assignShift(ShiftAssignDTO model) {
		Set<AssignShift> asSet = new HashSet<>();
		ShiftAssignDTO responce = new ShiftAssignDTO();
		for (ProjectShiftDTO projectShiftDTO : model.getMapList()) {
			Optional<Project> projectOptional = projectRepo.findById(projectShiftDTO.getProjectId());
			if (!projectOptional.isPresent()) {
				return null;
			}
			Project p = projectOptional.get();
			List<ShiftEmployeeDTO> shiftEmployeeDTO = projectShiftDTO.getShifts();
			for (ShiftEmployeeDTO shiftEmpDTO : shiftEmployeeDTO) {
				Optional<Shift> findById = shiftRepo.findById(shiftEmpDTO.getShiftId());
				if (!findById.isPresent()) {
					return null;
				}
				Shift shift = findById.get();
				for (Long employeeid : shiftEmpDTO.getEmployeeIds()) {
					Optional<Employee> findById2 = employeeRepo.findById(employeeid);
					if (!findById2.isPresent()) {
						return null;
					}
					Employee emp = findById2.get();
					List<AssignShift> aslist = repo.findByEmplolyeeIdAndProjectId(emp.getId(), p.getId());
					if (!aslist.isEmpty()) {
						for (AssignShift as1 : aslist) {
							as1.setShift(shift);
							as1.setShiftName(shift.getShiftName());
							as1.setFromDate(p.getStartDate());
							as1.setToDate(p.getEndDate());
							as1.setProjectName(p.getName());
							as1.setProjectId(p.getId());
							as1.setManagerId(model.getEmployeeManagerId());
							as1.setIsDelete(Boolean.FALSE);
							List<AssignShift> findByEmployeeId = repo.findByEmployeeId(emp.getId());
							if (!findByEmployeeId.isEmpty()) {
								for (AssignShift assignShift2 : findByEmployeeId) {
									assignShift2.setShift(shift);
									assignShift2.setShiftName(shift.getShiftName());
									asSet.add(assignShift2);
								}
								asSet.add(as1);
							}
						}
					} else {
						AssignShift entity = new AssignShift();
						entity.setEmployeeName(emp.getFirstName().concat(" ").concat(emp.getLastName()));
						entity.setShift(shift);
						entity.setShiftName(shift.getShiftName());
						entity.setEmployee(emp);
						entity.setFromDate(p.getStartDate());
						entity.setToDate(p.getEndDate());
						entity.setProjectName(p.getName());
						entity.setProjectId(p.getId());
						entity.setManagerId(model.getEmployeeManagerId());
						entity.setIsDelete(Boolean.FALSE);
						asSet.add(entity);
					}
				}
			}
		}
		asSet.remove(null);
		repo.saveAll(asSet);
		responce.setMapList(model.getMapList());
		responce.setEmployeeManagerId(model.getEmployeeManagerId());
		logger.info("Shift Assigned to employee :: ");
		return responce;
	}

	public static String getDayStringNew(String date, Locale locale) {
		LocalDate localDate = LocalDate.parse(date);
		DayOfWeek day = localDate.getDayOfWeek();
		return day.getDisplayName(TextStyle.FULL, locale);
	}

	@Override
	@Cacheable(value = "getAssignShiftByEmpId", unless = "#result == null", key = "#empId")
	public List<AssignShiftDTO> getAssignShiftByEmpId(Long empId, String companyId) {
		List<AssignShiftDTO> alist = repo.findByEmpId(empId, companyId);
		logger.info("Shift  found");
		return alist;
	}

	@Override

	public String changeShiftRequest(ShiftRequestDTO model) {
		ShiftRequest shiftRequest = new ShiftRequest();

		Optional<Employee> findById = employeeRepo.findById(model.getEmployeeId());
		if (!findById.isPresent()) {
			logger.info("employee not found");
			return null;
		}
		Employee e = findById.get();
		shiftRequest.setEmployeeName(e.getFirstName() + " " + e.getLastName());
		shiftRequest.setEmployee(e);
		shiftRequest.setReason(model.getReason());
		shiftRequest.setCurrentShiftName(model.getCurrentShift());
		shiftRequest.setRequestShiftID(model.getRequestShiftId());
		shiftRequest.setRemarks(model.getRemark());
		String shift = shiftRepo.findById1(model.getRequestShiftId());
		if (shift == null) {
			logger.info("Requested shift not available");
			return Constants.REQUESTEDSHIFTNOTAVAILABLE;
		}
		shiftRequest.setRequestShiftName(shift);
		shiftRequest.setStatus(Constants.PENDING);
		shiftRequest.setFromdate(model.getFromdate());
		shiftRequest.setTodate(model.getTodate());
		shiftRequestRepository.save(shiftRequest);
		logger.info("Shift Requested Successfully");
		return Constants.SHIFTREQUESTSUCCESS;
	}

	@Override
	public Map<String, Object> getAllAssignShifts(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AssignShift> pagedResult = null;
		Boolean status = true;

		pagedResult = repo.assignShiftPage(searchKey, companyId, status, paging);
		logger.info("For AssignShift Records page is created");
		return mapData(pagedResult);

	}

	public static Map<String, Object> mapData(Page<AssignShift> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<AssignShiftDTO> assignShift = pagedResult.stream().map(assignShiftEntity -> {
			AssignShiftDTO model = new AssignShiftDTO();
			model.setFromdate(assignShiftEntity.getFromDate());
			model.setTodate(assignShiftEntity.getToDate());
			model.setEmployeeId(assignShiftEntity.getEmployee().getId());
			model.setEmployeeName(assignShiftEntity.getEmployee().getFirstName() + " "
					+ assignShiftEntity.getEmployee().getLastName());
			model.setManagerId(assignShiftEntity.getManagerId());
			model.setProjectId(assignShiftEntity.getProjectId());
			model.setProjectName(assignShiftEntity.getProjectName());
			model.setFromdate(assignShiftEntity.getFromDate());
			model.setTodate(assignShiftEntity.getToDate());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, assignShift);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("AssignShift map object is created for Paging");
		return response;
	}

	@Override
	@Cacheable(value = "findAll", unless = "#result.size() == 0")
	public List<AssignShiftDTO> findAll(String companyId) {
		List<AssignShift> a = repo.findAll(companyId);
		logger.info("Shift  found :: ");
		List<AssignShiftDTO> models;
		models = a.stream().map(entity -> {
			AssignShiftDTO model = new AssignShiftDTO();
			model.setId(entity.getId());
			model.setFromdate(entity.getFromDate());
			model.setTodate(entity.getToDate());
			model.setShiftId(entity.getShift().getId());
			model.setShiftName(entity.getShift().getShiftName());
			model.setProjectName(entity.getProjectName());
			model.setEmployeeId(entity.getEmployee().getId());
			model.setProjectId(entity.getProjectId());
			model.setFromdate(entity.getFromDate());
			model.setTodate(entity.getToDate());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	@Override
	public String updateRequestedShift(ShiftRequestDTO model) throws ParseException {
		long day = 1000 * 60 * 60 * 24L;
		Optional<ShiftRequest> findById = shiftRequestRepository.findById(model.getId());
		if (!findById.isPresent()) {
			return null;
		}
		ShiftRequest s = findById.get();
		List<AssignShift> assignShift = repo.findByEmployeeId(s.getEmployee().getId());
		Optional<Shift> findById2 = shiftRepo.findById(s.getRequestShiftID());
		if (!findById2.isPresent()) {
			return null;
		}
		Shift requestedshift = findById2.get();
		if (model.getStatus().equalsIgnoreCase(Constants.APPROVED)) {
			Date reqStartDate = new SimpleDateFormat(Constants.DATEFORMAT).parse(s.getFromdate());
			Date reqEndDate = new SimpleDateFormat(Constants.DATEFORMAT).parse(s.getTodate());
			for (AssignShift shif : assignShift) {
				Date startDate = new SimpleDateFormat(Constants.DATEFORMAT).parse(shif.getFromDate());
				Date endDate = new SimpleDateFormat(Constants.DATEFORMAT).parse(shif.getToDate());
				if (reqStartDate.after(startDate) && reqEndDate.before(endDate)) {
					AssignShift shift = shif;
					shift.setIsDelete(Boolean.TRUE);
					repo.save(shif);
					AssignShift shift1 = new AssignShift();
					shift1.setFromDate(shift.getFromDate());
					Date to = new Date(reqStartDate.getTime() - day);
					DateFormat dateformat = new SimpleDateFormat(Constants.DATEFORMAT);
					String toDate = dateformat.format(to);
					shift1.setEmployeeName(
							shift.getEmployee().getFirstName().concat(" ").concat(shift.getEmployee().getLastName()));
					shift1.setShiftName(shift.getShiftName());
					shift1.setToDate(toDate);
					shift1.setEmployee(shift.getEmployee());
					shift1.setProjectName(shift.getProjectName());
					shift1.setProjectId(shift.getProjectId());
					shift1.setShift(shift.getShift());
					shift1.setManagerId(shift.getManagerId());
					shift1.setIsDelete(Boolean.FALSE);
					repo.save(shift1);
					AssignShift shift2 = new AssignShift();
					shift1.setEmployeeName(
							shift.getEmployee().getFirstName().concat(" ").concat(shift.getEmployee().getLastName()));
					shift1.setShiftName(shift.getShiftName());
					shift2.setFromDate(dateformat.format(reqStartDate));
					shift2.setEmployee(shift.getEmployee());
					shift2.setProjectName(shift.getProjectName());
					shift2.setProjectId(shift.getProjectId());
					shift2.setShift(requestedshift);
					shift2.setIsDelete(Boolean.FALSE);
					shift2.setToDate(dateformat.format(reqEndDate));
					shift2.setManagerId(shift.getManagerId());
					repo.save(shift2);
					AssignShift shift3 = new AssignShift();
					Date from = new Date(reqEndDate.getTime() + day);
					shift1.setEmployeeName(
							shift.getEmployee().getFirstName().concat(" ").concat(shift.getEmployee().getLastName()));
					shift1.setShiftName(shift.getShiftName());
					shift3.setFromDate(dateformat.format(from));
					shift3.setEmployee(shift.getEmployee());
					shift3.setProjectName(shift.getProjectName());
					shift3.setProjectId(shift.getProjectId());
					shift3.setShift(shift.getShift());
					shift3.setManagerId(shift.getManagerId());
					shift3.setIsDelete(Boolean.FALSE);
					shift3.setToDate(shift.getToDate());
					repo.save(shift3);
				}
			}
			s.setStatus(model.getStatus());
			s.setRemarks(model.getRemark());
			shiftRequestRepository.save(s);
			logger.info("Requested Shift ");
			return Constants.APPROVE_SUCCESS;
		} else if (model.getStatus().equalsIgnoreCase(Constants.REJECTED)) {
			s.setStatus(model.getStatus());
			s.setRemarks(model.getRemark());
			shiftRequestRepository.save(s);
			return Constants.REJECT_SUCCESS;
		} else {
			logger.info("approval is invalid for Shift Request ");
			return "Failed To Update";
		}

	}

	@Override
	public boolean validate(AssignShiftDTO model, boolean isSave) {
		return false;
	}

	@Override
	public String updateChangeShiftRequest(ShiftRequestDTO model, Long id) {
		Optional<ShiftRequest> findById = shiftRequestRepository.findById(id);
		if (!findById.isPresent()) {
			return null;
		}
		ShiftRequest a = findById.get();
		if (a.getStatus().equalsIgnoreCase(Constants.PENDING)) {

			Optional<Shift> optionalShift = shiftRepo.findById(model.getRequestShiftId());
			if (!optionalShift.isPresent()) {
				return null;
			}
			Shift s = optionalShift.get();
			Optional<Employee> optionalEmployee = employeeRepo.findById(model.getEmployeeId());
			if (!optionalEmployee.isPresent()) {
				return null;
			}
			Employee e = optionalEmployee.get();
			a.setReason(model.getReason());
			a.setRequestShiftID(model.getRequestShiftId());
			a.setFromdate(model.getFromdate());
			a.setTodate(model.getTodate());
			a.setCurrentShiftName(model.getCurrentShift());
			a.setRequestShiftName(s.getShiftName());
			a.setEmployeeName(e.getFirstName() + " " + e.getLastName());
			a.setStatus(Constants.PENDING);
			shiftRequestRepository.save(a);
			return Constants.UPDATE_SUCCESS;
		} else {
			return Constants.UPDATE_FAIL;
		}

	}

	@Override
	public Map<String, Object> getAllEmployeeShift(Long empId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<ShiftRequest> pagedResult = null;

		String status = Constants.PENDING;
		if (isActive == null || isActive.isEmpty()) {
			pagedResult = shiftRequestRepository.allShiftRequestPage(searchKey, empId, companyId, paging);
		} else {
			if (isActive.equals("1")) {
				status = Constants.APPROVED;
			} else if (isActive.equals("2")) {
				status = Constants.REJECTED;
			}
			pagedResult = shiftRequestRepository.shiftRequestPage(searchKey, empId, status, companyId, paging);
		}
		if (pagedResult.hasContent())

		{
			logger.info("For ShiftRequest Records page is created");
			return mapData1(pagedResult);
		} else {
			return new HashMap<>();
		}

	}

	public static Map<String, Object> mapData1(Page<ShiftRequest> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<ShiftRequestDTO> shiftModels = new ArrayList<>();
		for (ShiftRequest shiftEntity : pagedResult) {
			ShiftRequestDTO model = new ShiftRequestDTO();
			model.setId(shiftEntity.getId());
			model.setStatus(shiftEntity.getStatus());
			model.setEmployeeId(shiftEntity.getEmployee().getId());
			model.setRequestShiftId(shiftEntity.getRequestShiftID());
			model.setRequestShiftName(shiftEntity.getRequestShiftName());
			model.setCurrentShift(shiftEntity.getCurrentShiftName());
			model.setEmployeeName(shiftEntity.getEmployeeName());
			model.setFromdate(shiftEntity.getFromdate());
			model.setTodate(shiftEntity.getTodate());
			model.setReason(shiftEntity.getReason());
			model.setRemark(shiftEntity.getRemarks());
			shiftModels.add(model);

		}
		if (shiftModels.isEmpty()) {
			return new HashMap<>();
		} else {
			response.put(Constants.DATA, shiftModels);
			response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
			response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
			response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
			return response;
		}
	}

	@Override
	public Map<String, Object> getAllManagerShift(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<ShiftRequest> pagedResult = null;
		String status = "Pending";
		if (isActive == null || isActive.isEmpty()) {
			pagedResult = shiftRequestRepository.allShiftRequestManagerPage(searchKey,companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = Constants.PENDING;
			} else if (isActive.equals("1")) {
				status = Constants.APPROVED;
			} else if (isActive.equals("2")) {
				status = Constants.REJECTED;
			}
			pagedResult = shiftRequestRepository.shiftRequestManagerPage(searchKey, status,companyId, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For ShiftRequest Records page is created");
			return mapData2(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapData2(Page<ShiftRequest> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<ShiftRequestDTO> shiftModels = pagedResult.stream().map(shiftEntity -> {
			ShiftRequestDTO model = new ShiftRequestDTO();
			model.setId(shiftEntity.getId());
			model.setStatus(shiftEntity.getStatus());
			model.setEmployeeId(shiftEntity.getEmployee().getId());
			model.setRequestShiftId(shiftEntity.getRequestShiftID());
			model.setRequestShiftName(shiftEntity.getRequestShiftName());
			model.setEmployeeName(shiftEntity.getEmployeeName());
			model.setFromdate(shiftEntity.getFromdate());
			model.setTodate(shiftEntity.getTodate());
			model.setReason(shiftEntity.getReason());
			model.setRemark(shiftEntity.getRemarks());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, shiftModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}
}
