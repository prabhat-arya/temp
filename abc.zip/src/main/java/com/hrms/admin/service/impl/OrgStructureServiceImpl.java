package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.OrgStructureChild;
import com.hrms.admin.dto.OrgStructureData;
import com.hrms.admin.dto.OrgStructureParent;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.service.OrgStructureService;

/**
 * @author Prabhat
 * 
 * @see This is implementation class for Orgenization Structure
 * 
 */
@Service
public class OrgStructureServiceImpl implements OrgStructureService {
	
	private static final Logger log = LoggerFactory.getLogger(OrgStructureServiceImpl.class);

	@Autowired
	EmployeeRepository employeeRepository;


	/**
	 * @see This method is used to get the Whole orgenigation structure
	 */
	@Override
	@Cacheable(value= "getOrgCache", unless= "#result.size() == 0")
	public List<OrgStructureParent> getOrg() {

		List<OrgStructureParent> allOrgStructure = new ArrayList<>();

		List<Employee> employeeByLevelId = employeeRepository.getEmpByReportToNo(getHigherReporterNo());
		for (Employee employee : employeeByLevelId) {
			OrgStructureParent setParentEmpData = setParentEmpData(employee);

			List<Employee> allChildEmp = employeeRepository.getEmpByReportToNo(employee.getId());
			List<OrgStructureChild> allChildList = getchildrens(allChildEmp);

			setParentEmpData.setChildren(allChildList);

			if (!allOrgStructure.contains(setParentEmpData))
				allOrgStructure.add(setParentEmpData);

		}
		return allOrgStructure;

	}

	/**
	 * @see This method used to get Childrens
	 */

	@Override
	public List<OrgStructureChild> getchildrens(List<Employee> allChildemp) {

		List<OrgStructureChild> allChildList = new ArrayList<>();
		for (Employee empChild : allChildemp) {
			OrgStructureChild setEmpData = setChildEmpData(empChild);

			allChildList.add(setEmpData);

			List<Employee> allChild2emp = employeeRepository.getEmpByReportToNo(empChild.getId());

			List<OrgStructureChild> getchild3 = getchildrens(allChild2emp);

			setEmpData.setChildren(getchild3);
			if (!allChildList.contains(setEmpData))
				allChildList.add(setEmpData);

		}
		return allChildList;
	}

	/**
	 * @see This is use to set the Child Employee data
	 */

	@Override
	public OrgStructureChild setChildEmpData(Employee emp) {

		OrgStructureChild childData = new OrgStructureChild();
		OrgStructureData childEmpData = new OrgStructureData();
		childEmpData.setId(emp.getId());
		childEmpData.setManagerid(emp.getManager().getId());
		childEmpData.setEmail(emp.getEmail());
		childEmpData.setName(emp.getFirstName() + " " + emp.getLastName());
		childEmpData.setDepartmentname(emp.getDepartment().getName());
		childEmpData.setCount(getChildCount(emp.getId()));

		childData.setLabel(emp.getDesignation().getDesignation());
		childData.setStyleClass("deptstyle");
		childData.setType("person");
		childData.setData(childEmpData);

		return childData;

	}

	/**
	 * @see This is use to set the Parent Employee data
	 */

	@Override
	public OrgStructureParent setParentEmpData(Employee emp) {

		OrgStructureParent parentEmp = new OrgStructureParent();
		OrgStructureData empData = new OrgStructureData();
		empData.setId(emp.getId());
		empData.setManagerid(emp.getManager().getId());
		empData.setEmail(emp.getEmail());
		empData.setName(emp.getFirstName() + " " + emp.getLastName());
		empData.setDepartmentname(emp.getDepartment().getName());
		empData.setCount(getChildCount(emp.getId()));

		parentEmp.setLabel(emp.getDesignation().getDesignation());
		parentEmp.setStyleClass("deptstyle");
		parentEmp.setType("person");
		parentEmp.setData(empData);

		return parentEmp;

	}

	/**
	 * @see this method is used to create get the total number of Child
	 */

	@Override
	public String getChildCount(Long empId) {

		List<Employee> allChildEmp = employeeRepository.getEmpByReportToNo(empId);
		return String.valueOf(allChildEmp.size());

	}
	
	/**
	 * @see this method is used to get the higher autherity popele Like CEO
	 */

	public Long getHigherReporterNo() {
		return employeeRepository.getFirstRepoter();
	}

}
