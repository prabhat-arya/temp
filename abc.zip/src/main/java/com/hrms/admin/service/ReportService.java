package com.hrms.admin.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.InputStreamResource;
import org.supercsv.io.ICsvBeanWriter;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.PayrollReportPaginationDTO;
import com.hrms.admin.dto.ReportPageDTO;
import com.itextpdf.text.DocumentException;

public interface ReportService {
	public Map<String, Object> getOnboardingReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String startDate, String endDate, String gender,
			Long departmentId, Long designationId, String companyId) throws ParseException;

	public ICsvBeanWriter getAllonboardListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws IOException, ParseException;

	public InputStreamResource getEmployeeExcelReports(String startDate, String endDate, String status,
			String searchKey, String gender, Long departmentId, Long designationId, String companyId)
			throws IOException, ParseException;

	public InputStreamResource getAllEmployeepdfReports(String startDate, String endDate, String status,
			String searchKey, String gender, Long departmentId, Long designationId, String companyId)
			throws ParseException, Exception;

	public Map<String, Object> getAllShiftReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, Long projectId, Long shiftId, String startDate, String endDate, String companyId);

	public InputStreamResource getShiftExcelReportShifts(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId) throws IOException;

	public InputStreamResource getAllpdfReportShifts(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId) throws Exception;

	public ICsvBeanWriter getAllshiftListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws IOException;

	public Map<String, Object> getAllLeaveReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String startDate, String endDate, String companyId) throws ParseException;

	// public List<LeaveReportDTO> getLeaveReports(String startDate, String endDate)
	// throws ParseException;

	public InputStreamResource getLeaveExcelReport(String startDate, String endDate, String searchKey, String companyId)
			throws IOException, ParseException, Exception;

	public InputStreamResource getLeavepdfReport(String startDate, String endDate, String searchKey, String companyId)
			throws ParseException, MalformedURLException, DocumentException, IOException, Exception;

	public ICsvBeanWriter getAllleaveListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws IOException, ParseException, Exception;

	public String currentDateandTime();

	public Map<String, Object> getAttendanceReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, String companyId) throws ParseException;

	public List<AttendanceInfoDTO> getAttendanceReports(String startDate, String endDate, String companyId,
			String searchKey) throws ParseException;

	public InputStreamResource getAttendanceExcelReport(String startDate, String endDate, String companyId,
			String searchKey) throws IOException, ParseException, Exception;

	public InputStreamResource getAttendancepdfReport(String startDate, String endDate, String companyId,
			String searchKey) throws ParseException, MalformedURLException, DocumentException, IOException, Exception;

	public ICsvBeanWriter getAllAttendanceListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws IOException, ParseException, Exception;

	public Map<String, Object> getPerfomannceReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, String companyId) throws ParseException;

	public InputStreamResource getPerfomanceExcelReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception;

	public InputStreamResource getPerfomancepdfReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception;

	public ICsvBeanWriter getAllPerfomanceListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws IOException, ParseException;

	// payroll reports
	public Map<String, Object> getAllEmployeeReportBasedOnSalaryRange(int pageIndex, int pageSize, String sortBy,
			String key, String orderBy, String status, String salaryRange, String fromDate, String toDate,
			Long departmentId, Long designationId, String companyId) throws ParseException;

	/**
	 * payroll excel report generate
	 * 
	 * @throws ParseException
	 */
	InputStreamResource getPayrollExcelReport(String key, String status, String salaryRange, String fromDate,
			String toDate, Long departmentId, Long designationId, String companyId) throws IOException, ParseException;

	/*
	 * payroll pdf report genereate
	 */
	public InputStreamResource getPayrollPdfReport(String key, String status, String salaryRange, String fromDate,
			String toDate, Long departmentId, Long designationId, String companyId)
			throws ParseException, MalformedURLException, DocumentException, IOException;

	/*
	 * this method is used to download the csv file
	 */
	public ICsvBeanWriter csvFileForPayrollReport(HttpServletResponse response, PayrollReportPaginationDTO pagingDto,
			String companyId) throws IOException, ParseException;

	// Promotional(Employment Type) Reports start

	public Map<String, Object> getEmploymentTypeReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String startDate, String endDate, Long employmentTypeId, String companyId)
			throws ParseException;

	public InputStreamResource getPromotionalExcelReport(String startDate, String endDate, Long employmentTypeId,
			String companyId, String searchKey) throws IOException, ParseException, Exception;

	public InputStreamResource getPromotionalPdfReport(String startDate, String endDate, Long employmentTypeId,
			String companyId, String searchKey) throws IOException, ParseException, Exception;

	public ICsvBeanWriter getEmployeesPromotionalListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws IOException, ParseException;

	public Map<String, Object> getAllExitEmployeeReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String startDate, String endDate, String companyId) throws Exception;

	public InputStreamResource getAllExitEmployeeExcelReport(String startDate, String endDate, String companyId,
			String searchKey) throws Exception;

	public InputStreamResource getAllExitEmployeepdfReport(String startDate, String endDate, String companyId,
			String searchKey) throws Exception;

	public ICsvBeanWriter getAllExitEmployeeExportToCSV(HttpServletResponse response, ReportPageDTO pagingDto, String companyId) throws Exception;
}
