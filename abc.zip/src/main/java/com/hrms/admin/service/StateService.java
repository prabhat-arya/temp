package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.entity.State;

public interface StateService {
	public List<State> findByCountry(Long id);

}
