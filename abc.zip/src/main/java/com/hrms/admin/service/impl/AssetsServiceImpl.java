package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AssetsDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Assets;
import com.hrms.admin.entity.Company;
import com.hrms.admin.repository.AssetsRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.service.AssetsService;
import com.hrms.admin.util.Constants;

@Service
public class AssetsServiceImpl implements AssetsService {
	private static final Logger logger = LoggerFactory.getLogger(AssetsServiceImpl.class);

	@Autowired
	private AssetsRepository assetRepo;

	@Autowired
	private CompanyRepository companyRepo;


	/**
	 * Returns true when new Assets is store in database
	 * 
	 * @param model - new Assets data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(AssetsDTO model) {
		Assets entity = new Assets();
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		Company cmp = new Company();
		cmp.setId(model.getCompanyId());
		entity.setCompany(cmp);
		entity.setIsActive(Boolean.TRUE);
		entity.setIsDelete(Boolean.FALSE);
		Assets d = assetRepo.save(entity);
		logger.info("Assets Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(d.getId());
		dto.setName(d.getName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;

	}
	
	/**
	 * Returns Assets data when Assets data is available in database by id
	 * @param id - AssetsId
	 * @return - AssetsModel
	 */

	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public AssetsDTO getById(Long id, String companyId) {
		Optional<Assets> optionalEntity = assetRepo.findById(id, companyId);
		if (optionalEntity.isPresent()) {
			Assets entity = optionalEntity.get();
			AssetsDTO model = new AssetsDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			logger.info("Assets found in DB with id:{}",id);
			return model;
		} else {
			logger.info("Assets Not found in DB with id:{}",id);
			return null;
		}
	}

	@Override
	public boolean deleteAssets(Long id) {
		assetRepo.deleteById(id);
		logger.info("Assets record is deleted from database");
		return true;
	}
	
	/**
	 * Returns true when existing Assets data is store in database
	 * 
	 * @param model - AssetsDTO
	 * @param id    - AssetsId
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> updateAssets(AssetsDTO model) {
		Optional<Assets> findById = assetRepo.findById(model.getId());
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Assets oldAssets = findById.get();
			oldAssets.setName(model.getName());
			oldAssets.setDescription(model.getDescription());
			Optional<Company> company = companyRepo.findById(model.getCompanyId());
			if (company.isPresent()) {
				oldAssets.setCompany(company.get());
			}
			Assets d = assetRepo.save(oldAssets);
			logger.info("Assets record is updated in database with Id:{}",model.getId());
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getName());
			list.add(dto);
			return list;
		} else {
			logger.info("Assets record is not found in database with id:{}",model.getId());
			return list;
		}

	}
	

	/**
	 * @param companyId
	 * @return return the Assets based on CompanyId
	 */

	@Override
	@Cacheable(value = " AllAssetse", unless = "#result == null", key = "#companyId")
	public List<AssetsDTO> AllAssets(String companyId) {
		List<Assets> allAsset = assetRepo.findByCompany(companyId);
		List<AssetsDTO> models = allAsset.stream().map(entity -> {
			AssetsDTO model = new AssetsDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());

			return model;
		}).collect(Collectors.toList());
		logger.info("Assets Records are converted in to Assets models");
		return models;
	}
	
	/**
	 * @param id -Assets,
	 * @return -  change value from database isDisable is true
	 */

	public List<EntityDTO> softDeleteAssets(Long id) {
		Optional<Assets> findById = assetRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Assets assets = findById.get();
			assets.setIsActive(Boolean.FALSE);
			assets.setIsDelete(Boolean.TRUE);
			Assets p = assetRepo.save(assets);
			logger.info("Asset is found in database with assetId:{}",id);
			EntityDTO dto = new EntityDTO();
			dto.setId(p.getId());
			dto.setName(p.getName());
			list.add(dto);
			return list;
		} else {
			logger.info("Asset is not found in database with assetId:{}",id);
			return list;
		}

	}
	
	/**
	 * @param Assets Entity
	 * @return - page size
	 */

	public static Map<String, Object> mapData(Page<AssetsDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<AssetsDTO> designationModels = pagedResult.stream().map(entity -> {
			AssetsDTO model = new AssetsDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			Company cmp = new Company();
			model.setCompanyId(cmp.getId());
			model.setCompanyName(entity.getCompanyName());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, designationModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put( Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("Assets map object is created for Paging");
		return response;
	}

	/**
	 * @param AssetsDTO,
	 *  @param boolean value,
	 * @return -  if record exit return true or if record not exit  return false
	 */
	
	@Override
	public boolean validate(AssetsDTO assets, boolean isSave) {
		Long count;
		if (isSave)
			count = assetRepo.getSkillCountSave(assets.getName(), assets.getCompanyId());
		else
			count = assetRepo.getSkillCountUpdate(assets.getCompanyId(), assets.getName(), assets.getId());
		return count > 0;
	}

	/**
	 * @param pageIndex,
	 * @param pageSize,sortBy,
	 * @param searchKey,
	 * @param orderBy,
	 * @param status
	 * @return - page size
	 */

	@Override
	public Map<String, Object> getAllAssets(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AssetsDTO> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = assetRepo.allAssetsPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = assetRepo.assetsPage(searchKey,companyId,status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Assets Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * @param AssertsId,
	 *  @param String,
	 * @return -  if record is updateAttendanceByStatus based on Asserts id
	 */

	public List<EntityDTO> updateAssetsByStatus(Long id, String status) {
		Optional<Assets> findById = assetRepo.findByAsset(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Assets a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Assets e = assetRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Assets is activated in  database with assetId:{}",id);
				return list;
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Assets e = assetRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Assets is deactivated in  database with assetId:{}",id);
				return list;
			}
		}
		logger.info("Assets is not available in database with assetId:{}",id);
		return list;
	}
}
