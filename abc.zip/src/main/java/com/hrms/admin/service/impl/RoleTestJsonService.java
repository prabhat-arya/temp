package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.Menu;
import com.hrms.admin.entity.RoleJson;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.repository.RoleJsonRepo;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.role.dto.EmpRoleDTO;
import com.hrms.admin.role.dto.EmployeeRoleDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.MenuSortingDTOConverter;

@Service
public class RoleTestJsonService {

	@Autowired
	private RoleJsonRepo roleJsonRepo;

	@Autowired
	private MenuRepository menuRepo;

	@Autowired
	private RolesRepository roleRepo;

	@Autowired
	private MenuSortingDTOConverter menuConverter;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final Logger logger = LoggerFactory.getLogger(RoleTestJsonService.class);

	public EmployeeRoleDTO createRole(EmployeeRoleDTO empRole, String companyId) {

		List<MenuSortingDTO> menuSorting = empRole.getMenuSorting();
		Set<MenuSortingDTO> menuSortingDTOParent = new HashSet<>();
		Set<MenuSortingDTO> menuSortingDTOchild = new HashSet<>();
		List<MenuSortingDTO> menuSortingDTOList = new ArrayList<>();
		for (MenuSortingDTO menuSortingDTO : menuSorting) {

			Menu findByMenuId = menuRepo.findByMenuId(menuSortingDTO.getId());
			menuSortingDTO.setMenuPath(findByMenuId.getMenuPath());
			menuSortingDTO.setMenuIcon(findByMenuId.getMenuIcon());
			menuSortingDTO.setParentId(findByMenuId.getParentId());

			if (menuSortingDTO.getParentId() > 0) {
				menuSortingDTOchild.add(menuSortingDTO);
				Menu findByMenuId2 = menuRepo.findByMenuId(menuSortingDTO.getParentId());
				MenuSortingDTO parentDto = new MenuSortingDTO();
				parentDto.setId(findByMenuId2.getMenuId());
				parentDto.setMenuTitle(findByMenuId2.getMenuTitle());
				parentDto.setMenuPath(findByMenuId2.getMenuPath());
				parentDto.setMenuIcon(findByMenuId2.getMenuIcon());
				menuSortingDTOParent.add(parentDto);

			} else {

				Menu findByMenuId2 = menuRepo.findByMenuId(menuSortingDTO.getId());

				menuSortingDTO.setMenuPath(findByMenuId2.getMenuPath());
				menuSortingDTO.setMenuIcon(findByMenuId2.getMenuIcon());
				menuSortingDTOParent.add(menuSortingDTO);
			}
		}
		for (MenuSortingDTO parentMenu : menuSortingDTOParent) {

			List<MenuSortingDTO> childListMap = new ArrayList<>();
			for (MenuSortingDTO menuSortingDTO : menuSortingDTOchild) {

				if (menuSortingDTO.getParentId().equals(parentMenu.getId())) {
					childListMap.add(menuSortingDTO);
				}
			}
			Collections.sort(childListMap);
			parentMenu.setChilds(childListMap);
			menuSortingDTOList.add(parentMenu);
		}
		Collections.sort(menuSortingDTOList);
		String convertToDatabaseColumn = menuConverter.convertToDatabaseColumn(menuSortingDTOList);

		RoleJson roleJson = new RoleJson();
		roleJson.setAccessList(convertToDatabaseColumn);
		RoleJson save = roleJsonRepo.save(roleJson);
		EmployeeRoles employeeRoles = new EmployeeRoles();
		employeeRoles.setRoleName(empRole.getRoleName());
		employeeRoles.setIsActive(true);
		employeeRoles.setIsDelete(false);
		employeeRoles.setRoleJson(save);
		Optional<Company> findById = companyRepo.findById(companyId);
		if (findById.isPresent()) {
			employeeRoles.setCompany(findById.get());
		}
		roleRepo.save(employeeRoles);

		EmployeeRoleDTO employeeRoleDTO = new EmployeeRoleDTO();
		employeeRoleDTO.setRoleId(employeeRoles.getRoleId());
		employeeRoleDTO.setRoleName(employeeRoles.getRoleName());
		employeeRoleDTO.setIsActive(employeeRoles.getIsActive());
		employeeRoleDTO.setIsDelete(employeeRoles.getIsDelete());
		employeeRoleDTO.setMenuSorting(menuSortingDTOList);

		return employeeRoleDTO;
	}

	public EmployeeRoleDTO updateRole(EmployeeRoleDTO empRoleDTO, String companyId) {

		EmployeeRoles employeeRoles = roleRepo.findById(empRoleDTO.getRoleId()).get();
		RoleJson roleJson = employeeRoles.getRoleJson();

		List<MenuSortingDTO> menuSorting = empRoleDTO.getMenuSorting();

		Set<MenuSortingDTO> parentMenus = new HashSet<>();
		Set<MenuSortingDTO> childMenus = new HashSet<>();
		List<MenuSortingDTO> finalMenus = new ArrayList<>();

		for (MenuSortingDTO menuSortingDTO : menuSorting) {

			if (menuSortingDTO.getChilds().size() > 0) {

				Menu findByMenuId = menuRepo.findByMenuId(menuSortingDTO.getId());
				menuSortingDTO.setMenuIcon(findByMenuId.getMenuIcon());
				menuSortingDTO.setMenuPath(findByMenuId.getMenuPath());
				menuSortingDTO.setMenuTitle(findByMenuId.getMenuTitle());
				parentMenus.add(menuSortingDTO);
				List<MenuSortingDTO> childs = menuSortingDTO.getChilds();
				for (MenuSortingDTO child : childs) {
					Menu menu = menuRepo.findByMenuId(child.getId());
					child.setParentId(menu.getParentId());
					child.setMenuIcon(menu.getMenuIcon());
					child.setMenuPath(menu.getMenuPath());
					child.setMenuTitle(menu.getMenuTitle());
					parentMenus.add(menuSortingDTO);
					childMenus.add(child);
				}
			} else {
				Menu findByMenuId = menuRepo.findByMenuId(menuSortingDTO.getId());
				menuSortingDTO.setMenuIcon(findByMenuId.getMenuIcon());
				menuSortingDTO.setMenuPath(findByMenuId.getMenuPath());
				menuSortingDTO.setMenuTitle(findByMenuId.getMenuTitle());
				parentMenus.add(menuSortingDTO);
			}
		}

		for (MenuSortingDTO parentMenu : parentMenus) {

			List<MenuSortingDTO> childListMap = new ArrayList<>();
			for (MenuSortingDTO menuSortingDTO : childMenus) {

				if (menuSortingDTO.getParentId().equals(parentMenu.getId())) {
					childListMap.add(menuSortingDTO);
				}
			}

			Collections.sort(childListMap);
			parentMenu.setChilds(childListMap);
			finalMenus.add(parentMenu);
		}
		String convertToDatabaseColumn = menuConverter.convertToDatabaseColumn(menuSorting);
		roleJson.setAccessList(convertToDatabaseColumn);
		RoleJson dbRoleJson = roleJsonRepo.save(roleJson);
		String accessList = dbRoleJson.getAccessList();
		List<MenuSortingDTO> convertToEntityAttribute = menuConverter.convertToEntityAttribute(accessList);
		employeeRoles.setRoleJson(dbRoleJson);
		employeeRoles.setRoleName(empRoleDTO.getRoleName());
		Optional<Company> findById = companyRepo.findById(companyId);
		if (findById.isPresent()) {
			employeeRoles.setCompany(findById.get());
		}
		roleRepo.save(employeeRoles);
		EmployeeRoleDTO employeeRoleDTO = new EmployeeRoleDTO();
		employeeRoleDTO.setRoleId(employeeRoles.getRoleId());
		employeeRoleDTO.setRoleName(employeeRoles.getRoleName());
		employeeRoleDTO.setIsActive(employeeRoles.getIsActive());
		employeeRoleDTO.setIsDelete(employeeRoles.getIsDelete());
		employeeRoleDTO.setMenuSorting(convertToEntityAttribute);

		return employeeRoleDTO;
	}

	public EmployeeRoleDTO getRoleById(Long roleId) {
		EmployeeRoles employeeRoles = roleRepo.findById(roleId).get();
		EmployeeRoleDTO empRoleDTO = new EmployeeRoleDTO();
		empRoleDTO.setRoleId(employeeRoles.getRoleId());
		empRoleDTO.setRoleName(employeeRoles.getRoleName());
		empRoleDTO.setIsActive(employeeRoles.getIsActive());
		empRoleDTO.setIsDelete(employeeRoles.getIsDelete());

		String accessList = employeeRoles.getRoleJson().getAccessList();
		List<MenuSortingDTO> dbMenus = menuConverter.convertToEntityAttribute(accessList);

		for (MenuSortingDTO menuSortingDTO : dbMenus) {

			if (menuSortingDTO.getChilds().size() > 0) {
				Collections.sort(menuSortingDTO.getChilds());
			}
		}
		Collections.sort(dbMenus);
		empRoleDTO.setMenuSorting(dbMenus);
		return empRoleDTO;
	}

	public Map<String, Object> getAllRoles(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = null;

		Page<EmployeeRoles> pagedResult = null;
		if (isActive.trim().equals("") || isActive.equals(null)) {
			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				pagedResult = roleRepo.findAllSearchWithPagination(searchKey, companyId, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPagination(searchKey, companyId, paging);
			}
		} else if (isActive.equals("1")) {
			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				pagedResult = roleRepo.findAllSearchWithPaginationActiveRecords(searchKey, companyId, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPaginationActiveRecords(searchKey, companyId, paging);
			}

		} else {

			if (orderBy.equalsIgnoreCase(Constants.ASC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
				// Page<Attendance> pagedResult = attRepo.findAll(paging);
				pagedResult = roleRepo.findAllSearchWithPaginationInActiveRecord(searchKey, companyId, paging);

			} else if (orderBy.equalsIgnoreCase(Constants.DESC_ORDER)) {
				paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
				pagedResult = roleRepo.findAllSearchWithPaginationInActiveRecord(searchKey, companyId, paging);
			}
		}
		if (pagedResult.hasContent()) {
			logger.info("For Role Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	public Map<String, Object> mapData(Page<EmployeeRoles> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeRoleDTO> deptModels = pagedResult.stream().map(roleEntity -> {

			return getRoleById(roleEntity.getRoleId());

		}).collect(Collectors.toList());

		response.put(Constants.DATA, deptModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Department map object is created for Paging");
		return response;
	}

	public EmployeeRoleDTO deactiveRole(EmployeeRoleDTO empRoleDTO) {

		EmployeeRoles employeeRoles = roleRepo.findById(empRoleDTO.getRoleId()).get();
		EmployeeRoleDTO employeeRoleDTO = new EmployeeRoleDTO();
		if (employeeRoles.getIsActive() == true) {

			employeeRoles.setIsActive(false);
			employeeRoles.setIsDelete(false);
			roleRepo.save(employeeRoles);
		} else {
			employeeRoles.setIsActive(true);
			employeeRoles.setIsDelete(false);
			roleRepo.save(employeeRoles);
		}

		roleRepo.save(employeeRoles);
		employeeRoleDTO.setRoleId(employeeRoles.getRoleId());
		employeeRoleDTO.setRoleName(employeeRoles.getRoleName());

		return employeeRoleDTO;
	}

	public boolean dependencyCheck(Long roleId) {

		String SQL = "SELECT count(emp_id) FROM  emp_roles WHERE ROLE_ID = ?";
		Long count = (Long) jdbcTemplate.queryForObject(SQL, new Object[] { roleId }, Long.class);
		return (count == 0) ? true : false;
	}

	public List<MenuSortingDTO> getAllMenus() {

		List<Menu> menuDbList = menuRepo.findAll();
		List<Menu> parentMenu = new ArrayList<>();
		List<Menu> childMenus = new ArrayList<>();
		for (Menu menu : menuDbList) {
			if (menu.getIsParent() == 1 && menu.getIsParent() != 0) {
				parentMenu.add(menu);
			} else {
				childMenus.add(menu);
			}
		}

		List<MenuSortingDTO> menuList = new ArrayList<>();

		for (Menu menu : parentMenu) {

			// MenuSortingDTO sortedMenu = new MenuSortingDTO(menu.getMenuTitle(),
			// menu.getMenuIcon(), menu.getMenuPath(), menu.getMenuId());
			MenuSortingDTO sortedMenu = new MenuSortingDTO();
			sortedMenu.setId(menu.getMenuId());
			sortedMenu.setMenuTitle(menu.getMenuTitle());

			List<MenuSortingDTO> childs = new ArrayList<>();
			for (Menu childMenu : childMenus) {
				MenuSortingDTO childMenu1 = new MenuSortingDTO();
				if (menu.getMenuId().equals(childMenu.getParentId())) {
					// childMenu1 = new MenuSortingDTO(childMenu.getMenuTitle(),
					// childMenu.getMenuIcon(), childMenu.getMenuPath(), childMenu.getMenuId());
					childMenu1.setId(childMenu.getMenuId());
					childMenu1.setMenuTitle(childMenu.getMenuTitle());
					childs.add(childMenu1);
				}
				sortedMenu.setChilds(childs);
			}
			menuList.add(sortedMenu);
		}
		Collections.sort(menuList);
		return menuList;
	}

	public List<EmpRoleDTO> getAllRoles(String companyId) {

		List<EmployeeRoles> roleList = roleRepo.getAllRolesByCompany(companyId);
		List<EmpRoleDTO> roleListDto = new ArrayList<>();

		for (EmployeeRoles empRoles : roleList) {

			EmpRoleDTO empRoleDTO = new EmpRoleDTO();
			empRoleDTO.setRoleId(empRoles.getRoleId());
			empRoleDTO.setRoleName(empRoles.getRoleName());
			roleListDto.add(empRoleDTO);
		}
		return roleListDto;
	}
}
