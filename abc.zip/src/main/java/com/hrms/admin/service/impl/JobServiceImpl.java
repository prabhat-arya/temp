package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.JobDTO;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Job;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.Jobrepository;
import com.hrms.admin.service.JobService;
import com.hrms.admin.util.Constants;

@Service
public class JobServiceImpl implements JobService {

	private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

	@Autowired
	private Jobrepository jobRepository;
	@Autowired
	private CompanyRepository compnyRepo;

	/**
	 * Returns true when new Job is store in database
	 * 
	 * @param model - new Job data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(JobDTO model) {

		Job entity = new Job();
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setExperience(model.getExperience());
		Optional<Company> company2 = compnyRepo.findById(model.getCompanyId());
		if (company2.isPresent()) {
			entity.setCompany(company2.get());
		}
		Branch branch = new Branch();
		branch.setId(model.getBranchId());
		entity.setBranch(branch);
		entity.setIsActive(Boolean.TRUE);
		entity.setIsDelete(Boolean.FALSE);
		Job jobsaved = jobRepository.save(entity);
		logger.info("Job Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(jobsaved.getId());
		dto.setName(jobsaved.getName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	/**
	 * @param pageIndex,
	 * @param pageSize,sortBy,
	 * @param searchKey,
	 * @param orderBy,
	 * @param status
	 * @return - page size
	 */

	@Override
	public Map<String, Object> getAllJob(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<JobDTO> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals(" ")) {
			pagedResult = jobRepository.allJobPage(searchKey,companyId, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = jobRepository.jobPage(searchKey, companyId,status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Job Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns Job data when Job data is available in database by id
	 * 
	 * @param id - JobId
	 * @return - JobModel
	 */

	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public JobDTO getJobByCompanyId(Long id,String companyId) {
		Optional<Job> optionalEntity = jobRepository.findJobByCompanyId(id,companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Job entity = optionalEntity.get();
		JobDTO model = new JobDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDescription(entity.getDescription());
		model.setExperience(entity.getExperience());
		model.setCompanyId(entity.getCompany().getId());
		model.setBranchId(entity.getBranch().getId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		model.setIsActive(entity.getIsActive());
		model.setIsDelete(entity.getIsDelete());
		logger.info("Job found in DB with Id:{}",id);
		return model;

	}

	/**
	 * @param id,
	 * @return - true when is deleted
	 */
	@Override
	public boolean deleteJob(Long id) {
		jobRepository.deleteById(id);
		logger.info("Job record is deleted from database");
		return true;
	}

	/**
	 * Returns true when existing Job data is store in database
	 * 
	 * @param model - JobDTO
	 * @param id    - JobId
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateJob(JobDTO model, Long id) {
		Optional<Job> findById = jobRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Job oldJob = findById.get();
			logger.info("Job record is found from database with id:{}", oldJob.getName());
			oldJob.setName(model.getName());
			oldJob.setDescription(model.getDescription());
			oldJob.setExperience(model.getExperience());
			Optional<Company> company = compnyRepo.findById(model.getCompanyId());
			if (company.isPresent()) {
				oldJob.setCompany(company.get());
			}
			Job jobsaved = jobRepository.save(oldJob);
			logger.info("Job record is updated in to database with id:{}",id);
			EntityDTO dto = new EntityDTO();
			dto.setId(jobsaved.getId());
			dto.setName(jobsaved.getName());
			list.add(dto);
			return list;
		}
		return list;
	}

	/**
	 * @param Job Entity
	 * @return - page size
	 */
	public static Map<String, Object> mapData(Page<JobDTO> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<JobDTO> jobModels = pagedResult.stream().map(entity -> {
			JobDTO model = new JobDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			model.setExperience(entity.getExperience());
			Company cmp = new Company();
			model.setCompanyId(cmp.getId());
			model.setBranchId(entity.getBranchId());
			model.setCompanyName(entity.getCompanyName());
			model.setBranchName(entity.getBranchName());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, jobModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * @param jobid,
	 * @param String,
	 * @return - if record is updateJobByStatus based on jobid
	 */

	@Override
	public List<EntityDTO> updateJobByStatus(Long id, String status) {
		Optional<Job> findById = jobRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Job job = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			job.setIsActive(Boolean.TRUE);
			Job e = jobRepository.save(job);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getName());
			list.add(dto);
			logger.info("Job is Activated in database");
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			job.setIsActive(Boolean.FALSE);
			Job e = jobRepository.save(job);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getName());
			list.add(dto);
			logger.info("Job is Deactivated in database");
			return list;
		}
		logger.info("Job is failed to Activate or Deactivate in database");
		return list;
	}

	/**
	 * @param jobId,
	 * @return - change value from database isDisable is true
	 */

	@Override
	public List<EntityDTO> softDeleteJob(Long id) {
		Optional<Job> findById = jobRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Job job = findById.get();
		job.setIsActive(Boolean.FALSE);
		job.setIsDelete(Boolean.TRUE);
		Job j = jobRepository.save(job);
		logger.info("Job is SoftDeleted in database");
		EntityDTO dto = new EntityDTO();
		dto.setId(j.getId());
		dto.setName(j.getName());
		list.add(dto);
		return list;
	}

	/**
	 * @param JobDTO,
	 * @param boolean value,
	 * @return - if record exit return true or if record not exit return false
	 */

	@Override
	public boolean validate(JobDTO job, boolean isSave) {
		Long count;
		if (isSave)
			count = jobRepository.getJobCountForSave(job.getName(), job.getCompanyId(), job.getBranchId());
		else
			count = jobRepository.getJobCountForUpdate(job.getName(), job.getCompanyId(), job.getBranchId(),
					job.getId());
		return count > 0;
	}

}
