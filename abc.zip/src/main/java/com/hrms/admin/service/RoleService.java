/*package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.role.dto.EmpRoleDTO;
import com.hrms.admin.role.dto.EmployeeRoleDTO;
import com.hrms.admin.role.dto.MenuSortingDTO;
import com.hrms.admin.role.dto.RoleAccessDTO;

public interface RoleService {
	
	public EmployeeRoles createRole(RoleAccessDTO empRole);
	
	//public EmpRoleDTO addUserToRole(Long roleId, Long empId);
	
	public boolean deleteUserFromRole(EmployeeRoleDTO empRole);
	
	public Map<String, Object> getAllRoles(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,String orderBy, String isActive);

	public List<MenuSortingDTO> getAllMenus();
	
	public List<EmpRoleDTO> getAllRoles();
	
	public EmployeeRoleDTO  roleGetById(Long roleId);
	
	public EmployeeRoleDTO addUserListToRole(EmpRoleDTO empRoleDto);
	
	public List<MenuSortingDTO> getRoles(List<String> roles);
	
	public EmployeeRoleDTO getRoleViewId(Long roleId);
	
	public EmployeeRoles update(EmployeeRoleDTO empRoleDTO);
}
*/
