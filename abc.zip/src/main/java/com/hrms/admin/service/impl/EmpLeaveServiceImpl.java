package com.hrms.admin.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.CancelLeaveDTO;
import com.hrms.admin.dto.EmpLeaveCountDTO;
import com.hrms.admin.dto.EmpLeaveDTO;
import com.hrms.admin.dto.EmployeeManagerDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.ManagerDTO;
import com.hrms.admin.entity.AnnualLeaves;
import com.hrms.admin.entity.BellIconNotifications;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.LeaveType;
import com.hrms.admin.exceptions.NotFoundException;
import com.hrms.admin.repository.AnnualLeavesRepository;
import com.hrms.admin.repository.BellIconNotificationsRepository;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.LeaveTypeRepository;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.service.EmpLeaveService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.S3ServiceUtil;
import com.hrms.admin.util.StringToDateUtility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmpLeaveServiceImpl implements EmpLeaveService {

//	private static final log log = logFactory.getlog(EmpLeaveServiceImpl.class);

	@Autowired
	private EmpLeaveRepository repo;

	@Autowired
	private StringToDateUtility dateCount;

	@Autowired
	private EmailServiceUtil email;
	/*
	 * @Autowired private GridFsTemplate gridFsTemplate;
	 */
	@Autowired
	private LeaveTypeRepository leaveTypeRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private AnnualLeavesRepository annualLeavesRepo;

	@Autowired
	private BellIconNotificationsRepository bellIconRepo;

	@Autowired
	private S3ServiceUtil s3ServiceUtil;

	@Autowired
	private RolesRepository role;

	@Autowired
	private EmployeeRepository rep;

	@Value("${aws.bucket.empleavedocfolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@Value("${leave.approval.link}")
	private String leaveApprovalLink;

	@PostConstruct
	public void init() {
		String name = s3ServiceUtil.createFolder(foldername);
		log.info("folder created in s3 bucket foldername ::{}", name);
	}

	/**
	 * Returns All EmpLeave data when empLeave data is available in database
	 * 
	 * @return - List of EmpLeavemodel
	 */
	@Override
	@Cacheable(value = "getAllEmpLeave", unless = "#result.size() == 0")
	public List<EmpLeaveDTO> getAllEmpLeave(String companyId) {
		List<EmpLeave> empLeave = repo.findAll(companyId);
		List<EmpLeaveDTO> models = empLeave.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setStatus(entity.getStatus());
			model.setRemark(entity.getRemark());
			model.setEmployeeName(entity.getEmployee().getFirstName() + "  " + entity.getEmployee().getLastName());
			model.setEmployeeId(entity.getEmployeeId());
			model.setManagerId(entity.getManagerId());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns EmpLeave data when empLeave data is available in database by id
	 * 
	 * @param id - Id
	 * @return - EmpLeaveModel
	 */
	@Override
	@Cacheable(value = "getEmpLeaveByid", unless = "#result == null", key = "#id")
	public EmpLeaveDTO getEmpLeaveByid(Long id) {

		Optional<EmpLeave> optional = repo.findById(id);
		if (optional.isPresent()) {
			EmpLeave entity = optional.get();
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getStartDate());
			model.setId(entity.getId());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setStatus(entity.getStatus());
			model.setRemark(entity.getRemark());
			model.setEmployeeName(entity.getEmployee().getFirstName() + "  " + entity.getEmployee().getLastName());
			model.setEmployeeId(entity.getEmployeeId());
			model.setManagerId(entity.getManagerId());
			log.info("EmpLeave found in DB with Id:{}", id);
			return model;
		} else {
			log.info("EmpLeave not found in DB with Id:{}", id);
			return null;
		}
	}

	/**
	 * Returns true when new EmpLeave is store in database
	 * 
	 * @param model - new EmpLeaveRequest data
	 * @return - boolean
	 * @throws IOException
	 */
	@Transactional
	@Override
	public List<EntityDTO> addEmpLeave(EmpLeaveDTO model, MultipartFile file, String companyId) throws IOException {
		List<EntityDTO> list = new ArrayList<>();
		AnnualLeaves annualLeavesObj = annualLeavesRepo.findByEmpId(model.getEmployeeId(), model.getLeaveTypeId());
		if (annualLeavesObj == null) {
			EntityDTO dto = new EntityDTO();
			dto.setName("nodata");
			list.add(dto);
		}
		EmpLeave entity = new EmpLeave();
		LeaveType optional1 = leaveTypeRepository.findByLeaveTypeId(model.getLeaveTypeId());
		String leaveType = optional1.getLeaveType();
		entity.setEmployeeId(model.getEmployeeId());
		entity.setStartDate(model.getStartDate());
		entity.setEndDate(model.getEndDate());
		entity.setReason(model.getReason());

		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		EmployeeManagerDTO emp = employeeRepository.findByEmpId(model.getEmployeeId());
		EmployeeManagerDTO manager = employeeRepository.findByEmpId(model.getManagerId());
		entity.setManagerId(model.getManagerId());
		entity.setLeaveType(leaveType);
		entity.setStatus(Constants.APPLIED);
		entity.setLeaveTypeId(model.getLeaveTypeId());
		Long totalDays = dateCount.daysCount(model.getStartDate(), model.getEndDate());
		entity.setTotalDays(totalDays);
		entity.setLeaveApplyDate(new Timestamp(new Date().getTime()));

		if (file != null) {
			Boolean flag = Boolean.FALSE;
			flag = s3ServiceUtil.uploadFileInFolder(file, foldername, file.getOriginalFilename());
			if (flag.equals(Boolean.TRUE)) {
				entity.setAttachmentId(s3ServiceUtil.generateFileUrl(file.getOriginalFilename(), foldername));
				entity.setFileName(file.getOriginalFilename());
			}
			/*
			 * DBObject metaData = new BasicDBObject(); metaData.put(Constants.TYPE,
			 * Constants.FILE); metaData.put(Constants.TITLE, file.getOriginalFilename());
			 * ObjectId id = gridFsTemplate.store(file.getInputStream(),
			 * file.getOriginalFilename(), file.getContentType(), metaData);
			 * entity.setAttachmentId(id.toString());
			 * entity.setFileName(file.getOriginalFilename());
			 */ }
		String passCode = RandomStringUtils.randomNumeric(4);
		entity.setLeavePasscode(passCode);
		EmpLeave empLeave = repo.save(entity);
		if (!Objects.isNull(empLeave)) {
			BellIconNotifications bell = new BellIconNotifications();
			bell.setApproverId(model.getManagerId());
			bell.setNotificationFlag(false);
			bell.setEmployeeNotificationFlag(false);
			bell.setNotificationMenuPath(Constants.LEAVE_APPROVAL_MENU_PATH);
			bell.setCompanyId(companyId);
			bell.setNotificationType(Constants.LEAVE_NOTIFICATION_TYPE);
			bell.setEmployeeId(model.getEmployeeId());
			bell.setEmployeeName(emp.getEmpFirstName() + " " + emp.getEmpLastName());
			bell.setNotificationMessage(Constants.LEAVE_NOTIFICATION_MESSAGE);
			Date leaveApplyDate = model.getLeaveApplyDate();
			SimpleDateFormat ft = new SimpleDateFormat("E yyyy-MM-dd");
			bell.setNotificationDate(ft.format(leaveApplyDate));
			bell.setLeaveStatus(Constants.PENDING);
			bellIconRepo.save(bell);
		}
		AnnualLeaves annualLeaves = annualLeavesRepo.findByEmpId(emp.getEmpId(), optional1.getId());
		annualLeaves.setAvailableLeaves(annualLeaves.getAvailableLeaves() - totalDays);
		annualLeaves.setTotalTookLeaves(annualLeaves.getTotalTookLeaves() + totalDays);
		annualLeavesRepo.save(annualLeaves);
		log.info("EmpLeave Added into database");

		// sending mail to manager for leave request
		MailDTO request = new MailDTO();
		request.setTo(manager.getEmpOfficeMail());
		request.setSubject("Leave Request");
		request.setTemplate("LeaveApply.html");
		request.setFrom(emp.getEmpOfficeMail());
		request.setCompanyId(emp.getCompanyId());
		Map<String, Object> mailModel = new HashMap<>();
		mailModel.put(Constants.LEAVETYPE, leaveType);
		mailModel.put(Constants.EMP, emp.getEmpFirstName() + " " + emp.getEmpLastName());
		mailModel.put("manager", manager.getEmpFirstName() + " " + manager.getEmpLastName());
		mailModel.put("passcode", passCode);
		mailModel.put(Constants.URL, leaveApprovalLink);
		email.sendEmail(request, mailModel);
		log.info("Employee Leave request mail sended to Manager mailId:{}", manager.getEmpOfficeMail());
		EntityDTO dto = new EntityDTO();
		dto.setId(empLeave.getId());
		dto.setName(empLeave.getLeaveType());
		list.add(dto);
		return list;

	}

	/**
	 * Returns true when empLeave data is deleted from database by id
	 * 
	 * @param id - id
	 * @return - boolean
	 */
	@Override
	public boolean deleteEmpLeave(Long id) {
		Optional<EmpLeave> empLeave = repo.findById(id);
		if (empLeave.isPresent()) {
			repo.deleteById(id);
			log.info("empLeave deleted from Database with id:{}", id);
			return true;
		} else {
			throw new NotFoundException("Emp leave id not available with Id:" + id);
		}
	}

	/**
	 * Returns true when new EmpLeave is store in database
	 * 
	 * @param model - new EmpLeave data
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateEmpLeave(EmpLeaveDTO model, Long id) {
		Optional<EmpLeave> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			EmpLeave empLeave = findById.get();
			AnnualLeaves annualLeaves = annualLeavesRepo.findByEmployeeId(empLeave.getEmployeeId(),
					empLeave.getLeaveTypeId());
			annualLeaves.setAvailableLeaves(annualLeaves.getAvailableLeaves() + empLeave.getTotalDays());
			annualLeaves.setTotalTookLeaves(annualLeaves.getTotalTookLeaves() - empLeave.getTotalDays());
			EmpLeave existingEmpLeave = findById.get();
			existingEmpLeave.setStatus(Constants.APPLIED);
			Long days = dateCount.daysCount(model.getStartDate(), model.getEndDate());
			existingEmpLeave.setTotalDays(days);
			existingEmpLeave.setStartDate(model.getStartDate());
			existingEmpLeave.setEndDate(model.getEndDate());
			existingEmpLeave.setReason(model.getReason());
			existingEmpLeave.setLeaveApplyDate(new Timestamp(new Date().getTime()));
			existingEmpLeave.setLeaveTypeId(model.getLeaveTypeId());
			EmpLeave n = repo.save(existingEmpLeave);
			annualLeaves.setAvailableLeaves(annualLeaves.getAvailableLeaves() - days);
			annualLeaves.setTotalTookLeaves(annualLeaves.getTotalTookLeaves() + days);
			annualLeavesRepo.save(annualLeaves);
			EntityDTO dto = new EntityDTO();
			dto.setId(n.getId());
			dto.setName(n.getLeaveType());
			log.info(Constants.EMP_LEAVE + " is updated in to database");
			list.add(dto);

		}
		return list;

	}

	/**
	 * Returns true when leave approved/rejected
	 * 
	 * @param approval - Approved/Rejected
	 * @param Long     - EmpLeaveId
	 * @return - boolean
	 */
	@Transactional
	@Override
	public List<EntityDTO> approveOrReject(EmpLeaveDTO model1, Long id) {
		Optional<EmpLeave> optional = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!optional.isPresent()) {
			return list;
		} else {
			EmpLeave entity = optional.get();
//			Date leaveApplyDate = entity.getLeaveApplyDate();
//			SimpleDateFormat ft = new SimpleDateFormat("E yyyy-MM-dd");
			String approval = model1.getStatus();
			if (approval.equalsIgnoreCase(Constants.APPROVED)) {
				entity.setStatus(approval);
				entity.setRemark(model1.getRemark());
				entity.setLeavePasscode("");
				EmpLeave empLeave = repo.save(entity);
				EntityDTO dto = new EntityDTO();
				dto.setName(empLeave.getLeaveType());
				dto.setId(empLeave.getId());
				log.info(Constants.EMP_LEAVE + "is approved in database");
				list.add(dto);
				// sending mail to employee for updating approval information
				MailDTO request = new MailDTO();
				Optional<Employee> employeeOptional = employeeRepository.findById(entity.getEmployeeId());
				if (!employeeOptional.isPresent()) {
					return new ArrayList<>();
				}
				Employee emp = employeeOptional.get();
				Employee manager = emp.getManager();
				request.setTo(emp.getOfficalMail());
				request.setSubject("Your leave request has been approved");
				request.setName(Constants.EMPLOYEE);
				request.setTemplate("LeaveApproval.html");
				request.setFrom(manager.getOfficalMail());
				request.setCompanyId(emp.getCompany().getId());
				Map<String, Object> model = new HashMap<>();
				String leavetype = entity.getLeaveType1().getLeaveType();
				model.put(Constants.LEAVETYPE, leavetype);
				model.put("empName", emp.getFirstName());
				model.put(Constants.STATUS, approval);
				model.put("LeaveId", entity.getId());
				model.put("remarks", model1.getRemark());
				model.put("companyNmae", emp.getCompany().getName());
				if (!Objects.isNull(empLeave)) {
					Optional<BellIconNotifications> findNotification = bellIconRepo
							.findNotificationBymanagerAndEmployee(model1.getNotificationId());
					if (findNotification.isPresent()) {
						BellIconNotifications bellIcon = findNotification.get();
						bellIcon.setNotificationMessage(Constants.LEAVE_APPROVED_MESSAGE);
						bellIcon.setLeaveStatus(Constants.APPROVED);
						bellIconRepo.save(bellIcon);
					}
				}
				email.sendEmail(request, model);
				log.info(Constants.EMP_LEAVE + "is approved in database");
				return list;
			} else if (approval.equalsIgnoreCase(Constants.REJECTED)) {
				entity.setStatus(approval);
				entity.setRemark(model1.getRemark());
				entity.setLeavePasscode("");
				EmpLeave empLeave = repo.save(entity);
				AnnualLeaves annualLeaves = annualLeavesRepo.findByEmployeeId(entity.getEmployeeId(),
						entity.getLeaveTypeId());
				annualLeaves.setAvailableLeaves(annualLeaves.getAvailableLeaves() + entity.getTotalDays());
				annualLeaves.setTotalTookLeaves(annualLeaves.getTotalTookLeaves() - entity.getTotalDays());
				annualLeavesRepo.save(annualLeaves);
				EntityDTO dto = new EntityDTO();
				dto.setId(empLeave.getId());
				dto.setName(empLeave.getLeaveType());
				log.info(Constants.EMP_LEAVE + " is approved in database");
				list.add(dto);

				// sending mail to employee for updating approval information
				MailDTO request = new MailDTO();
				Optional<Employee> employeeOptional = employeeRepository.findById(entity.getEmployeeId());
				if (!employeeOptional.isPresent()) {
					return new ArrayList<>();
				}
				Employee emp = employeeOptional.get();
				Employee manager = emp.getManager();
				request.setTo(emp.getOfficalMail());
				request.setFrom(manager.getOfficalMail());
				request.setSubject("Your leave request has been rejected");
				request.setName("employee");
				request.setTemplate("LeaveApproval.html");
				request.setCompanyId(emp.getCompany().getId());
				Map<String, Object> model = new HashMap<>();
				String leavetype = entity.getLeaveType1().getLeaveType();
				model.put(Constants.LEAVETYPE, leavetype);
				model.put("empName", emp.getFirstName());
				model.put("status", approval);
				model.put("LeaveId", entity.getId());
				model.put("remarks", model1.getRemark());
				model.put("companyNmae", emp.getCompany().getName());
				if (!Objects.isNull(empLeave)) {
					Optional<BellIconNotifications> findNotification = bellIconRepo
							.findNotificationBymanagerAndEmployee(model1.getNotificationId());
					if (findNotification.isPresent()) {
						BellIconNotifications bellIcon = findNotification.get();
						bellIcon.setNotificationMessage(Constants.LEAVE_REJECTED_MESSAGE);
						bellIcon.setLeaveStatus(Constants.REJECTED);
						bellIconRepo.save(bellIcon);
					}
				}
				email.sendEmail(request, model);
				log.info(Constants.EMP_LEAVE + " is rejected in database");
				return list;
			}
		}
		return list;
	}

	/**
	 * Returns EmpLeave for given Date
	 * 
	 * @param date1 - Date
	 * @return - list of employee leaves
	 */
	@Override
	@Cacheable(value = "findLeavesbyDate", unless = "#result.size() == 0")
	public List<EmpLeaveDTO> findLeavesbyDate(Date date, String companyId) {
		List<EmpLeave> empLeave = repo.findByStartDate(date, companyId);
		List<EmpLeaveDTO> models1 = empLeave.stream().map(entity -> {
			EmpLeaveDTO model1 = new EmpLeaveDTO();
			model1.setEmployeeId(entity.getEmployeeId());
			model1.setId(entity.getId());
			model1.setStartDate(entity.getStartDate());
			model1.setEndDate(entity.getEndDate());
			model1.setLeaveApplyDate(entity.getLeaveApplyDate());
			model1.setLeaveType(entity.getLeaveType1().getLeaveType());
			model1.setReason(entity.getReason());
			model1.setTotalDays(entity.getTotalDays());
			model1.setStatus(entity.getStatus());
			model1.setRemark(entity.getRemark());
			model1.setManagerId(entity.getManagerId());
			model1.setIsDelete(entity.getIsDelete());
			model1.setIsActive(entity.getIsActive());
			return model1;
		}).collect(Collectors.toList());

		return models1;

	}

	/**
	 * Returns EmpLeave for given time period
	 * 
	 * @param date1 - startDate
	 * @param date2 - endDate
	 * @return - list of employee leaves
	 */
	@Override
	@Cacheable(value = "getEmpLeavesByDate", unless = "#result.size() == 0")
	public List<EmpLeaveDTO> getEmpLeavesByDate(Long id, Date startDate, Date endDate) {
		List<EmpLeave> list2 = new ArrayList<>();
		List<EmpLeave> list = repo.findByEmployeeId(id);
		for (EmpLeave empLeave : list) {
			Date mydate = empLeave.getStartDate();
			DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();
			int retVal = dateTimeComparator.compare(mydate, startDate);
			int retVal1 = dateTimeComparator.compare(mydate, endDate);
			if (retVal == 0) {
				list2.add(empLeave);
			} else if (retVal > 0) {
				list2.add(empLeave);
			}
			if (retVal1 == 0) {
				list2.add(empLeave);
			}

			else if (retVal1 < 0) {
				list2.add(empLeave);
			}

		}
		List<EmpLeaveDTO> models = list2.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setId(entity.getId());
			model.setEmployeeId(entity.getEmployeeId());
			model.setEndDate(entity.getEndDate());
			model.setStatus(entity.getStatus());
			model.setStartDate(entity.getStartDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setTotalDays(entity.getTotalDays());
			model.setRemark(entity.getRemark());
			model.setManagerId(entity.getManagerId());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			model.setAttachmentId(entity.getAttachmentId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;
	}

	/**
	 * Returns EmpLeave for given employee
	 * 
	 * @param id - empId
	 * @return - list of employee leaves
	 */
	@Override
	@Cacheable(value = "findLeavesbyEmpId", unless = "#result == null", key = "#id")
	public List<EmpLeaveDTO> findLeavesbyEmpId(Long id) {
		List<EmpLeave> empLeave = repo.findByEmployeeId(id);
		List<EmpLeaveDTO> models = empLeave.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setStatus(entity.getStatus());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setManagerId(entity.getManagerId());
			model.setRemark(entity.getRemark());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			model.setAttachmentId(entity.getAttachmentId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;
	}

	@Override
	// @Cacheable(value = "getAllEmpLeaves",unless = "#result.size == 0")
	public Map<String, Object> getAllEmpLeaves(Long empId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmpLeave> pagedResult = null;
		String status = Constants.APPLIED;
		if (isActive == null || isActive.isEmpty()) {
			pagedResult = repo.allEmpLeavePage(searchKey, companyId, empId, paging);
		} else {
			if (isActive.equals("1")) {
				status = Constants.APPROVED;
			} else if (isActive.equals("2")) {
				status = Constants.REJECTED;
			} else if (isActive.equals("3")) {
				status = Constants.CANCEL_APPLIED;
			} else if (isActive.equals("4")) {
				status = Constants.CANCEL_REJECTED;
			} else if (isActive.equals("5")) {
				status = Constants.CANCEL_APPROVED;
			}

			pagedResult = repo.empLeavePage(searchKey, companyId, status, empId, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapData(Page<EmpLeave> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmpLeaveDTO> leaveModels = pagedResult.stream().map(leaveEntity -> {

			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setId(leaveEntity.getId());
			model.setTotalDays(leaveEntity.getTotalDays());
			model.setLeaveApplyDate(leaveEntity.getLeaveApplyDate());
			model.setEndDate(leaveEntity.getEndDate());
			model.setReason(leaveEntity.getReason());
			model.setStartDate(leaveEntity.getStartDate());
			model.setStatus(leaveEntity.getStatus());
			model.setManagerId(leaveEntity.getManagerId());
			model.setIsDelete(leaveEntity.getIsDelete());
			model.setIsActive(leaveEntity.getIsActive());
			model.setLeaveType(leaveEntity.getLeaveType1().getLeaveType());
			model.setEmployeeId(leaveEntity.getEmployeeId());
			model.setEmployeeName(
					leaveEntity.getEmployee().getFirstName() + " " + leaveEntity.getEmployee().getLastName());
			if (leaveEntity.getAttachmentId() != null && leaveEntity.getFileName() != null
					&& leaveEntity.getFileName().indexOf(".") > 0) {
				model.setName(leaveEntity.getFileName().substring(0, leaveEntity.getFileName().lastIndexOf(".")));
				model.setFileType("." + FilenameUtils.getExtension(leaveEntity.getFileName()));
				model.setAttachmentId(leaveEntity.getAttachmentId());
			}
			return model;
		}).collect(Collectors.toList());
		if (leaveModels.isEmpty()) {
			return new HashMap<>();
		} else {
			response.put("data", leaveModels);
			response.put("pageIndex", pagedResult.getNumber());
			response.put("totalRecords", pagedResult.getTotalElements());
			response.put("totalPages", pagedResult.getTotalPages());
			return response;
		}
	}

	@Override
	// @Cacheable(value = "getAllTeamLeaves",unless = "#result.size == 0")
	public Map<String, Object> getAllTeamLeaves(Long managerId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmpLeave> pagedResult = null;
		String status = Constants.APPLIED;
		if (isActive == null || isActive.isEmpty()) {
			pagedResult = repo.allEmpLeaveManagerPage(searchKey, companyId, managerId, paging);
		} else {
			if (isActive.equals("1")) {
				status = Constants.APPROVED;
			} else if (isActive.equals("2")) {
				status = Constants.REJECTED;
			} else if (isActive.equals("3")) {
				status = Constants.CANCEL_APPLIED;
			} else if (isActive.equals("4")) {
				status = Constants.CANCEL_REJECTED;
			} else if (isActive.equals("5")) {
				status = Constants.CANCEL_APPROVED;
			}
			pagedResult = repo.empLeaveManagerPage(searchKey, companyId, status, managerId, paging);
		}

		if (pagedResult.hasContent()) {
			return mapData1(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapData1(Page<EmpLeave> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmpLeaveDTO> leaveModels = pagedResult.stream().map(leaveEntity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setId(leaveEntity.getId());
			model.setStartDate(leaveEntity.getStartDate());
			model.setEndDate(leaveEntity.getEndDate());
			model.setReason(leaveEntity.getReason());
			model.setTotalDays(leaveEntity.getTotalDays());
			model.setLeaveApplyDate(leaveEntity.getLeaveApplyDate());
			model.setStatus(leaveEntity.getStatus());
			model.setLeaveType(leaveEntity.getLeaveType1().getLeaveType());
			model.setEmployeeId(leaveEntity.getEmployeeId());
			model.setEmployeeName(
					leaveEntity.getEmployee().getFirstName() + " " + leaveEntity.getEmployee().getLastName());
			model.setIsDelete(leaveEntity.getIsDelete());
			model.setIsActive(leaveEntity.getIsActive());
			if (leaveEntity.getAttachmentId() != null && leaveEntity.getFileName() != null
					&& leaveEntity.getFileName().indexOf(".") > 0) {
				model.setName(leaveEntity.getFileName().substring(0, leaveEntity.getFileName().lastIndexOf(".")));
				model.setFileType("." + FilenameUtils.getExtension(leaveEntity.getFileName()));
				model.setAttachmentId(leaveEntity.getAttachmentId());
			}
			return model;
		}).collect(Collectors.toList());

		response.put("data", leaveModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	public List<ManagerDTO> findManager(Long id, String companyId) {
		Optional<Employee> optional = employeeRepository.findById(id);
		List<ManagerDTO> mngr = new ArrayList<>();
		if (optional.isPresent()) {

			ManagerDTO m = new ManagerDTO();
			m.setId(optional.get().getManager().getId());
			m.setMailId(optional.get().getManager().getOfficalMail());
			m.setName(optional.get().getManager().getFirstName() + " " + optional.get().getManager().getLastName());
			mngr.add(m);

		}
		return mngr;
	}

	@Override
	public List<ManagerDTO> allmangerList(String companyId) {
		EmployeeRoles findRoleByCompany = role.findRoleByCompany("Manager", companyId);
		List<Employee> allManagers = rep.allManagers(findRoleByCompany.getRoleId());
		List<ManagerDTO> mngr = new ArrayList<>();
		for (Employee employee : allManagers) {
			ManagerDTO m = new ManagerDTO();
			m.setId(employee.getId());
			m.setMailId(employee.getManager().getOfficalMail());
			m.setName(employee.getManager().getFirstName() + " " + employee.getManager().getLastName());
			mngr.add(m);
		}
		return mngr;
	}

	@Override
	public List<EntityDTO> softDeleteEmpLeave(Long id) {
		Optional<EmpLeave> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		EmpLeave empLeave = findById.get();
		empLeave.setIsActive(Boolean.FALSE);
		empLeave.setIsDelete(Boolean.TRUE);
		EmpLeave p = repo.save(empLeave);
		log.info(Constants.EMP_LEAVE + " is SoftDeleted in database");
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getLeaveType());
		list.add(dto);
		return list;
	}

	@Override
	public boolean validate(EmpLeaveDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getLeaveTypeCount(model.getEmployeeId(), model.getStartDate(), model.getEndDate());
		else
			count = repo.getCompanyCountForUpdate(model.getEmployeeId(), model.getStartDate(), model.getEndDate(),
					model.getId());
		return count > 0;
	}

	public List<EntityDTO> updateEmpLeaveByStatus(Long id, String status) {
		Optional<EmpLeave> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		EmpLeave a = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			a.setIsActive(Boolean.TRUE);
			EmpLeave e = repo.save(a);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getLeaveType());
			list.add(dto);
			log.info(Constants.EMP_LEAVE + " is activated in database");
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			a.setIsActive(Boolean.FALSE);
			EmpLeave e = repo.save(a);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getLeaveType());
			list.add(dto);
			log.info(Constants.EMP_LEAVE + " is deactivated in database");
			return list;
		}
		log.info(Constants.EMP_LEAVE + " is falied to active or deactivated in database");
		return list;
	}

	@Override
	@Cacheable(value = "getEmployeeLeavesCountById", unless = "#result == null", key = "#employeeId")
	public EmpLeaveCountDTO getEmployeeLeavesCountById(Long employeeId) {
		EmpLeaveCountDTO empleaveCount = new EmpLeaveCountDTO();
		List<EmpLeave> emps = repo.findByEmployeeId(employeeId);
		Long availableLeaves = annualLeavesRepo.getEmpAvailableLeaves(employeeId);
		if (availableLeaves == null || availableLeaves < 0) {
			empleaveCount.setTotalLeaves(0l);
		} else {
			empleaveCount.setTotalLeaves(availableLeaves);
		}

		if (!emps.isEmpty()) {
			Long approvedLeaves = repo.getEmpAprovedLeaves(employeeId);
			Long rejectedLeaves = repo.getEmpRejectedLeaves(employeeId);
			Long cancelLeaves = repo.getEmpCancelledLeaves(employeeId);
			Long pendingLeaves = repo.getEmpPendingLeaves(employeeId);

			if (approvedLeaves > 0) {
				empleaveCount.setApprovedLeaves(approvedLeaves);
			} else {
				empleaveCount.setApprovedLeaves(0l);
			}
			if (rejectedLeaves > 0) {
				empleaveCount.setRejectedLeaves(rejectedLeaves);
			} else {
				empleaveCount.setRejectedLeaves(0l);
			}
			if (cancelLeaves > 0) {
				empleaveCount.setCancelLeaves(cancelLeaves);
			} else {
				empleaveCount.setCancelLeaves(0l);
			}
			if (pendingLeaves > 0) {
				empleaveCount.setPendingLeaves(pendingLeaves);
			} else {
				empleaveCount.setPendingLeaves(0l);
			}
			return empleaveCount;
		} else {
			empleaveCount.setApprovedLeaves(0l);
			empleaveCount.setRejectedLeaves(0l);
			empleaveCount.setCancelLeaves(0l);
			empleaveCount.setPendingLeaves(0l);
			return empleaveCount;
		}
	}

	@Override
	@Cacheable(value = "cancelLeaves", unless = "#result.size == 0")
	public List<EntityDTO> cancelLeaves(CancelLeaveDTO dto, Long id) {
		Optional<EmpLeave> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		EmpLeave entity = findById.get();
		Long usedDays = entity.getTotalDays() - dto.getNoofDays();
		entity.setTotalDays(usedDays);
		repo.save(entity);
		EmpLeave model = new EmpLeave();
		model.setEmployeeId(entity.getEmployeeId());
		model.setStartDate(entity.getStartDate());
		model.setEndDate(entity.getStartDate());
		model.setLeaveApplyDate(entity.getLeaveApplyDate());
		model.setReason(entity.getReason());
		model.setTotalDays(dto.getNoofDays());
		model.setLeaveTypeId(entity.getLeaveTypeId());
		model.setLeaveType(entity.getLeaveType1().getLeaveType());
		model.setStatus(dto.getStatus());
		model.setRemark(dto.getRemarks());
		model.setEmployeeId(entity.getEmployeeId());
		model.setManagerId(entity.getManagerId());
		EmpLeave l = repo.save(model);
		AnnualLeaves annualLeaves = annualLeavesRepo.findByEmployeeId(entity.getEmployeeId(), entity.getLeaveTypeId());
		annualLeaves.setAvailableLeaves(annualLeaves.getAvailableLeaves() + entity.getTotalDays());
		annualLeaves.setTotalTookLeaves(annualLeaves.getTotalTookLeaves() - entity.getTotalDays());
		annualLeavesRepo.save(annualLeaves);
		EntityDTO edto = new EntityDTO();
		edto.setId(l.getId());
		edto.setName(l.getLeaveType());
		list.add(edto);
		return list;
	}

	public List<EntityDTO> getEmployeeCancellationofApprovedLeaves(EmpLeaveDTO empLeaveDto) {
		Optional<EmpLeave> empApprovedLeaves = repo.findByEmpApprovedLeaves(empLeaveDto.getEmployeeId(),
				empLeaveDto.getStatus(), empLeaveDto.getLeaveApplyDate());
		List<EntityDTO> list = new ArrayList<>();
		if (!empApprovedLeaves.isPresent()) {
			return list;

		} else {
			EmpLeave entity = empApprovedLeaves.get();
			if (empLeaveDto.getStatus().equalsIgnoreCase(Constants.APPROVED)) {
				entity.setStatus(Constants.CANCEL_APPLIED);
				entity.setReasonLeaveCancel(empLeaveDto.getReasonLeaveCancel());
				EmpLeave empLeave = repo.save(entity);
				EntityDTO dto = new EntityDTO();
				dto.setName(empLeave.getLeaveType());
				dto.setId(empLeave.getId());
				log.info(Constants.EMP_LEAVE + "is Cancel Applied in database");
				list.add(dto);

			}

		}
		return list;

	}

	@Override
	public List<EntityDTO> getEmployeeCancelAppliedRejectLeaves(EmpLeaveDTO empLeaveDto) {
		Optional<EmpLeave> empCancelAppliedRejectLeaves = repo.findByEmpApprovedLeaves(empLeaveDto.getEmployeeId(),
				empLeaveDto.getStatus(), empLeaveDto.getLeaveApplyDate());
		List<EntityDTO> list = new ArrayList<>();
		if (!empCancelAppliedRejectLeaves.isPresent()) {
			return list;

		} else {
			EmpLeave entity = empCancelAppliedRejectLeaves.get();
			if (empLeaveDto.getStatus().equalsIgnoreCase(Constants.CANCEL_APPLIED)) {
				entity.setStatus(Constants.CANCEL_REJECTED);
				entity.setReasonLeaveCancel(empLeaveDto.getReasonLeaveCancel());
				EmpLeave empLeave = repo.save(entity);
				EntityDTO dto = new EntityDTO();
				dto.setName(empLeave.getLeaveType());
				dto.setId(empLeave.getId());
				log.info(Constants.EMP_LEAVE + "is Cancel Rejected in database");
				list.add(dto);
			}
		}
		return list;

	}

	@Override
	public List<EntityDTO> getEmployeeCancelApprovedLeaves(EmpLeaveDTO empLeaveDto) {
		Optional<EmpLeave> empCancelAppliedRejectLeaves = repo.findByEmpCancelApprovedLeaves(empLeaveDto.getManagerId(),
				empLeaveDto.getStatus(), empLeaveDto.getLeaveApplyDate());
		List<EntityDTO> list = new ArrayList<>();
		if (!empCancelAppliedRejectLeaves.isPresent()) {
			return list;

		} else {
			EmpLeave entity = empCancelAppliedRejectLeaves.get();
			if (empLeaveDto.getStatus().equalsIgnoreCase(Constants.CANCEL_APPLIED)) {
				entity.setStatus(Constants.CANCEL_APPROVED);
				entity.setReasonLeaveCancel(empLeaveDto.getReasonLeaveCancel());
				EmpLeave empLeave = repo.save(entity);
				EntityDTO dto = new EntityDTO();
				dto.setName(empLeave.getLeaveType());
				dto.setId(empLeave.getId());
				log.info(Constants.EMP_LEAVE + "is Cancel Approved in database");
				list.add(dto);
			}
		}
		return list;
	}
}