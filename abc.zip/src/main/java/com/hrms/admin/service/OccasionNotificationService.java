package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.EmployeeOccasionDTO;

public interface OccasionNotificationService {

	public List<EmployeeOccasionDTO> getOccasionNotification(String companyId);

	public List<EmployeeOccasionDTO> getBirthDayNotification(String comapnyId);

	public List<EmployeeOccasionDTO> getAllNotification(String companyId);

}
