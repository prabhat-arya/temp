package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.SkillDTO;
import com.hrms.admin.entity.Skill;

public interface SkillService {

	public List<EntityDTO> save(SkillDTO model);

	public List<EntityDTO> updateSkill(SkillDTO model, Long id);

	public SkillDTO getSkillByCompanyId(Long id,String companyId);
	
	public List<SkillDTO> getAllSkill(String id);

	/* public boolean deleteSkill(Long id); */
	
	public List<EntityDTO> updateSkillByStatus(Long id, String status);
	
	public boolean validate(SkillDTO leaveType, boolean isSave);

	public Map<String, Object> getAllSkill(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy,String isActive,String companyId);
	
	public List<EntityDTO> softDeleteSkill(Long id);
	
	public Skill findByName(String skillName,String companyId);

}
