package com.hrms.admin.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.InputStreamResource;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.ICsvBeanWriter;

import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.dto.AttendPaginationDTO;
import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.BarChartDateWiseCountDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PieChartRequestDTO;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.entity.AttendanceInfoErrorRecords;
import com.itextpdf.text.DocumentException;

public interface AttendanceInfoService {

	public List<EntityDTO> save(AttendanceInfoDTO model);

	public List<EntityDTO> updateEmployeeAttendance(AttendanceInfoDTO model);

	public AttendanceInfoDTO getEmployeeAttendance(Long empId, String date);

	public boolean deleteEmployeeAttendance(AttendanceInfoDTO model);

	public String currentDateandTime();

	public AttendanceInfoDTO copyPropertites(AttendanceInfo info);

	// for validation
	public boolean validate(AttendanceInfoDTO model);

	public List<AttendanceInfoDTO> getAttendanceListBetweenDates(Long empid, String fromDate, String toDate,
			String companyId);

	public List<AttendanceInfoDTO> getEmpAttDetailsbetweenDates(String fromDate, String toDate, String companyId);

	public List<AttendanceInfoDTO> getAllAttendenceDetails(String companyId);

	public AttPercentagePieChartDto attendancePercentagePieChart(String companyId);

	public BarChartDateWiseCountDTO employeeAttCountBarChart(PieChartRequestDTO pieChartDto, String companyId)
			throws ParseException;

	public List<AttendanceInfoErrorRecords> getAllAttendanceErrorRecordList();

	public AttPercentagePieChartDto getAllEmpAttPercentagePieChartByProjectId(Long id, String companyId);

	public BarChartDateWiseCountDTO allEmpAttCountProjectBarChart(PieChartRequestDTO pieChartDto, String companyId)
			throws ParseException;

	public Map<String, Object> empPresentAttListByProjectPieChart(PaginationDTO pagingDto, String companyId);

	public Map<String, Object> empAbsentAttListByProjectPieChart(PaginationDTO pagingDto, String companyId);

	public Map<String, Object> empPresentAttListByProjectBarChart(AttendPaginationDTO pagingDto, String companyId);

	public Map<String, Object> empabsentAttListByProjectBarChart(AttendPaginationDTO pagingDto, String companyId);

	public InputStreamResource getAllExcelReportAttendances(String companyId) throws IOException, Exception;

	public InputStreamResource getAllpdfReportAttendances(String companyId)
			throws IOException, DocumentException, Exception;

	public ICsvBeanWriter getAllAttendanceErrorRecordListCsv(HttpServletResponse response) throws IOException;

	public ICsvBeanWriter getAllAttendenceDetailsCsv(HttpServletResponse response, String companyId)
			throws IOException, Exception;

	// att piechart by branchId
	public AttPercentagePieChartDto attendancePercentagePieChartByEmpid(Long empid, String companyId);

	public Map<String, Object> getAllPresentListPieChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAllAbesntListPieChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAllPresentListBarChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAllAbsentListBarChart(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String companyId);

	public Map<String, Object> getAllAttendenceByEmpId(Long empid, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAttendanceListBetweenDatesPaging(Long empid, String fromDate, String toDate,
			Integer pageIndex, Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAllAttendanceListDateShiftPaging(String fromDate, String toDate, Long shiftId,
			Integer pageIndex, Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId);

	public Map<String, Object> getEmpAttDetailsbetweenDatesPaging(String fromDate, String toDate, Integer pageIndex,
			Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId);

	public Map<String, Object> getPresentAttendenceListByEmpIdInPieChart(Long empid, Integer pageIndex,
			Integer pageSize, String sortBy, String searchKey, String orderBy, String companyId);

	public Map<String, Object> getAbsentAttendenceListByEmpIdInPieChart(Long empid, Integer pageIndex, Integer pageSize,
			String sortBy, String searchKey, String orderBy, String companyId);

	// public List<Map<String, Integer>> saveAttendanceCsv(MultipartFile file,
	// String companyId) throws Exception;

	public List<Map<String, Integer>> attendanceBreakHistoryCsv(MultipartFile file, String companyId) throws Exception;

	public List<AttendanceInfoErrorRecords> excelReportAllErrorAttendanceInfoErrorRecords();

	public ICsvBeanWriter getErrorAttRecordsListCsv(HttpServletResponse response) throws IOException;

	public Map<String, Object> getPresentListBarChartOnDate(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String date, String companyId);

	public Map<String, Object> getAbsentListBarChartOnDate(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String date, String companyId);

	public Map<String, Object> presentEmployeeAttListByProjectBarChartOnDate(AttendPaginationDTO pagingDto,
			String companyId);

	public Map<String, Object> empabsentAttListByProjectBarChartOnDate(AttendPaginationDTO pagingDto, String companyId);

}
