package com.hrms.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.City;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.service.CityService;

@Service
public class CityServiceImpl implements CityService {

	@Autowired
	private CityRepository cityRepository;

	@Override
	public List<City> findByState(Long id) {
		return cityRepository.findAllBystateId(id);
	}

}
