package com.hrms.admin.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.CompanyDTO;
import com.hrms.admin.dto.CompanyRegisterDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.CertificateType;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.EmploymentType;
import com.hrms.admin.entity.Menu;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.Questions;
import com.hrms.admin.entity.RoleJson;
import com.hrms.admin.entity.State;
import com.hrms.admin.repository.AddressRepository;
import com.hrms.admin.repository.CertificateTypeRepository;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.repository.EmploymentTypeRepository;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.QuestionsRepository;
import com.hrms.admin.repository.RoleJsonRepo;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.repository.StateRepository;
import com.hrms.admin.service.CompanyService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.EmployeeServiceUtil;
import com.hrms.admin.util.ImageUtils;
import com.hrms.admin.util.S3ServiceUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Chandu}
 *
 */
@Service
@Slf4j
public class CompanyServiceImpl implements CompanyService {

//	private static final log log = logFactory.getlog(CompanyServiceImpl.class);

	@Autowired
	private CompanyRepository companyRepo;

	/*
	 * @Autowired private SequenceGeneratorUtil seqGeneratorService;
	 * 
	 * @Autowired private CompanyProfileImageRepository companyProfileImageRepo;
	 */

	@Autowired
	private EmailServiceUtil emailUtil;

	@Autowired
	private EmployeeServiceUtil employeeUtil;

	@Autowired
	private CityRepository cityRepo;

	@Autowired
	private StateRepository stateRepo;

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private MenuRepository menuRepo;

	@Autowired
	private RoleJsonRepo rjRepo;

	@Autowired
	private RolesRepository rolesRepo;

	@Autowired
	private QuestionsRepository questionsRepo;

	@Autowired
	private CertificateTypeRepository certificateTypeRepo;

	@Autowired
	private EmploymentTypeRepository employmentTypeRepo;

	@Autowired
	private ImageUtils imageUtils;

	@Value("${file.s3UploadImg}")
	private String folderpath;

	@Value("${user.login.link}")
	private String loginUrl;
	@Autowired
	private S3ServiceUtil s3ServiceUtil;

	@Value("${aws.bucket.imagefolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@Autowired
	private ProfileImageRepository profileRepo;

	@PostConstruct
	public void init() throws Exception {
		String name = s3ServiceUtil.createFolder(foldername);
		log.info("folder created in s3 bucket foldername ::{}", name);

		InputStream is = null;
		ObjectMapper mapper = new ObjectMapper();
		ClassLoader classLoader = getClass().getClassLoader();
		final String countryFile = "Images/countryList.json";
		is = classLoader.getResourceAsStream(countryFile);
		List<Country> countryList = Arrays.asList(mapper.readValue(is, Country[].class));
		if (countryRepo.findAll().isEmpty() && countryList != null) {
			countryRepo.saveAll(countryList);
		}

		final String stateFile = "Images/stateList.json";
		is = classLoader.getResourceAsStream(stateFile);
		List<State> stateList = Arrays.asList(mapper.readValue(is, State[].class));
		if (stateRepo.findAll().isEmpty() && stateList != null) {
			stateRepo.saveAll(stateList);
		}

		final String cityFile = "Images/cityList.json";
		is = classLoader.getResourceAsStream(cityFile);
		List<City> cityList = Arrays.asList(mapper.readValue(is, City[].class));
		if (cityRepo.findAll().isEmpty() && cityList != null) {
			cityRepo.saveAll(cityList);
		}

		final String menuFile = "Images/menuList.json";
		is = classLoader.getResourceAsStream(menuFile);
		List<Menu> menuList = Arrays.asList(mapper.readValue(is, Menu[].class));
		if (menuRepo.findAll().isEmpty() && menuList != null) {
			menuRepo.saveAll(menuList);
		}
		final String roleJosnFile = "Images/roleJson.json";
		is = classLoader.getResourceAsStream(roleJosnFile);
		String accessList = new String(FileCopyUtils.copyToByteArray(is), StandardCharsets.UTF_8);
		RoleJson json = new RoleJson();
		json.setAccessList(accessList.replaceAll("\\s", ""));
		RoleJson roleJson = null;
		if (rjRepo.findAll().isEmpty() && !accessList.isEmpty()) {
			roleJson = rjRepo.save(json);
		}

		final String employeeRolesFile = "Images/employeeRoles.json";
		is = classLoader.getResourceAsStream(employeeRolesFile);
		EmployeeRoles employeeRoles = mapper.readValue(is, EmployeeRoles.class);
		if (rolesRepo.findAll().isEmpty() && employeeRoles != null) {
			employeeRoles.setRoleJson(roleJson);
			rolesRepo.save(employeeRoles);
		}
		final String deafultQuestions = "Images/deafultQuestions.json";
		is = classLoader.getResourceAsStream(deafultQuestions);
		List<Questions> questions = Arrays.asList(mapper.readValue(is, Questions[].class));
		if (questionsRepo.findAll().isEmpty() && questions != null) {
			/*
			 * List<Questions> list=new ArrayList<>(); for(ExitQuestions q:questions) {
			 * Questions que=new Questions();
			 * que.setObjectiveQuestion(q.getSubjectiveQuestion());
			 * que.setObjectiveQuestion(q.getObjectiveQuestion());
			 * que.setRadioQuestionComment(q.getRadioQuestionComment()); list.add(que); }
			 */
			questionsRepo.saveAll(questions);
		}
		final String certificateTypeFile = "Images/certificateType.json";
		is = classLoader.getResourceAsStream(certificateTypeFile);
		List<CertificateType> certificateTypeList = Arrays.asList(mapper.readValue(is, CertificateType[].class));
		if (certificateTypeRepo.findAll().isEmpty() && certificateTypeList != null) {
			certificateTypeRepo.saveAll(certificateTypeList);
		}
		final String employmentTypeFile = "Images/employmentTypeList.json";
		is = classLoader.getResourceAsStream(employmentTypeFile);
		List<EmploymentType> employmentTypeList = Arrays.asList(mapper.readValue(is, EmploymentType[].class));
		if (employmentTypeRepo.findAll().isEmpty() && certificateTypeList != null) {
			employmentTypeRepo.saveAll(employmentTypeList);
		}
	}

	@Autowired
	private AddressRepository addressRepo;

	/**
	 * Returns true when new Attendance is store in database
	 * 
	 * @param model - new Attendance data
	 * @return - boolean
	 * 
	 */
	@Override
	public List<CompanyDTO> save(CompanyDTO model) {

		Company entity = new Company();
		BeanUtils.copyProperties(model, entity);
		entity.setName(model.getName().toUpperCase());
		entity.setContact(model.getContact());
		entity.setEmail(model.getEmail().toLowerCase());
		entity.setWebsite(model.getWebsite());

		entity.setBranch(model.getBranch());
		entity.setContactPerson(model.getContactPerson());
		entity.setPanNumber(model.getPanNumber());
		entity.setGstNumber(model.getGstNumber());
		entity.setTanNumber(model.getTanNumber());
		entity.setLocation(model.getLocation());

		Address address = new Address();
		address.setAddress(model.getAddress().getAddress());
		address.setLandmark(model.getAddress().getLandmark());
		address.setStreet(model.getAddress().getStreet());
		address.setCity(model.getAddress().getCity());
		address.setDistrict(model.getAddress().getDistrict());
		address.setState(model.getAddress().getState());
		address.setCountry(model.getAddress().getCountry());
		address.setPincode(model.getAddress().getPincode());
		address.setType(model.getAddress().getType());
		entity.setAddress(address);
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);

		Company company = companyRepo.save(entity);
		log.info("Company Record is stored in Database with id:{}", company.getId());

		List<CompanyDTO> list = new ArrayList<>();
		model.setId(company.getId());
		list.add(model);
		return list;

	}

	/**
	 * Returns Company data when Company data is available in database by id
	 * 
	 * @param id - Company Id
	 * @return - CompanyModel
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public CompanyDTO getById(String id) {

		Optional<Company> optionalEntity = companyRepo.findById(id);
		if (optionalEntity.isPresent()) {
			Company entity = optionalEntity.get();
			CompanyDTO model = new CompanyDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setContact(entity.getContact());
			model.setEmail(entity.getEmail());
			model.setWebsite(entity.getWebsite());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setBranch(entity.getBranch());
			model.setContactPerson(entity.getContactPerson());
			model.setPanNumber(entity.getPanNumber());
			model.setGstNumber(entity.getGstNumber());
			model.setTanNumber(entity.getTanNumber());
			model.setLocation(entity.getLocation());
			List<ProfileImage> findByCompanyId = profileRepo.findByCompanyId(id);
			ProfileImageDTO profileImageDTO = new ProfileImageDTO();
			if (!findByCompanyId.isEmpty()) {
				for (ProfileImage image : findByCompanyId) {
					if (!image.getImageName().contains("_")) {
						profileImageDTO.setId(image.getId());
						profileImageDTO.setImageurl(image.getImageurl());
						profileImageDTO.setFileType(image.getFileType());
						profileImageDTO.setImageName(image.getImageName());
					}
				}
				model.setImage(profileImageDTO);
			}

			/*
			 * if (!findByCompanyId.isEmpty()) { Optional<ProfileImage> findById =
			 * profileRepo.findById(entity.getImage().getId()); if (findById.isPresent()) {
			 * ProfileImage cimage = findById.get(); ProfileImageDTO imageDto = new
			 * ProfileImageDTO(); imageDto.setFileType(cimage.getFileType());
			 * imageDto.setId(cimage.getId()); imageDto.setImageName(cimage.getImageName());
			 * imageDto.setImageurl(cimage.getImageurl()); model.setImage(imageDto); } //
			 * model.setAttechementId(entity.getAttachementId());
			 * 
			 * Optional<CompanyProfileImage> image =
			 * companyProfileImageRepo.findById(entity.getAttechementId()); if
			 * (image.isPresent()) { model.setImage(image.get().getImage());
			 * model.setContantType(image.get().getContantType()); }
			 * 
			 * }
			 */else {
				model.setImage(new ProfileImageDTO());
			}
			AddressDTO address1 = new AddressDTO();
			address1.setId(entity.getAddress().getId());
			address1.setAddress(entity.getAddress().getAddress());
			address1.setLandmark(entity.getAddress().getLandmark());
			address1.setStreet(entity.getAddress().getStreet());
			address1.setCity(entity.getAddress().getCity());
			address1.setDistrict(entity.getAddress().getDistrict());
			address1.setState(entity.getAddress().getState());
			address1.setCountry(entity.getAddress().getCountry());
			address1.setPincode(entity.getAddress().getPincode());
			address1.setType(entity.getAddress().getType());
			model.setAddress(address1);
			model.setIsDelete(entity.getIsDelete());
			log.info("Company found with Id:{}", id);
			return model;
		}
		return null;
	}

//	/**
//	 * @param id,
//	 * @return - true when is deleted
//	 */
//	@Override
//	public boolean deleteCompany(String id) {
//		companyRepo.deleteById(id);
//		log.info("Company record is deleted from database with id:{}", id);
//		return true;
//	}

	/**
	 * Returns true when existing Company data is store in database
	 * 
	 * @param model - new Company data
	 * @param id    - Company Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateCompany(CompanyDTO model) {
		Optional<Company> findById = companyRepo.findById(model.getId());
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Company oldCompany = findById.get();
			oldCompany.setName(model.getName().toUpperCase());
			oldCompany.setContact(model.getContact());
			oldCompany.setEmail(model.getEmail().toLowerCase());
			oldCompany.setWebsite(model.getWebsite());
			oldCompany.setBranch(model.getBranch());
			oldCompany.setContactPerson(model.getContactPerson());
			oldCompany.setPanNumber(model.getPanNumber());
			oldCompany.setGstNumber(model.getGstNumber());
			oldCompany.setTanNumber(model.getTanNumber());
			Address address = new Address();
			address.setId(oldCompany.getAddress().getId());
			address.setAddress(model.getAddress().getAddress());
			address.setLandmark(model.getAddress().getLandmark());
			address.setStreet(model.getAddress().getStreet());
			address.setCity(model.getAddress().getCity());
			address.setDistrict(model.getAddress().getDistrict());
			address.setState(model.getAddress().getState());
			address.setCountry(model.getAddress().getCountry());
			address.setPincode(model.getAddress().getPincode());
			address.setType(model.getAddress().getType());
			oldCompany.setAddress(address);
			Company a = companyRepo.save(oldCompany);
			log.info("Company record is updated in to database with id:{}", model.getId());
			EntityDTO dto = new EntityDTO();
			dto.setCompanyId(a.getId());
			dto.setName(a.getName());
			list.add(dto);
			return list;
		} else {
			log.info("Company record is not updated in to database with id:{}", model.getId());
			return list;
		}
	}

	@Override
	public Map<String, Object> getAllCompany(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Company> pagedResult = null;
		Boolean status = true;
		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = companyRepo.allCompanyPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = companyRepo.companyPage(searchKey, status, companyId, paging);
		}
		if (pagedResult.hasContent()) {
			log.info("For Company Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * @param Company Entity
	 * @return - page size
	 */
	public static Map<String, Object> mapData(Page<Company> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<CompanyDTO> companyModels = pagedResult.stream().map(companyEntity -> {
			CompanyDTO model = new CompanyDTO();
			AddressDTO addressDTO = new AddressDTO();
			Address address = companyEntity.getAddress();
			BeanUtils.copyProperties(address, addressDTO);
			BeanUtils.copyProperties(companyEntity, model);
			model.setAddress(addressDTO);
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, companyModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		log.info("Company map object is created for Paging");
		return response;
	}

	/**
	 * @param id,
	 * @return - List of Company based on CompanyId
	 */
	@Override
	@Cacheable(value = "AllCompany", unless = "#result.size() == 0")
	public List<CompanyDTO> AllCompany(String companyId) {
		List<Company> allCompany = new ArrayList<>();
		List<CompanyDTO> models = new ArrayList<>();
		Optional<Company> company = companyRepo.findById(companyId);
		if (company.isPresent()) {
			allCompany.add(company.get());
			models = allCompany.stream().map(entity -> {
				CompanyDTO model = new CompanyDTO();
				BeanUtils.copyProperties(entity, model);
				AddressDTO addressDTO = new AddressDTO();
				Address address = entity.getAddress();
				BeanUtils.copyProperties(address, addressDTO);
				model.setAddress(addressDTO);
				return model;
			}).collect(Collectors.toList());
			return models;
		} else {
			return models;
		}

	}

	/**
	 * @param id -Company,
	 * @return - change value from database isDisable is true
	 */
	public List<EntityDTO> softDeleteCompany(Long id) {
		Optional<Company> findById = companyRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Company company = findById.get();
			company.setIsDelete(Boolean.TRUE);
			company.setIsActive(Boolean.FALSE);
			Company p = companyRepo.save(company);
			log.info("Company is SoftDeleted in to database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setCompanyId(p.getId());
			dto.setName(p.getName());
			list.add(dto);
			return list;
		}
		return list;

	}

	/**
	 * @param CompanyDTO,
	 * @param boolean     value,
	 * @return - if record exit return true or if record not exit return false
	 */
	@Override
	public boolean validate(CompanyDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = companyRepo.getCompanyCount(model.getName());
		else
			count = companyRepo.getCompanyCountForUpdate(model.getName(), model.getId());
		return count > 0;
	}

	/**
	 * @param CompanyId,
	 * @param String     status,
	 * @return - if record is updateCompanyByStatus based on Company id
	 */
	public List<EntityDTO> updateCompanyByStatus(Long id, String status) {
		Optional<Company> findById = companyRepo.findByCompany(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Company a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Company e = companyRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setCompanyId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				log.info("Company is activated in to database with Id:{}", id);
				return list;
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Company e = companyRepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setCompanyId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				log.info("Company is deactivated in to database with Id:{}", id);
				return list;
			}
		}
		log.info("Company is failed to activated or deactivated in database with Id:{}", id);
		return list;
	}

	/**
	 * @param String companyName , * @param Long companyId
	 * @return - Company based on CompanyName
	 */
	@Override
	public Company findByCompanyName(String companyName) {
		return companyRepo.findByName(companyName);
	}

	/**
	 * based on company update profile image
	 */
	@Override
	public List<EntityDTO> saveCompanyImage(MultipartFile file, String id) throws IOException {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Company> findByCompayntId = companyRepo.findById(id);
		if (!findByCompayntId.isPresent()) {
			return list;
		}
		Company company = findByCompayntId.get();
		String filename = file.getOriginalFilename();
		filename = FilenameUtils.removeExtension(filename);
		filename = filename.replaceAll("[^a-zA-Z]", "");
		filename = filename + "." + FilenameUtils.getExtension(file.getOriginalFilename());
		String imageName = filename.replace("." + FilenameUtils.getExtension(file.getOriginalFilename()), "");
		String imageName350x120 = imageName + "_" + "350x120" + "."
				+ FilenameUtils.getExtension(file.getOriginalFilename());
		byte[] bytes = file.getBytes();
		Path path = Paths.get(folderpath + Constants.SUFFIX + filename);
		Files.write(path, bytes);
		String uri = path.toString();
		List<ProfileImage> findByCompanyId = profileRepo.findByCompanyId(id);

		if (findByCompanyId.isEmpty()) {
			List<ProfileImage> imagelist = new ArrayList<>();
			imagelist.add(copyCompanyimage(file, filename, id));

			imageUtils.resize(uri, 120, 350, FilenameUtils.getExtension(file.getOriginalFilename()), imageName350x120);
			MultipartFile file350x120 = imageUtils.file(imageName350x120, file.getContentType());
			imagelist.add(copyCompanyimage(file350x120, imageName350x120, id));
//			flag = s3ServiceUtil.uploadFileInFolder(file350x120, foldername, imageName350x120);
//			if (flag == true) {
//				ProfileImage image = new ProfileImage();
//				image.setImageName(imageName350x120);
//				image.setImageurl(s3ServiceUtil.generateFileUrl(imageName350x120, foldername));
//				image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
//				image.setCompanyId(id);
//				imagelist.add(image);
//			}
			imageUtils.deleteAllTempFiles();
			profileRepo.saveAll(imagelist);
			/*
			 * CompanyProfileImage companyImage1 = new CompanyProfileImage();
			 * companyImage1.setId(seqGeneratorService.generateSequence(CompanyProfileImage.
			 * SEQUENCE_NAME)); companyImage1.setImage(file.getBytes());
			 * companyImage1.setContantType(file.getContentType());
			 * companyImage1.setFileName(file.getOriginalFilename()); CompanyProfileImage
			 * image = companyProfileImageRepo.insert(companyImage1);
			 * company.setAttechementId(image.getId());
			 */
			EntityDTO dto = new EntityDTO();
			dto.setCompanyId(company.getId());
			dto.setName(company.getName());
			list.add(dto);
			return list;
		} else {
			for (ProfileImage img : findByCompanyId) {
				s3ServiceUtil.deleteFileFromFolder(img.getImageName(), foldername);
				profileRepo.deleteById(img.getId());
			}
			List<ProfileImage> imagelist = new ArrayList<>();
			imagelist.add(copyCompanyimage(file, filename, id));

			imageUtils.resize(uri, 120, 350, FilenameUtils.getExtension(file.getOriginalFilename()), imageName350x120);
			MultipartFile file350x120 = imageUtils.file(imageName350x120, file.getContentType());
			imagelist.add(copyCompanyimage(file350x120, imageName350x120, id));
//			flag = s3ServiceUtil.uploadFileInFolder(file, foldername, filename);
//			if (flag == true) {
//				ProfileImage image = new ProfileImage();
//				image.setImageName(filename);
//				image.setImageurl(s3ServiceUtil.generateFileUrl(filename, foldername));
//				image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
//				image.setCompanyId(id);
//				imagelist.add(image);
//			}
//			imageUtils.resize(uri, 120, 350, FilenameUtils.getExtension(file.getOriginalFilename()), imageName350x120);
//			MultipartFile file350x120 = imageUtils.file(imageName350x120, file.getContentType());
//			flag = s3ServiceUtil.uploadFileInFolder(file350x120, foldername, imageName350x120);
//			if (flag == true) {
//				ProfileImage image = new ProfileImage();
//				image.setImageName(imageName350x120);
//				image.setImageurl(s3ServiceUtil.generateFileUrl(imageName350x120, foldername));
//				image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
//				image.setCompanyId(id);
//				imagelist.add(image);
//			}
			imageUtils.deleteAllTempFiles();
			profileRepo.saveAll(imagelist);
			/*
			 * companyProfileImageRepo.deleteById(company.getAttechementId());
			 * CompanyProfileImage companyImage = new CompanyProfileImage();
			 * companyImage.setId(seqGeneratorService.generateSequence(CompanyProfileImage.
			 * SEQUENCE_NAME)); companyImage.setImage(file.getBytes());
			 * companyImage.setContantType(file.getContentType());
			 * companyImage.setFileName(file.getOriginalFilename()); CompanyProfileImage
			 * image = companyProfileImageRepo.insert(companyImage);
			 * company.setAttechementId(image.getId());
			 */
			EntityDTO dto = new EntityDTO();
			dto.setCompanyId(company.getId());
			dto.setName(company.getName());
			list.add(dto);
			return list;
		}
	}

	@Override
	public List<EntityDTO> multipleCompanyDelete(List<Long> ids) {

		List<EntityDTO> entityDto = new ArrayList<>();

		for (Long id : ids) {
			Company companyById = null;

			Optional<Company> findById = companyRepo.findById(id);

			if (findById.isPresent()) {
				Company company = findById.get();
				company.setIsDelete(Boolean.TRUE);
				company.setIsActive(Boolean.FALSE);
				companyById = companyRepo.save(company);
				Long addressId = company.getAddress().getId();
				Optional<Address> findByaddressId = addressRepo.findById(addressId);
				if (findByaddressId.isPresent()) {
					Address address = findByaddressId.get();
					addressRepo.delete(address);
				}
				EntityDTO dto = new EntityDTO();
				dto.setId(id);
				dto.setName(companyById.getName());
				entityDto.add(dto);
			}
		}
		return entityDto;

	}

	@Override
	@Transactional
	public Map<String, String> companyRegister(CompanyRegisterDTO model) {
		Company entity = new Company();
		Company company = null;
		Map<String, String> listData = null;

		try {
			Address address = new Address();
			address.setAddress(model.getAddress());
			address.setLandmark("");
			address.setStreet("");
			address.setCity(1L);
			address.setDistrict("");
			address.setState(1L);
			address.setCountry(model.getCountryId());
			address.setPincode("000000");

			entity.setName(model.getCompanyName());
			entity.setContact(model.getMobileNo());
			entity.setEmail(model.getEmail().toLowerCase());
			entity.setWebsite("");
			entity.setBranch("");
			entity.setContactPerson(model.getFirstName() + model.getLastName());
			entity.setPanNumber("");
			entity.setGstNumber("");
			entity.setTanNumber("");
			entity.setLocation("");
			entity.setFirstName(model.getFirstName());
			entity.setLastName(model.getLastName());
			entity.setUserName(model.getUserName());
			entity.setAddress(address);
			entity.setIsDelete(Boolean.FALSE);
			entity.setIsActive(Boolean.TRUE);
			String companyName;
			companyName = model.getCompanyName().replaceAll("\\s", "");
			companyName = companyName.substring(0, 4);
			companyName = companyName.toUpperCase();
			String companyId = companyRepo.getLostInsertedCompany();
			if (!Objects.isNull(companyId) && companyId != null && !companyId.equals("")) {
				String id = companyId.substring(4, companyId.length());
				Long idVal = Long.parseLong(id);
				Long idValue = idVal + 1L;
				String userid = companyName.concat("000").concat(idValue.toString());
				entity.setId(userid);
			} else {
				entity.setId(companyName.concat("0001"));
			}
			company = companyRepo.save(entity);

			String password = employeeUtil.saveUserToEmployeeDataSave(company);

			MailDTO request = new MailDTO();
			request.setTo(company.getEmail());
			request.setSubject("Welcome to O-Staff");
			request.setTemplate(Constants.SIGNUP_TEMPLATE_NAME);
			String url = loginUrl;
			Map<String, Object> mapModel = new HashMap<>();
			mapModel.put(Constants.URL, url);
			mapModel.put(Constants.TEMPPASS, password);
			mapModel.put(Constants.USERNAME, company.getUserName());
			emailUtil.sendUserSignUpMail(request, mapModel);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (company != null) {
			listData = new HashedMap<>();
			String data = "User Signed In successfully/signup respective mail sent.";
			listData.put("data", data);
			log.info(data);
		}
		return listData;
	}

	@Override
	public boolean validateCompanyRegister(CompanyRegisterDTO model, boolean isSave) {
		Long count = null;
		if (isSave) {
			count = companyRepo.getCompanySaveCount(model.getCompanyName(), model.getUserName(), model.getMobileNo(),
					model.getEmail());
		}
		return count > 0;
	}

	@Override
	public boolean validateCompanyEmail(CompanyRegisterDTO model, boolean isSave) {
		Long count = null;
		if (isSave) {
			count = companyRepo.getCompanySaveCountByEmail(model.getEmail());
		}
		return count > 0;
	}

	@Override
	public boolean validateCompanyUserName(CompanyRegisterDTO model, boolean isSave) {
		Long count = null;
		if (isSave) {
			count = companyRepo.getCompanySaveCountByUserName(model.getUserName());
		}
		return count > 0;
	}

	@Override
	public boolean validateCompanyContactNo(CompanyRegisterDTO model, boolean isSave) {
		Long count = null;
		if (isSave) {
			count = companyRepo.getCompanySaveCountByContact(model.getMobileNo());
		}
		return count > 0;
	}

	@Override
	public boolean validateCompanyName(CompanyRegisterDTO model, boolean isSave) {
		Long count = null;
		if (isSave) {
			count = companyRepo.getCompanySaveCountByName(model.getCompanyName());
		}
		return count > 0;
	}

	public ProfileImage copyCompanyimage(MultipartFile file, String fileName, String companyId) {
		boolean flag = s3ServiceUtil.uploadFileInFolder(file, foldername, fileName);
		ProfileImage image = new ProfileImage();
		if (flag == true) {
			image.setImageName(fileName);
			image.setImageurl(s3ServiceUtil.generateFileUrl(fileName, foldername));
			image.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));
			image.setCompanyId(companyId);
			image.setContentType(file.getContentType());
		}
		return image;

	}

}
