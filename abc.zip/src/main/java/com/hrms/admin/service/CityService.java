package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.entity.City;

public interface CityService {
	
	public List<City> findByState(Long id);

}
