package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.BellIconNotificationsDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.NotificationDTO;
import com.hrms.admin.dto.WishesDTO;
import com.hrms.admin.entity.BellIconNotifications;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Notification;
import com.hrms.admin.repository.BellIconNotificationsRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.NotificationRepository;
import com.hrms.admin.service.NotificationService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.StringToDateUtility;

@Service
public class NotificationServiceImpl implements NotificationService {

	private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Autowired
	private NotificationRepository repo;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private StringToDateUtility dateUtil;

	@Autowired
	private BellIconNotificationsRepository bellIconRepo;

	/**
	 * Returns true when new notification is store in database
	 * 
	 * @param model - new notification data
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> save(NotificationDTO model) {
		Notification entity = new Notification();

		Company company = null;
		Optional<Company> findByCompanyId = companyRepo.findById(model.getCompanyId());
		if (findByCompanyId.isPresent()) {
			company = findByCompanyId.get();
			entity.setSubject(model.getSubject());
			entity.setDescription(model.getDescription());
			entity.setCompany(company);
			entity.setEventDate(model.getEventDate());
			entity.setIsActive(Boolean.TRUE);
			entity.setIsDelete(Boolean.FALSE);
			entity.setFromMail(model.getFromMail());

			Notification d = repo.save(entity);
			logger.info("Notification Added into database");

			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getSubject());
			List<EntityDTO> list = new ArrayList<>();
			list.add(dto);
			return list;
		} else
			logger.info("Notification not added into database");
		return null;
	}

	@Transactional
	@Override
	public List<EntityDTO> sendNotifications(Long id, String formMail) throws Exception {
		Optional<Notification> findById = repo.findById(id);
		if (findById.isPresent()) {
			Notification model = findById.get();
			MailDTO request = new MailDTO();
			request.setSubject(
					Constants.EVENT + " " + model.getSubject() + " " + dateUtil.changeISTDate(model.getEventDate()));
			request.setName(model.getSubject());
			request.setTemplate("event_join.html");
			request.setFrom(formMail);
			request.setCompanyId(model.getCompany().getId());
			Map<String, Object> model1 = new HashMap<>();
			model1.put(Constants.MSG, Constants.EVENT);
			model1.put(Constants.EVENTDATE, model.getEventDate());
			model1.put(Constants.NAME, model.getSubject());
			model1.put(Constants.DESCRIPTION, model.getDescription());
			List<Employee> findAll = employeeRepo.findByCompany(model.getCompany().getId());
			for (Employee employee2 : findAll) {
				if (employee2.getOfficalMail() != null || !employee2.getOfficalMail().isBlank()) {
					request.setTo(employee2.getOfficalMail());
					emailServiceUtil.sendNotificationEmail(request, model1);
					logger.info("Wishes mail send to:{}", employee2.getOfficalMail());
				}
			}
			logger.info("Event mail send successfully");
			EntityDTO dto = new EntityDTO();
			dto.setId(model.getId());
			dto.setName(model.getSubject());

			List<EntityDTO> list = new ArrayList<>();
			list.add(dto);
			return list;
		}
		return null;
	}

	/**
	 * Returns true when existing notification data is store in database
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateNotification(NotificationDTO model, Long id) {
		Optional<Notification> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Notification oldNotification = findById.get();
			oldNotification.setSubject(model.getSubject());
			oldNotification.setDescription(model.getDescription());
			oldNotification.setEventDate(model.getEventDate());
			oldNotification.setFromMail(model.getFromMail());
			Notification n = repo.save(oldNotification);
			logger.info("Notification record is updated in database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(n.getId());
			dto.setName(n.getSubject());
			list.add(dto);
			return list;
		}
		return list;
	}

	/**
	 * Returns Notification data when notification data is available in database by
	 * 
	 * @param id - notification Id
	 * @return - NotificationModel
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public NotificationDTO getById(Long id, String companyId) {
		Optional<Notification> optionalEntity = repo.findNotificationByCompanyId(id, companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Notification entity = optionalEntity.get();
		NotificationDTO model = new NotificationDTO();
		model.setId(entity.getId());
		model.setSubject(entity.getSubject());
		model.setCompanyId(entity.getCompany().getId());
		model.setCompanyName(entity.getCompany().getName());
		model.setDescription(entity.getDescription());
		model.setEventDate(entity.getEventDate());
		model.setIsActive(entity.getIsActive());
		model.setIsDelete(entity.getIsDelete());
		model.setFromMail(entity.getFromMail());
		logger.info("Skill found in BD with Id:{}", id);
		return model;
	}

	/**
	 * Returns All Notification data when notification data is available in database
	 * 
	 * @return - List of NotificationModel
	 */
	@Override
	public List<NotificationDTO> getAllNotificationList() {
		List<Notification> allNotifications = repo.findAll();
		List<NotificationDTO> models = allNotifications.stream().map(entity -> {
			NotificationDTO model = new NotificationDTO();
			model.setId(entity.getId());
			model.setSubject(entity.getSubject());
			model.setDescription(entity.getDescription());
			Company cmp = new Company();
			model.setCompanyId(cmp.getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setEventDate(entity.getEventDate());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			model.setFromMail(entity.getFromMail());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * Returns true when notification data is deleted from database by id
	 * 
	 * @param id - notification id
	 * @return - boolean
	 */
	@Override
	public boolean deleteNotification(Long id) {
		repo.deleteById(id);
		logger.info("Notification record is deleted from database");
		return true;
	}

	/**
	 * Returns All Leave data when Notification data is available in database
	 * 
	 * @return - List of NotificationresponseModel
	 */

	@Override
	public Map<String, Object> getAllNotification(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Notification> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = repo.allNotificationPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = repo.notificationPage(searchKey, companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Notification Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * @param Notification Entity
	 * @return - page size
	 */

	public static Map<String, Object> mapData(Page<Notification> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<NotificationDTO> notificationModels = pagedResult.stream().map(entity -> {
			NotificationDTO model = new NotificationDTO();
			model.setId(entity.getId());
			model.setSubject(entity.getSubject());
			model.setDescription(entity.getDescription());
			model.setEventDate(entity.getEventDate());
			Company cmp = new Company();
			model.setCompanyId(cmp.getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			model.setFromMail(entity.getFromMail());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, notificationModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("Notification map object is created for Paging");
		return response;
	}

	/**
	 * @param id,
	 * @param String,
	 * @return - if record is updateNotificationByStatus based onNotificationid
	 */

	@Override
	public List<EntityDTO> updateNotificationByStatus(Long id, String status) {
		Optional<Notification> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Notification notification = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			notification.setIsActive(Boolean.TRUE);
			Notification e = repo.save(notification);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getSubject());
			list.add(dto);
			logger.info("Notification is Activated in database with Id:{}", id);
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			notification.setIsActive(Boolean.FALSE);
			Notification e = repo.save(notification);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getSubject());
			list.add(dto);
			logger.info("Notification  is Deactivated in to database Id:{}", id);
			return list;
		} else
			logger.info("Notification status is invalid  with Id:{}", id);
		return list;
	}

	/**
	 * @param id -LeaveType,
	 * @return - change value from database isDisable is true
	 */

	public List<EntityDTO> softDeleteNotification(Long id) {
		Optional<Notification> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Notification notification = findById.get();
		notification.setIsActive(Boolean.FALSE);
		notification.setIsDelete(Boolean.TRUE);
		Notification n = repo.save(notification);
		logger.info("Notification is SoftDeleted in database with Id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(n.getId());
		dto.setName(n.getSubject());
		list.add(dto);
		return list;

	}

	/**
	 * @param NotificationDTO ,
	 * @param boolean         value,
	 * @return - if record exit return true or if record not exit return false
	 */

	@Override
	public boolean validate(NotificationDTO leaveType, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getNotificationCountSave(leaveType.getSubject(), leaveType.getCompanyId());
		else
			count = repo.getNotificationCountUpdate(leaveType.getSubject(), leaveType.getCompanyId(),
					leaveType.getId());
		return count > 0;
	}

	@Override
	public List<EntityDTO> wishesList(WishesDTO w, String companyId) {
		List<EntityDTO> list = new ArrayList<>();
		MailDTO request = new MailDTO();
		Map<String, Object> model1 = new HashMap<>();
		if (w.getEmpId() != null) {
			Optional<Employee> findById = employeeRepo.findById(w.getEmpId());
			if (!findById.isPresent()) {
				return list;
			}
			Employee e = findById.get();
			Boolean isActive = e.getIsActive();
			if (isActive) {
				if (w.getType().equalsIgnoreCase(Constants.BABYBOY)) {
					request.setSubject(Constants.CONGRATULATIONS_ON_YOUR_NEW_BABY);
					request.setTemplate("newborn_boy.html");
					model1.put(Constants.NAME, e.getFirstName() + " " + e.getLastName());
					model1.put(Constants.MSG, w.getType());
				} else if (w.getType().equalsIgnoreCase(Constants.BABYGIRL)) {
					request.setSubject(Constants.CONGRATULATIONS_ON_YOUR_NEW_BABY);
					request.setTemplate("newborn_girl.html");
					model1.put(Constants.NAME, e.getFirstName() + " " + e.getLastName());
					model1.put(Constants.MSG, w.getType());
				} else if (w.getType().equalsIgnoreCase(Constants.PROMOTION)) {
					request.setSubject("Congratulations" + " " + e.getFirstName() + " " + e.getLastName());
					request.setTemplate("promotion.html");
					model1.put(Constants.NAME, e.getFirstName() + " " + e.getLastName());
					model1.put(Constants.MSG, w.getType());
				} else if (w.getType().equalsIgnoreCase("employeeOfMonth")) {
					request.setSubject("Congratulations" + " " + e.getFirstName() + " " + e.getLastName());
					request.setTemplate("employeeof_month.html");
					model1.put(Constants.NAME, e.getFirstName() + " " + e.getLastName());
					model1.put(Constants.MSG, w.getType());
				}
			}
		} else {
			if (w.getType().equalsIgnoreCase(Constants.TEAMAPPRECIALS)) {
				request.setSubject("Congratulations to the" + " " + w.getTeamName() + " " + "Team");
				request.setTemplate("team_appreciation.html");
				model1.put(Constants.TEAMNAME, w.getTeamName());
				model1.put(Constants.MSG, w.getType());
			} else if (w.getType().equalsIgnoreCase(Constants.TRAINING)) {
				request.setSubject(Constants.WE_HAVE_YOUR_NEXT_GREAT_OPPORTUNITY);
				request.setTemplate("opportunity.html");
				model1.put(Constants.MSG, w.getType());
				model1.put(Constants.PHONE, w.getPhone());
				model1.put(Constants.FAX, w.getFax());
				model1.put(Constants.EMAIL, w.getEmail());
			} else if (w.getType().equalsIgnoreCase(Constants.HOLIDAY)) {
				request.setSubject(Constants.HOLIDAY_DECLARE);
				request.setTemplate("holiday_declare.html");
				model1.put(Constants.DATE, w.getDate());
				model1.put(Constants.REASON, w.getReason());
				model1.put(Constants.MSG, w.getType());
			}
		}
		List<EmployeeInfoDTO> findAll = employeeRepo.findEmp(companyId);
		for (EmployeeInfoDTO employee2 : findAll) {
			request.setTo(employee2.getOfficalMail());
			request.setFrom(Constants.HRMS);
			emailServiceUtil.sendNotificationEmail(request, model1);
			logger.info("Wishes mail send to: {}", employee2.getOfficalMail());
			EntityDTO dto = new EntityDTO();
			dto.setName(w.getType());
			list.add(dto);
		}
		return list;
	}

	/**
	 * @param empId ,
	 * @return - true welcome mail send other wise false based on empid
	 */

	@Override
	public Boolean welcomeMail(Long empId, String companyId) {
		Boolean flag = Boolean.FALSE;
		Optional<Employee> findById = employeeRepo.findById(empId);
		if (!findById.isPresent()) {
			return flag;
		}
		Employee e = findById.get();
		logger.info("welcome mail  based on empid:{}", empId);
		Boolean isActive = e.getIsActive();
		if (isActive) {
			List<Employee> findAll = employeeRepo.findAllEmployeeEmailsByCompanyId(companyId);
			for (Employee employee2 : findAll) {
				MailDTO request = new MailDTO();
				request.setTo(employee2.getOfficalMail());
				request.setFrom(Constants.HR);
				request.setSubject(Constants.WELCOME_ONBOARD);
				request.setTemplate("employee_onboard.html");
				request.setCompanyId(companyId);
				Map<String, Object> model = new HashMap<>();
				model.put(Constants.NAME, e.getFirstName() + " " + e.getLastName());
				model.put(Constants.MSG, Constants.HAPPY_JOINNINGDAY);
				emailServiceUtil.sendOccationEmail(request, model);
				logger.info("Wishes mail send to:{}", employee2.getEmail());
				flag = Boolean.TRUE;
			}
		}
		return flag;
	}

	/*
	 * @Override public BellIconNotificationsDTO getBellIconNotifications(String
	 * companyId) { List<BellIconNotifications> notifications =
	 * bellIconRepo.getNotifications(companyId); HashMap<String,
	 * ArrayList<BellIconNotifications>> collect = notifications.stream()
	 * .collect(Collectors.groupingBy(BellIconNotifications::getNotificationType,
	 * HashMap::new, Collectors.toCollection(ArrayList::new)));
	 * BellIconNotificationsDTO dto = new BellIconNotificationsDTO();
	 * dto.setCount(notifications.size()); dto.setData(collect); return dto; }
	 */
	@Override
	public Map<String, Object> getBellIconNotificationsTomanager(Long approverId, String companyId) {
		Map<String, Object> map = new HashMap<>();
		List<BellIconNotifications> leaveIconNotifications = bellIconRepo.getNotificationsForManager(approverId,
				companyId);
		map.put("count", leaveIconNotifications.size());
		map.put("notificationList", leaveIconNotifications);
		return map;
	}

	@Override
	public Map<String, Object> getBellIconNotificationsToemployee(Long empId, String companyId) {
		Map<String, Object> map = new HashMap<>();
		List<BellIconNotifications> leaveIconNotifications = bellIconRepo.getNotificationsForEmployee(empId, companyId);
		map.put("count", leaveIconNotifications.size());
		map.put("notificationList", leaveIconNotifications);
		return map;
	}

	@Override
	public BellIconNotifications getBellIconNotificationById(BellIconNotificationsDTO notification) {
		BellIconNotifications bellIcon = new BellIconNotifications();
		Optional<BellIconNotifications> findById = bellIconRepo.findById(notification.getNotificationId());
		if (findById.isPresent()) {
			BellIconNotifications iconId = findById.get();
			if (notification.isNotificationFlag()) {
				bellIcon.setNotificationFlag(notification.isNotificationFlag());
			} else {
				bellIcon.setNotificationFlag(iconId.isNotificationFlag());
			}
			bellIcon.setNotificationMenuPath(iconId.getNotificationMenuPath());
			bellIcon.setNotificationType(iconId.getNotificationType());
			bellIcon.setApproverId(iconId.getApproverId());
			bellIcon.setNotificationId(iconId.getNotificationId());
			bellIcon.setCompanyId(iconId.getCompanyId());
			bellIcon.setEmployeeId(iconId.getEmployeeId());
			bellIcon.setEmployeeName(iconId.getEmployeeName());
			bellIcon.setNotificationDate(iconId.getNotificationDate());
			bellIcon.setNotificationMessage(iconId.getNotificationMessage());
			bellIcon.setLeaveStatus(iconId.getLeaveStatus());
			if (notification.isEmployeeNotificationFlag()) {
				bellIcon.setEmployeeNotificationFlag(notification.isEmployeeNotificationFlag());
			} else {
				bellIcon.setEmployeeNotificationFlag(iconId.isEmployeeNotificationFlag());
			}
			return bellIconRepo.save(bellIcon);
		}
		return bellIcon;
	}

	@Override
	public boolean deleteBellIconNotificationById(Long notificationId) {
		Optional<BellIconNotifications> findById = bellIconRepo.findById(notificationId);
		if (findById.isPresent()) {
			BellIconNotifications bellIconNotifications = findById.get();
			bellIconRepo.delete(bellIconNotifications);
			return true;
		}
		return false;
	}

	@Override
	public List<BellIconNotifications> getBellNotificationsListTomanager(Long approverId, String companyId) {
		List<BellIconNotifications> list = new ArrayList<>();
		List<BellIconNotifications> bellNotificationList = bellIconRepo.getBellNotificationListOfManager(approverId,
				companyId);
		for (BellIconNotifications bellIcon : bellNotificationList) {
			BellIconNotifications bellIconlist = new BellIconNotifications();
			bellIconlist.setNotificationId(bellIcon.getNotificationId());
			bellIconlist.setEmployeeId(bellIcon.getEmployeeId());
			bellIconlist.setEmployeeName(bellIcon.getEmployeeName());
			bellIconlist.setNotificationType(bellIcon.getNotificationType());
			bellIconlist.setNotificationMessage(bellIcon.getNotificationMessage());
			bellIconlist.setNotificationDate(bellIcon.getNotificationDate());
			list.add(bellIconlist);
		}
		return list;
	}

	@Override
	public List<BellIconNotifications> getBellNotificationsListToemployee(Long empId, String companyId) {
		List<BellIconNotifications> list = new ArrayList<>();
		List<BellIconNotifications> bellNotificationList = bellIconRepo.getBellNotificationListOfEmployee(empId,
				companyId);
		for (BellIconNotifications bellIcon : bellNotificationList) {
			BellIconNotifications bellIconlist = new BellIconNotifications();
			bellIconlist.setNotificationId(bellIcon.getNotificationId());
			bellIconlist.setEmployeeId(bellIcon.getEmployeeId());
			bellIconlist.setEmployeeName(bellIcon.getEmployeeName());
			bellIconlist.setNotificationType(bellIcon.getNotificationType());
			bellIconlist.setNotificationMessage(bellIcon.getNotificationMessage());
			bellIconlist.setNotificationDate(bellIcon.getNotificationDate());
			list.add(bellIconlist);
		}
		return list;
	}
}