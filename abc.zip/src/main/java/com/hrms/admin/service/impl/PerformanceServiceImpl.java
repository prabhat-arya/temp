package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EmployeeManagerDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.GoalQuestionAnsReview;
import com.hrms.admin.dto.PerformanceDTO;
import com.hrms.admin.entity.GoalCreation;
import com.hrms.admin.entity.GoalQuestions;
import com.hrms.admin.entity.Performance;
import com.hrms.admin.entity.PerformanceQuesAnsReview;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.GoalCreationRepository;
import com.hrms.admin.repository.PerformanceRepository;
import com.hrms.admin.service.PerformanceService;
import com.hrms.admin.util.Constants;

@Service
public class PerformanceServiceImpl implements PerformanceService {

	private static final Logger logger = LoggerFactory.getLogger(PerformanceServiceImpl.class);

	@Autowired
	private PerformanceRepository performanceRepository;

	@Autowired
	private GoalCreationRepository goalCreationRepository;

	@Autowired
	private EmployeeRepository employeeRepo;

	@Override
	public List<EntityDTO> saveAndUpdatePerformanceByEmployee(PerformanceDTO model) {

		// call this method when Employee wants to insert the form or update the form
		List<EntityDTO> list = new ArrayList<>();
		Performance employeeInPerformance = performanceRepository.findByEmployeeId(model.getEmployeeId());
		if (employeeInPerformance == null) {

			// employee only fill his related details and submit the form
			return employeeOnlyRelatedDetails(model, list);

		} else {

			return employeeUpdatedDetails(model, list, employeeInPerformance);
		}
	}

	// refracted method
	private List<EntityDTO> employeeOnlyRelatedDetails(PerformanceDTO model, List<EntityDTO> list) {

		Performance performanceEntity = new Performance();
		performanceEntity.setAssignDate(model.getAssignDate());
		performanceEntity.setDueDate(model.getDueDate());
		performanceEntity.setEmployeeId(model.getEmployeeId());
		performanceEntity.setDepartmentName(model.getDepartmentName());
		performanceEntity.setEmployeeName(model.getEmployeeName());
		performanceEntity.setPeriod(model.getPeriod());
		performanceEntity.setReviewStart(model.getReviewStart());
		performanceEntity.setReviewEnd(model.getReviewEnd());
		performanceEntity.setReviwerComment(model.getReviwerComment());
		performanceEntity.setReviwerRating(model.getReviwerRating());
		performanceEntity.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in Goals table");
			return list;
		}
		if (model.getTempSave().equals(Boolean.TRUE)) {
			performanceEntity.setEmployeeStatus(Constants.EMP_INPROGRESS);
			goal.setStatus(Constants.EMP_INPROGRESS);
		} else {
			performanceEntity.setEmployeeStatus(Constants.EMP_SUBMITTED);
			goal.setStatus(Constants.EMP_SUBMITTED);
		}
		goalCreationRepository.save(goal);

		performanceEntity.setManagerStatus(Constants.MANAGER_INPROGRESS);
		performanceEntity.setReviewManager(model.getReviewManager());
		// set the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {

			PerformanceQuesAnsReview qarEntity = new PerformanceQuesAnsReview();
			qarEntity.setQuestion(goalQuestionAnsReview.getQuestion());
			qarEntity.setEmployeeAnswer(goalQuestionAnsReview.getEmployeeAnswer());
			qarEntity.setQuestionId(goalQuestionAnsReview.getQuestionId());
			qarEntity.setEmployeeReview(goalQuestionAnsReview.getEmployeeReview());
			qarlist.add(qarEntity);
		}
		performanceEntity.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(performanceEntity);
		logger.info("Performance is saved by employee");
		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	// refracted method
	private List<EntityDTO> employeeUpdatedDetails(PerformanceDTO model, List<EntityDTO> list,
			Performance employeeInPerformance) {
		employeeInPerformance.setDepartmentName(model.getDepartmentName());
		employeeInPerformance.setAssignDate(model.getAssignDate());
		employeeInPerformance.setDueDate(model.getDueDate());
		employeeInPerformance.setEmployeeId(model.getEmployeeId());
		employeeInPerformance.setEmployeeName(model.getEmployeeName());
		employeeInPerformance.setPeriod(model.getPeriod());
		employeeInPerformance.setReviewStart(model.getReviewStart());
		employeeInPerformance.setReviewEnd(model.getReviewEnd());
		employeeInPerformance.setReviwerComment(model.getReviwerComment());
		employeeInPerformance.setReviwerRating(model.getReviwerRating());
		employeeInPerformance.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in Goals table");
			return list;
		}
		if (model.getTempSave().equals(Boolean.TRUE)) {
			employeeInPerformance.setEmployeeStatus(Constants.EMP_INPROGRESS);
			goal.setStatus(Constants.EMP_INPROGRESS);
		} else {
			employeeInPerformance.setEmployeeStatus(Constants.EMP_SUBMITTED);
			goal.setStatus(Constants.EMP_SUBMITTED);
		}
		goalCreationRepository.save(goal);

		// update the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {
			for (PerformanceQuesAnsReview goalQuestionsAnsReview : employeeInPerformance.getGoalQuestionsAnsReview()) {
				if (goalQuestionAnsReview.getQuestionId().equals(goalQuestionsAnsReview.getQuestionId())) {
					goalQuestionsAnsReview.setEmployeeAnswer(goalQuestionAnsReview.getEmployeeAnswer());
					goalQuestionsAnsReview.setQuestion(goalQuestionAnsReview.getQuestion());
					goalQuestionsAnsReview.setEmployeeReview(goalQuestionAnsReview.getEmployeeReview());
					qarlist.add(goalQuestionsAnsReview);
				}
			}
		}
		employeeInPerformance.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(employeeInPerformance);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	// manager give review and update the form
	@Override
	public List<EntityDTO> saveAndUpdatePerformanceByManager(PerformanceDTO model) {

		// call this method when manager wants to insert the form or update the form
		List<EntityDTO> list = new ArrayList<>();
		Performance employeeInPerformance = performanceRepository.findByEmployeeId(model.getEmployeeId());
		if (employeeInPerformance == null) {

			// manger only fill manager related details for the employee and submit the form
			return managerFillDetails(model, list);

		} else {

			// if the employee is already exist then update the employeeAnswers in
			// performance table
			// employee only fill his related details and submit the form
			return employeeAlreadyExist(model, list, employeeInPerformance);
		}
	}

	// refracted method
	private List<EntityDTO> employeeAlreadyExist(PerformanceDTO model, List<EntityDTO> list,
			Performance employeeInPerformance) {
		employeeInPerformance.setAssignDate(model.getAssignDate());
		employeeInPerformance.setDepartmentName(model.getDepartmentName());
		employeeInPerformance.setEmployeeId(model.getEmployeeId());
		employeeInPerformance.setEmployeeName(model.getEmployeeName());
		employeeInPerformance.setPeriod(model.getPeriod());
		employeeInPerformance.setDueDate(model.getDueDate());
		employeeInPerformance.setReviewEnd(model.getReviewEnd());
		employeeInPerformance.setReviewStart(model.getReviewStart());
		employeeInPerformance.setReviewManager(model.getReviewManager());
		employeeInPerformance.setReviwerComment(model.getReviwerComment());
		employeeInPerformance.setReviwerRating(model.getReviwerRating());
		employeeInPerformance.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in goal table");
			return list;
		}
		if (model.getTempSave().equals(Boolean.TRUE)) {
			employeeInPerformance.setManagerStatus(Constants.MANAGER_INPROGRESS);
			if (employeeInPerformance.getEmployeeStatus() == null) {//
				employeeInPerformance.setEmployeeStatus(Constants.EMP_INPROGRESS); // new added
			} //
			goal.setStatus(Constants.MANAGER_INPROGRESS);
		} else {
			employeeInPerformance.setManagerStatus(Constants.MANAGER_REVIEWED);
			goal.setStatus(Constants.MANAGER_REVIEWED);
		}
		goalCreationRepository.save(goal);

		employeeInPerformance.setFinalComment(model.getFinalComment());
		employeeInPerformance.setCompletedDate(model.getCompletedDate());
		employeeInPerformance.setFinalRating(model.getFinalRating());

		// update the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {
			for (PerformanceQuesAnsReview goalQuestionsAnsReview : employeeInPerformance.getGoalQuestionsAnsReview()) {
				if (goalQuestionAnsReview.getQuestionId().equals(goalQuestionsAnsReview.getQuestionId())) {
					goalQuestionsAnsReview.setManagerAnswer(goalQuestionAnsReview.getManagerAnswer());
					goalQuestionsAnsReview.setManagerReview(goalQuestionAnsReview.getManagerReview());
					goalQuestionsAnsReview.setQuestion(goalQuestionAnsReview.getQuestion());
					qarlist.add(goalQuestionsAnsReview);
				}
			}
		}
		employeeInPerformance.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(employeeInPerformance);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	// refracted method
	private List<EntityDTO> managerFillDetails(PerformanceDTO model, List<EntityDTO> list) {
		Performance performanceEntity = new Performance();
		performanceEntity.setAssignDate(model.getAssignDate());
		performanceEntity.setDepartmentName(model.getDepartmentName());
		performanceEntity.setDueDate(model.getDueDate());
		performanceEntity.setPeriod(model.getPeriod());
		performanceEntity.setReviewEnd(model.getReviewEnd());
		performanceEntity.setReviewStart(model.getReviewStart());
		performanceEntity.setEmployeeId(model.getEmployeeId());
		performanceEntity.setEmployeeName(model.getEmployeeName());
		performanceEntity.setReviewManager(model.getReviewManager());
		performanceEntity.setReviwerComment(model.getReviwerComment());
		performanceEntity.setReviwerRating(model.getReviwerRating());
		performanceEntity.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in goal table");
			return list;
		}
		if (model.getTempSave().equals(Boolean.TRUE)) {
			performanceEntity.setManagerStatus(Constants.MANAGER_INPROGRESS);
			performanceEntity.setEmployeeStatus(Constants.EMP_INPROGRESS);
			goal.setStatus(Constants.MANAGER_INPROGRESS);
		} else {
			performanceEntity.setManagerStatus(Constants.MANAGER_REVIEWED);
//			performanceEntity.setEmployeeStatus(Constants.MANAGER_INPROGRESS);
			goal.setStatus(Constants.MANAGER_REVIEWED);
		}
		goalCreationRepository.save(goal);

		performanceEntity.setFinalRating(model.getFinalRating());
		performanceEntity.setFinalComment(model.getFinalComment());
		performanceEntity.setCompletedDate(model.getCompletedDate());

		// set the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {

			PerformanceQuesAnsReview qarEntity = new PerformanceQuesAnsReview();
			qarEntity.setQuestion(goalQuestionAnsReview.getQuestion());
			qarEntity.setManagerReview(goalQuestionAnsReview.getManagerReview());
			qarEntity.setQuestionId(goalQuestionAnsReview.getQuestionId());
			qarEntity.setManagerAnswer(goalQuestionAnsReview.getManagerAnswer());
			qarlist.add(qarEntity);
		}
		performanceEntity.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(performanceEntity);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	// To get the performance if the it exist and if not get that employee questions
	@Override
//	@Cacheable(value= "findPerformanceByEmployeeIdCache",unless= "#result.size() == 0",key = "#employeeId")
	public List<PerformanceDTO> findPerformanceByEmployeeId(Long employeeId) {
		// here it will only insert the status column as "In Progress"
		List<PerformanceDTO> list = new ArrayList<>();

		PerformanceDTO model = new PerformanceDTO();
		Performance pEntity = performanceRepository.findByEmployeeId(employeeId);

		if (pEntity != null) {

			// employee is already exist in the Performance table
			model.setAssignDate(pEntity.getAssignDate());
			model.setEmployeeName(pEntity.getEmployeeName());
			model.setCompletedDate(pEntity.getCompletedDate());
			model.setDepartmentName(pEntity.getDepartmentName());
			model.setDueDate(pEntity.getDueDate());
			model.setEmployeeId(pEntity.getEmployeeId());
			model.setFinalComment(pEntity.getFinalComment());
			model.setFinalRating(pEntity.getFinalRating());
			model.setPerfomanceId(pEntity.getPerfomanceId());
			model.setPeriod(pEntity.getPeriod());
			model.setReviewEnd(pEntity.getReviewEnd());
			model.setReviewStart(pEntity.getReviewStart());
			model.setEmployeeStatus(pEntity.getEmployeeStatus());
			model.setReviewManager(pEntity.getReviewManager());
			model.setManagerStatus(pEntity.getManagerStatus());
			model.setReviwerStatus(pEntity.getReviwerStatus());
			model.setReviwerComment(pEntity.getReviwerComment());
			model.setReviwerRating(pEntity.getReviwerRating());
			model.setReviwercompletedDate(pEntity.getReviwercompletedDate());
			model.setReviwerName(pEntity.getReviewerName());
			// set the questions
			List<GoalQuestionAnsReview> qList = new ArrayList<>();
			for (PerformanceQuesAnsReview prfmanceEntity : pEntity.getGoalQuestionsAnsReview()) {

				GoalQuestionAnsReview gqr = new GoalQuestionAnsReview();
				gqr.setEmployeeAnswer(prfmanceEntity.getEmployeeAnswer());
				gqr.setEmployeeReview(prfmanceEntity.getEmployeeReview());
				gqr.setQuestionId(prfmanceEntity.getQuestionId());
				gqr.setManagerAnswer(prfmanceEntity.getManagerAnswer());
				gqr.setQuestion(prfmanceEntity.getQuestion());
				gqr.setManagerReview(prfmanceEntity.getManagerReview());
				gqr.setReviwerReview(prfmanceEntity.getReviwerReview());
				gqr.setReviwerAnswer(prfmanceEntity.getReviwerAnswer());

				qList.add(gqr);
			}
			model.setGoalQuestionsDto(qList);
			list.add(model);
			return list;
		} else {
			// if the employee record is not there in the Performance Table
			// we have to get the data from the goal repository
			GoalCreation goalEntity = goalCreationRepository.findByEmployeeId(employeeId);
			if (goalEntity == null) {
				return list;
			}
			model.setAssignDate(goalEntity.getAssignDate());
			model.setDepartmentName(goalEntity.getDepartmentName());
			model.setDueDate(goalEntity.getDueDate());
			model.setEmployeeId(goalEntity.getEmployeeId());
			model.setPeriod(goalEntity.getPeriod());
			model.setEmployeeName(goalEntity.getEmployeeName());
			model.setReviewEnd(goalEntity.getReviewEnd());
			model.setReviewStart(goalEntity.getReviewStart());
			model.setReviewManager(goalEntity.getReviewManager());
			model.setEmployeeStatus(Constants.EMP_INPROGRESS);
			model.setManagerStatus(Constants.MANAGER_INPROGRESS);
			model.setReviwerStatus(Constants.REV_INPROGRESS);
			// set the questions
			List<GoalQuestionAnsReview> qList = new ArrayList<>();
			for (GoalQuestions prfmanceEntity : goalEntity.getGoalQuestions()) {

				GoalQuestionAnsReview gqr = new GoalQuestionAnsReview();
				gqr.setQuestionId(prfmanceEntity.getQuestionId());
				gqr.setQuestion(prfmanceEntity.getQuestion());
				qList.add(gqr);
			}
			model.setGoalQuestionsDto(qList);
			list.add(model);
			return list;
		}
	}

	// here employee final submit his status (Employee agreed)

	@Override
	public List<EntityDTO> saveAndUpdatePerformanceByEmployeeFinalSubmit(PerformanceDTO model) {

		// call this method when Employee wants to insert the form or update the form
		List<EntityDTO> list = new ArrayList<>();
		Performance employeeInPerformance = performanceRepository.findByEmployeeId(model.getEmployeeId());
		if (employeeInPerformance == null) {

			// employee only fill his related details and submit the form
			return employeeFillForFinalSubmission(model, list);

		} else {

			// if the employee is already exist then update the employeeAnswers in
			// performance table
			// employee only fill his related details and submit the form
			return employeeAlreadyExistInPerformance(model, list, employeeInPerformance);
		}
	}

	private List<EntityDTO> employeeAlreadyExistInPerformance(PerformanceDTO model, List<EntityDTO> list,
			Performance employeeInPerformance) {
		employeeInPerformance.setDepartmentName(model.getDepartmentName());
		employeeInPerformance.setAssignDate(model.getAssignDate());
		employeeInPerformance.setEmployeeId(model.getEmployeeId());
		employeeInPerformance.setEmployeeName(model.getEmployeeName());
		employeeInPerformance.setDueDate(model.getDueDate());
		employeeInPerformance.setPeriod(model.getPeriod());
		employeeInPerformance.setReviewStart(model.getReviewStart());
		employeeInPerformance.setReviewEnd(model.getReviewEnd());
		employeeInPerformance.setReviwerComment(model.getReviwerComment());
		employeeInPerformance.setReviwerRating(model.getReviwerRating());
		employeeInPerformance.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in Goals table");
			return list;
		}

		if (!model.getTempSave().equals(Boolean.TRUE)) {
			employeeInPerformance.setEmployeeStatus(Constants.IN_PROGRASS);
			employeeInPerformance.setManagerStatus(Constants.MANAGER_REVIEWED);
			goal.setStatus(Constants.IN_PROGRASS);
		} else {
			employeeInPerformance.setEmployeeStatus(Constants.COMPLETED);
			employeeInPerformance.setManagerStatus(Constants.MANAGER_REVIEWED);
			goal.setStatus(Constants.COMPLETED);
		}
		goalCreationRepository.save(goal);

		// update the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {
			for (PerformanceQuesAnsReview goalQuestionsAnsReview : employeeInPerformance.getGoalQuestionsAnsReview()) {
				if (goalQuestionAnsReview.getQuestionId().equals(goalQuestionsAnsReview.getQuestionId())) {
					goalQuestionsAnsReview.setEmployeeReview(goalQuestionAnsReview.getEmployeeReview());
					goalQuestionsAnsReview.setQuestion(goalQuestionAnsReview.getQuestion());
					goalQuestionsAnsReview.setEmployeeAnswer(goalQuestionAnsReview.getEmployeeAnswer());
					qarlist.add(goalQuestionsAnsReview);
				}
			}
		}
		employeeInPerformance.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(employeeInPerformance);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	private List<EntityDTO> employeeFillForFinalSubmission(PerformanceDTO model, List<EntityDTO> list) {
		Performance performanceEntity = new Performance();
		performanceEntity.setAssignDate(model.getAssignDate());
		performanceEntity.setDepartmentName(model.getDepartmentName());
		performanceEntity.setPeriod(model.getPeriod());
		performanceEntity.setDueDate(model.getDueDate());
		performanceEntity.setEmployeeId(model.getEmployeeId());
		performanceEntity.setEmployeeName(model.getEmployeeName());
		performanceEntity.setReviewEnd(model.getReviewEnd());
		performanceEntity.setReviewStart(model.getReviewStart());
		performanceEntity.setReviwerComment(model.getReviwerComment());
		performanceEntity.setReviwerRating(model.getReviwerRating());
		performanceEntity.setReviwercompletedDate(model.getReviwercompletedDate());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in goals table");
			return list;
		}

		if (!model.getTempSave().equals(Boolean.TRUE)) {
			performanceEntity.setEmployeeStatus(Constants.COMPLETED);
			performanceEntity.setManagerStatus(Constants.MANAGER_REVIEWED);
			goal.setStatus(Constants.COMPLETED);
		} else {
			performanceEntity.setEmployeeStatus(Constants.IN_PROGRASS);
			performanceEntity.setManagerStatus(Constants.MANAGER_REVIEWED);
			goal.setStatus(Constants.IN_PROGRASS);
		}
		goalCreationRepository.save(goal);

		// set the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {

			PerformanceQuesAnsReview qarEntity = new PerformanceQuesAnsReview();
			qarEntity.setQuestion(goalQuestionAnsReview.getQuestion());
			qarEntity.setQuestionId(goalQuestionAnsReview.getQuestionId());
			qarEntity.setEmployeeReview(goalQuestionAnsReview.getEmployeeReview());
			qarEntity.setEmployeeAnswer(goalQuestionAnsReview.getEmployeeAnswer());
			qarlist.add(qarEntity);
		}
		performanceEntity.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(performanceEntity);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}

	// manager give review and update the form
	@Override
	public List<EntityDTO> saveAndUpdatePerformanceByReviewer(PerformanceDTO model) {

		// call this method when manager wants to insert the form or update the form
		List<EntityDTO> list = new ArrayList<>();
		Performance employeeInPerformance = performanceRepository.findByEmployeeId(model.getEmployeeId());

		// if the employee is already exist then update the employeeAnswers in
		// performance table
		// employee only fill his related details and submit the form
		return hrFilledData(model, list, employeeInPerformance);
	}

	// refracted method
	private List<EntityDTO> hrFilledData(PerformanceDTO model, List<EntityDTO> list,
			Performance employeeInPerformance) {
		employeeInPerformance.setAssignDate(model.getAssignDate());
		employeeInPerformance.setDepartmentName(model.getDepartmentName());
		employeeInPerformance.setEmployeeId(model.getEmployeeId());
		employeeInPerformance.setEmployeeName(model.getEmployeeName());
		employeeInPerformance.setPeriod(model.getPeriod());
		employeeInPerformance.setDueDate(model.getDueDate());
		employeeInPerformance.setReviewEnd(model.getReviewEnd());
		employeeInPerformance.setReviewStart(model.getReviewStart());
		employeeInPerformance.setReviewManager(model.getReviewManager());
		employeeInPerformance.setReviwerComment(model.getReviwerComment());
		employeeInPerformance.setReviwerRating(model.getReviwerRating());
		employeeInPerformance.setReviwercompletedDate(model.getReviwercompletedDate());
		EmployeeManagerDTO findByEmpId = employeeRepo.findByEmpId(model.getReviewerId());
		employeeInPerformance.setReviewerName(findByEmpId.getEmpFirstName() + " " + findByEmpId.getEmpLastName());

		// changing the status in goal creation
		GoalCreation goal = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (goal == null) {
			logger.info("Goal is not found in goal table");
			return list;
		}
		if (model.getTempSave().equals(Boolean.TRUE)) {
			employeeInPerformance.setReviwerStatus(Constants.REV_INPROGRESS);
			goal.setStatus(Constants.REV_INPROGRESS);
		} else {
			employeeInPerformance.setReviwerStatus(Constants.REV_REVIEWED);
			goal.setStatus(Constants.REV_REVIEWED);
		}
		goalCreationRepository.save(goal);

		/*
		 * employeeInPerformance.setHrFinalComment(model.getHrFinalComment());
		 * employeeInPerformance.setHrCompletedDate(model.getHrCompletedDate());
		 * employeeInPerformance.setHrFinalRating(model.getHrFinalRating());
		 */
		// update the questions and answers
		List<PerformanceQuesAnsReview> qarlist = new ArrayList<>();
		for (GoalQuestionAnsReview goalQuestionAnsReview : model.getGoalQuestionsDto()) {
			for (PerformanceQuesAnsReview goalQuestionsAnsReview : employeeInPerformance.getGoalQuestionsAnsReview()) {
				if (goalQuestionAnsReview.getQuestionId().equals(goalQuestionsAnsReview.getQuestionId())) {
					goalQuestionsAnsReview.setManagerAnswer(goalQuestionAnsReview.getManagerAnswer());
					goalQuestionsAnsReview.setManagerReview(goalQuestionAnsReview.getManagerReview());
					goalQuestionsAnsReview.setEmployeeAnswer(goalQuestionAnsReview.getEmployeeAnswer());
					goalQuestionsAnsReview.setEmployeeReview(goalQuestionAnsReview.getEmployeeReview());
					goalQuestionsAnsReview.setReviwerAnswer(goalQuestionAnsReview.getReviwerAnswer());
					goalQuestionsAnsReview.setReviwerReview(goalQuestionAnsReview.getReviwerReview());
					goalQuestionsAnsReview.setQuestion(goalQuestionAnsReview.getQuestion());
					qarlist.add(goalQuestionsAnsReview);
				}
			}
		}
		employeeInPerformance.setGoalQuestionsAnsReview(qarlist);
		Performance save = performanceRepository.save(employeeInPerformance);

		EntityDTO response = new EntityDTO();
		response.setId(save.getPerfomanceId());
		list.add(response);
		return list;
	}
}
