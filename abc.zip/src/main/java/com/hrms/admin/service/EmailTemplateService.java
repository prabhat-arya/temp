package com.hrms.admin.service;

import java.io.IOException;
import java.security.Principal;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import com.hrms.admin.dto.EmailTemplateDTO;
import com.hrms.admin.dto.EntityDTO;

public interface EmailTemplateService {
	
	public List<EntityDTO> saveTemplate(EmailTemplateDTO emailTemplateDto,Principal principal,Long empId,String companyId) throws IOException, SerialException, SQLException;

	public List<EntityDTO> updateByEmpId(EmailTemplateDTO model, Long empId,String templateName) throws SerialException, SQLException;

	EmailTemplateDTO getEmailTemplateByEmpId(Long empId, String templateName) throws SQLException;

}
