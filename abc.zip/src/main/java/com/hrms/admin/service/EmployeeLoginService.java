package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.role.dto.EmployeeIdsDTO;

public interface EmployeeLoginService {

	
	    public Employee getUserByUserName(String name) ;

		public Employee createPasswordResetTokenForUser(String userName);

		public List<EntityDTO> validatetTokenAndSavePassword(String newPassword,String confirmPassword,String token);

		public String findtoken(String token);

		public void increaseFailedAttempts(String username);

		public void unlockEmployeeEveryDay();

		public void unlockEmployee(EmployeeIdsDTO employeeIdsDTO);
		
		public List<EntityDTO> resetPassword(String newPassword,String confirmPassword,String oldPassword, String loggedUser);

		public Employee getUserByUserEmail(String email);

		public Employee createForgotPasswordResetToken(String email);

		public EntityDTO validatetTokenAndSavePassword(String token) ;
		
		public void isLockZero(String username);


}
