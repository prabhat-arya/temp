package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.DesignationDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Designation;

public interface DesignationService {

	public DesignationDTO getById(Long id,String companyId);

	public List<EntityDTO> save(DesignationDTO model);

	public List<EntityDTO> updateDesignation(DesignationDTO model);

	public boolean deleteDesignation(Long id);

	public List<DesignationDTO> getDepartmentById(Long id,String companyId);

	public Map<String, Object> getAllDesignation(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String IsActive,String companyId);

	public List<EntityDTO> softDeleteDesignation(Long id);

	public boolean validate(DesignationDTO model, boolean isSave);

	public List<EntityDTO> updateDesignationByStatus(Long id, String status);

	public Designation findByDesignationName(String name, String companyId, Long branchId, Long departmentId);


}
