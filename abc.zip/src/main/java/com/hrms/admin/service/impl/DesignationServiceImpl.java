package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.DesignationDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Department;
import com.hrms.admin.entity.Designation;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.DepartmentRepository;
import com.hrms.admin.repository.Designationrepository;
import com.hrms.admin.service.DesignationService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to perform DB operation on Designation Record
 * 
 * @author {Ramesh}
 *
 */
@Service
public class DesignationServiceImpl implements DesignationService {

	private  static Logger logger = LoggerFactory.getLogger(DesignationServiceImpl.class);

	@Autowired
	private Designationrepository designrepo;

	@Autowired
	private DepartmentRepository departmentRepo;

	@Autowired
	private BranchRepository branchRepo;

	@Autowired
	private CompanyRepository companyRepo;

	/**
	 * Returns Designation data when designation data is available in database by id
	 * 
	 * @param id - Designation Id
	 * @return - DesignationModel
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public DesignationDTO getById(Long id,String companyId) {

		Optional<Designation> designation = designrepo.findById(id,companyId);

		if (designation.isPresent()) {
			Designation entity = designation.get();
			DesignationDTO model = new DesignationDTO();
			model.setId(entity.getId());
			model.setDesignation(entity.getDesignation());
			model.setSkills(entity.getSkills());
			model.setExperiance(entity.getExperiance());
			model.setDepartmentId(entity.getDepartment().getId());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchName(entity.getBranch().getName());
			model.setBranchId(entity.getBranch().getId());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setBand(entity.getBand());
			logger.info("Designation found with id:{}",id);
			return model;
		}
		logger.info("Designation not found in DB with id:{}",id);
		return null;
	}

	/**
	 * Returns true when new Designation is store in database
	 * 
	 * @param model - new designation data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(DesignationDTO model) {

		Designation entity = new Designation();
		entity.setDesignation(model.getDesignation());
		entity.setSkills(model.getSkills());
		entity.setExperiance(model.getExperiance());
		
		entity.setBand(model.getBand());
		Department department;
		Optional<Department> findByIdDepartmentId = departmentRepo.findById(model.getDepartmentId());		 
		 if (findByIdDepartmentId.isPresent()) {
			 department= findByIdDepartmentId.get();
			 entity.setDepartment(department);			
		}
		 Company company ;
		 Optional<Company> findByIdCompanyId = companyRepo.findById(model.getCompanyId());
		 if (findByIdCompanyId.isPresent()) {
			 company=findByIdCompanyId.get();
			 entity.setCompany(company);			
		}
		Branch branch = new Branch();
		branch.setId(model.getBranchId());
		entity.setBranch(branch);

		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		Designation d = designrepo.save(entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(d.getId());
		dto.setName(d.getDesignation());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	/**
	 * Returns true when existing designation data is store in database
	 * 
	 * @param model - new designation data
	 * @param id    - designation Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateDesignation(DesignationDTO model) {
		Optional<Designation> findById = designrepo.findById(model.getId());
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Designation olddesignationEntity = findById.get();
			olddesignationEntity.setDesignation(model.getDesignation());
			olddesignationEntity.setSkills(model.getSkills());
			olddesignationEntity.setExperiance(model.getExperiance());

			olddesignationEntity.setBand(model.getBand());
			Department department;
			Optional<Department> findByDepartmentId = departmentRepo.findById(model.getDepartmentId());
			if (findByDepartmentId.isPresent()) {
				department=findByDepartmentId.get();
				olddesignationEntity.setDepartment(department);				
			}
			Branch branch;
			Optional<Branch> findByBranchId = branchRepo.findById(model.getBranchId());
			if (findByBranchId.isPresent()) {
				branch=findByBranchId.get();
				olddesignationEntity.setBranch(branch);			
			}
			
			Company company;
			Optional<Company> findByCompanyId = companyRepo.findById(model.getCompanyId());
			if (findByCompanyId.isPresent()) {
				company=findByCompanyId.get();
				olddesignationEntity.setCompany(company);				
			}

			Designation d = designrepo.save(olddesignationEntity);
			logger.info("Designation record is updated in to database with id:{}",model.getId());
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getDesignation());
			list.add(dto);
			return list;
		}
		logger.info("Designation is failed to updated in database with id:{}",model.getId());
		return list;
	}

	/**
	 * Returns true when Designation data is deleted from database by id
	 * 
	 * @param id - designation id
	 * @return - boolean
	 */
	@Override
	public boolean deleteDesignation(Long id) {
		designrepo.deleteById(id);
		logger.info("Designation record is deleted from database");
		return true;
	}

	/**
	 * @param Designation Entity
	 * @return - page size
	 */
	public static Map<String, Object> mapData(Page<DesignationDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<DesignationDTO> designationModels = pagedResult.stream().map(entity -> {
			DesignationDTO model = new DesignationDTO();
			model.setId(entity.getId());
			model.setDesignation(entity.getDesignation());
			model.setSkills(entity.getSkills());
			model.setExperiance(entity.getExperiance());
			model.setDepartmentId(entity.getDepartmentId());
			model.setDepartmentName(entity.getDepartmentName());
			model.setBand(entity.getBand());
			model.setBranchId(entity.getBranchId());
			model.setBranchName(entity.getBranchName());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompanyName());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, designationModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("Designation map object is created for Paging");
		return response;
	}

	/**
	 * @param Designation Entity
	 * @return - page size
	 */

	@Override
	public Map<String, Object> getAllDesignation(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<DesignationDTO> pagedResult = null;
		Boolean status = true;
		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = designrepo.allDesignationPage(searchKey,companyId,status, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = designrepo.designationPage(searchKey,companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * @param id,
	 * @return - List of Designation based on DesignationId
	 */

	@Override
	@Cacheable(value = "getDepartmentById", unless = "#result == null", key = "#id")
	public List<DesignationDTO> getDepartmentById(Long id,String companyId) {
		List<Designation> a = designrepo.findDepartmentByCompanyId(id,companyId);
		logger.info("Designation found from Database based on Department id:{}",id);
		List<DesignationDTO> models = a.stream().map(entity -> {

			DesignationDTO model = new DesignationDTO();
			model.setId(entity.getId());
			model.setDesignation(entity.getDesignation());
			model.setBranchId(entity.getBranch().getId());
			model.setBranchName(entity.getBranch().getName());
			model.setCompanyId(entity.getCompany().getId());
			model.setBranchId(entity.getBranch().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setDepartmentId(entity.getDepartment().getId());
			model.setDesignation(entity.getDesignation());
			model.setExperiance(entity.getExperiance());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			model.setSkills(entity.getSkills());
			model.setDepartmentName(entity.getDepartment().getName());
			model.setBand(entity.getBand());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * @param id -Designation,
	 * @return - change value from database isDisable is true
	 */

	public List<EntityDTO> softDeleteDesignation(Long id) {
		Optional<Designation> findById = designrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Designation designation = findById.get();
			designation.setIsDelete(Boolean.TRUE);
			designation.setIsActive(Boolean.FALSE);
			Designation p = designrepo.save(designation);
			logger.info("Designation is SoftDeleted in database with Id:{}",id);
			EntityDTO dto = new EntityDTO();
			dto.setId(p.getId());
			dto.setName(p.getDesignation());
			list.add(dto);
			return list;
		}
		logger.info("Designation is not soft deleted in database with Id:{}",id);
		return list;

	}

	/**
	 * @param DesignationDTO,
	 *  @param boolean value,
	 * @return -  if record exit return true or if record not exit  return false
	 */
	
	@Override
	public boolean validate(DesignationDTO model, boolean isSave) {
		Long count;
		if (isSave) 
			count = designrepo.getDesignationCountForSave(model.getDesignation(), model.getDepartmentId(),
					model.getCompanyId(), model.getBranchId());
		else
			count = designrepo.getDesignationCountForUpdate(model.getDesignation(), model.getDepartmentId(),
					model.getCompanyId(), model.getBranchId(), model.getId());
		return count > 0;
	}

	/**
	 * @param Designation id,
	 * @param String,
	 * @return - if record is updateAttendanceByStatus based on Designation id
	 */

	

	public List<EntityDTO> updateDesignationByStatus(Long id, String status) {
		Optional<Designation> findById = designrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Designation a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Designation e = designrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getDesignation());
				list.add(dto);
				logger.info("Designation is activated in database with Id:{}",id);
				return list;
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Designation e = designrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getDesignation());
				list.add(dto);
				logger.info("Designation is deactivated in database with Id:{}",id);
				return list;
			}
		}
		logger.info("Designation failed to activated or deactivate in DB with Id:{}",id);
		return list;
	}

	/**
	 * @param String DesignationName , * @param Long companyId
	 * @return - Designation based on Designation
	 */
	@Override
	public Designation findByDesignationName(String name, String companyId, Long branchId, Long departmentId) {
		return designrepo.findBydesignationName(name, companyId, branchId, departmentId);
	}
}
