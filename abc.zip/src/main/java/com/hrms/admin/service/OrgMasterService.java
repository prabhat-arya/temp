/*
 * package com.hrms.admin.service;
 * 
 * import java.util.Map;
 * 
 * import com.hrms.admin.dto.OrgMasterDTO;
 * 
 * public interface OrgMasterService {
 * 
 * public Map<String,String> save(OrgMasterDTO model);
 * 
 * 
 * public List<OrgMaster> getAll();
 * 
 * boolean validate(OrgMasterDTO model, boolean isSave); boolean
 * validateEmail(OrgMasterDTO model, boolean isSave);
 * 
 * }
 */