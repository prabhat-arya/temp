package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ShiftDTO;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Shift;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.ShiftRepository;
import com.hrms.admin.service.ShiftService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.StringToDateUtility;

@Service
public class ShiftServiceImpl implements ShiftService {

	private static final Logger logger = LoggerFactory.getLogger(ShiftServiceImpl.class);

	@Autowired
	private ShiftRepository repo;

	@Autowired
	private StringToDateUtility util;

	@Autowired
	private CompanyRepository companyRepository;

	ObjectMapper mapper = new ObjectMapper();

	@Override
	public List<EntityDTO> save(ShiftDTO model) throws Exception {
		Shift entity = new Shift();
		Optional<Company> findById = companyRepository.findById(model.getCompanyId());
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			logger.error("Company is not Found in DB with the CompanyId:{}", model.getCompanyId());
			EntityDTO dto = new EntityDTO();
			dto.setCompanyId(model.getCompanyId());
			dto.setName("is not Exist");
			list.add(dto);
			return list;
		}
		Company company = findById.get();
		entity.setShiftName(model.getShiftName());
		entity.setCompany(company);
		entity.setInTime(model.getInTime());
		entity.setOutTime(model.getOutTime());
		entity.setAllowanceApplicable(model.getAllowanceApplicable());
		if (model.getAllowanceApplicable().equals(Boolean.TRUE)) {
			if (model.getAllowanceAmount() < 1) {
				EntityDTO dto = new EntityDTO();
				dto.setName("Allowance Amount");
				list.add(dto);
				return list;
			}
			entity.setAllowanceAmount(util.roundTwoDecimalsInPercentage(model.getAllowanceAmount()));
		}else {
			entity.setAllowanceAmount(model.getAllowanceAmount());
		}
		String weekoff = mapper.writeValueAsString(model.getWeekofDays());
		entity.setWeekend(weekoff);
		entity.setIsActive(Boolean.TRUE);
		entity.setIsDelete(Boolean.FALSE);
		entity.setType(model.getType());
		Shift a = repo.save(entity);
		logger.info("Shift Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(a.getId());
		dto.setName(a.getShiftName());
		list.add(dto);
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public ShiftDTO getById(Long id, String companyId) throws Exception {
		Optional<Shift> optionalEntity = repo.findShiftById(id, companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Shift entity = optionalEntity.get();
		ShiftDTO model = new ShiftDTO();
		model.setId(entity.getId());
		model.setCompanyName(entity.getCompany().getName());
		model.setShiftName(entity.getShiftName());
		model.setCompanyId(entity.getCompany().getId());
		Map<String, List<Integer>> map = mapper.readValue(entity.getWeekend(), Map.class);
		model.setWeekofDays(map);
		model.setInTime(entity.getInTime());
		model.setOutTime(entity.getOutTime());
		model.setIsDelete(entity.getIsDelete());
		model.setIsActive(entity.getIsActive());
		model.setType(entity.getType());
		model.setAllowanceAmount(entity.getAllowanceAmount());
		model.setAllowanceApplicable(entity.getAllowanceApplicable());
		logger.info("Shift found in DB with Id:{}", id);
		return model;
	}

	@Override
	public List<EntityDTO> updateShift(ShiftDTO model, Long id) throws Exception {
		Optional<Shift> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Shift oldShift = findById.get();
			oldShift.setInTime(model.getInTime());
			oldShift.setOutTime(model.getOutTime());
			oldShift.setShiftName(model.getShiftName());
			String weekoff = mapper.writeValueAsString(model.getWeekofDays());
			oldShift.setWeekend(weekoff);
			oldShift.setType(model.getType());
			oldShift.setAllowanceApplicable(model.getAllowanceApplicable());
			if (model.getAllowanceApplicable().equals(Boolean.TRUE)) {
				if (model.getAllowanceAmount() < 1) {
					EntityDTO dto = new EntityDTO();
					dto.setName("Allowance Amount");
					list.add(dto);
					return list;
				}
				oldShift.setAllowanceAmount(util.roundTwoDecimalsInPercentage(model.getAllowanceAmount()));
			}else {
				oldShift.setAllowanceAmount(model.getAllowanceAmount());
			}
			Shift s = repo.save(oldShift);
			logger.info("Shift  updated in to database");
			EntityDTO dto = new EntityDTO();
			dto.setId(s.getId());
			dto.setName(s.getShiftName());
			list.add(dto);
			return list;
		} else {
			return list;
		}
	}

	@Override
	public List<EntityDTO> softDeleteShift(Long id) {
		Optional<Shift> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Shift shift = findById.get();
		shift.setIsActive(Boolean.FALSE);
		shift.setIsDelete(Boolean.TRUE);
		Shift s = repo.save(shift);
		logger.info("Shift SoftDeleted from database");
		EntityDTO dto = new EntityDTO();
		dto.setId(s.getId());
		list.add(dto);
		return list;
	}

	@Override
	public boolean validate(ShiftDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getShiftCount(model.getShiftName(), model.getCompanyId());

		else
			count = repo.getUpdateShiftCount(model.getShiftName(), model.getId(), model.getCompanyId());
		return count > 0;
	}

	@Override
	public List<EntityDTO> updateShiftByStatus(Long id, String status) {
		Optional<Shift> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		} else {
			Shift a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Shift s = repo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(s.getId());
				dto.setName(s.getShiftName());
				list.add(dto);
				logger.info("Shift  activated in database");
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Shift s = repo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(s.getId());
				dto.setName(s.getShiftName());
				list.add(dto);
				logger.info("Shift  deactivated in database");
			}
			return list;
		}
	}

	@Override
	@Cacheable(value = "findAll", unless = "#result == null", key = "#companyId")
	public List<ShiftDTO> findAll(String companyId) {
		List<Shift> a = repo.findByCompany(companyId);
		logger.info("Shift  found  in DB with companyId:{}", companyId);
		List<ShiftDTO> models;
		models = a.stream().map(entity -> {
			ShiftDTO model = new ShiftDTO();
			model.setId(entity.getId());
			model.setShiftName(entity.getShiftName());
			model.setCompanyName(entity.getCompany().getName());
			model.setCompanyId(entity.getCompany().getId());
			model.setInTime(entity.getInTime());
			model.setOutTime(entity.getOutTime());
			model.setIsDelete(entity.getIsDelete());
			model.setType(entity.getType());
			model.setIsActive(entity.getIsActive());
			model.setAllowanceApplicable(entity.getAllowanceApplicable());
			model.setAllowanceAmount(entity.getAllowanceAmount());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	@Override
	public Map<String, Object> getAllShift(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Shift> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = repo.allShiftPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = repo.shiftPage(searchKey, companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Shift Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapData(Page<Shift> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<ShiftDTO> shiftModels = pagedResult.stream().map(entity -> {
			ShiftDTO model = new ShiftDTO();
			model.setId(entity.getId());
			model.setShiftName(entity.getShiftName());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setType(entity.getType());
			model.setInTime(entity.getInTime());
			model.setOutTime(entity.getOutTime());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setAllowanceApplicable(entity.getAllowanceApplicable());
			model.setAllowanceAmount(entity.getAllowanceAmount());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, shiftModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

}
