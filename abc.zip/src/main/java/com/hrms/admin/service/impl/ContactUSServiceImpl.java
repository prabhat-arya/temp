package com.hrms.admin.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.ContactUSDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.ContactUS;
import com.hrms.admin.repository.ContactUSRepository;
import com.hrms.admin.service.ContactUSService;

@Service
public class ContactUSServiceImpl implements ContactUSService{
	
	@Autowired
	private ContactUSRepository contactRepo;

	@Override
	public EntityDTO save(ContactUSDTO model) {
		
		ContactUS contactUs = new ContactUS();
		contactUs.setEmail(model.getEmail());
		contactUs.setFirstName(model.getFirstName());
		contactUs.setIsDelete(Boolean.FALSE);
		contactUs.setLastName(model.getLastName());
		contactUs.setMessage(model.getMessage());
		contactUs.setPhoneNumber(model.getPhoneNumber());
		contactUs.setStatus(Boolean.TRUE);
		ContactUS contact2 = contactRepo.save(contactUs);
		
		EntityDTO dto = new EntityDTO();
		dto.setId(contact2.getId());
		dto.setName(contact2.getFirstName());
		return dto;
		
	}

}
