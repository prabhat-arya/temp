package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.EmployeeExitMgmtDTO;
import com.hrms.admin.dto.EmployeeExitMgmtShowDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ExitMgmtQuestionAnswersDTO;
import com.hrms.admin.dto.ObjectiveQuestions;
import com.hrms.admin.dto.QuestionsDTO;
import com.hrms.admin.dto.ResignationDTO;
import com.hrms.admin.dto.SubjectiveQuestions;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeExitMgmt;
import com.hrms.admin.entity.ExitFeedback;
import com.hrms.admin.entity.ExitMgmtQuestionAnswers;
import com.hrms.admin.entity.Questions;
import com.hrms.admin.entity.Resignation;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.EmployeeExitMgmtRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ExitFeedbackRepository;
import com.hrms.admin.repository.QuestionsRepository;
import com.hrms.admin.repository.ResignationRepository;
import com.hrms.admin.service.EmployeeExitService;
import com.hrms.admin.service.ExitFeedbackService;
import com.hrms.admin.util.Constants;

@Service
public class EmployeeExitServiceImpl implements EmployeeExitService {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeExitServiceImpl.class);

	@Autowired
	private EmployeeExitMgmtRepository employeeExitMgmtRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private CompanyRepository companyRepo;
	@Autowired
	private QuestionsRepository questionRepository;

	@Autowired
	private ExitFeedbackService exitFeedbackService;

	@Autowired
	private ExitFeedbackRepository exitFeedbackRepository;

	@Autowired
	private ResignationRepository resignationRepo;

	ObjectMapper mapper = new ObjectMapper();

	@Override
	public List<EntityDTO> saveAndUpdateEmployeeExit(EmployeeExitMgmtDTO model) {

		List<EntityDTO> list = new ArrayList<>();
		EmployeeExitMgmt employeeExitMgmt = employeeExitMgmtRepository.findByEmployeeId(model.getEmployeeId());

		if (employeeExitMgmt == null) {

			// for the first time new employee saved
			EmployeeExitMgmt newEmployeeExitMgmt = new EmployeeExitMgmt();

			newEmployeeExitMgmt.setEmployeeId(model.getEmployeeId());
			newEmployeeExitMgmt.setHireDate(model.getHireDate());
			newEmployeeExitMgmt.setLastWorkingDate(model.getLastWorkingDate());
			newEmployeeExitMgmt.setEmployeeName(model.getEmployeeName());
			newEmployeeExitMgmt.setStatus(Constants.IN_PROGRASS);
			List<ExitMgmtQuestionAnswers> questAnsSet = new ArrayList<>();
			for (ExitMgmtQuestionAnswersDTO qdto : model.getQuestionAnswers()) {
				ExitMgmtQuestionAnswers entity = new ExitMgmtQuestionAnswers();

				entity.setQuestionId(qdto.getQuestionId());
				// to set the radio Question and answer
				if ((qdto.getBoxQuestion() == null || qdto.getBoxQuestion().isEmpty())
						&& (qdto.getBoxAnswers() == null || qdto.getBoxAnswers().isEmpty())
						&& (qdto.getRadioQuestion() == null || qdto.getRadioQuestion().isEmpty())
						&& (qdto.getRadioAnswers() == 0)) {
					// to save only the comment
					entity.setRadioQuestionComment(qdto.getRadioQuestionComment());
					entity.setRadioAnswers(qdto.getRadioAnswers());
				}

				if ((qdto.getRadioQuestion() == null || qdto.getRadioQuestion().isEmpty())
						&& (qdto.getRadioAnswers() == 0)
						&& (qdto.getRadioQuestionComment() == null || qdto.getRadioQuestionComment().isEmpty())) {

					// to save the Box Answers and and questions
					entity.setBoxQuestion(qdto.getBoxQuestion());
					entity.setBoxAnswers(qdto.getBoxAnswers());
					entity.setRadioAnswers(qdto.getRadioAnswers());

				}
				if ((qdto.getBoxQuestion() == null || qdto.getBoxQuestion().isEmpty())
						&& (qdto.getBoxAnswers() == null || qdto.getBoxAnswers().isEmpty())
						&& (qdto.getRadioQuestionComment() == null || qdto.getRadioQuestionComment().isEmpty())) {

					entity.setRadioQuestion(qdto.getRadioQuestion());

					entity.setRadioAnswers(qdto.getRadioAnswers());
				}
				questAnsSet.add(entity);

			}
			Comparator<ExitMgmtQuestionAnswers> comparator = (ExitMgmtQuestionAnswers e1,
					ExitMgmtQuestionAnswers e2) -> e1.getQuestionId().compareTo(e2.getQuestionId());
			Collections.sort(questAnsSet, comparator);
			newEmployeeExitMgmt.setQuestionAnswers(questAnsSet);
			EmployeeExitMgmt exitMgmtSave = employeeExitMgmtRepository.save(newEmployeeExitMgmt);

			EntityDTO dto = new EntityDTO();
			dto.setId(exitMgmtSave.getEmployeeExitId());
			list.add(dto);
			logger.info("Employee Exit form is saved in DB");
			return list;

		} else {

			// employee is there with given id so we have to (update) the employee Details
			// with the question and answers

			employeeExitMgmt.setHireDate(model.getHireDate());
			employeeExitMgmt.setLastWorkingDate(model.getLastWorkingDate());
			employeeExitMgmt.setEmployeeName(model.getEmployeeName());
			List<ExitMgmtQuestionAnswers> questAnsSet = new ArrayList<>();
			for (ExitMgmtQuestionAnswersDTO qdto : model.getQuestionAnswers()) {
				for (ExitMgmtQuestionAnswers oldQuestions : employeeExitMgmt.getQuestionAnswers()) {
					if (oldQuestions.getQuestionId().equals(qdto.getQuestionId())) {

						// to set the radio Question and answer
						if ((qdto.getBoxQuestion() == null || qdto.getBoxQuestion().isEmpty())
								&& (qdto.getBoxAnswers() == null || qdto.getBoxAnswers().isEmpty())
								&& (qdto.getRadioQuestion() == null || qdto.getRadioQuestion().isEmpty())
								&& qdto.getRadioAnswers() == 0) {
							// to save only the comment
							oldQuestions.setRadioQuestionComment(qdto.getRadioQuestionComment());
						}
						if ((qdto.getRadioQuestion() == null || qdto.getRadioQuestion().isEmpty())
								&& (qdto.getRadioAnswers() == 0) && (qdto.getRadioQuestionComment() == null
										|| qdto.getRadioQuestionComment().isEmpty())) {
							// to save the Box Answers and and questions
							oldQuestions.setBoxQuestion(qdto.getBoxQuestion());
							oldQuestions.setBoxAnswers(qdto.getBoxAnswers());

						}
						if ((qdto.getBoxQuestion() == null || qdto.getBoxQuestion().isEmpty())
								&& (qdto.getBoxAnswers() == null || qdto.getBoxAnswers().isEmpty())
								&& (qdto.getRadioQuestionComment() == null
										|| qdto.getRadioQuestionComment().isEmpty())) {

							oldQuestions.setRadioQuestion(qdto.getRadioQuestion());
							oldQuestions.setRadioAnswers(qdto.getRadioAnswers());
						}
						questAnsSet.add(oldQuestions);
					}
				}

			}
			Comparator<ExitMgmtQuestionAnswers> comparator = (ExitMgmtQuestionAnswers e1,
					ExitMgmtQuestionAnswers e2) -> e1.getQuestionId().compareTo(e2.getQuestionId());
			Collections.sort(questAnsSet, comparator);
			employeeExitMgmt.setQuestionAnswers(questAnsSet);

			// setting the status(If all the feedback is Completed then complete
			// and if any one is inComplete then ExitMgmt of employee is in Progress)
			employeeExitMgmt.setStatus(Constants.COMPLETED);
			List<ExitFeedback> exitLists = exitFeedbackRepository.findByEmployeeExitMgmtId(model.getEmployeeExitId());
			if (!exitLists.isEmpty()) {
				for (ExitFeedback exitFeedback : exitLists) {
					if (exitFeedback.getStatus().equals(Constants.IN_PROGRASS)) {
						employeeExitMgmt.setStatus(Constants.IN_PROGRASS);
					}
				}
			}
			EmployeeExitMgmt exitMgmtSave = employeeExitMgmtRepository.save(employeeExitMgmt);
//			if (exitMgmtSave.getStatus().equals(Constants.COMPLETED)) {
//				Employee emp = employeeRepository.getOne(exitMgmtSave.getEmployeeId());
//				emp.setIsExit(Boolean.TRUE);
//				employeeRepository.save(emp);
//				
//				Resignation resignation = resignationRepo.getByEmployee(exitMgmtSave.getEmployeeId());
//				resignation.setStatus(Constants.COMPLETED);
//				resignationRepo.save(resignation);
//			}
			EntityDTO dto = new EntityDTO();
			dto.setId(exitMgmtSave.getEmployeeExitId());
			logger.info("Employee Exit form data is updated in DB");
			list.add(dto);
			return list;
		}

	}

	@Override
	@Cacheable(value = "findExitFormByEmployeeIdCache", unless = "#result == null", key = "#employeeId")
	public EmployeeExitMgmtShowDTO findExitFormByEmployeeId(Long employeeId, String companyId) {

		EmployeeExitMgmt empExit = employeeExitMgmtRepository.findByEmployeeId(employeeId);
		EmployeeExitMgmtShowDTO model = new EmployeeExitMgmtShowDTO();
		if (empExit == null) {
			// if the employee is not filled the exit form then we have to show the company
			// based questions for that particular employee
			Optional<Employee> employee = employeeRepository.findById(employeeId);
			if (!employee.isPresent()) {
				logger.info("Employee is not found in the Employee Table");
				return null;
			}

			if (employee.get().getCompany().getId() == null) {
				logger.info("Employee does not have any company in DB");
				return null;
			}

			List<Questions> allcustomizeQuestionList = questionRepository.getAllcustomizeQuestionList(companyId);
			List<Questions> questions;
			if (allcustomizeQuestionList.isEmpty()) {
				questions = questionRepository.getAllDeafultQuestionList();
			} else {
				questions = questionRepository.getAllcustomizeQuestionList(companyId);
			}
			// List<Questions> questions = questionRepository.findByCompanyId(companyId);

			if (questions.isEmpty()) {
				return null;
			}
			List<ExitMgmtQuestionAnswersDTO> quesAn = new ArrayList<>();

			for (Questions q : questions) {
				// set the Box Q and A
				if ((q.getObjectiveQuestion() == null || q.getObjectiveQuestion().isEmpty())
						&& (q.getRadioQuestionComment() == null || q.getRadioQuestionComment().isEmpty())) {
					ExitMgmtQuestionAnswersDTO boxQuestion = new ExitMgmtQuestionAnswersDTO();

					boxQuestion.setQuestionId(q.getQuestionId());
					boxQuestion.setBoxQuestion(q.getSubjectiveQuestion());
					quesAn.add(boxQuestion);
				}
				// set Radio Q and A
				if ((q.getSubjectiveQuestion() == null || q.getSubjectiveQuestion().isEmpty())
						&& (q.getRadioQuestionComment() == null || q.getRadioQuestionComment().isEmpty())) {
					ExitMgmtQuestionAnswersDTO radioQuestion = new ExitMgmtQuestionAnswersDTO();
					radioQuestion.setQuestionId(q.getQuestionId());
					radioQuestion.setRadioQuestion(q.getObjectiveQuestion());
					quesAn.add(radioQuestion);
				}
				// set Radio Comment
				if ((q.getSubjectiveQuestion() == null || q.getSubjectiveQuestion().isEmpty())
						&& (q.getObjectiveQuestion() == null || q.getObjectiveQuestion().isEmpty())) {
					ExitMgmtQuestionAnswersDTO comment = new ExitMgmtQuestionAnswersDTO();
					comment.setQuestionId(q.getQuestionId());
					if (q.getRadioQuestionComment() == null) {
						comment.setRadioQuestionComment(
								"What did you think of your supervisor on the following points");
					} else {
						comment.setRadioQuestionComment(q.getRadioQuestionComment());
					}
					quesAn.add(comment);
				}
			}
			Comparator<ExitMgmtQuestionAnswersDTO> comparator = (ExitMgmtQuestionAnswersDTO e1,
					ExitMgmtQuestionAnswersDTO e2) -> e1.getQuestionId().compareTo(e2.getQuestionId());
			Collections.sort(quesAn, comparator);
			model.setQuestionAnswers(quesAn);
			// we need to set the Manager and the department details also here
			Optional<Employee> employee1 = employeeRepository.findById(employeeId);
			if (!employee1.isPresent()) {
				return null;
			}
			model.setDesignation(employee1.get().getDesignation().getDesignation());
			model.setDepartmentId(employee1.get().getDepartment().getId());
			model.setDepartmentName(employee1.get().getDepartment().getName());
			model.setEmployeeName(employee1.get().getFirstName());
			model.setEmployeeId(employee1.get().getId());
			model.setHireDate(employee1.get().getJoiningDate());
			Resignation resignation = resignationRepo.getByEmployee(employee1.get().getId());
			model.setLastWorkingDate(resignation.getTentativeLeavingDate());
			Long managerId = employee1.get().getManager().getId();
			Optional<Employee> manager = employeeRepository.findById(managerId);// finding the manager
			if (!manager.isPresent()) {
				return null;
			}
			model.setManagerId(managerId);
			model.setManagerName(manager.get().getFirstName());
			return model;
		} else {

			// here the employee Already filled the form so we need to show the Filled
			// details of employee

			// we need to set the Manager and the department details also here
			Optional<Employee> employee = employeeRepository.findById(employeeId);
			if (!employee.isPresent()) {
				return null;
			}

			model.setDepartmentId(employee.get().getDepartment().getId());
			model.setDepartmentName(employee.get().getDepartment().getName());
			model.setEmployeeName(employee.get().getFirstName());
			model.setDesignation(employee.get().getDesignation().getDesignation());
			Long managerId = employee.get().getManager().getId();
			Optional<Employee> manager = employeeRepository.findById(managerId);// finding the manager
			if (!manager.isPresent()) {
				return null;
			}
			model.setManagerId(managerId);
			model.setManagerName(manager.get().getFirstName());
			model.setEmployeeExitId(empExit.getEmployeeExitId());
			model.setEmployeeId(empExit.getEmployeeId());
			model.setHireDate(empExit.getHireDate());
			model.setLastWorkingDate(empExit.getLastWorkingDate());
			model.setEmployeeName(empExit.getEmployeeName());
			// set the boxQ for boxQ and RadioQ for RadioQ
			List<ExitMgmtQuestionAnswersDTO> quesAn = new ArrayList<>();
			for (ExitMgmtQuestionAnswers quesAnsEntity : empExit.getQuestionAnswers()) {

				// set Radio Q and A
				if ((quesAnsEntity.getBoxAnswers() == null || quesAnsEntity.getBoxAnswers().isEmpty())
						&& (quesAnsEntity.getBoxQuestion() == null || quesAnsEntity.getBoxQuestion().isEmpty())
						&& (quesAnsEntity.getRadioQuestionComment() == null
								|| quesAnsEntity.getRadioQuestionComment().isEmpty())) {

					ExitMgmtQuestionAnswersDTO radioQAC = new ExitMgmtQuestionAnswersDTO();

					radioQAC.setQuestionId(quesAnsEntity.getQuestionId());
					radioQAC.setRadioQuestion(quesAnsEntity.getRadioQuestion());
					radioQAC.setBoxQuestion("");
					radioQAC.setBoxAnswers("");
					radioQAC.setRadioQuestionComment("");
					radioQAC.setRadioAnswers(quesAnsEntity.getRadioAnswers());

					quesAn.add(radioQAC);
				}
				// set Box Q and A
				if ((quesAnsEntity.getRadioAnswers() == 0)
						&& (quesAnsEntity.getRadioQuestion() == null || quesAnsEntity.getRadioQuestion().isEmpty())
						&& (quesAnsEntity.getRadioQuestionComment() == null
								|| quesAnsEntity.getRadioQuestionComment().isEmpty())) {

					ExitMgmtQuestionAnswersDTO boxQAC = new ExitMgmtQuestionAnswersDTO();

					boxQAC.setQuestionId(quesAnsEntity.getQuestionId());
					boxQAC.setBoxAnswers(quesAnsEntity.getBoxAnswers());
					boxQAC.setBoxQuestion(quesAnsEntity.getBoxQuestion());
					boxQAC.setRadioAnswers(0);
					boxQAC.setRadioQuestion("");
					boxQAC.setRadioQuestionComment("");
					quesAn.add(boxQAC);
				}
				// set comment
				if ((quesAnsEntity.getRadioAnswers() == 0)
						&& (quesAnsEntity.getRadioQuestion() == null || quesAnsEntity.getRadioQuestion().isEmpty())
						&& (quesAnsEntity.getBoxQuestion() == null || quesAnsEntity.getBoxQuestion().isEmpty())
						&& (quesAnsEntity.getBoxAnswers() == null || quesAnsEntity.getBoxAnswers().isEmpty())) {

					ExitMgmtQuestionAnswersDTO radioC = new ExitMgmtQuestionAnswersDTO();
					radioC.setQuestionId(quesAnsEntity.getQuestionId());
					radioC.setRadioQuestionComment(quesAnsEntity.getRadioQuestionComment());
					radioC.setRadioAnswers(0);
					radioC.setBoxAnswers("");
					radioC.setBoxQuestion("");
					radioC.setRadioQuestion("");
					quesAn.add(radioC);
				}
			}
			Comparator<ExitMgmtQuestionAnswersDTO> comparator = (ExitMgmtQuestionAnswersDTO e1,
					ExitMgmtQuestionAnswersDTO e2) -> e1.getQuestionId().compareTo(e2.getQuestionId());
			Collections.sort(quesAn, comparator);
			model.setQuestionAnswers(quesAn);

			return model;
		}
	}

	@Override
	@Cacheable(value = "getAllEmpExitDetailsCache", unless = "#result.size() == 0")
	public List<EmployeeExitMgmtDTO> getAllEmpExitDetails(String companyId) {
		List<EmployeeExitMgmtDTO> list = new ArrayList<>();
		List<EmployeeExitMgmt> findAll = employeeExitMgmtRepository.exitFormPage(companyId);
		if (findAll.isEmpty()) {
			return list;
		}
		List<EmployeeExitMgmtDTO> models = findAll.stream().map(entity -> {
			EmployeeExitMgmtDTO model = new EmployeeExitMgmtDTO();
			model.setEmployeeExitId(entity.getEmployeeExitId());
			model.setEmployeeId(entity.getEmployeeId());
			model.setLastWorkingDate(entity.getLastWorkingDate());
			model.setHireDate(entity.getHireDate());
			model.setEmployeeName(entity.getEmployeeName());

			// here also need to set the Status for EmpExitMgmt if something has changed in
			// Any feedback form
			model.setStatus(Constants.COMPLETED);
			List<ExitFeedback> exitLists = exitFeedbackRepository.findByEmployeeExitMgmtId(entity.getEmployeeExitId());
			if (!exitLists.isEmpty()) {
				for (ExitFeedback exitFeedback : exitLists) {
					if (exitFeedback.getStatus().equals(Constants.IN_PROGRASS)) {
						model.setStatus(Constants.IN_PROGRASS);
					}
				}
			}
			return model;
		}).collect(Collectors.toList());
		logger.info("Found All Employee Exit Details in DB");
		return models;
	}

	// for pagination
	@Override
	public Map<String, Object> getAllEmpExitDetails(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmployeeExitMgmt> pagedResult = null;

		pagedResult = employeeExitMgmtRepository.exitFormPage(companyId, paging);

		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapData(Page<EmployeeExitMgmt> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeExitMgmtDTO> exitModels = pagedResult.stream().map(entity -> {
			EmployeeExitMgmtDTO model = new EmployeeExitMgmtDTO();
			model.setEmployeeExitId(entity.getEmployeeExitId());
			model.setEmployeeId(entity.getEmployeeId());
			model.setLastWorkingDate(entity.getLastWorkingDate());
			model.setHireDate(entity.getHireDate());
			model.setEmployeeName(entity.getEmployeeName());

			// here also need to set the Status for EmpExitMgmt if something has changed in
			// Any feedback form
			model.setStatus(Constants.APPROVED);
			List<ExitFeedback> exitLists = exitFeedbackRepository.findByEmployeeExitMgmtId(entity.getEmployeeExitId());
			if (exitLists.isEmpty()) {
				model.setStatus(Constants.IN_PROGRASS);
			}
			if (!exitLists.isEmpty()) {
				for (ExitFeedback exitFeedback : exitLists) {
					if (exitFeedback.getStatus().equals(Constants.IN_PROGRASS)) {
						model.setStatus(Constants.IN_PROGRASS);
					}
				}
			}
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, exitModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Exit map object is created for Paging");
		return response;
	}

	@Override
	public List<EntityDTO> deleteEmployeeExitRecordByExitId(Long employeeExitId) {

		List<EntityDTO> list = new ArrayList<>();
		Optional<EmployeeExitMgmt> findById = employeeExitMgmtRepository.findById(employeeExitId);
		if (!findById.isPresent()) {
			logger.info("ExitId is not Present in DB");
			return list;
		}
		List<ExitFeedback> feedbackId = exitFeedbackRepository
				.findByEmployeeExitMgmtId(findById.get().getEmployeeExitId());
		if (!feedbackId.isEmpty()) {
			for (ExitFeedback exitFeedback : feedbackId) {
				exitFeedbackService.deleteExitFeedbackBasedOnFeedbackId(exitFeedback.getFeedbackId());
				logger.info("ExitId status is changed in DB");
			}
		}
		employeeExitMgmtRepository.deleteById(employeeExitId);
		logger.info("ExitId is successfully deleted from the DB");
		list.add(new EntityDTO());
		return list;
	}

	@Override
	public List<EntityDTO> saveSubjectiveAndObjectiveQuestion(QuestionsDTO model, String companyId) {
		List<EntityDTO> list = new ArrayList<>();
		List<Questions> questionlist = new ArrayList<>();
		Optional<Company> findById = companyRepo.findById(companyId);
		Company company = null;
		if (findById.isPresent()) {
			company = findById.get();

			List<Questions> objectiveQuestions = questionRepository.findByCompanyId(companyId);
			if (!model.getObjective().isEmpty() && !model.getSubjective().isEmpty()) {
				questionRepository.deleteInBatch(objectiveQuestions);
			}
			if (!model.getObjective().isEmpty()) {

				for (ObjectiveQuestions question : model.getObjective()) {
					Questions questionObj = new Questions();
					Long validateQuestionPostCall = validateQuestionPostCall(question.getObjectiveQuestion(),
							companyId);
					if (validateQuestionPostCall == 0L) {
						questionObj.setCompany(company);
						questionObj.setObjectiveQuestion(question.getObjectiveQuestion());
						questionObj.setIsDefault(Boolean.FALSE);
						questionlist.add(questionObj);
					}
				}
			}
			if (!model.getSubjective().isEmpty()) {

				for (SubjectiveQuestions question : model.getSubjective()) {
					Questions questionObj = new Questions();
					Long validateQuestionPostCall = validateQuestionPostCall(question.getSubjectiveQuestion(),
							companyId);
					if (validateQuestionPostCall == 0L) {
						questionObj.setCompany(company);
						questionObj.setSubjectiveQuestion(question.getSubjectiveQuestion());
						questionObj.setIsDefault(Boolean.FALSE);
						questionlist.add(questionObj);
					}
				}
			}
			questionRepository.saveAll(questionlist);
			logger.info("Questions are added in DB");
			list.add(new EntityDTO());
			return list;
		}

		else {
			return list;
		}
	}

	/**
	 * @param QuestionsDTO,
	 * @param boolean       value,
	 * @return - if record exit return true or if record not exit return false
	 */
	@Override
	public Long validateQuestionPostCall(String question, String companyId) {
		return questionRepository.getQuestionCount(question, companyId);
	}

	@Override
	public Long validateQuestionPutCall(String question, String companyId, Long qId) {
		return questionRepository.getQuestionCountWhileUpdate(question, companyId, qId);
	}

	@Override
	public List<EntityDTO> saveEmployeeResignation(ResignationDTO model) {
		List<EntityDTO> list = new ArrayList<>();
		Resignation resignationEntity = new Resignation();
		Employee emp = employeeRepository.getOne(model.getEmpId());
		resignationEntity.setEmployee(emp.getId());
		resignationEntity.setResignationSubmittedOn(model.getResigSubDate());
		resignationEntity.setTentativeLeavingDate(model.getTentLeaveDate());
		resignationEntity.setReason(model.getReason());
		resignationEntity.setNoticePeriod(model.getNoticePeriod());
		resignationEntity.setDescription(model.getDescription());
		resignationEntity.setStatus(Constants.SUBMITTED);
		resignationEntity.setIsChecked(model.getIsChecked());
		Resignation resignationSave = resignationRepo.save(resignationEntity);
		EntityDTO dto = new EntityDTO();
		dto.setId(resignationSave.getId());
		list.add(dto);
		return list;

	}

	@Override
	public ResignationDTO findResignedEmpByEmployee(Long employeeId) {
		Resignation resignation = resignationRepo.getByEmployee(employeeId);
		Employee emp = employeeRepository.getOne(employeeId);
		ResignationDTO resignationDto = new ResignationDTO();
		resignationDto.setEmpId(resignation.getEmployee());
		resignationDto.setEmpName(emp.getFirstName() + " " + emp.getLastName());
		resignationDto.setResigSubDate(resignation.getResignationSubmittedOn());
		resignationDto.setTentLeaveDate(resignation.getTentativeLeavingDate());
		resignationDto.setStatus(resignation.getStatus());

		resignationDto.setDeptName(emp.getDepartment().getName());
		resignationDto.setDescription(resignation.getDescription());
		resignationDto.setDesignName(emp.getDesignation().getDesignation());
		resignationDto.setNoticePeriod(resignation.getNoticePeriod());
		resignationDto.setReason(resignation.getReason());
		Employee emp1 = employeeRepository.getOne(emp.getManager().getId());
		resignationDto.setReportMngr(emp1.getFirstName()+" "+emp1.getLastName());
		resignationDto.setIsChecked(resignation.getIsChecked());
		resignationDto.setResignationApprovedDate(resignation.getResignationApprovedDate());
		resignationDto.setReasonForReject(resignation.getReasonForReject());
		resignationDto.setReasonForEmpRevoke(resignation.getReasonForEmpRevoke());
		resignationDto.setReasonForManagerRevoke(resignation.getReasonForManagerRevoke());
		resignationDto.setRevokeAppliedDate(resignation.getRevokeAppliedDate());
		return resignationDto;
	}

	@Override
	public QuestionsDTO getAllExitRecordQuestions(String companyId) {
		QuestionsDTO qdto = new QuestionsDTO();
		List<SubjectiveQuestions> defaultSubjective = new ArrayList<>();
		List<ObjectiveQuestions> defaultObjective = new ArrayList<>();
		List<SubjectiveQuestions> Subjective = new ArrayList<>();
		List<ObjectiveQuestions> Objective = new ArrayList<>();
		List<Questions> allDeafultQuestionList = questionRepository.getAllDeafultQuestionList();
		List<Questions> allcustomizeQuestionList = questionRepository.getAllcustomizeQuestionList(companyId);
		for (Questions q : allDeafultQuestionList) {
			if (q.getSubjectiveQuestion() != null) {
				SubjectiveQuestions dto = new SubjectiveQuestions();
				dto.setSubjectiveQuestion(q.getSubjectiveQuestion());
				defaultSubjective.add(dto);
			} else if (q.getObjectiveQuestion() != null) {
				ObjectiveQuestions dto = new ObjectiveQuestions();
				dto.setObjectiveQuestion(q.getObjectiveQuestion());
				defaultObjective.add(dto);
			}
		}
		for (Questions q : allcustomizeQuestionList) {
			if (q.getSubjectiveQuestion() != null) {
				SubjectiveQuestions dto = new SubjectiveQuestions();
				dto.setSubjectiveQuestion(q.getSubjectiveQuestion());
				Subjective.add(dto);
			} else if (q.getObjectiveQuestion() != null) {
				ObjectiveQuestions dto = new ObjectiveQuestions();
				dto.setObjectiveQuestion(q.getObjectiveQuestion());
				Objective.add(dto);
			}
		}

		qdto.setDefaultsubjective(defaultSubjective);
		qdto.setDefaultobjective(defaultObjective);
		qdto.setObjective(Objective);
		qdto.setSubjective(Subjective);
		return qdto;

	}

	@Override
	public Map<String, Object> getAllEmpResignationDetails(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String companyId, Long managerId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Resignation> pagedResult = null;

		pagedResult = resignationRepo.resignationFormPage(companyId,managerId, paging);

		if (pagedResult.hasContent()) {
			return mapData1(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapData1(Page<Resignation> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<ResignationDTO> exitModels = pagedResult.stream().map(entity -> {
			ResignationDTO model = new ResignationDTO();
			model.setEmpId(entity.getEmployee());
			Employee emp = employeeRepository.getOne(entity.getEmployee());
			model.setEmpName(emp.getFirstName() + " " + emp.getLastName());
			model.setResigSubDate(entity.getResignationSubmittedOn());
			model.setTentLeaveDate(entity.getTentativeLeavingDate());
			model.setStatus(entity.getStatus());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, exitModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		logger.info("Resignation map object is created for Paging");
		return response;
	}

	@Override
	public List<EntityDTO> updateEmployeeResignation(@Valid ResignationDTO model) {
		Resignation resignationEntity = resignationRepo.getByEmployee(model.getEmpId());
		List<EntityDTO> list = new ArrayList<>();
		Employee emp = employeeRepository.getOne(model.getEmpId());
		resignationEntity.setEmployee(emp.getId());
		resignationEntity.setTentativeLeavingDate(model.getTentLeaveDate());
		resignationEntity.setNoticePeriod(model.getNoticePeriod());
		resignationEntity.setDescription(resignationEntity.getDescription());
		resignationEntity.setReason(resignationEntity.getReason());
		resignationEntity.setResignationSubmittedOn(resignationEntity.getResignationSubmittedOn());
		resignationEntity.setResignationApprovedDate(model.getResignationApprovedDate());
		if (model.getStatus().equals(Constants.APPROVED)) {
			resignationEntity.setStatus(Constants.EXIT_PROCESS);
		} else if (model.getStatus().equals(Constants.REJECTED)) {
			resignationEntity.setStatus(Constants.REJECTED);
		}
		resignationEntity.setReasonForReject(model.getReasonForReject());
		Resignation resignationSave = resignationRepo.save(resignationEntity);
		EntityDTO dto = new EntityDTO();
		dto.setId(resignationSave.getId());
		list.add(dto);
		return list;

	}

	@Override
	public String getResignationStatus(Long empId) {
		return resignationRepo.findStatusByEmpId(empId);

	}

	@Override
	public List<EntityDTO> revokeEmployeeResignation(@Valid ResignationDTO model) {
		Resignation resignationEntity = resignationRepo.getByEmployee(model.getEmpId());
		List<EntityDTO> list = new ArrayList<>();
		Employee emp = employeeRepository.getOne(model.getEmpId());
		resignationEntity.setEmployee(emp.getId());
		resignationEntity.setReasonForEmpRevoke(model.getReasonForEmpRevoke());
		if (model.getStatus().equals(Constants.REVOKED)) {
			resignationEntity.setStatus(Constants.REVOKE_APPLIED);
		} 
		resignationEntity.setRevokeAppliedDate(model.getRevokeAppliedDate());
		Resignation resignationSave = resignationRepo.save(resignationEntity);
		EntityDTO dto = new EntityDTO();
		dto.setId(resignationSave.getId());
		list.add(dto);
		return list;

	}

	@Override
	public Resignation getResignationSubmitted(Long empId) {		
		return resignationRepo.getByEmployee(empId);
		
	}
	
	@Override
	@Scheduled(cron = "0 30 16 * * *", zone = "IST")
	public void exitStatusTrue() {
		List<Resignation> empList = resignationRepo.findAllByStatus(Constants.COMPLETED);
		for (Resignation emp : empList) {
			if(emp.getTentativeLeavingDate().equals(LocalDate.now())){
				Employee emp1 = employeeRepository.getOne(emp.getEmployee());
				emp1.setIsExit(Boolean.TRUE);
				employeeRepository.save(emp1);
			}
		}
	}

	@Override
	public List<EntityDTO> updateResigAfterRevokeApply(@Valid ResignationDTO model) {
		Resignation resignationEntity = resignationRepo.getByEmployee(model.getEmpId());
		List<EntityDTO> list = new ArrayList<>();
		Employee emp = employeeRepository.getOne(model.getEmpId());
		resignationEntity.setEmployee(emp.getId());
		resignationEntity.setTentativeLeavingDate(resignationEntity.getTentativeLeavingDate());
		resignationEntity.setNoticePeriod(resignationEntity.getNoticePeriod());
		resignationEntity.setDescription(resignationEntity.getDescription());
		resignationEntity.setReason(resignationEntity.getReason());
		resignationEntity.setResignationSubmittedOn(resignationEntity.getResignationSubmittedOn());
		resignationEntity.setRevokeAppliedDate(resignationEntity.getRevokeAppliedDate());
		resignationEntity.setReasonForManagerRevoke(model.getReasonForManagerRevoke());
		resignationEntity.setRevokeApprovedDate(model.getRevokeApprovedDate());
		if (model.getStatus().equals(Constants.REVOKE_APPROVED)) {
			resignationEntity.setStatus(Constants.REVOKE_APPROVED);
		} else if (model.getStatus().equals(Constants.REVOKE_REJECTED)) {
			resignationEntity.setStatus(Constants.EXIT_PROCESS);
		}
		Resignation resignationSave = resignationRepo.save(resignationEntity);
		EntityDTO dto = new EntityDTO();
		dto.setId(resignationSave.getId());
		list.add(dto);
		return list;
	}
}
