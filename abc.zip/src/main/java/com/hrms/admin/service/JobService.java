package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.JobDTO;

public interface JobService {

	public List<EntityDTO> save(JobDTO model);

	public List<EntityDTO> updateJob(JobDTO model, Long id);

	public Map<String, Object> getAllJob(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String isActive,String companyId);

	public JobDTO getJobByCompanyId(Long id,String companyId);

	public boolean deleteJob(Long id);

	public List<EntityDTO> updateJobByStatus(Long id, String status);

	public List<EntityDTO> softDeleteJob(Long id);
	
	 //for validation
	public boolean validate(JobDTO job, boolean isSave);

}
