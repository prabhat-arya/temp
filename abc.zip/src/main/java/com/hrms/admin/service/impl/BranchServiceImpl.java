package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.service.BranchService;
import com.hrms.admin.util.Constants;

@Service
public class BranchServiceImpl implements BranchService {

	private static final Logger logger = LoggerFactory.getLogger(BranchServiceImpl.class);

	@Autowired
	private BranchRepository repo;
	
	ObjectMapper mapper = new ObjectMapper();
	
	/**
	 * Returns true when new branch is store in database
	 * @param model - new branch data
	 * @return - boolean
	 * @throws Exception 
	 */

	@Override
	public List<EntityDTO> save(BranchDTO model) throws Exception {
		Branch entity = new Branch();
		entity.setName(model.getName().toUpperCase());
		entity.setContactNo(model.getContactNo());
		entity.setEmail(model.getEmail().toLowerCase());
		entity.setFax(model.getFax());
		Company company = new Company();
		company.setId(model.getCompanyId());
		entity.setCompany(company);
		Address address = new Address();
		address.setAddress(model.getAddress().getAddress());
		address.setLandmark(model.getAddress().getLandmark());
		address.setStreet(model.getAddress().getStreet());
		address.setCity(model.getAddress().getCity());
		address.setDistrict(model.getAddress().getDistrict());
		address.setState(model.getAddress().getState());
		address.setCountry(model.getAddress().getCountry());
		address.setPincode(model.getAddress().getPincode());
		entity.setAddress(address);
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		Branch d = repo.save(entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(d.getId());
		dto.setName(d.getName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	/**
	 * Returns All Branch data when branch data is available in database
	 * @return - List of Branchresponse
	 */
	@Override
	public Map<String, Object> getAllBranch(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId) {
		
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Branch> pagedResult = null;
		Boolean status = true;
		
		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = repo.allBranchPage(searchKey,companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = repo.branchPage(searchKey,companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Branch Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns Branch data when branch data is available in database by id
	 * @param id - branch Id
	 * @return - BranchResponse
	 * @throws Exception 
	 * @throws JsonMappingException 
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public BranchDTO getById(Long id,String companyId) throws  Exception {
		Optional<Branch> optionalEntity = repo.findBranchByCompanyId(id,companyId);
		if(optionalEntity.isPresent()) {
			Branch entity = optionalEntity.get();
			BranchDTO model = new BranchDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setContactNo(entity.getContactNo());
			model.setEmail(entity.getEmail());
			model.setFax(entity.getFax());
			model.setCompanyId(entity.getCompany().getId());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			AddressDTO address = new AddressDTO();
			address.setId(entity.getAddress().getId());
			address.setAddress(entity.getAddress().getAddress());
			address.setLandmark(entity.getAddress().getLandmark());
			address.setStreet(entity.getAddress().getStreet());
			address.setCity(entity.getAddress().getCity());
			address.setDistrict(entity.getAddress().getDistrict());
			address.setState(entity.getAddress().getState());
			address.setCountry(entity.getAddress().getCountry());
			address.setPincode(entity.getAddress().getPincode());	
			model.setAddress(address);
			return model;
		}else {
			logger.info("Branch not found in DB with Id:{}",id);
			return null;
		}
	}

	/**
	 * Returns true when existing Branch data is store in database
	 * 
	 * @param model - new branch data
	 * @param id    - branch Id
	 * @return - boolean
	 * @throws Exception 
	 */
	@Override
	public List<EntityDTO> updateBranch(BranchDTO model) throws Exception {
		Optional<Branch> findById = repo.findById(model.getId());
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Branch oldBranch = findById.get();
			oldBranch.setName(model.getName().toUpperCase());
			oldBranch.setContactNo(model.getContactNo());
			oldBranch.setEmail(model.getEmail().toLowerCase());
			oldBranch.setFax(model.getFax());
			Company company = new Company();
			company.setId(model.getCompanyId());
			oldBranch.setCompany(company);
			Address address = new Address();
			address.setId(oldBranch.getAddress().getId());
			address.setAddress(model.getAddress().getAddress());
			address.setLandmark(model.getAddress().getLandmark());
			address.setStreet(model.getAddress().getStreet());
			address.setCity(model.getAddress().getCity());
			address.setDistrict(model.getAddress().getDistrict());
			address.setState(model.getAddress().getState());
			address.setCountry(model.getAddress().getCountry());
			address.setPincode(model.getAddress().getPincode());
			oldBranch.setAddress(address);
			Branch b = repo.save(oldBranch);
			EntityDTO dto = new EntityDTO();
			dto.setId(b.getId());
			dto.setName(b.getName());
			list.add(dto);
			return list;
		}else {
			logger.info("Branch failed to update");
			return list;
		}
	}

	/**
	 * 
	 * @param Entity -  branch data
	 * @param id    - branch Id
	 * @return - Map object
	 */
	public static Map<String, Object> mapData(Page<Branch> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<BranchDTO> branchModels = pagedResult.stream().map(entity -> {
			BranchDTO model = new BranchDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setContactNo(entity.getContactNo());
			model.setEmail(entity.getEmail());
			model.setFax(entity.getFax());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			AddressDTO address = new AddressDTO();
			address.setAddress(entity.getAddress().getAddress());
			address.setCity(entity.getAddress().getCity());
			address.setCountry(entity.getAddress().getCountry());
			address.setDistrict(entity.getAddress().getDistrict());
			address.setId(entity.getAddress().getId());
			address.setLandmark(entity.getAddress().getLandmark());
			address.setPincode(entity.getAddress().getPincode());
			address.setState(entity.getAddress().getState());
			address.setStreet(entity.getAddress().getStreet());
			address.setType(entity.getAddress().getType());
			model.setAddress(address);
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, branchModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * @param id    - branch Id
	 * @return - List of Branches based on branch Id
	 */
	@Override
	@Cacheable(value = "listOfBranch", unless = "#result == null", key = "#id")
	public List<BranchDTO> listOfBranch(String id) {
		List<BranchDTO> models=null;
		List<Branch> allBranch = repo.findByCompanyId(id);
		 models = allBranch.stream().map(entity -> {
			BranchDTO model = new BranchDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * @param Branch Id,
	 * @return - Change value from database isDisable is true
	 */
	public List<EntityDTO> softDeleteBranch(Long id) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Branch> findById = repo.findById(id);
		if(findById.isPresent()) {
			Branch branch = findById.get();
			branch.setIsActive(Boolean.FALSE);
			branch.setIsDelete(Boolean.TRUE);
			Branch p = repo.save(branch);
			EntityDTO dto = new EntityDTO();
			dto.setId(p.getId());
			dto.setName(p.getName());
			list.add(dto);
			return list;
		}else {
			logger.info("Branch failed to soft delete with Id:{}",id);
			return list;
		}

	}
	
	/**
	 * @param BranchDTO,
	 *  @param boolean value,
	 * @return -  if record exit return true or if record not exit  return false
	 */
	
	@Override
	public boolean validate(BranchDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getBranchCount(model.getCompanyId(), model.getName());
		else
			count = repo.getBranchCountForUpdate(model.getCompanyId(), model.getName(), model.getId());
		return count > 0;
	}
	
	/**
	 * @param Branch id,
	 *  @param String,
	 * @return -  if record exit update the Record based on Branch Status and Branch Id 
	 */

	public List<EntityDTO> updateBranchByStatus(Long id, String status) {
		Optional<Branch> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();	
		if(findById.isPresent()) {
			Branch a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Branch e = repo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Branch is activated in to database with brancId:{}",id);
				return list;
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Branch e = repo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Branch is deactivated in to database with brancId:{}",id);
				return list;
			}
		}
		logger.info("Branch is failed to activated or deactivated with brancId:{}",id);
		return list;
	}

	/**
	 * @param String branchName ,
	 * * @param Long companyId
	 * @return - Branch based on BranchName  
	 */
	@Override
	public Branch findByBranchName(String branchName, String companyId) {
		return repo.findByBranchName(branchName,companyId);
	}

	


}