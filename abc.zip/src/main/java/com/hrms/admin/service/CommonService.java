package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.CertificateTypeDTO;
import com.hrms.admin.dto.EmployeeProjectsDTO;
import com.hrms.admin.dto.EmploymentTypeDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.entity.AcadmicDetailsErrorRecords;
import com.hrms.admin.entity.BankDetailsErrorRecords;
import com.hrms.admin.entity.CertificateType;
import com.hrms.admin.entity.EmergencyContactDetailErrorRecords;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.EmployeeErrorRecords;
import com.hrms.admin.entity.EmployeeMailErrorRecords;
import com.hrms.admin.entity.PersonalDetailsErrorRecords;
import com.hrms.admin.entity.ProfessionalDetailsErrorRecords;

public interface CommonService {

	public List<ProjectDTO> managerHierarchy(Long id);

	public List<BankDetailsErrorRecords> excelReportAllErrorBankDetails();

	public List<ProfessionalDetailsErrorRecords> excelReportAllErrorProfessionalDetailsError();

	public List<EmployeeErrorRecords> excelReportAllErrorEmployeeDetailsError();

	public List<Employee> excelReportAllSuccessEmployeeDetails(String companyId);

	public List<EmployeeMailErrorRecords> excelReportAllErrorEmployeeMailIdError();

	public List<EmployeeProjectsDTO> projectsBasedOnCompany(String companyId);

	public List<EmployeeProjectsDTO> projectsListBasedOnManger(Long managerId, String companyId);

	List<AcadmicDetailsErrorRecords> excelReportAllErrorEducationalDetailsError();

	public List<EmergencyContactDetailErrorRecords> excelReportAllErrorEmergencyContactDetailsError();

	public List<CertificateTypeDTO> getCertificateTypeList();

	public CertificateType saveCertificateType(CertificateTypeDTO model);

	public List<EmploymentTypeDTO> getEmploymentTypeList();

	public boolean validateCertificateType(CertificateTypeDTO model);

	public List<PersonalDetailsErrorRecords> excelReportAllErrorPersonalContactDetailsError();

}