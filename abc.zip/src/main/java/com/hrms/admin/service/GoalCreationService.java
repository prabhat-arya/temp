package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.GoalCreationDTO;
import com.hrms.admin.dto.GoalCreationEmployeeDTO;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;

public interface GoalCreationService {

	public List<EntityDTO> save(GoalCreationDTO model);

	public Map<String, Object> findAllGoals(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String manager, String companyId);

	public List<GoalCreationEmployeeDTO> findDepartmentByEmployeeId(Long employeeId);

	public GoalCreationDTO findOneGoalByEmployeeId(Long employeeId);
	
	public List<PayrollEmpListDTO> getEmployeeIds(Long managerId);

}
