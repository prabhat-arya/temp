package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.LeaveTypeDTO;
import com.hrms.admin.entity.AnnualLeaves;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.LeaveType;
import com.hrms.admin.repository.AnnualLeavesRepository;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.LeaveTypeRepository;
import com.hrms.admin.service.LeaveTypeService;
import com.hrms.admin.util.Constants;

@Service
public class LeaveTypeServiceImpl implements LeaveTypeService {

	private static final Logger logger = LoggerFactory.getLogger(LeaveTypeServiceImpl.class);

	@Autowired
	private LeaveTypeRepository repo;

	@Autowired
	private AnnualLeavesRepository annualLeavesRepo;

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private CompanyRepository comRepo;

	@Autowired
	private BranchRepository branchRepo;

	/**
	 * Returns true when new LeaveType is store in database
	 * 
	 * @param model - new LeaveType data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(LeaveTypeDTO model) {
		List<EntityDTO> list = new ArrayList<>();
		LeaveType entity = new LeaveType();
		entity.setLeaveType((model.getLeaveType()));
		entity.setDescription((model.getDescription()));

		Optional<Company> optional = comRepo.findById(model.getCompanyId());
		if (!optional.isPresent()) {
			return list;
		}
		Company company = optional.get();
		entity.setCompany(company);
		Optional<Branch> findById = branchRepo.findById(model.getBranchId());
		if (!findById.isPresent()) {
			return list;
		}
		Branch branch = findById.get();
		entity.setBranch(branch);
		entity.setAnnualLeaves(model.getAnnualLeaves());
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		entity.setMonthlyLeaves(model.getMonthlyLeaves());
		entity.setIsCarryForward(model.getIsCarryForward());
		entity.setIsDocumentReq(model.getIsDocumentReq());
		LeaveType d = repo.save(entity);
		List<Employee> empList = employeeRepo.findAll();
		for (Employee emp : empList) {
			AnnualLeaves annualLeaves = new AnnualLeaves();
			annualLeaves.setYearlyLeaves(model.getAnnualLeaves());
			annualLeaves.setEmployee(emp);
			annualLeaves.setLeaveType(entity);
			Long leave = 0L;
			annualLeaves.setAvailableLeaves(leave);
			annualLeaves.setTotalTookLeaves(leave);
			annualLeavesRepo.save(annualLeaves);
		}
		logger.info("Leave Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setId(d.getId());
		dto.setName(d.getLeaveType());
		list.add(dto);
		return list;
	}

	/**
	 * Returns All Leave data when Leave data is available in database
	 * 
	 * @return - List of LeaveresponseModel
	 */
	@Override
	public Map<String, Object> getAllLeaves(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<LeaveType> pagedResult = null;
		Boolean status = true;
		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = repo.allLeaveTypePage(searchKey,companyId, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = repo.leaveTypePage(searchKey,companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns Leave data when branch data is available in database by id
	 * 
	 * @param id - Leave Id
	 * @return - LeaveResponseModel
	 */
	@Override
	public LeaveTypeDTO getById(Long id , String companyId) {
		Optional<LeaveType> optionalEntity = repo.findLeaveByCompanyId(id , companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		LeaveType entity = optionalEntity.get();
		LeaveTypeDTO model = new LeaveTypeDTO();
		model.setId(entity.getId());
		model.setLeaveType(entity.getLeaveType());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompany().getId());
		model.setBranchId(entity.getBranch().getId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		model.setAnnualLeaves(entity.getAnnualLeaves());
		model.setMonthlyLeaves(entity.getMonthlyLeaves());
		model.setIsCarryForward(entity.getIsCarryForward());
		model.setIsDocumentReq(entity.getIsDocumentReq());
		model.setIsActive(entity.getIsActive());
		model.setIsDelete(entity.getIsDelete());
		logger.info("Skill found in DB with Id:{}", id);
		return model;
	}

	/**
	 * Returns true when existing Leave data is store in database
	 * 
	 * @param model - new Leave data
	 * @param id    - Leave Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateLeave(LeaveTypeDTO model, Long id) {
		Optional<LeaveType> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			LeaveType oldLeave = findById.get();
			oldLeave.setLeaveType((model.getLeaveType()));
			oldLeave.setDescription(model.getDescription());
			Optional<Company> findByCompanyId = comRepo.findById(model.getCompanyId());
			if (!findByCompanyId.isPresent()) {
				return list;
			}
			Company company = findByCompanyId.get();
			oldLeave.setCompany(company);
			Optional<Branch> findByBranchId = branchRepo.findById(model.getBranchId());
			if (!findByBranchId.isPresent()) {
				return list;
			}
			Branch branch = findByBranchId.get();
			oldLeave.setBranch(branch);
			oldLeave.setIsCarryForward(model.getIsCarryForward());
			oldLeave.setMonthlyLeaves(model.getMonthlyLeaves());
			oldLeave.setAnnualLeaves(model.getAnnualLeaves());
			oldLeave.setIsDocumentReq(model.getIsDocumentReq());
			LeaveType d = repo.save(oldLeave);
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getLeaveType());
			list.add(dto);
			logger.info("LeaveType record is updated in database with id:{}", id);
			return list;
		}
		logger.info("LeaveType record is failed to updated in database with id:{}", id);
		return list;
	}

	/**
	 * @param LeaveType Entity
	 * @return - page size
	 */
	public static Map<String, Object> mapData(Page<LeaveType> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<LeaveTypeDTO> leaveModels = pagedResult.stream().map(entity -> {
			LeaveTypeDTO model = new LeaveTypeDTO();
			model.setId(entity.getId());
			model.setLeaveType(entity.getLeaveType());
			model.setCompanyId(entity.getCompany().getId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchId(entity.getBranch().getId());
			model.setBranchName(entity.getBranch().getName());
			model.setMonthlyLeaves(entity.getMonthlyLeaves());
			model.setIsCarryForward(entity.getIsCarryForward());
			model.setIsDocumentReq(entity.getIsDocumentReq());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, leaveModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * Return All LeaveType data Exist in database
	 * 
	 * @return - ResponseEntity
	 * 
	 */
	@Override
	@Cacheable(value = "AllLeavesTypes", unless = "#result.size() == 0")
	public List<LeaveTypeDTO> AllLeavesTypes(String companyId) {
		List<LeaveType> allLeaveType = repo.findAllLeaveTypeByCompanyId(companyId);
		logger.info("LeaveType Records are found from Database");
		List<LeaveTypeDTO> models = allLeaveType.stream().map(entity -> {
			LeaveTypeDTO model = new LeaveTypeDTO();
			model.setId(entity.getId());
			model.setLeaveType(entity.getLeaveType());
			model.setIsActive(entity.getIsActive());
			model.setIsDocumentReq(entity.getIsDocumentReq());
			model.setIsCarryForward(entity.getIsCarryForward());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * @param LeaveType id,
	 * @param String,
	 * @return - if record is updateAttendanceByStatus based on LeaveTypeid
	 */

	@Override
	public List<EntityDTO> updateLeaveTypeByStatus(Long id, String status) {
		Optional<LeaveType> findById = repo.findByLeave(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		LeaveType leaveType = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			leaveType.setIsActive(Boolean.TRUE);
			LeaveType e = repo.save(leaveType);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getLeaveType());
			list.add(dto);
			logger.info(Constants.LEAVETYPE + " is Activated in database");
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			leaveType.setIsActive(Boolean.FALSE);
			LeaveType e = repo.save(leaveType);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getLeaveType());
			list.add(dto);
			logger.info(Constants.LEAVETYPE + " is Deactivated in database");
			return list;
		} else
			logger.info(Constants.LEAVETYPE + " is status is invalid");
		return list;
	}

	/**
	 * @param id -LeaveType,
	 * @return - change value from database isDisable is true
	 */
	@Override
	public List<EntityDTO> softDeleteLeaveType(Long id) {
		Optional<LeaveType> findById = repo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		LeaveType leaveType = findById.get();
		leaveType.setIsActive(Boolean.FALSE);
		leaveType.setIsDelete(Boolean.TRUE);
		LeaveType l = repo.save(leaveType);
		logger.info(Constants.LEAVETYPE + " is SoftDeleted in database");
		EntityDTO dto = new EntityDTO();
		dto.setId(l.getId());
		dto.setName(l.getLeaveType());
		list.add(dto);
		return list;
	}

	/**
	 * @param LeaveTypeDTO ,
	 * @param boolean      value,
	 * @return - if record exit return true or if record not exit return false
	 */

	@Override
	public boolean validate(LeaveTypeDTO leaveType, boolean isSave) {
		Long count;
		if (isSave)
			count = repo.getLeaveTypeCountSave(leaveType.getLeaveType(), leaveType.getCompanyId());
		else
			count = repo.getLeaveTypeCountUpdate(leaveType.getCompanyId(), leaveType.getLeaveType(), leaveType.getId());
		return count > 0;
	}

}