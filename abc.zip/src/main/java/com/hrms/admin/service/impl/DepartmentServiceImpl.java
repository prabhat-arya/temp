package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.DepartmentDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Department;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.DepartmentRepository;
import com.hrms.admin.service.DepartmentService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Prabhat}
 *
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

	private static final Logger logger = LoggerFactory.getLogger(DepartmentServiceImpl.class);

	@Autowired
	private DepartmentRepository deptrepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private BranchRepository branchRepo;

	/**
	 * Returns true when new department is store in database
	 * 
	 * @param model - new department data
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> save(DepartmentDTO model) {
		Department entity = new Department();
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		Optional<Company> company = companyRepo.findById(model.getCompanyId());
		if (company.isPresent()) {
			entity.setCompany(company.get());
		}
		Optional<Branch> branch = branchRepo.findById(model.getBranchId());
		if (branch.isPresent()) {
			entity.setBranch(branch.get());
		}
		entity.setIsDelete(Boolean.FALSE);
		entity.setIsActive(Boolean.TRUE);
		Department d = deptrepo.save(entity);
		logger.info("Department Record is stored in Database with id:{}", d.getId());
		EntityDTO dto = new EntityDTO();
		dto.setId(d.getId());
		dto.setName(d.getName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	/**
	 * Returns true when existing department data is store in database
	 * 
	 * @param model - new department data
	 * @param id    - depatment Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateDepartment(DepartmentDTO model, Long id) {
		Optional<Department> findById = deptrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Department oldDepartment = findById.get();
			oldDepartment.setName(model.getName());
			oldDepartment.setDescription(model.getDescription());
			Optional<Company> company = companyRepo.findById(model.getCompanyId());
			if (company.isPresent()) {
				oldDepartment.setCompany(company.get());
			}
			Optional<Branch> branch = branchRepo.findById(model.getBranchId());
			if (branch.isPresent()) {
				oldDepartment.setBranch(branch.get());
			}
			Department d = deptrepo.save(oldDepartment);
			logger.info("Department record is updated in to database with id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(d.getId());
			dto.setName(d.getName());
			list.add(dto);
			return list;
		}
		return list;

	}

	/**
	 * Returns Department data when department data is available in database by id
	 * 
	 * @param id - DepartmentId
	 * @return - DepartmentModel
	 */
	@Override
	@Cacheable(value = " getById", unless = "#result == null", key = "#id")
	public DepartmentDTO getById(Long id, String companyId) {
		Optional<Department> optionalEntity = deptrepo.findDepartmentIdByCompanyId(id, companyId);
		// Optional<Department> optionalEntity = deptrepo.findById(id);

		if (optionalEntity.isPresent()) {
			Department departmentEntity = optionalEntity.get();
			DepartmentDTO model = new DepartmentDTO();
			model.setId(departmentEntity.getId());
			model.setName(departmentEntity.getName());
			model.setDescription(departmentEntity.getDescription());
			model.setCompanyId(departmentEntity.getCompany().getId());
			model.setCompanyName(departmentEntity.getCompany().getName());
			model.setBranchName(departmentEntity.getBranch().getName());
			model.setBranchId(departmentEntity.getBranch().getId());
			model.setIsDelete(departmentEntity.getIsDelete());
			model.setIsActive(departmentEntity.getIsActive());
			return model;
		}
		return null;
	}

	/**
	 * Returns Lis of Department data when department data is available in database
	 * 
	 * @return - DepartmentModel
	 */
	@Override
	@Cacheable(value = "AllDepartment", unless = "#result.size() == 0")
	public List<DepartmentDTO> AllDepartment(String companyId) {
		List<Department> allDepartment = deptrepo.findAllDepartmentByCompanyId(companyId);
		logger.info("Department Records are found from Database");
		List<DepartmentDTO> models = allDepartment.stream().map(entity -> {
			DepartmentDTO model = new DepartmentDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setIsDelete(entity.getIsDelete());
			model.setCompanyId(entity.getCompany().getId());
			model.setBranchName(entity.getBranch().getName());
			model.setCompanyName(entity.getCompany().getName());
			model.setDescription(entity.getDescription());
			model.setIsActive(entity.getIsActive());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * 
	 * @param Entity - Department
	 * @param id     - DepartmentId
	 * @return - Map object
	 */

	@Override
	public Map<String, Object> getAllDepartment(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<DepartmentDTO> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals(" ")) {
			pagedResult = deptrepo.allDepartmentPage(searchKey, companyId, paging);
		} else {
			if (isActive.equals(Constants.ZERO)) {
				status = false;
			}
			pagedResult = deptrepo.departmentPage(searchKey, companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("For Department Records page is created");
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * 
	 * @param Entity - Department
	 * @param id     - DepartmentId
	 * @return - Map object
	 */

	public static Map<String, Object> mapData(Page<DepartmentDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<DepartmentDTO> deptModels = pagedResult.stream().map(deptEntity -> {
			DepartmentDTO model = new DepartmentDTO();
			model.setId(deptEntity.getId());
			model.setName(deptEntity.getName());
			model.setBranchName(deptEntity.getBranchName());
			model.setCompanyId(deptEntity.getCompanyId());
			model.setCompanyName(deptEntity.getCompanyName());
			model.setIsDelete(deptEntity.getIsDelete());
			model.setIsActive(deptEntity.getIsActive());
			model.setDescription(deptEntity.getDescription());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, deptModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("Department map object is created for Paging");
		return response;
	}

	/**
	 * @param id - branch Id
	 * @return - List of Department based on DepartmentId
	 */

	@Override
	@Cacheable(value = "getBranchById", unless = "#result == null", key = "#id")
	public List<DepartmentDTO> getBranchById(Long id, String companyId) {
		List<Department> a = deptrepo.findByBranchId(id, companyId);
		List<DepartmentDTO> models = a.stream().map(entity -> {
			DepartmentDTO model = new DepartmentDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setIsDelete(entity.getIsDelete());
			model.setDescription(entity.getDescription());
			model.setBranchId(entity.getBranch().getId());
			model.setCompanyId(entity.getCompany().getId());
			model.setBranchName(entity.getBranch().getName());
			model.setCompanyName(entity.getCompany().getName());
			model.setIsActive(entity.getIsActive());
			model.setIsDelete(entity.getIsDelete());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	/**
	 * @param DepartmentId,
	 * @return - Change value from database isDisable is true
	 */

	public List<EntityDTO> softDeleteDepartment(Long id) {
		Optional<Department> findById = deptrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Department department = findById.get();
			department.setIsDelete(Boolean.TRUE);
			department.setIsActive(Boolean.FALSE);
			Department p = deptrepo.save(department);
			logger.info("Department is SoftDeleted in to database with Id:{}", id);
			EntityDTO dto = new EntityDTO();
			dto.setId(p.getId());
			dto.setName(p.getName());
			list.add(dto);
			return list;
		}
		return list;

	}

	/**
	 * @param DepartmentDTO,
	 * @param boolean        value,
	 * @return - if record exit return true or if record not exit return false
	 */

	@Override
	public boolean validate(DepartmentDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = deptrepo.getDepartmentCountSave(model.getName(), model.getCompanyId(), model.getBranchId());
		else
			count = deptrepo.getDepartmentCountUpdate(model.getName(), model.getCompanyId(), model.getId(),
					model.getBranchId());
		return count > 0;
	}

	/**
	 * @param Departmentid,
	 * @param String        status,
	 * @return - if record exit update the Record based on Department Status and
	 *         DepartmentId
	 */
	public List<EntityDTO> updateDepartmentByStatus(Long id, String status) {
		Optional<Department> findById = deptrepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (findById.isPresent()) {
			Department a = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				a.setIsActive(Boolean.TRUE);
				Department e = deptrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Employee is activated in to database");
				return list;
			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				a.setIsActive(Boolean.FALSE);
				Department e = deptrepo.save(a);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				logger.info("Employee is deactivated in to database");
				return list;
			}
		}
		logger.info("Employee is failed to deactivated or activated in to database");
		return list;
	}

	/**
	 * @param String departmentName,
	 * @param Long   companyId
	 * @param Long   branchId
	 * @return - Department based on DepartmentName
	 */
	@Override
	public Department findByName(String departmentName, String companyId, Long branchId) {
		Optional<Department> findBydeptname = deptrepo.findByName(departmentName, companyId, branchId);
//		return deptrepo.findBydeptname(departmentName, companyId, branchId);
		if (findBydeptname.isPresent()) {
			return findBydeptname.get();
		} else {
			return null;
		}
	}

}