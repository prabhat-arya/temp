package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Branch;

public interface BranchService {

	public List<EntityDTO> save(BranchDTO branch) throws Exception;

	public BranchDTO getById(Long data,String companyId) throws Exception;

	public List<EntityDTO> updateBranch(BranchDTO model) throws Exception;

	public Map<String, Object> getAllBranch(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId);

	public List<BranchDTO> listOfBranch(String id);

	public List<EntityDTO> softDeleteBranch(Long id);
	
	public boolean validate(BranchDTO branch, boolean isSave);
	
	public List<EntityDTO> updateBranchByStatus(Long id , String status);
	
	public Branch findByBranchName(String branchName, String companyId);
}
