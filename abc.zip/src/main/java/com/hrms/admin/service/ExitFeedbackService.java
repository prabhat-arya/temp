package com.hrms.admin.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ExitFeedbackDTO;
import com.hrms.admin.entity.ExitFeedback;

@Service
public interface ExitFeedbackService {

	public List<EntityDTO> saveExitFeedback(MultipartFile[] file, String data);

	public List<ExitFeedbackDTO> getExitFeedbackBasedOnExitId(Long exitId);

	public ExitFeedbackDTO getExitFeedbackBasedOnFeedbackId(Long feedBackId);

	public List<ExitFeedbackDTO> getExitFeedbackBasedOnEmployeeId(Long employeeId);

	public Boolean uploadFeedBackFiles(MultipartFile[] file, ExitFeedback exitFeedback) throws IOException;

	public List<EntityDTO> deleteFeedBackFile(Long fileId);

	ExitFeedbackDTO deleteExitFeedbackBasedOnFeedbackId(Long feedBackId);

//	public DocumentDetails previewFeedBackDocument(String fileId);

	public List<ExitFeedback> findAllExitFeedBacks(String companyId);
}
