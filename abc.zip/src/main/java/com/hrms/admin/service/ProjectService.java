package com.hrms.admin.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ProjectPieChartDTO;
import com.hrms.admin.dto.ProjectReleaseDTO;

public interface ProjectService {

	public List<EntityDTO> save(ProjectDTO model);

	public List<ProjectDTO> getAllProject(String id);

	public ProjectDTO getById(Long id , String companyId);

	public boolean deleteProject(Long id);

	public List<EntityDTO> updateProject(ProjectDTO model, Long id);

	public ProjectDTO findAllEmployeeByProjId(Long id,String companyId);

	public Map<String, Object> getAllProject(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId);

	// for duplicate check..
	public boolean validate(ProjectDTO project, boolean isSave);

	public List<EntityDTO> softDeleteProject(Long id);

	public List<EntityDTO> updateProjectByStatus(Long id, String status);

	//public Long getAllProjectCountBasedOnBranch(Long branchId);

	public boolean projectReleaseAnnounce(ProjectReleaseDTO model);

//	public List<ProjectDTO> getAllProjectBasedOnBranch(Long branchId);

	public Set<ProjectPieChartDTO> getAllProjectPieChart(String comanyId, Long projectId);

	public Set<ProjectPieChartDTO> getProjectsListDonatChartUnderManager(Long managerId, Long projectId,String companyId);
	
}
