package com.hrms.admin.service;

import java.util.List;

import javax.validation.Valid;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PerformanceDTO;

public interface PerformanceService {
	
	

	public List<EntityDTO> saveAndUpdatePerformanceByEmployee(PerformanceDTO model);
	
	public List<EntityDTO> saveAndUpdatePerformanceByManager(PerformanceDTO model);
	
	public List<PerformanceDTO> findPerformanceByEmployeeId(Long employeeId);

	List<EntityDTO> saveAndUpdatePerformanceByEmployeeFinalSubmit(PerformanceDTO model);

	public List<EntityDTO> saveAndUpdatePerformanceByReviewer(@Valid PerformanceDTO model);
}
