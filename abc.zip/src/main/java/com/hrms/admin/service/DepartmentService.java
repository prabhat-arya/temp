package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.DepartmentDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Department;

public interface DepartmentService {

	public List<EntityDTO> save(DepartmentDTO model);

//	public Map<String, Object> getAllDepartment(Integer pageIndex, Integer pageSize, String sortBy);

//	 Map<String, Object> getAllDepartment(Integer pageNo, Integer pageSize, String sortBy);

	public DepartmentDTO getById(Long data,String companyId);

	/*
	 * public DepartmentDTO getByName(String name);
	 * 
	 * public boolean deleteDepartment(Long id);
	 */

	public List<EntityDTO> updateDepartment(DepartmentDTO model, Long id);

	public List<DepartmentDTO> AllDepartment(String companyId);

	public Map<String, Object> getAllDepartment(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String isActive,String companyId);

	public List<DepartmentDTO> getBranchById(Long id,String companyId);

	public List<EntityDTO> softDeleteDepartment(Long id);

	public boolean validate(DepartmentDTO model, boolean isSave);
	
	public List<EntityDTO> updateDepartmentByStatus(Long id , String status);
	
	public Department findByName(String departmentName, String companyId, Long branchId);


}
