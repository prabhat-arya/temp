package com.hrms.admin.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.math3.util.Precision;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.dto.EmployeePageDTO;
import com.hrms.admin.dto.EmployeeReportDTO;
import com.hrms.admin.dto.ExitReportDTO;
import com.hrms.admin.dto.LeaveReportDTO;
import com.hrms.admin.dto.PayrollReportPaginationDTO;
import com.hrms.admin.dto.PayrollReportResponseDTO;
import com.hrms.admin.dto.PerfomanceReportDTO;
import com.hrms.admin.dto.PerfomanceResponceDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ReportPageDTO;
import com.hrms.admin.dto.ShiftReportDTO;
import com.hrms.admin.entity.AssignShift;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.GoalCreation;
import com.hrms.admin.entity.Project;
import com.hrms.admin.fileuploaddownload.property.ExcelGenerator;
import com.hrms.admin.fileuploaddownload.property.PdfReportGenerator;
import com.hrms.admin.repository.AssignShiftRepository;
import com.hrms.admin.repository.AttendanceInfoRepository;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.GoalCreationRepository;
import com.hrms.admin.repository.PerformanceRepository;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.service.ReportService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.EmployeeServiceUtil;
import com.hrms.admin.util.StringToDateUtility;
import com.itextpdf.text.DocumentException;

@Service
public class ReportServiceImpl implements ReportService {

	private static Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private AssignShiftRepository assignShiftRepo;

	@Autowired
	private EmpLeaveRepository empLeaveRepo;

	@Autowired
	private AttendanceInfoRepository attendanceRepo;

	@Autowired
	private PerformanceRepository performanceRepo;
	@Autowired
	private EmailServiceUtil util;

	@Autowired
	private EmployeeServiceUtil employeeServiceUtil;

	@Autowired
	private GoalCreationRepository goalRepository;

	@Autowired
	private ProjectRepository projectRepo;

	@Autowired
	private PdfReportGenerator pdfReportGenerator;
	@Autowired
	private ExcelGenerator excelGenerator;

	@Autowired
	private StringToDateUtility dateUtil;

	@Override
	public Map<String, Object> getOnboardingReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String startDate, String endDate, String gender,
			Long departmentId, Long designationId, String companyId) throws ParseException {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmployeePageDTO> pagedResult = null;
		if (startDate != null && endDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			Date start = simpleDateFormat.parse(startDate);
			Date end = simpleDateFormat.parse(endDate);
			if (isActive.isEmpty() || isActive.equals("")) {
				pagedResult = employeeRepo.allEmployeeReports(searchKey, start, end, companyId, paging);
			} else {
				Boolean status = Boolean.TRUE;
				if (isActive.equals(Constants.ZERO)) {
					status = Boolean.FALSE;
				}
				pagedResult = employeeRepo.employeeReports(searchKey, status, start, end, companyId, paging);
				if (gender.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeeReports(searchKey, status, start, end, companyId, paging);
				}
				if (!gender.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeeReportByGender(searchKey, status, gender, start, end, companyId,
							paging);
				}
				if (!gender.equals("") && departmentId != 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeeReportByGenderDept(searchKey, status, gender, departmentId,
							start, end, companyId, paging);
				}
				if (!gender.equals("") && departmentId == 0L && designationId != 0L) {
					pagedResult = employeeRepo.employeeReportByGenderDesg(searchKey, status, gender, designationId,
							start, end, companyId, paging);
				}
				if (departmentId != 0L && gender.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.employeeReportByDepartment(searchKey, status, departmentId, start, end,
							companyId, paging);
				}
				if (departmentId != 0L && gender.equals("") && designationId != 0L) {
					pagedResult = employeeRepo.employeeReportByDepartmentDesg(searchKey, status, departmentId,
							designationId, start, end, companyId, paging);
				}
				if (designationId != 0L && departmentId == 0L && gender.equals("")) {
					pagedResult = employeeRepo.employeeReportByDesignation(searchKey, status, designationId, start, end,
							companyId, paging);
				}
				if (!gender.equals("") && departmentId != 0L && designationId != 0L) {
					pagedResult = employeeRepo.employeeReportByGenderDeptDesig(searchKey, status, gender, departmentId,
							designationId, start, end, companyId, paging);
				}
			}

		} else {
			if (isActive.isEmpty() || isActive.equals("")) {
				pagedResult = employeeRepo.allEmployeePage(searchKey, companyId, paging);
			} else {
				Boolean status = Boolean.TRUE;
				if (isActive.equals(Constants.ZERO)) {
					status = Boolean.FALSE;
				}
				pagedResult = employeeRepo.employeePage(searchKey, status, companyId, paging);
				if (gender.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeePage(searchKey, status, companyId, paging);
				}
				if (!gender.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeePageByGender(searchKey, status, gender, companyId, paging);
				}
				if (!gender.equals("") && departmentId != 0L && designationId == 0L) {
					pagedResult = employeeRepo.employeePageByGenderDept(searchKey, status, gender, departmentId,
							companyId, paging);
				}
				if (!gender.equals("") && departmentId == 0L && designationId != 0L) {
					pagedResult = employeeRepo.employeePageByGenderDesg(searchKey, status, gender, designationId,
							companyId, paging);
				}
				if (departmentId != 0L && gender.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.employeePageByDepartment(searchKey, status, departmentId, companyId,
							paging);
				}
				if (departmentId != 0L && gender.equals("") && designationId != 0L) {
					pagedResult = employeeRepo.employeePageByDepartmentDesg(searchKey, status, departmentId,
							designationId, companyId, paging);
				}
				if (designationId != 0L && departmentId == 0L && gender.equals("")) {
					pagedResult = employeeRepo.employeePageByDesignation(searchKey, status, designationId, companyId,
							paging);
				}
				if (!gender.equals("") && departmentId != 0L && designationId != 0L) {
					pagedResult = employeeRepo.employeePageByGenderDeptDesig(searchKey, status, gender, departmentId,
							designationId, companyId, paging);
				}
			}
		}
		if (pagedResult.hasContent()) {
			logger.info("For Employee Records page is created");
			return mapDataOnboard(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapDataOnboard(Page<EmployeePageDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeReportDTO> employeeModels = pagedResult.stream().map(employeeEntity -> {
			EmployeeReportDTO model = new EmployeeReportDTO();
			model.setEmployeeId(employeeEntity.getId());
			model.setEmployeeName(employeeEntity.getFirstName() + " " + employeeEntity.getLastName());
			model.setEmailId(employeeEntity.getOfficalMail());
			model.setDesignation(employeeEntity.getDesignationName());
			model.setMobileNumber(employeeEntity.getContactNo());
			model.setAction(employeeEntity.getIsActive());
			model.setDepartment(employeeEntity.getDepartmentName());
			model.setGender(employeeEntity.getGender());
			Date date = employeeEntity.getJoiningDate();
			DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			String joinDate = dateFormat.format(date);
			model.setJoinDate(joinDate);
			String name = "100x100";
			ProfileImageDTO copyProfileImage = employeeServiceUtil.copyProfileImage(employeeEntity.getId(), name);
			model.setProfileimage(copyProfileImage);
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, employeeModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	public List<EmployeeReportDTO> getOnboardReports(String startDate, String endDate, String isActive,
			String searchKey, String gender, Long departmentId, Long designationId, String companyId)
			throws ParseException {
		List<EmployeePageDTO> employeeReport = null;
		if (startDate != null && endDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			Date start = simpleDateFormat.parse(startDate);
			Date end = simpleDateFormat.parse(endDate);
			if (isActive.isEmpty() || isActive.equals("")) {
				employeeReport = employeeRepo.allEmployeeListReports(searchKey, start, end, companyId);
			} else {
				Boolean status = Boolean.TRUE;
				if (isActive.equals(Constants.ZERO)) {
					status = Boolean.FALSE;
				}
				employeeReport = employeeRepo.employeeListReports(searchKey, status, start, end, companyId);
				if (gender.equals("") && departmentId == 0L && designationId == 0L) {
					employeeReport = employeeRepo.employeeListReports(searchKey, status, start, end, companyId);
				}
				if (!gender.equals("") && departmentId == 0L && designationId == 0L) {
					employeeReport = employeeRepo.employeeListReportByGender(searchKey, status, gender, start, end,
							companyId);
				}
				if (!gender.equals("") && departmentId != 0L && designationId == 0L) {
					employeeReport = employeeRepo.employeeListReportByGenderDept(searchKey, status, gender,
							departmentId, start, end, companyId);
				}
				if (!gender.equals("") && departmentId == 0L && designationId != 0L) {
					employeeReport = employeeRepo.employeeListReportByGenderDesg(searchKey, status, gender,
							designationId, start, end, companyId);
				}
				if (departmentId != 0L && gender.equals("") && designationId == 0L) {
					employeeReport = employeeRepo.employeeListReportByDepartment(searchKey, status, departmentId, start,
							end, companyId);
				}
				if (departmentId != 0L && gender.equals("") && designationId != 0L) {
					employeeReport = employeeRepo.employeeListReportByDepartmentDesg(searchKey, status, departmentId,
							designationId, start, end, companyId);
				}
				if (designationId != 0L && departmentId == 0L && gender.equals("")) {
					employeeReport = employeeRepo.employeeListReportByDesignation(searchKey, status, designationId,
							start, end, companyId);
				}
				if (!gender.equals("") && departmentId != 0L && designationId != 0L) {
					employeeReport = employeeRepo.employeeListReportByGenderDeptDesig(searchKey, status, gender,
							departmentId, designationId, start, end, companyId);
				}
			}

		} else

		if (isActive.isEmpty() || isActive.equals("")) {
			employeeReport = employeeRepo.allEmployeeListReport(searchKey, companyId);
		} else {
			Boolean status = Boolean.TRUE;
			if (isActive.equals(Constants.ZERO)) {
				status = Boolean.FALSE;
			}
			employeeReport = employeeRepo.employeeListReport(searchKey, status, companyId);
			if (gender.equals("") && departmentId == 0L && designationId == 0L) {
				employeeReport = employeeRepo.employeeListReport(searchKey, status, companyId);
			}
			if (!gender.equals("") && departmentId == 0L && designationId == 0L) {
				employeeReport = employeeRepo.employeeListByGenderReport(searchKey, status, gender, companyId);
			}
			if (!gender.equals("") && departmentId != 0L && designationId == 0L) {
				employeeReport = employeeRepo.employeeListByGenderDeptReport(searchKey, status, gender, departmentId,
						companyId);
			}
			if (!gender.equals("") && departmentId == 0L && designationId != 0L) {
				employeeReport = employeeRepo.employeeListByGenderDesgReport(searchKey, status, gender, designationId,
						companyId);
			}
			if (departmentId != 0L && gender.equals("") && designationId == 0L) {
				employeeReport = employeeRepo.employeeListByDepartmentReport(searchKey, status, departmentId,
						companyId);
			}
			if (departmentId != 0L && gender.equals("") && designationId != 0L) {
				employeeReport = employeeRepo.employeeListByDepartmentDesgReport(searchKey, status, departmentId,
						designationId, companyId);
			}
			if (designationId != 0L && departmentId == 0L && gender.equals("")) {
				employeeReport = employeeRepo.employeeListByDesignationReport(searchKey, status, designationId,
						companyId);
			}
			if (!gender.equals("") && departmentId != 0L && designationId != 0L) {
				employeeReport = employeeRepo.employeeListByGenderDeptDesigReport(searchKey, status, gender,
						departmentId, designationId, companyId);
			}
		}

		List<EmployeeReportDTO> employee = new ArrayList<>();
		if (employeeReport.isEmpty()) {
			return employee;
		}
		employee = employeeReport.stream().map(employeeEntity -> {
			EmployeeReportDTO model = new EmployeeReportDTO();
			model.setEmployeeId(employeeEntity.getId());
			model.setEmployeeName(employeeEntity.getFirstName() + " " + employeeEntity.getLastName());
			model.setMobileNumber(employeeEntity.getContactNo());
			model.setEmailId(employeeEntity.getOfficalMail());
			model.setDesignation(employeeEntity.getDesignationName());
			model.setDepartment(employeeEntity.getDepartmentName());
			model.setGender(employeeEntity.getGender());
			if (Boolean.TRUE.equals(employeeEntity.getIsActive())) {
				model.setIsActive(Constants.ACTIVE);
			} else {
				model.setIsActive(Constants.INACTIVE);
			}
			return model;
		}).collect(Collectors.toList());
		return employee;
	}

	@Override
	public ICsvBeanWriter getAllonboardListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws IOException, ParseException {
		List<EmployeeReportDTO> allemployeeDetails = getOnboardReports(pagingDto.getStartDate(), pagingDto.getEndDate(),
				pagingDto.getStatus(), pagingDto.getSearchKey(), pagingDto.getGender(), pagingDto.getDepartmentId(),
				pagingDto.getDesignationId(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Mobile No", "Email ID", "Designation", "Action",
				"Department", "Gender" };
		String[] nameMapping = { "employeeId", "employeeName", "mobileNumber", "emailId", "designation", "isActive",
				"department", "gender" };
		csvWriter.writeHeader(csvHeader);
		for (EmployeeReportDTO att : allemployeeDetails) {
			csvWriter.write(att, nameMapping);
		}
		logger.info("csv Report for onboard employees  are generated");
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public InputStreamResource getEmployeeExcelReports(String startDate, String endDate, String status,
			String searchKey, String gender, Long departmentId, Long designationId, String companyId)
			throws IOException, ParseException {
		List<EmployeeReportDTO> onboardReport = getOnboardReports(startDate, endDate, status, searchKey, gender,
				departmentId, designationId, companyId);
		ByteArrayInputStream in = excelGenerator.OnboardToExcel(onboardReport);
		return new InputStreamResource(in);
	}

	@Override
	public InputStreamResource getAllEmployeepdfReports(String startDate, String endDate, String status,
			String searchKey, String gender, Long departmentId, Long designationId, String companyId) throws Exception {
		List<EmployeeReportDTO> onboardReport = getOnboardReports(startDate, endDate, status, searchKey, gender,
				departmentId, designationId, companyId);
		ByteArrayInputStream bis = pdfReportGenerator.OnboardToPdf(onboardReport, companyId);
		logger.info("getAllpdfReport for Onboard Employees");
		return new InputStreamResource(bis);
	}

	@Override
	public Map<String, Object> getAllShiftReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, Long projectId, Long shiftId, String startDate, String endDate, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AssignShift> pagedResult = null;
		Boolean status = Boolean.FALSE;
		if (startDate != null && endDate != null) {
			if (projectId != null && shiftId != null && projectId != 0 && shiftId != 0) {
				pagedResult = assignShiftRepo.assignShiftReport(searchKey, projectId, shiftId, status, startDate,
						endDate, companyId, paging);
			} else if (projectId != null && projectId != 0) {
				pagedResult = assignShiftRepo.assignShiftReportProjectDatebased(searchKey, projectId, status, startDate,
						endDate, companyId, paging);
			} else if (shiftId != null && shiftId != 0) {
				pagedResult = assignShiftRepo.assignShiftReportShiftDatebased(searchKey, shiftId, status, startDate,
						endDate, companyId, paging);
			} else {
				pagedResult = assignShiftRepo.assignShiftReportDatebased(searchKey, status, startDate, endDate,
						companyId, paging);

			}
		} else {
			if (projectId != null && shiftId != null && projectId != 0 && shiftId != 0) {
				pagedResult = assignShiftRepo.assignShiftReport(searchKey, projectId, shiftId, status, companyId,
						paging);
			} else if (projectId != null && projectId != 0) {
				pagedResult = assignShiftRepo.assignShiftReportProjectbased(searchKey, projectId, status, companyId,
						paging);
			} else if (shiftId != null && shiftId != 0) {
				pagedResult = assignShiftRepo.assignShiftReportShiftbased(searchKey, shiftId, status, companyId,
						paging);

			} else {
				pagedResult = assignShiftRepo.allAssignShiftAllReports(searchKey, status, companyId, paging);
			}
		}
		return mapDataShift(pagedResult);
	}

	public Map<String, Object> mapDataShift(Page<AssignShift> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<ShiftReportDTO> assignShift = pagedResult.stream().map(assignShiftEntity -> {
			ShiftReportDTO model = new ShiftReportDTO();
			model.setEmployeeId(assignShiftEntity.getEmployee().getId());
			model.setEmployeeName(assignShiftEntity.getEmployee().getFirstName() + " "
					+ assignShiftEntity.getEmployee().getLastName());
			model.setDesignation(assignShiftEntity.getEmployee().getDesignation().getDesignation());
			model.setDepartment(assignShiftEntity.getEmployee().getDepartment().getName());
			model.setEmailId(assignShiftEntity.getEmployee().getOfficalMail());
			Optional<Project> project = projectRepo.findById(assignShiftEntity.getProjectId());
			if (project.isPresent()) {
				model.setProjectName(project.get().getName());
			}
			model.setReportingManager(assignShiftEntity.getEmployee().getManager().getFirstName() + " "
					+ assignShiftEntity.getEmployee().getManager().getLastName());
			model.setShiftName(assignShiftEntity.getShift().getShiftName());
			model.setStartDate(assignShiftEntity.getFromDate());
			model.setEndDate(assignShiftEntity.getToDate());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, assignShift);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		logger.info("AssignShift map object is created for Paging");
		return response;
	}

	public List<ShiftReportDTO> getShiftReports(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId) {
		List<AssignShift> shiftreport;
		if (startDate != null && endDate != null) {
			if (projectId != null && shiftId != null && projectId != 0 && shiftId != 0) {
				shiftreport = assignShiftRepo.findShiftReportSPDatebased(projectId, shiftId, startDate, endDate,
						searchKey, companyId);
			} else if (projectId != null && projectId != 0) {
				shiftreport = assignShiftRepo.findShiftReportDateProjectbased(projectId, startDate, endDate, searchKey,
						companyId);
			} else if (shiftId != null && shiftId != 0) {
				shiftreport = assignShiftRepo.findShiftReportDateShiftbased(shiftId, startDate, endDate, searchKey,
						companyId);
			} else {
				shiftreport = assignShiftRepo.findShiftReportDatebased(startDate, endDate, searchKey, companyId);
			}
		} else {
			if (projectId != null && shiftId != null && projectId != 0 && shiftId != 0) {
				shiftreport = assignShiftRepo.findShiftReportSPbased(projectId, shiftId, searchKey, companyId);
			} else if (projectId != null && projectId != 0) {
				shiftreport = assignShiftRepo.findShiftReportPbased(projectId, searchKey, companyId);
			} else if (shiftId != null && shiftId != 0) {
				shiftreport = assignShiftRepo.findShiftReportSbased(shiftId, searchKey, companyId);
			} else {
				shiftreport = assignShiftRepo.findShiftAllReport(searchKey, companyId);
			}
		}
		List<ShiftReportDTO> assignShift = new ArrayList<>();
		if (shiftreport.isEmpty()) {
			return assignShift;
		}
		assignShift = shiftreport.stream().map(assignShiftEntity -> {
			ShiftReportDTO model = new ShiftReportDTO();
			model.setEmployeeId(assignShiftEntity.getEmployee().getId());
			model.setEmployeeName(assignShiftEntity.getEmployee().getFirstName() + " "
					+ assignShiftEntity.getEmployee().getLastName());
			model.setDesignation(assignShiftEntity.getEmployee().getDesignation().getDesignation());
			model.setDepartment(assignShiftEntity.getEmployee().getDepartment().getName());
			model.setEmailId(assignShiftEntity.getEmployee().getOfficalMail());
			Optional<Project> project = projectRepo.findById(assignShiftEntity.getProjectId());
			if (project.isPresent()) {
				model.setProjectName(project.get().getName());
			}
			model.setReportingManager(assignShiftEntity.getEmployee().getManager().getFirstName() + " "
					+ assignShiftEntity.getEmployee().getManager().getLastName());
			model.setShiftName(assignShiftEntity.getShift().getShiftName());
			return model;
		}).collect(Collectors.toList());
		return assignShift;
	}

	@Override
	public InputStreamResource getShiftExcelReportShifts(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId) throws IOException {
		List<ShiftReportDTO> assignShift = getShiftReports(projectId, shiftId, startDate, endDate, searchKey,
				companyId);
		ByteArrayInputStream in = excelGenerator.ShiftToExcel(assignShift);
		logger.info("get AllExcel Report Assigned Shifts from DB");
		return new InputStreamResource(in);

	}

	@Override
	public InputStreamResource getAllpdfReportShifts(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId) throws Exception {
		List<ShiftReportDTO> assignShift = getShiftReports(projectId, shiftId, startDate, endDate, searchKey,
				companyId);
		ByteArrayInputStream bis = pdfReportGenerator.shiftReport(assignShift, companyId);
		logger.info("get Allpdf Report Assigned Shifts from DB");
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getAllshiftListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws IOException {
		List<ShiftReportDTO> allshiftDetails = getShiftReports(pagingDto.getProjectId(), pagingDto.getShiftId(),
				pagingDto.getStartDate(), pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Email ID", "Designation", "Department", "Project Name",
				"Shift Name", "Reporting Manager" };
		String[] nameMapping = { "employeeId", "employeeName", "EmailId", "designation", "department", "projectName",
				"shiftName", "reportingManager" };
		csvWriter.writeHeader(csvHeader);
		for (ShiftReportDTO att : allshiftDetails) {
			csvWriter.write(att, nameMapping);
		}
		logger.info("csv Report for Assigned Shifts are generated");
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public Map<String, Object> getAllLeaveReports(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String startDate, String endDate, String companyId) throws ParseException {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmpLeave> pagedResult = null;
		String status = Constants.APPROVED;
		if (startDate != null && endDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			Date start = simpleDateFormat.parse(startDate);
			Date end = simpleDateFormat.parse(endDate);
			pagedResult = empLeaveRepo.allEmpLeaveReport(searchKey, companyId, paging, start, end, status);
		} else {
			pagedResult = empLeaveRepo.empLeaveReport(searchKey, status, companyId, paging);
		}

		if (pagedResult.hasContent()) {
			logger.info("For EmpLeave Records page is created");
			return mapDataLeave(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapDataLeave(Page<EmpLeave> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<LeaveReportDTO> leaveModels;
		leaveModels = pagedResult.stream().map(leaveEntity -> {
			LeaveReportDTO model1 = new LeaveReportDTO();
			model1.setEmployeeId(leaveEntity.getEmployee().getId());
			model1.setFromDate(leaveEntity.getStartDate());
			model1.setToDate(leaveEntity.getEndDate());
			model1.setLeaveDays(leaveEntity.getTotalDays());
			model1.setAppliedDate(leaveEntity.getLeaveApplyDate());
			model1.setLeaveType(leaveEntity.getLeaveType1().getLeaveType());
			model1.setEmployeeName(
					leaveEntity.getEmployee().getFirstName() + " " + leaveEntity.getEmployee().getLastName());
			return model1;
		}).collect(Collectors.toList());

		if (leaveModels.isEmpty()) {
			return new HashMap<>();
		} else {
			response.put(Constants.DATA, leaveModels);
			response.put(Constants.PAGEINDEX, pagedResult.getNumber());
			response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
			response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
			return response;
		}
	}

	// @Override
	public List<LeaveReportDTO> getLeaveReports(String startDate, String endDate, String searchKey, String companyId)
			throws ParseException {

		String status = Constants.APPROVED;
		List<EmpLeave> shiftreport;
		if (startDate != null && endDate != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			Date start = simpleDateFormat.parse(startDate);
			Date end = simpleDateFormat.parse(endDate);
			shiftreport = empLeaveRepo.allEmpLeaveReportsDateBased(start, end, status, searchKey, companyId);
		} else {
			shiftreport = empLeaveRepo.allEmpLeaveReports(status, searchKey, companyId);
		}
		List<LeaveReportDTO> leaveModels = new ArrayList<>();
		if (shiftreport.isEmpty()) {
			return leaveModels;
		}
		leaveModels = shiftreport.stream().map(leaveEntity -> {
			LeaveReportDTO model = new LeaveReportDTO();
			model.setEmployeeId(leaveEntity.getEmployee().getId());
			model.setFromDate(leaveEntity.getStartDate());
			model.setToDate(leaveEntity.getEndDate());
			model.setLeaveDays(leaveEntity.getTotalDays());
			model.setAppliedDate(leaveEntity.getLeaveApplyDate());
			model.setLeaveType(leaveEntity.getLeaveType1().getLeaveType());
			model.setEmployeeName(
					leaveEntity.getEmployee().getFirstName() + " " + leaveEntity.getEmployee().getLastName());
			return model;
		}).collect(Collectors.toList());
		return leaveModels;
	}

	@Override
	public InputStreamResource getLeaveExcelReport(String startDate, String endDate, String searchKey, String companyId)
			throws Exception {
		List<LeaveReportDTO> leaveModels = getLeaveReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream in = excelGenerator.LeaveToExcel(leaveModels);
		logger.info("Excel Report for employees leaves are generated");
		return new InputStreamResource(in);
	}

	@Override
	public InputStreamResource getLeavepdfReport(String startDate, String endDate, String searchKey, String companyId)
			throws Exception {
		List<LeaveReportDTO> leaveModels = getLeaveReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream bis = pdfReportGenerator.leaveReport(leaveModels, companyId);
		logger.info("pdf Report for employees leaves are generated");
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getAllleaveListCsv(HttpServletResponse response, ReportPageDTO pagingDto, String companyId)
			throws Exception {
		List<LeaveReportDTO> leaveModels = getLeaveReports(pagingDto.getStartDate(), pagingDto.getEndDate(),
				pagingDto.getSearchKey(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Applied Date", "Leave Type", "From Date", "To Date",
				"Leave Days" };
		String[] nameMapping = { "employeeId", "employeeName", "csvAppliedDate", "leaveType", "csvFromDate",
				"csvToDate", "leaveDays" };
		csvWriter.writeHeader(csvHeader);
		for (LeaveReportDTO att : leaveModels) {
			att.setCsvFromDate(dateUtil.changeDateFormat(att.getFromDate()));
			att.setCsvAppliedDate(dateUtil.changeDateFormat(att.getAppliedDate()));
			att.setCsvToDate(dateUtil.changeDateFormat(att.getToDate()));
			csvWriter.write(att, nameMapping);
		}
		logger.info("csv Report for employees leaves are generated");
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public String currentDateandTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDate = formatter.format(date);
		logger.info("currentDateandTime:{}", currentDate);
		return currentDate;
	}

	// Attendance Reports

	@Override
	public Map<String, Object> getAttendanceReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, String companyId)
			throws ParseException {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<AttendanceInfo> pagedResult = null;
		if (startDate == null && endDate == null) {
			pagedResult = attendanceRepo.allAttendancePageReports(searchKey, companyId, paging);
		} else {
			pagedResult = attendanceRepo.getEmpAttDetailsBetweenDaysPaging(startDate, endDate, searchKey, companyId,
					paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list based on date");
			return mapDataAttendance(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public static Map<String, Object> mapDataAttendance(Page<AttendanceInfo> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info(" found get All Attendnace pagenation" + ":", pagedResult);
		List<AttendanceInfoDTO> attendanceInfoModel = pagedResult.stream().map(attendanceInfoEntity -> {
			AttendanceInfoDTO model = new AttendanceInfoDTO();
			BeanUtils.copyProperties(attendanceInfoEntity, model);
			model.setEmployee(attendanceInfoEntity.getEmployee().getFirstName() + " "
					+ attendanceInfoEntity.getEmployee().getLastName());
			model.setShift(attendanceInfoEntity.getShift().getShiftName());
			model.setEmpId(attendanceInfoEntity.getEmployee().getId());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendanceInfoModel);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	@Override
	public List<AttendanceInfoDTO> getAttendanceReports(String startDate, String endDate, String searchKey,
			String companyId) throws ParseException {
		List<AttendanceInfo> attInfo;
		if (startDate != null && endDate != null) {
			attInfo = attendanceRepo.getEmpAttDetailsBetweenDaysReports(startDate, endDate, searchKey, companyId);
		} else {
			attInfo = attendanceRepo.findAllReports(searchKey, companyId);
		}
		List<AttendanceInfoDTO> models = attInfo.stream().map(info -> {
			AttendanceInfoDTO model = new AttendanceInfoDTO();
			model.setEmpId(info.getEmployee().getId());
			model.setEmployee(info.getEmployee().getFirstName() + " " + info.getEmployee().getLastName());
			model.setInTime(info.getInTime());
			model.setDate(info.getDate());
			model.setShiftId(info.getShift().getId());
			model.setAttndsPercentage(info.getAttndsPercentage());
			model.setReason(info.getReason());
			model.setShift(info.getShift().getShiftName());
			model.setOutTime(info.getOutTime());
			model.setReason(info.getReason());
			model.setTotalHrs(info.getTotalHrs());
			model.setNoOfHrs(info.getNoOfHrs());
			model.setBreakHrs(info.getBreakHrs());
			return model;
		}).collect(Collectors.toList());
		return models;
	}

	@Override
	public InputStreamResource getAttendanceExcelReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception {
		List<AttendanceInfoDTO> list = getAttendanceReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream in = excelGenerator.attendanceInfoToExcel(list);
		logger.info(" All Emplooyee's Excel Report Attendance:{}", in);
		return new InputStreamResource(in);
	}

	@Override
	public InputStreamResource getAttendancepdfReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception {
		List<AttendanceInfoDTO> list = getAttendanceReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream bis = pdfReportGenerator.attendanceReport(list, companyId);
		logger.info(" All Emplooyee's Pdf Report Attendance:{}", bis);
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getAllAttendanceListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws Exception {
		List<AttendanceInfoDTO> allAttendenceDetails = getAttendanceReports(pagingDto.getStartDate(),
				pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Shift", "In Time", "Out Time", "Date", "Total Hours",
				"Work Hours", "Break Hours", "Reason", "Attendance Percentage" };
		String[] nameMapping = { "empId", "employee", "shift", "csvInTime", "csvOutTime", "csvDate", "totalHrs",
				"noOfHrs", "breakHrs", "reason", "attndsPercentage" };
		csvWriter.writeHeader(csvHeader);
		logger.info(" All Emplooyee's Csv Report Attendance");
		for (AttendanceInfoDTO att : allAttendenceDetails) {
			att.setCsvDate(dateUtil.changeDateFormatFromString(att.getDate()));
			att.setCsvInTime(dateUtil.changeDateFormatFromStringDateAndTime(att.getInTime()));
			att.setCsvOutTime(dateUtil.changeDateFormatFromStringDateAndTime(att.getOutTime()));
			csvWriter.write(att, nameMapping);
		}
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public Map<String, Object> getPerfomannceReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, String companyId)
			throws ParseException {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<PerfomanceResponceDTO> pagedResult = null;
		if (startDate != null && endDate != null) {
			Date startDate1 = StringToDateUtility.stringToDate(startDate);
			Date endDate1 = StringToDateUtility.stringToDate(endDate);
			pagedResult = performanceRepo.performanceReportByDates(searchKey, companyId, paging, startDate1, endDate1);

		} else {
			pagedResult = performanceRepo.performanceReport(searchKey, companyId, paging);

		}
		if (pagedResult.hasContent()) {
			logger.info("All Employee's Attendance list based on date");
			return mapDataPerfomance(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	public Map<String, Object> mapDataPerfomance(Page<PerfomanceResponceDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		logger.info("found get All Attendnace pagenation from DB");
		List<PerfomanceReportDTO> models = pagedResult.stream().map(entity -> {
			PerfomanceReportDTO model = new PerfomanceReportDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setDesignation(entity.getDesignation());
			model.setEmployeeName(entity.getFirstName() + " " + entity.getLastName());
			Date d = entity.getAssignDate();
			if (d != null) {
				LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int monthNumber = localDate.getMonthValue();
				String month = util.getMonthForInt(monthNumber - 1);
				model.setReviewMonth(month);
			}
			DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			if (entity.getReviewStart() != null && entity.getReviewEnd() != null) {
				String start = dateFormat.format(entity.getReviewStart());
				String end = dateFormat.format(entity.getReviewEnd());
				// model.setReviewPeriod(start.concat(" - ").concat(end));
				model.setReviewStart(start);
				model.setReviewEnd(end);
			}
			GoalCreation goalStatus = goalRepository.findByEmployeeId(entity.getEmployeeId());
			if (goalStatus != null) {
				model.setStatus(goalStatus.getStatus());
			}
			if (entity.getCompletedDate() != null) {
				String submited = dateFormat.format(entity.getCompletedDate());
				model.setSubmitedDate(submited);
			}
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, models);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	public List<PerfomanceReportDTO> getPerfomanceReports(String startDate, String endDate, String searchKey,
			String companyId) throws ParseException {
		List<PerfomanceResponceDTO> perfomanceReport = null;
		if (startDate != null && endDate != null) {

			Date startDate1 = StringToDateUtility.stringToDate(startDate);
			Date endDate1 = StringToDateUtility.stringToDate(endDate);
			perfomanceReport = performanceRepo.findperformanceReportByDates(startDate1, endDate1, searchKey, companyId);
		} else {

			perfomanceReport = performanceRepo.findperformanceReports(searchKey, companyId);

		}
		List<PerfomanceReportDTO> perfomance = new ArrayList<>();
		if (perfomanceReport.isEmpty()) {
			return perfomance;
		}
		perfomance = perfomanceReport.stream().map(entity -> {
			PerfomanceReportDTO model = new PerfomanceReportDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setDesignation(entity.getDesignation());
			model.setEmployeeName(entity.getFirstName() + " " + entity.getLastName());
			Date d = entity.getAssignDate();
			LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			int monthNumber = localDate.getMonthValue();
			String month = util.getMonthForInt(monthNumber - 1);
			model.setReviewMonth(month);
			DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			String start = dateFormat.format(entity.getReviewStart());
			String end = dateFormat.format(entity.getReviewEnd());
//			model.setReviewPeriod(start.concat(" - ").concat(end));
			try {
				model.setReviewPeriod(dateUtil.changeDateFormatFromString(start).concat(" - ")
						.concat(dateUtil.changeDateFormatFromString(end)));
			} catch (Exception e1) {
				logger.info("Error in converting the date");
			}
			if (entity.getCompletedDate() != null) {
				String submited = dateFormat.format(entity.getCompletedDate());
				try {
					model.setSubmitedDate(dateUtil.changeDateFormatFromString(submited));
				} catch (Exception e) {
					logger.info("Error in converting the date");
				}
			}
			model.setStatus(entity.getManagerStatus());
			model.setReviewStart(start);
			model.setReviewEnd(end);
			return model;
		}).collect(Collectors.toList());
		return perfomance;
	}

	@Override
	public InputStreamResource getPerfomanceExcelReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception {
		List<PerfomanceReportDTO> list = getPerfomanceReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream in = excelGenerator.PerfomanceToExcel(list);
		logger.info("All Emplooyee's Perfomance Excel Report:{}", in);
		return new InputStreamResource(in);
	}

	@Override
	public InputStreamResource getPerfomancepdfReport(String startDate, String endDate, String searchKey,
			String companyId) throws Exception {
		List<PerfomanceReportDTO> list = getPerfomanceReports(startDate, endDate, searchKey, companyId);
		ByteArrayInputStream bis = pdfReportGenerator.perfomanceReport(list, companyId);
		logger.info(" All Emplooyees Perfomance Pdf Report:{}", bis);
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getAllPerfomanceListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws IOException, ParseException {
		List<PerfomanceReportDTO> allPerfomanceDetails = getPerfomanceReports(pagingDto.getStartDate(),
				pagingDto.getEndDate(), pagingDto.getSearchKey(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Designation", "Review Month", "Submited Date",
				"Review Period", "Status" };
		String[] nameMapping = { "employeeId", "employeeName", "designation", "reviewMonth", "submitedDate",
				"reviewPeriod", "status" };
		csvWriter.writeHeader(csvHeader);
		logger.info(" All Emplooyee's Csv Report Perfomance");
		for (PerfomanceReportDTO att : allPerfomanceDetails) {
			csvWriter.write(att, nameMapping);
		}
		csvWriter.close();
		return csvWriter;
	}

	/**
	 * This method is used to show the report based on the salary range
	 * 
	 * @throws ParseException
	 */
	@Override
	public Map<String, Object> getAllEmployeeReportBasedOnSalaryRange(int pageIndex, int pageSize, String sortBy,
			String key, String orderBy, String status, String salaryRange, String fromDate, String toDate,
			Long departmentId, Long designationId, String companyId) throws ParseException {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<PayrollReportResponseDTO> pagedResult = null;

		// date def value
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = simpleDateFormat.parse("0000-00-00");
		Date endDate = simpleDateFormat.parse("0000-00-00");

		// dept and designation def value
		departmentId = (departmentId != null) ? departmentId : 0L;
		designationId = (designationId != null) ? designationId : 0L;

		// def salary
		Double startSalary = 0.0;
		Double endSalary = 0.0;

		Boolean isActive = Boolean.TRUE;

		if (status.equals("1") || status.equals("0")) { // find active and deactive record
			if (status.equals("1")) {
				isActive = Boolean.TRUE;
			}
			if (status.equals("0")) {
				isActive = Boolean.FALSE;
			}
			if (!fromDate.equals("") && !toDate.equals("")) {

				String[] split = fromDate.split("/");
				String fromMM = split[0];
				String fromYYYY = split[1];
				String fDate = fromYYYY + "-" + fromMM + "-" + "01";

				String[] split1 = toDate.split("/");
				String toMM = split1[0];
				String toYYYY = split1[1];
				String tDate = "";

				if (toMM.equals("02")) { // 28 days
					tDate = toYYYY + "-" + toMM + "-" + "28";
				} else if (toMM.equals("01") || toMM.equals("03") || toMM.equals("05") || toMM.equals("07")
						|| toMM.equals("08") || toMM.equals("10") || toMM.equals("12")) { // 31 days
					tDate = toYYYY + "-" + toMM + "-" + "31";
				} else if (toMM.equals("04") || toMM.equals("06") || toMM.equals("09") || toMM.equals("11")) {// 30 days
					tDate = toYYYY + "-" + toMM + "-" + "30";
				}
				startDate = simpleDateFormat.parse(fDate);
				endDate = simpleDateFormat.parse(tDate);

				// byDate
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportByDate(key, isActive, paging, startDate, endDate,
							companyId);
				}
				// bySalary - Date
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDate(key, isActive, startSalary, endSalary, paging,
							startDate, endDate, companyId);
				}
				// salary - departmentId - date
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDeptDate(key, isActive, startSalary, endSalary,
							departmentId, paging, startDate, endDate, companyId);
				}
				// salary - designation - date
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDesigDate(key, isActive, startSalary, endSalary,
							designationId, paging, startDate, endDate, companyId);
				}
				// departmentId - Date
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportDeptDate(key, isActive, departmentId, paging, startDate,
							endDate, companyId);
				}
				// departmetId - designationId -Date
				if (departmentId != 0L && salaryRange.equalsIgnoreCase("") && designationId != 0L) {
					pagedResult = employeeRepo.payrollReportDepDesigDate(key, isActive, departmentId, designationId,
							paging, startDate, endDate, companyId);
				}
				// designationId - Date
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					pagedResult = employeeRepo.payrollReportDesigDate(key, isActive, designationId, paging, startDate,
							endDate, companyId);
				}
				// salary - departmentId - designationId - Date
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDeptDesigDate(key, isActive, startSalary, endSalary,
							departmentId, designationId, paging, startDate, endDate, companyId);
				}
			} else {

				// without date
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportNoDate(key, isActive, companyId, paging);
				}
				// salary
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalaryNoDate(key, isActive, startSalary, endSalary,
							companyId, paging);
				}
				// salary - departmentId
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalDeptNoDate(key, isActive, startSalary, endSalary,
							departmentId, companyId, paging);
				}
				// salary - designation
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDesigNoDate(key, isActive, startSalary, endSalary,
							designationId, companyId, paging);
				}
				// departmentId
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportDeptNoDate(key, isActive, departmentId, companyId, paging);
				}
				// departmentId - designationId
				if (departmentId != 0L && salaryRange.equals("") && designationId != 0L) {
					pagedResult = employeeRepo.payrollReportDeptDesigNoDate(key, isActive, departmentId, designationId,
							companyId, paging);
				}
				// designation
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					pagedResult = employeeRepo.payrollReportDesigNoDate(key, isActive, designationId, companyId,
							paging);
				}
				// salary - departmentId - Designation
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDeptDesigNodate(key, isActive, startSalary, endSalary,
							departmentId, designationId, companyId, paging);
				}
			}
		}
		if (status.equals("")) { // all record both active and not active
			// isActive = Boolean.TRUE;No deed
			if (!fromDate.equals("") && !toDate.equals("")) {

				String[] split = fromDate.split("/");
				String fromMM = split[0];
				String fromYYYY = split[1];
				String fDate = fromYYYY + "-" + fromMM + "-" + "01";

				String[] split1 = toDate.split("/");
				String toMM = split1[0];
				String toYYYY = split1[1];
				String tDate = "";

				if (toMM.equals("02")) { // 28 days
					tDate = toYYYY + "-" + toMM + "-" + "28";
				} else if (toMM.equals("01") || toMM.equals("03") || toMM.equals("05") || toMM.equals("07")
						|| toMM.equals("08") || toMM.equals("10") || toMM.equals("12")) { // 31 days
					tDate = toYYYY + "-" + toMM + "-" + "31";
				} else if (toMM.equals("04") || toMM.equals("06") || toMM.equals("09") || toMM.equals("11")) {// 30 days
					tDate = toYYYY + "-" + toMM + "-" + "30";
				}
				startDate = simpleDateFormat.parse(fDate);
				endDate = simpleDateFormat.parse(tDate);

				// byDate
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportByDateAll(key, paging, startDate, endDate, companyId);
				}
				// bySalary - Date
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDateAll(key, startSalary, endSalary, paging,
							startDate, endDate, companyId);
				}
				// salary - departmentId - date
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDeptDateAll(key, startSalary, endSalary,
							departmentId, paging, startDate, endDate, companyId);
				}
				// salary - designation - date
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalaryDesigDateAll(key, startSalary, endSalary,
							designationId, paging, startDate, endDate, companyId);
				}
				// departmentId - Date
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportDeptDateAll(key, departmentId, paging, startDate, endDate,
							companyId);
				}
				// departmetId - designationId -Date
				if (departmentId != 0L && salaryRange.equalsIgnoreCase("") && designationId != 0L) {
					pagedResult = employeeRepo.payrollReportDepDesigDateAll(key, departmentId, designationId, paging,
							startDate, endDate, companyId);
				}
				// designationId - Date
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					pagedResult = employeeRepo.payrollReportDesigDateAll(key, designationId, paging, startDate, endDate,
							companyId);
				}
				// salary - departmentId - designationId - Date
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDeptDesigDateAll(key, startSalary, endSalary,
							departmentId, designationId, paging, startDate, endDate, companyId);
				}
			} else {

				// without date
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportNoDateAll(key, companyId, paging);
				}
				// salary
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalaryNoDateAll(key, startSalary, endSalary, companyId,
							paging);
				}
				// salary - departmentId
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportBySalDeptNoDateAll(key, startSalary, endSalary,
							departmentId, companyId, paging);
				}
				// salary - designation
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDesigNoDateAll(key, startSalary, endSalary,
							designationId, companyId, paging);
				}
				// departmentId
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					pagedResult = employeeRepo.payrollReportDeptNoDateAll(key, departmentId, companyId, paging);
				}
				// departmentId - designationId
				if (departmentId != 0L && salaryRange.equals("") && designationId != 0L) {
					pagedResult = employeeRepo.payrollReportDeptDesigNoDateAll(key, departmentId, designationId,
							companyId, paging);
				}
				// designation
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					pagedResult = employeeRepo.payrollReportDesigNoDateAll(key, designationId, companyId, paging);
				}
				// salary - departmentId - Designation
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					pagedResult = employeeRepo.payrollReportSalDeptDesigNodateAll(key, startSalary, endSalary,
							departmentId, designationId, companyId, paging);
				}
			}
		}

		if (pagedResult.hasContent()) {
			return mapDataSalary(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	private Map<String, Object> mapDataSalary(Page<PayrollReportResponseDTO> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<PayrollReportResponseDTO> models = pagedResult.stream().map(entity -> {
			PayrollReportResponseDTO model = new PayrollReportResponseDTO();
			model.setEmployeeId(entity.getEmployeeId());
			if (entity.getCtc() != null) {
				model.setCtc(entity.getCtc());
				Double monthlySalary = Precision.round(entity.getCtc() / 12, 2);
				model.setMonthlySalary(monthlySalary);
			}
			model.setFirstName(entity.getFirstName());
			model.setLastName(entity.getLastName());
			Optional<Employee> empId = employeeRepo.findById(entity.getEmployeeId());
			if (empId.isPresent()) {
				Employee employee = empId.get();
				String departmentName = employee.getDepartment().getName();
				String designationName = employee.getDesignation().getDesignation();
				model.setDepartmentName(departmentName);
				model.setDesignationName(designationName);
			}
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, models);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	/**
	 * payroll excel report generate
	 * 
	 * @throws ParseException
	 */
	@Override
	public InputStreamResource getPayrollExcelReport(String key, String status, String salaryRange, String fromDate,
			String toDate, Long departmentId, Long designationId, String companyId) throws IOException, ParseException {

		List<PayrollReportResponseDTO> list = getPayrollReportsList(key, status, salaryRange, fromDate, toDate,
				departmentId, designationId, companyId);
		ByteArrayInputStream in = ExcelGenerator.payrollToExcel(list);
		logger.info("All Emplooyee's Payroll Excel Report:{}", in);
		return new InputStreamResource(in);
	}

	// called here
	private List<PayrollReportResponseDTO> getPayrollReportsList(String key, String status, String salaryRange,
			String fromDate, String toDate, Long departmentId, Long designationId, String companyId)
			throws ParseException {

		List<PayrollReportResponseDTO> payrollReportList = null;
		// added---
		// date def value
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = simpleDateFormat.parse("0000-00-00");
		Date endDate = simpleDateFormat.parse("0000-00-00");

		// dept and designation def value
		departmentId = (departmentId != null) ? departmentId : 0L;
		designationId = (designationId != null) ? designationId : 0L;

		// def salary
		Double startSalary = 0.0;
		Double endSalary = 0.0;

		Boolean isActive = Boolean.TRUE;

		if (status.equals("1") || status.equals("0")) { // find active and deactive record
			if (status.equals("1")) {
				isActive = Boolean.TRUE;
			}
			if (status.equals("0")) {
				isActive = Boolean.FALSE;
			}
			if (!fromDate.equals("") && !toDate.equals("")) {

				String[] split = fromDate.split("/");
				String fromMM = split[0];
				String fromYYYY = split[1];
				String fDate = fromYYYY + "-" + fromMM + "-" + "01";

				String[] split1 = toDate.split("/");
				String toMM = split1[0];
				String toYYYY = split1[1];
				String tDate = "";

				if (toMM.equals("02")) { // 28 days
					tDate = toYYYY + "-" + toMM + "-" + "28";
				} else if (toMM.equals("01") || toMM.equals("03") || toMM.equals("05") || toMM.equals("07")
						|| toMM.equals("08") || toMM.equals("10") || toMM.equals("12")) { // 31 days
					tDate = toYYYY + "-" + toMM + "-" + "31";
				} else if (toMM.equals("04") || toMM.equals("06") || toMM.equals("09") || toMM.equals("11")) {// 30 days
					tDate = toYYYY + "-" + toMM + "-" + "30";
				}
				startDate = simpleDateFormat.parse(fDate);
				endDate = simpleDateFormat.parse(tDate);

				// byDate
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportByDate(key, isActive, startDate, endDate, companyId);
				}
				// bySalary - Date
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDate(key, isActive, startSalary, endSalary,
							startDate, endDate, companyId);
				}
				// salary - departmentId - date
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDeptDate(key, isActive, startSalary,
							endSalary, departmentId, startDate, endDate, companyId);
				}
				// salary - designation - date
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDesigDate(key, isActive, startSalary,
							endSalary, designationId, startDate, endDate, companyId);
				}
				// departmentId - Date
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportDeptDate(key, isActive, departmentId, startDate,
							endDate, companyId);
				}
				// departmetId - designationId -Date
				if (departmentId != 0L && salaryRange.equalsIgnoreCase("") && designationId != 0L) {
					payrollReportList = employeeRepo.payrollReportDepDesigDate(key, isActive, departmentId,
							designationId, startDate, endDate, companyId);
				}
				// designationId - Date
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					payrollReportList = employeeRepo.payrollReportDesigDate(key, isActive, designationId, startDate,
							endDate, companyId);
				}
				// salary - departmentId - designationId - Date
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDeptDesigDate(key, isActive, startSalary,
							endSalary, departmentId, designationId, startDate, endDate, companyId);
				}
			} else {

				// without date
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportNoDate(key, isActive, companyId);
				}
				// salary
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalaryNoDate(key, isActive, startSalary, endSalary,
							companyId);
				}
				// salary - departmentId
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalDeptNoDate(key, isActive, startSalary, endSalary,
							departmentId, companyId);
				}
				// salary - designation
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDesigNoDate(key, isActive, startSalary, endSalary,
							designationId, companyId);
				}
				// departmentId
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportDeptNoDate(key, isActive, departmentId, companyId);
				}
				// departmentId - designationId
				if (departmentId != 0L && salaryRange.equals("") && designationId != 0L) {
					payrollReportList = employeeRepo.payrollReportDeptDesigNoDate(key, isActive, departmentId,
							designationId, companyId);
				}
				// designation
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					payrollReportList = employeeRepo.payrollReportDesigNoDate(key, isActive, designationId, companyId);
				}
				// salary - departmentId - Designation
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDeptDesigNodate(key, isActive, startSalary,
							endSalary, departmentId, designationId, companyId);
				}
			}
		}
		if (status.equals("")) { // all record both active and not active
			// isActive = Boolean.TRUE;No deed
			if (!fromDate.equals("") && !toDate.equals("")) {

				String[] split = fromDate.split("/");
				String fromMM = split[0];
				String fromYYYY = split[1];
				String fDate = fromYYYY + "-" + fromMM + "-" + "01";

				String[] split1 = toDate.split("/");
				String toMM = split1[0];
				String toYYYY = split1[1];
				String tDate = "";

				if (toMM.equals("02")) { // 28 days
					tDate = toYYYY + "-" + toMM + "-" + "28";
				} else if (toMM.equals("01") || toMM.equals("03") || toMM.equals("05") || toMM.equals("07")
						|| toMM.equals("08") || toMM.equals("10") || toMM.equals("12")) { // 31 days
					tDate = toYYYY + "-" + toMM + "-" + "31";
				} else if (toMM.equals("04") || toMM.equals("06") || toMM.equals("09") || toMM.equals("11")) {// 30 days
					tDate = toYYYY + "-" + toMM + "-" + "30";
				}
				startDate = simpleDateFormat.parse(fDate);
				endDate = simpleDateFormat.parse(tDate);

				// byDate
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportByDateAll(key, startDate, endDate, companyId);
				}
				// bySalary - Date
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDateAll(key, startSalary, endSalary,
							startDate, endDate, companyId);
				}
				// salary - departmentId - date
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDeptDateAll(key, startSalary, endSalary,
							departmentId, startDate, endDate, companyId);
				}
				// salary - designation - date
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalaryDesigDateAll(key, startSalary, endSalary,
							designationId, startDate, endDate, companyId);
				}
				// departmentId - Date
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportDeptDateAll(key, departmentId, startDate, endDate,
							companyId);
				}
				// departmetId - designationId -Date
				if (departmentId != 0L && salaryRange.equalsIgnoreCase("") && designationId != 0L) {
					payrollReportList = employeeRepo.payrollReportDepDesigDateAll(key, departmentId, designationId,
							startDate, endDate, companyId);
				}
				// designationId - Date
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					payrollReportList = employeeRepo.payrollReportDesigDateAll(key, designationId, startDate, endDate,
							companyId);
				}
				// salary - departmentId - designationId - Date
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDeptDesigDateAll(key, startSalary, endSalary,
							departmentId, designationId, startDate, endDate, companyId);
				}
			} else {

				// without date
				if (salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportNoDateAll(key, companyId);
				}
				// salary
				if (!salaryRange.equals("") && departmentId == 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalaryNoDateAll(key, startSalary, endSalary,
							companyId);
				}
				// salary - departmentId
				if (!salaryRange.equals("") && departmentId != 0L && designationId == 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportBySalDeptNoDateAll(key, startSalary, endSalary,
							departmentId, companyId);
				}
				// salary - designation
				if (!salaryRange.equals("") && departmentId == 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDesigNoDateAll(key, startSalary, endSalary,
							designationId, companyId);
				}
				// departmentId
				if (departmentId != 0L && salaryRange.equals("") && designationId == 0L) {
					payrollReportList = employeeRepo.payrollReportDeptNoDateAll(key, departmentId, companyId);
				}
				// departmentId - designationId
				if (departmentId != 0L && salaryRange.equals("") && designationId != 0L) {
					payrollReportList = employeeRepo.payrollReportDeptDesigNoDateAll(key, departmentId, designationId,
							companyId);
				}
				// designation
				if (designationId != 0L && departmentId == 0L && salaryRange.equals("")) {
					payrollReportList = employeeRepo.payrollReportDesigNoDateAll(key, designationId, companyId);
				}
				// salary - departmentId - Designation
				if (!salaryRange.equals("") && departmentId != 0L && designationId != 0L) {
					String[] splitSal = salaryRange.split("-");
					String fromSalary = splitSal[0];
					String toSalary = splitSal[1];
					startSalary = Double.parseDouble(fromSalary) * 12;
					endSalary = Double.parseDouble(toSalary) * 12;
					payrollReportList = employeeRepo.payrollReportSalDeptDesigNodateAll(key, startSalary, endSalary,
							departmentId, designationId, companyId);
				}
			}
		}
		// ended---
		List<PayrollReportResponseDTO> report = new ArrayList<>();
		if (payrollReportList.isEmpty()) {
			return report;
		}

		report = payrollReportList.stream().map(entity -> {

			PayrollReportResponseDTO model = new PayrollReportResponseDTO();
			model.setEmployeeId(entity.getEmployeeId());
			if (entity.getCtc() != null) {
				model.setCsvCtc(dateUtil.formattedValue(entity.getCtc()));
				Double sal = entity.getCtc() / 12;
				model.setCsvMonthlySalary(dateUtil.formattedValue(sal));
			}
			Optional<Employee> empId = employeeRepo.findById(entity.getEmployeeId());
			if (empId.isPresent()) {
				Employee employee = empId.get();
				String departmentName = employee.getDepartment().getName();
				String designationName = employee.getDesignation().getDesignation();
				model.setDepartmentName(departmentName);
				model.setDesignationName(designationName);
			}
			model.setFirstName(entity.getFirstName());
			model.setLastName(entity.getLastName());
			return model;
		}).collect(Collectors.toList());
		return report;
	}

	/**
	 * Method to generate the pdf for payroll report
	 * 
	 * @throws ParseException
	 * @throws IOException
	 * @throws DocumentException
	 * @throws MalformedURLException
	 */
	@Override
	public InputStreamResource getPayrollPdfReport(String key, String status, String salaryRange, String fromDate,
			String toDate, Long departmentId, Long designationId, String companyId)
			throws ParseException, MalformedURLException, DocumentException, IOException {

		List<PayrollReportResponseDTO> list = getPayrollReportsList(key, status, salaryRange, fromDate, toDate,
				departmentId, designationId, companyId);
		ByteArrayInputStream bis = pdfReportGenerator.payrollPDFReport(list, companyId);
		logger.info(" All Emplooyee's Pdf Report for Payroll:{}", bis);
		return new InputStreamResource(bis);
	}

	/*
	 * This method is used to download the csv file
	 */
	@Override
	public ICsvBeanWriter csvFileForPayrollReport(HttpServletResponse response, PayrollReportPaginationDTO pagingDto,
			String companyId) throws IOException, ParseException {
		List<PayrollReportResponseDTO> list = getPayrollReportsList(pagingDto.getSearchKey(), pagingDto.getStatus(),
				pagingDto.getSalaryRange(), pagingDto.getFromDate(), pagingDto.getToDate(), pagingDto.getDepartmentId(),
				pagingDto.getDesignationId(), companyId);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Department", "Designation", "Ctc", "Gross Salary" };
		String[] nameMapping = { "employeeId", "firstName", "departmentName", "designationName", "csvCtc",
				"csvMonthlySalary" };
		csvWriter.writeHeader(csvHeader);
		logger.info(" All Emplooyee's Csv Report Payroll");
		for (PayrollReportResponseDTO payroll : list) {
			csvWriter.write(payroll, nameMapping);
		}
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public Map<String, Object> getEmploymentTypeReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, Long employmentTypeId, String companyId)
			throws ParseException {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmployeePageDTO> pagedResult = null;
		Date startDate1 = new Date();
		if (startDate == null) {
			startDate1 = null;
		} else if (!startDate.isEmpty()) {
			startDate1 = StringToDateUtility.stringToDate(startDate);
		}
		Date endDate1 = new Date();
		if (endDate == null) {
			endDate1 = null;
		} else if (!endDate.isEmpty()) {
			endDate1 = StringToDateUtility.stringToDate(endDate);

		}
		pagedResult = employeeRepo.employmentTypeReport(searchKey, companyId, paging);
		if (startDate != null && endDate != null) {
			pagedResult = employeeRepo.employmentTypeReportByDates(searchKey, companyId, startDate1, endDate1, paging);
		} else if (startDate != null && endDate != null && employmentTypeId != null) {
			pagedResult = employeeRepo.employmentTypeReportByDatesAndEmpType(searchKey, companyId, startDate1, endDate1,
					employmentTypeId, paging);
		} else if (startDate != null && employmentTypeId != null && endDate == null) {
			pagedResult = employeeRepo.employmentTypeReportByStartDatesAndEmpType(searchKey, companyId, startDate1,
					employmentTypeId, paging);
		} else if (employmentTypeId != null && !employmentTypeId.equals("") && startDate == null && endDate == null) {
			pagedResult = employeeRepo.employmentTypeReportByEmpType(searchKey, companyId, employmentTypeId, paging);
		}
		if (pagedResult.hasContent()) {
			logger.info("All Employee's employementType list");
			return mapDataEmployementType(pagedResult);
		} else {
			return new HashMap<>();
		}

	}

	public Map<String, Object> mapDataEmployementType(Page<EmployeePageDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
		List<EmployeeReportDTO> employeeModels = pagedResult.stream().map(employeeEntity -> {
			EmployeeReportDTO model = new EmployeeReportDTO();
			model.setEmployeeId(employeeEntity.getId());
			model.setEmployeeName(employeeEntity.getFirstName() + " " + employeeEntity.getLastName());
			model.setDesignation(employeeEntity.getDesignationName());
			model.setAction(employeeEntity.getIsActive());
			model.setEmploymentType(employeeEntity.getEmploymentType());
			if (employeeEntity.getEmpTypeStartDate() != null) {
				model.setEmpTypeStartDate(dateFormat.format(employeeEntity.getEmpTypeStartDate()));
			}
			if (employeeEntity.getEmpTypeEndDate() != null) {
				model.setEmpTypeEndDate(dateFormat.format(employeeEntity.getEmpTypeEndDate()));
			}
			String name = "100x100";
			ProfileImageDTO copyProfileImage = employeeServiceUtil.copyProfileImage(employeeEntity.getId(), name);
			model.setProfileimage(copyProfileImage);
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, employeeModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	public List<EmployeeReportDTO> getPromotionalReport(String startDate, String endDate, Long employmentTypeId,
			String companyId, String searchKey) throws IOException, ParseException {
		List<EmployeePageDTO> empList = null;
		List<EmployeeReportDTO> empTypeList = null;
		Date startDate1 = new Date();
		if (startDate == null) {
			startDate1 = null;
		} else if (!startDate.isEmpty()) {
			startDate1 = StringToDateUtility.stringToDate(startDate);
		}
		Date endDate1 = new Date();
		if (endDate == null) {
			endDate1 = null;
		} else if (!endDate.isEmpty()) {
			endDate1 = StringToDateUtility.stringToDate(endDate);

		}
		if (employmentTypeId.equals("")) {
			employmentTypeId = null;
		}

		if (startDate != null && endDate != null && employmentTypeId == null) {
			empList = employeeRepo.employmentTypeReportByDates(searchKey, companyId, startDate1, endDate1);
		} else if (startDate != null && endDate != null && employmentTypeId != null) {
			empList = employeeRepo.employmentTypeReportByDatesAndEmpType(searchKey, companyId, startDate1, endDate1,
					employmentTypeId);
		} else if (startDate != null && employmentTypeId != null && endDate == null) {
			empList = employeeRepo.employmentTypeReportByStartDatesAndEmpType(searchKey, companyId, startDate1,
					employmentTypeId);
		} else if (employmentTypeId != null && startDate == null && endDate == null) {
			empList = employeeRepo.employmentTypeReportByEmpType(searchKey, companyId, employmentTypeId);
		} else if (startDate == null && employmentTypeId == null && endDate == null) {
			empList = employeeRepo.employmentTypeReport(searchKey, companyId);
		}
		if (empList == null) {
			return empTypeList = new ArrayList<>();
		}
		empTypeList = empList.stream().map(empType -> {
			EmployeeReportDTO model = new EmployeeReportDTO();
			model.setEmployeeId(empType.getId());
			model.setEmployeeName(empType.getFirstName() + " " + empType.getLastName());
			if (Boolean.TRUE.equals(empType.getIsActive())) {
				model.setIsActive(Constants.ACTIVE);
			} else {
				model.setIsActive(Constants.INACTIVE);
			}
			model.setDesignation(empType.getDesignationName());
//			model.setEmploymentType(empType.getEmploymentType());
			DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			if (empType.getEmpTypeStartDate() != null) {
				String start = dateFormat.format(empType.getEmpTypeStartDate());
				model.setEmpTypeStartDate(start);
			} else {
				model.setEmpTypeStartDate("");
			}
			if (empType.getEmpTypeEndDate() != null) {
				String end = dateFormat.format(empType.getEmpTypeEndDate());
				model.setEmpTypeEndDate(end);
			} else {
				model.setEmpTypeStartDate("");
			}
			return model;
		}).collect(Collectors.toList());
		return empTypeList;

	}

	/**
	 * Promotional excel report generate
	 * 
	 * @throws Exception
	 */
	@Override
	public InputStreamResource getPromotionalExcelReport(String startDate, String endDate, Long employmentTypeId,
			String companyId, String searchKey) throws Exception {

		List<EmployeeReportDTO> list = getPromotionalReport(startDate, endDate, employmentTypeId, companyId, searchKey);
		ByteArrayInputStream in = excelGenerator.employeePromotionalToExcel(list);
		logger.info("All Emplooyee's Promotional Excel Report:{}", in);
		return new InputStreamResource(in);
	}

	/**
	 * Promotional excel report generate
	 * 
	 * @throws Exception
	 */
	@Override
	public InputStreamResource getPromotionalPdfReport(String startDate, String endDate, Long employmentTypeId,
			String companyId, String searchKey) throws IOException, ParseException, Exception {
		List<EmployeeReportDTO> onboardReport = getPromotionalReport(startDate, endDate, employmentTypeId, companyId,
				searchKey);
		ByteArrayInputStream bis = pdfReportGenerator.employeePromotionalToPdf(onboardReport, companyId);
		logger.info("getAllpdfReport for Promotional Employees");
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getEmployeesPromotionalListCsv(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws IOException, ParseException {
		List<EmployeeReportDTO> allemployeeDetails = getPromotionalReport(pagingDto.getStartDate(),
				pagingDto.getEndDate(), pagingDto.getEmploymentTypeId(), companyId, pagingDto.getSearchKey());
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Employement Type", "Designation", "Start Date",
				"End Date" };
		String[] nameMapping = { "employeeId", "employeeName", "employmentType", "designation", "empTypeStartDate",
				"empTypeEndDate" };
		csvWriter.writeHeader(csvHeader);
		for (EmployeeReportDTO att : allemployeeDetails) {
			csvWriter.write(att, nameMapping);
		}
		logger.info("csv Report for Promotional employees  are generated");
		csvWriter.close();
		return csvWriter;
	}

	@Override
	public Map<String, Object> getAllExitEmployeeReports(Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String startDate, String endDate, String companyId) throws Exception {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<EmployeePageDTO> pagedResult = null;
		Date startDate1 = new Date();
		if (startDate == null) {
			startDate1 = null;
		} else if (!startDate.isEmpty()) {
			startDate1 = StringToDateUtility.stringToDate(startDate);
		}
		Date endDate1 = new Date();
		if (endDate == null) {
			endDate1 = null;
		} else if (!endDate.isEmpty()) {
			endDate1 = StringToDateUtility.stringToDate(endDate);

		}
		if (startDate != null && endDate != null) {
			pagedResult = employeeRepo.allEmployeeExitReport(searchKey, companyId, startDate1, endDate1, paging);
		} else {
			pagedResult = employeeRepo.allEmployeeExitReport(searchKey, companyId, paging);
		}

		if (pagedResult.hasContent()) {
			logger.info("All Employee's employementType list");
			return mapDataExitType(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	private Map<String, Object> mapDataExitType(Page<EmployeePageDTO> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
		List<ExitReportDTO> employeeModels = pagedResult.stream().map(employeeEntity -> {
			ExitReportDTO model = new ExitReportDTO();
			model.setEmployeeId(employeeEntity.getId());
			model.setEmployeeName(employeeEntity.getFirstName() + " " + employeeEntity.getLastName());
			model.setEmpDesignation(employeeEntity.getDesignationName());
			if (employeeEntity.getJoiningDate() != null) {
				model.setJoiningDate(dateFormat.format(employeeEntity.getJoiningDate()));
			}
			if (employeeEntity.getExitDate() != null) {
				model.setExitDate(dateFormat.format(employeeEntity.getExitDate()));
			}
			/*
			 * String name = "100x100"; ProfileImageDTO copyProfileImage =
			 * employeeServiceUtil.copyProfileImage(employeeEntity.getId(), name);
			 * model.setProfileimage(copyProfileImage);
			 */
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, employeeModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}

	public List<ExitReportDTO> getExitReport(String startDate, String endDate, String companyId, String searchKey)
			throws IOException, ParseException {
		List<EmployeePageDTO> empList = null;
		List<ExitReportDTO> empTypeList = new ArrayList<>();
		Date startDate1 = new Date();
		if (startDate == null) {
			startDate1 = null;
		} else if (!startDate.isEmpty()) {
			startDate1 = StringToDateUtility.stringToDate(startDate);
		}
		Date endDate1 = new Date();
		if (endDate == null) {
			endDate1 = null;
		} else if (!endDate.isEmpty()) {
			endDate1 = StringToDateUtility.stringToDate(endDate);

		}
		if (startDate != null && endDate != null) {
			empList = employeeRepo.allEmployeeExitReport(searchKey, companyId, startDate1, endDate1);
		} else {
			empList = employeeRepo.allEmployeeExitReport(searchKey, companyId);
		}
		if (empList == null) {
			return empTypeList;
		}
		empTypeList = empList.stream().map(empType -> {
			ExitReportDTO model = new ExitReportDTO();
			model.setEmployeeId(empType.getId());
			model.setEmployeeName(empType.getFirstName() + " " + empType.getLastName());

			model.setEmpDesignation(empType.getDesignationName());
			DateFormat dateFormat = new SimpleDateFormat(Constants.DATEFORMAT);
			if (empType.getJoiningDate() != null) {
				model.setJoiningDate(dateFormat.format(empType.getJoiningDate()));
			} else {
				model.setJoiningDate("");
			}
			if (empType.getExitDate() != null) {
				model.setExitDate(dateFormat.format(empType.getExitDate()));
			} else {
				model.setExitDate("");
			}
			return model;
		}).collect(Collectors.toList());
		return empTypeList;

	}

	@Override
	public InputStreamResource getAllExitEmployeeExcelReport(String startDate, String endDate, String companyId,
			String searchKey) throws Exception {
		List<ExitReportDTO> list = getExitReport(startDate, endDate, companyId, searchKey);
		ByteArrayInputStream in = excelGenerator.employeeExitToExcel(list);
		logger.info("All Emplooyee's Exit Excel Report:{}", in);
		return new InputStreamResource(in);
	}

	@Override
	public InputStreamResource getAllExitEmployeepdfReport(String startDate, String endDate, String companyId,
			String searchKey) throws Exception {
		List<ExitReportDTO> onboardReport = getExitReport(startDate, endDate, companyId, searchKey);
		ByteArrayInputStream bis = pdfReportGenerator.employeeExitToPdf(onboardReport, companyId);
		logger.info("getAllpdfReport for Exit Employees");
		return new InputStreamResource(bis);
	}

	@Override
	public ICsvBeanWriter getAllExitEmployeeExportToCSV(HttpServletResponse response, ReportPageDTO pagingDto,
			String companyId) throws Exception {
		List<ExitReportDTO> allemployeeDetails = getExitReport(pagingDto.getStartDate(), pagingDto.getEndDate(),
				companyId, pagingDto.getSearchKey());
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Employee ID", "Employee Name", "Designation", "Start Date", "End Date" };
		String[] nameMapping = { "employeeId", "employeeName", "empDesignation", "joiningDate", "exitDate" };
		csvWriter.writeHeader(csvHeader);
		for (ExitReportDTO att : allemployeeDetails) {
			csvWriter.write(att, nameMapping);
		}
		logger.info("csv Report for Exit employees are generated");
		csvWriter.close();
		return csvWriter;

	}

}
