package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.GoalCreationDTO;
import com.hrms.admin.dto.GoalCreationEmployeeDTO;
import com.hrms.admin.dto.GoalQuestionAnsReview;
import com.hrms.admin.entity.Department;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.GoalCreation;
import com.hrms.admin.entity.GoalQuestions;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;
import com.hrms.admin.repository.DepartmentRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.GoalCreationRepository;
import com.hrms.admin.service.GoalCreationService;
import com.hrms.admin.util.Constants;

@Service
public class GoalCreationServiceImpl implements GoalCreationService {

	private static final Logger logger = LoggerFactory.getLogger(GoalCreationServiceImpl.class);

	@Autowired
	private GoalCreationRepository goalCreationRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	@Override
	public List<EntityDTO> save(GoalCreationDTO model) {

		List<EntityDTO> list = new ArrayList<>();
		GoalCreation empId = goalCreationRepository.findByEmployeeId(model.getEmployeeId());
		if (empId != null) {
			logger.info("Goal is already  found with employeeId:{} ", model.getEmployeeId());
			return list;
		}
		GoalCreation goalEntity = new GoalCreation();

		goalEntity.setAssignDate(model.getAssignDate());
		goalEntity.setDepartmentName(model.getDepartmentName());
		goalEntity.setDueDate(model.getDueDate());
		goalEntity.setEmployeeId(model.getEmployeeId());
		goalEntity.setEmployeeName(model.getEmployeeName());
		goalEntity.setPeriod(model.getPeriod());
		goalEntity.setReviewEnd(model.getReviewEnd());
		goalEntity.setReviewStart(model.getReviewStart());
		goalEntity.setReviewManager(model.getReviewManager());
		goalEntity.setStatus(Constants.EMP_INPROGRESS);

		List<GoalQuestions> listQuesions = new ArrayList<>();
		for (GoalQuestionAnsReview q : model.getGoalQuestionsDto()) {
			GoalQuestions questionEntity = new GoalQuestions();
			questionEntity.setQuestion(q.getQuestion());
			listQuesions.add(questionEntity);
		}
		goalEntity.setGoalQuestions(listQuesions);

		GoalCreation goalCreation = goalCreationRepository.save(goalEntity);

		EntityDTO dto = new EntityDTO();
		dto.setId(goalCreation.getGoalId());
		dto.setName(goalCreation.getEmployeeName());
		list.add(dto);
		logger.info("Goal is created in DB");
		return list;
	}

	@Override
	public Map<String, Object> findAllGoals(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String manager, String companyId) {

		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<GoalCreation> pagedResult = null;

		pagedResult = goalCreationRepository.goalPage(companyId, manager, paging);

		if (pagedResult.hasContent()) {
			return mapData(pagedResult, companyId);
		} else {
			return new HashMap<>();
		}
	}

	private Map<String, Object> mapData(Page<GoalCreation> pagedResult, String companyId) {
		HashMap<String, Object> response = new HashMap<>();
		List<GoalCreationDTO> goalModels = pagedResult.stream().map(entity -> {
			Optional<Department> department = departmentRepository.findByName(entity.getDepartmentName(), companyId);
			if (!department.isPresent()) {
				logger.info("Department is not present in DB with name:{}", entity.getDepartmentName());
				return null;
			}
			GoalCreationDTO model = new GoalCreationDTO();
			model.setDepartmentName(department.get().getName());
			model.setEmployeeId(entity.getEmployeeId());
			model.setEmployeeName(entity.getEmployeeName());
			model.setDepartmentName(entity.getDepartmentName());
			model.setDueDate(entity.getDueDate());
			model.setReviewStart(entity.getReviewStart());
			model.setReviewEnd(entity.getReviewEnd());
			model.setStatus(entity.getStatus());
			model.setGoalId(entity.getGoalId());
			return model;
		}).collect(Collectors.toList());

		response.put(Constants.DATA, goalModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	// it will give employeeId, employeeName, DepartmentId, DepartmentName
	@Override
	public List<GoalCreationEmployeeDTO> findDepartmentByEmployeeId(Long employeeId) {

		List<GoalCreationEmployeeDTO> list = new ArrayList<>();
		Optional<Employee> findById = employeeRepository.findById(employeeId);
		if (findById.isPresent()) {
			Employee employee = findById.get();
			GoalCreationEmployeeDTO dto = new GoalCreationEmployeeDTO();

			Long managerId = employee.getManager().getId();
			Optional<Employee> manager = employeeRepository.findById(managerId);// finding the manager
			if (!manager.isPresent()) {
				return list;
			}
			dto.setManagerName(manager.get().getFirstName()); // setting the manager name
			dto.setEmployeeId(employee.getId());
			dto.setEmployeeName(employee.getFirstName());
			dto.setDepartmentId(employee.getDepartment().getId());
			dto.setDepartmentName(employee.getDepartment().getName());
			list.add(dto);
			logger.info("Employee details found in DB");
		}
		return list;
	}

	@Override
	public GoalCreationDTO findOneGoalByEmployeeId(Long employeeId) {
		GoalCreation oneGoalemployee = goalCreationRepository.findByEmployeeId(employeeId);
		if (oneGoalemployee == null) {
			logger.info("Goal is not found in DB for employeeId: {}", employeeId);
			return null;
		}
		GoalCreationDTO model = new GoalCreationDTO();
		model.setDepartmentName(oneGoalemployee.getDepartmentName());
		model.setEmployeeId(oneGoalemployee.getEmployeeId());
		model.setEmployeeName(oneGoalemployee.getEmployeeName());
		model.setDueDate(oneGoalemployee.getDueDate());
		model.setReviewStart(oneGoalemployee.getReviewStart());
		model.setReviewEnd(oneGoalemployee.getReviewEnd());
		model.setStatus(oneGoalemployee.getStatus());
		model.setGoalId(oneGoalemployee.getGoalId());
		return model;
	}

	@Override
	public List<PayrollEmpListDTO> getEmployeeIds(Long managerId) {

		List<EmployeeInfoDTO> allEmployee = employeeRepository.findByMangerId(managerId);
		ArrayList<PayrollEmpListDTO> empList = new ArrayList<>();

		for (EmployeeInfoDTO employee : allEmployee) {

			if (Boolean.TRUE.equals(employee.getIsActive())) {

				PayrollEmpListDTO payrollEmpListDTO = new PayrollEmpListDTO();
				payrollEmpListDTO.setEmployeeId(employee.getId());
				payrollEmpListDTO.setFirstName(employee.getFirstName());
				payrollEmpListDTO.setLastName(employee.getLastName());
				payrollEmpListDTO.setUserName(employee.getUserName());
				empList.add(payrollEmpListDTO);
			}
		}
		return empList;
	}
}
