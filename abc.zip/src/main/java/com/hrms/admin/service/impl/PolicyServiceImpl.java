package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.PolicyPagenationDTO;
import com.hrms.admin.dto.VersionListDTO;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.PolicyRepository;
import com.hrms.admin.service.PolicyService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.S3ServiceUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * Contains method to perform DB operation on Policy Record
 * 
 * @author {Suresh}
 *
 */
@Service
@Slf4j
public class PolicyServiceImpl implements PolicyService {

	/*
	 * private static final log log = logFactory.getlog(PolicyServiceImpl.class);
	 */
	@Autowired
	PolicyRepository policyRepository;

	@Autowired
	private CompanyRepository companyRepo;

	/*
	 * @Autowired private GridFsTemplate gridFsTemplate;
	 * 
	 * @Autowired private GridFsOperations operations;
	 */

	@Autowired
	private S3ServiceUtil s3ServiceUtil;

	@Value("${aws.bucket.policyfolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@PostConstruct
	public void init() {
		String name = s3ServiceUtil.createFolder(foldername);
		log.info("folder created in s3 bucket foldername ::{}", name);
	}

	/**
	 * Returns All Policy data when Policy data is available in database
	 * 
	 * @return - List of PolicyResponse
	 */
	@Override
	@Cacheable(value = "getAllPolicy", unless = "#result == null", key = "#companyId")
	public List<PolicyDTO> getAllPolicy(String companyId) {
		List<Policy> allPolicy = policyRepository.findByCompany(companyId);
		List<PolicyDTO> models = allPolicy.stream().map(entity -> {
			PolicyDTO model = new PolicyDTO();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());
		log.info("Policy List found in DB");

		return models;

	}

	/**
	 * Returns true when new Policy is store in database
	 * 
	 * @param model - new Policy data
	 * @return - boolean
	 * @throws Exception
	 */
	@Override
	public List<EntityDTO> save(PolicyDTO model, MultipartFile file) throws Exception {
		boolean flag = Boolean.FALSE;
		List<EntityDTO> list = new ArrayList<>();

		Policy entity = new Policy();
		String filename = model.getName() + "." + FilenameUtils.getExtension(file.getOriginalFilename());

		/*
		 * DBObject metaData = new BasicDBObject(); metaData.put(Constants.TYPE,
		 * Constants.FILE); metaData.put(Constants.TITLE, filename); ObjectId id =
		 * gridFsTemplate.store(file.getInputStream(), filename, file.getContentType(),
		 * metaData); if (id != null) {
		 */
		flag = s3ServiceUtil.uploadFileInFolder(file, foldername, filename);
		if (flag == Boolean.TRUE) {
			entity.setName(model.getName());
			entity.setDescription(model.getDescription());

			Optional<Company> findById = companyRepo.findById(model.getCompanyId());
			if (!findById.isPresent()) {
				return list;
			}
			Company company = findById.get();
			entity.setCompany(company);
			entity.setVersion(model.getVersion());
			entity.setIsActive(Boolean.TRUE);
			entity.setIsDelete(Boolean.FALSE);
			/* entity.setAttachmentLink(id.toString()); */
			entity.setAttachmentLink(s3ServiceUtil.generateFileUrl(filename, foldername));
			entity.setFileType("." + FilenameUtils.getExtension(file.getOriginalFilename()));

		}
		Policy p = policyRepository.save(entity);
		log.info("Policy Added into database :: " + "", entity);
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getName());

		list.add(dto);
		return list;
	}

	/**
	 * Returns Policy data when Policy data is available in database by id
	 * 
	 * @param id - Id
	 * @return - PolicyResponse
	 */
	@Override
	@Cacheable(value = "getPolicyById", unless = "#result == null", key = "#id")
	public PolicyDTO getPolicyById(Long id , String companyId) {
		Optional<Policy> optionalEntity = policyRepository.findPolicyByCompanyId(id, companyId);
		if (!optionalEntity.isPresent()) {
			return null;
		}
		Policy policyEntity = optionalEntity.get();
		PolicyDTO model = new PolicyDTO();
		model.setName(policyEntity.getName());
		model.setDescription(policyEntity.getDescription());
		model.setAttachmentLink(policyEntity.getAttachmentLink());
		model.setCompanyId(policyEntity.getCompany().getId());
		model.setCompanyName(policyEntity.getCompany().getName());
		model.setVersion(policyEntity.getVersion());
		model.setFileType(policyEntity.getFileType());
		model.setIsActive(policyEntity.getIsActive());
		model.setIsDelete(policyEntity.getIsDelete());
		log.info("Policy found with in DB with Id:{}", id);
		return model;

	}

	/**
	 * Returns true when existing Policy data is store in database
	 * 
	 * @param model - new policy data
	 * @param id    - Policy Id
	 * @return - boolean
	 * @throws Exception
	 *//*
		 * @Override public List<EntityDTO> update(Long id, PolicyDTO policydto,
		 * MultipartFile file) throws Exception { List<EntityDTO> list = new
		 * ArrayList<>(); Optional<Policy> policy = policyRepository.findById(id); if
		 * (policy.isPresent()) { Policy oldPolicy = policy.get();
		 * log.info("Policy record is found from database with id:{}", id);
		 * gridFsTemplate.delete(new
		 * Query(Criteria.where("_id").is(oldPolicy.getAttachmentLink()))); String
		 * fileName = policydto.getName() + "." +
		 * FilenameUtils.getExtension(file.getOriginalFilename()); DBObject metaData =
		 * new BasicDBObject(); metaData.put(Constants.TYPE, Constants.FILE);
		 * metaData.put(Constants.TITLE, fileName); ObjectId documentId =
		 * gridFsTemplate.store(file.getInputStream(), fileName, file.getContentType(),
		 * metaData); if (documentId != null) { oldPolicy.setName(policydto.getName());
		 * oldPolicy.setDescription(policydto.getDescription());
		 * oldPolicy.setAttachmentLink(documentId.toString()); Optional<Company>
		 * findById = companyRepo.findById(policydto.getCompanyId()); if
		 * (!findById.isPresent()) { return list; } Company company = findById.get();
		 * oldPolicy.setCompany(company); oldPolicy.setVersion(policydto.getVersion());
		 * oldPolicy.setFileType("." +
		 * FilenameUtils.getExtension(file.getOriginalFilename())); } Policy p =
		 * policyRepository.save(oldPolicy); EntityDTO dto = new EntityDTO();
		 * dto.setId(p.getId()); dto.setName(p.getName()); list.add(dto); return list; }
		 * return list; }
		 */

	public Map<String, Object> mapData(Page<Policy> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<PolicyPagenationDTO> policyModels = pagedResult.stream().map(policyByName -> {
			PolicyPagenationDTO model = new PolicyPagenationDTO();
			// PolicyDTO policyByName = getPolicyByName(policyEntity.getName());
			model.setId(policyByName.getId());
			model.setName(policyByName.getName());
			model.setCompanyId(policyByName.getCompany().getId());
			model.setCompanyName(policyByName.getCompany().getName());
			model.setIsActive(policyByName.getIsActive());
			model.setIsDelete(policyByName.getIsDelete());
			model.setVersion(policyByName.getVersion());
			model.setAttachmentLink(policyByName.getAttachmentLink());
			model.setFileType(policyByName.getFileType());
			model.setUpdatedDate(policyByName.getModifiedDate());
			/*
			 * List<VersionListDTO> versionList = versionList(policyEntity.getName());
			 * model.setVersionList(versionList);
			 */
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, policyModels);
		response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
		response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages());
		return response;
	}

	/*
	 * public Map<String, Object> mapData(Page<Policy> pagedResult) {
	 * HashMap<String, Object> response = new HashMap<>(); List<PolicyPagenationDTO>
	 * policyModels = pagedResult.stream().map(policyEntity -> { PolicyPagenationDTO
	 * model = new PolicyPagenationDTO(); PolicyDTO policyByName =
	 * getPolicyByName(policyEntity.getName()); model.setId(policyByName.getId());
	 * model.setName(policyByName.getName());
	 * model.setCompanyId(policyByName.getCompanyId());
	 * model.setCompanyName(policyByName.getCompanyName());
	 * model.setIsActive(policyByName.getIsActive());
	 * model.setIsDelete(policyByName.getIsDelete());
	 * model.setVersion(policyByName.getVersion());
	 * model.setUpdatedDate(policyByName.getUpdatedDate());
	 * model.setAttachmentLink(policyByName.getAttachmentLink());
	 * model.setFileType(policyByName.getFileType());
	 * 
	 * List<VersionListDTO> versionList = versionList(policyEntity.getName());
	 * model.setVersionList(versionList);
	 * 
	 * return model; }).collect(Collectors.toList()); response.put(Constants.DATA,
	 * policyModels); response.put(Constants.PAGE_INDEX, pagedResult.getNumber());
	 * response.put(Constants.TOTAL_RECORDS, pagedResult.getTotalElements());
	 * response.put(Constants.TOTAL_PAGES, pagedResult.getTotalPages()); return
	 * response; }
	 */

	@Override
	public Map<String, Object> getAllPolicy(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Policy> pagedResult = null;
		Boolean status = true;

		if (isActive.isEmpty() || isActive.equals("")) {
			pagedResult = policyRepository.allpolicyPage(searchKey,companyId, paging);
		} else {
			if (isActive.equals("0")) {
				status = false;
			}
			pagedResult = policyRepository.policyPage(searchKey,companyId, status, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}

	}

	@Override
	public List<EntityDTO> updatePolicyByStatus(Long id, String status) {
		Optional<Policy> findById = policyRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		} else {

			Policy policy = findById.get();
			if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
				policy.setIsActive(Boolean.TRUE);
				Policy e = policyRepository.save(policy);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				log.info("Policy is activated in to database with Id:{}", id);

			} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
				policy.setIsActive(Boolean.FALSE);
				Policy e = policyRepository.save(policy);
				EntityDTO dto = new EntityDTO();
				dto.setId(e.getId());
				dto.setName(e.getName());
				list.add(dto);
				log.info("Policy is deactivated in to database Id:{}", id);
			}
		}
		log.info("Policy failed to activated or deactivated in database Id:{}", id);
		return list;
	}

	public List<EntityDTO> softDeletePolicy(Long id) {
		Optional<Policy> findById = policyRepository.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Policy policy = findById.get();
		policy.setIsActive(Boolean.FALSE);
		policy.setIsDelete(Boolean.TRUE);
		Policy p = policyRepository.save(policy);
		log.info("Policy is SoftDeleted in to database Id:{}", id);
		EntityDTO dto = new EntityDTO();
		dto.setId(p.getId());
		dto.setName(p.getName());
		list.add(dto);
		return list;
	}

	@Override
	public boolean validate(PolicyDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = policyRepository.getPolicyCountForSave(model.getCompanyId(), model.getName(), model.getVersion());
		else
			count = policyRepository.getPolicyCountForUpdate(model.getCompanyId(), model.getName(), model.getId(),
					model.getVersion());
		return count > 0;
	}

	/**
	 * @param mongodb document id
	 * @return document object form mongodb
	 *//*
		 * public DocumentDetails getDocument(String id) throws IllegalStateException,
		 * IOException { GridFSFile file = gridFsTemplate.findOne(new
		 * Query(Criteria.where("_id").is(id))); DocumentDetails document = new
		 * DocumentDetails();
		 * document.setTitle(file.getMetadata().get(Constants.TITLE).toString());
		 * document.setStream(operations.getResource(file).getInputStream()); return
		 * document; }
		 */
	/**
	 * @param policy name
	 * @return list of all policy's with same name
	 */
	@Override
	public PolicyDTO getPolicyByName(String name,String companyId) {
		List<Policy> policyList = policyRepository.findAllPolicies(name,companyId);
		if (!policyList.isEmpty()) {
			Comparator<Policy> compareByVersion = (Policy o1, Policy o2) -> o1.getVersion().compareTo(o2.getVersion());
			Collections.sort(policyList, compareByVersion);
			Policy policyObj = policyList.get(policyList.size() - 1);
			PolicyDTO dto = new PolicyDTO();
			dto.setId(policyObj.getId());
			dto.setName(policyObj.getName());
			dto.setDescription(policyObj.getDescription());
			dto.setFileType(policyObj.getFileType());
			dto.setVersion(policyObj.getVersion());
			dto.setUpdatedDate(policyObj.getModifiedDate());
			dto.setAttachmentLink(policyObj.getAttachmentLink());
			dto.setCompanyId(policyObj.getCompany().getId());
			dto.setCompanyName(policyObj.getCompany().getName());
			dto.setIsActive(policyObj.getIsActive());
			dto.setIsDelete(policyObj.getIsDelete());
			dto.setFileType(policyObj.getFileType());
			return dto;
		} else {
			return new PolicyDTO();
		}
	}

	/**
	 * @author Manikanta
	 * @param policyName
	 * @return all list of policies with having same name with different versions
	 */

	public List<VersionListDTO> versionList(String policyName) {
		List<VersionListDTO> list = new ArrayList<>();
		List<Policy> findAll = policyRepository.findAll();
		for (Policy policy : findAll) {
			if (policy.getName().equals(policyName)) {
				VersionListDTO dto = new VersionListDTO();
				dto.setId(policy.getId());
				dto.setName(policy.getName());
				dto.setAttachmentLink(policy.getAttachmentLink());
				dto.setVersion(policy.getVersion());
				dto.setIsActive(policy.getIsActive());
				dto.setIsDelete(policy.getIsDelete());
				dto.setUpdatedDate(policy.getModifiedDate());
				dto.setFileType(policy.getFileType());
				list.add(dto);
			}
		}
		Comparator<VersionListDTO> compareByVersion = (VersionListDTO o1, VersionListDTO o2) -> o1.getVersion()
				.compareTo(o2.getVersion());
		Collections.sort(list, compareByVersion);
		list.remove(list.size() - 1);
		Collections.reverse(list);
		return list;
	}

}