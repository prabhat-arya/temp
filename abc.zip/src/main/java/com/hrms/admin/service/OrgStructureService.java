package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.OrgStructureChild;
import com.hrms.admin.dto.OrgStructureParent;
import com.hrms.admin.entity.Employee;

public interface OrgStructureService {

	public List<OrgStructureParent> getOrg();
	
	public List<OrgStructureChild> getchildrens(List<Employee> allChildemp);
	
	public OrgStructureChild setChildEmpData(Employee emp);
	
	public OrgStructureParent setParentEmpData(Employee emp);
	
	public String getChildCount(Long empId);
	
}
