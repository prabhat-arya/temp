package com.hrms.admin.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.AssignShiftDTO;
import com.hrms.admin.dto.ShiftAssignDTO;
import com.hrms.admin.dto.ShiftRequestDTO;

public interface AssignShiftService {

	public String changeShiftRequest(ShiftRequestDTO model);

	public ShiftAssignDTO assignShift(ShiftAssignDTO model);

	public List<AssignShiftDTO> getAssignShiftByEmpId(Long empId,String companyId);

	public List<AssignShiftDTO> findAll(String companyId);

	public String updateRequestedShift(ShiftRequestDTO model) throws ParseException;

	// for validation
	public boolean validate(AssignShiftDTO model, boolean isSave);

	public Map<String, Object> getAllAssignShifts(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy,String companyId);

	public String updateChangeShiftRequest(ShiftRequestDTO model, Long id);

	public Map<String, Object> getAllManagerShift(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive,String companyId);

	public Map<String, Object> getAllEmployeeShift(Long empId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive,String companyId);
}
