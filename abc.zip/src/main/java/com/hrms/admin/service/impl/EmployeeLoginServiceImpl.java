package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.JwtToken;
import com.hrms.admin.entity.UserRequestDetails;
import com.hrms.admin.repository.EmployeeLoginRepository;
import com.hrms.admin.repository.JwtTokenRepo;
import com.hrms.admin.repository.UserRequestDetailsRepo;
import com.hrms.admin.role.dto.EmployeeIdsDTO;
import com.hrms.admin.service.EmployeeLoginService;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.FieldsValidation;

@Service
public class EmployeeLoginServiceImpl implements EmployeeLoginService {

	private static final Logger logger = LogManager.getLogger(EmployeeLoginServiceImpl.class);

	@Autowired
	private EmployeeLoginRepository loginRepository;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private EmailServiceUtil mailService;

	@Autowired
	private FieldsValidation validateUtil;

	@Autowired
	private UserRequestDetailsRepo userRequestDetailsRepo;

	@Autowired
	private JwtTokenRepo blackListTockenRepo;

	@Override
	public Employee getUserByUserName(String name) {

		logger.info("*************FETCHING USER FROM DB***************");
		Optional<Employee> optionalUser = loginRepository.findByUserName(name);
		if (optionalUser.isPresent()) {

			logger.info("*************USER FOUND FROM DB***************");
			return optionalUser.get();
		}
		return null;
	}

	@Override
	public Employee createPasswordResetTokenForUser(String userName) {
		Optional<Employee> optionalUser = loginRepository.findByUserName(userName);
		String s = UUID.randomUUID().toString();
		String token = UUID.randomUUID().toString().substring(s.length() - 12);
		Employee emp = null;
		if (optionalUser.isPresent()) {
			emp = optionalUser.get();
			if (emp != null) {
				emp.setToken(token);
				loginRepository.save(emp);
			}
		}
		return emp;

	}

	@Override
	public List<EntityDTO> validatetTokenAndSavePassword(String newPassword, String confirmPassword, String token) {
		Optional<Employee> user = loginRepository.findByToken(token);
		if (!(newPassword.equals(confirmPassword) && user.isPresent())) {
			EntityDTO dto = new EntityDTO();
			dto.setName("Password mismatched");
			List<EntityDTO> list = new ArrayList<>();
			list.add(dto);
			return list;
		}

		Employee employee = new Employee();
		Boolean validateNewPassword = validateUtil.validatePassword(newPassword);
		Boolean validateConformPassword = validateUtil.validatePassword(confirmPassword);
		if (validateNewPassword.equals(Boolean.FALSE) && validateConformPassword.equals(Boolean.FALSE)) {
			EntityDTO dto = new EntityDTO();
			dto.setName("enter valid password");
			List<EntityDTO> list = new ArrayList<>();
			list.add(dto);
			return list;
		}

		if (newPassword.equals(confirmPassword) && user.isPresent()) {
			employee = user.get();
			employee.setPassword(encoder.encode(newPassword));
			employee.setIsLock(0);
			employee.setToken(null);
			user.get().setPassword(encoder.encode(newPassword));
			user.get().setToken(null);
			if (user.get().getOfficalMail() != null) {
				try {
					employee.setIsLock(0);
					mailService.sendForgotMailConform(user.get().getOfficalMail(),
							"The password for your O-Staff account was successfully reset.",user.get().getCompany().getId());
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				try {
					mailService.sendForgotMailConform(user.get().getOfficalMail(),
							"The password for your O-Staff account was failed to reset.",user.get().getCompany().getId());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
		Employee user1 = loginRepository.save(employee);
		EntityDTO dto = new EntityDTO();
		dto.setId(user1.getId());
		dto.setName(user1.getFirstName() + user1.getLastName());
		List<EntityDTO> list = new ArrayList<>();
		list.add(dto);
		return list;
	}

	@Override
	public String findtoken(String token) {
		Optional<Employee> use = loginRepository.findByToken(token);
		String use1 = null;
		if (use.isPresent()) {
			use1 = use.get().getToken();
		}
		return use1;
	}

	@Override
	public void increaseFailedAttempts(String username) {
		Employee employee = getUserByUserName(username);
		int newFailAttempts = employee.getIsLock() + 1;
		employee.setIsLock(newFailAttempts);
		loginRepository.save(employee);
	}

	@Override
	public void unlockEmployeeEveryDay() {
		loginRepository.unlockEmployeeEveryDay();
	}

	@Override
	public void unlockEmployee(EmployeeIdsDTO employeeIdsDTO) {

		List<Long> ids = employeeIdsDTO.getEmpIds();
		for (Long id : ids) {
			loginRepository.unlockEmployee(id);
		}
	}

	@Override
	public Employee getUserByUserEmail(String email) {
		logger.info("*************FETCHING USER DEATIALS FROM DB***************");
		Optional<Employee> findByUserByEmail = loginRepository.findByUserByEmail(email);
		if (findByUserByEmail.isPresent()) {
			logger.info("*************USER DEATIALS FOUND FROM DB***************");
			return findByUserByEmail.get();

		} else {
			return null;
		}
	}

	@Override
	public Employee createForgotPasswordResetToken(String email) {
		Optional<Employee> userDetailsByEmail = loginRepository.findByUserByEmail(email);
		String randomId = UUID.randomUUID().toString();
		String token = UUID.randomUUID().toString().substring(randomId.length() - 12);
		Employee emp = null;
		if (userDetailsByEmail.isPresent()) {
			emp = userDetailsByEmail.get();
			if (emp != null) {
				emp.setToken(token);

				loginRepository.save(emp);
			}
		}

		return emp;
	}

	@Override
	public List<EntityDTO> resetPassword(String newPassword, String confirmPassword, String oldPassword,
			String loggedUser) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Employee> employee = loginRepository.employeePassword(loggedUser);
		if (employee.isPresent()) {
			Employee emp = employee.get();
			PasswordEncoder passencoder = new BCryptPasswordEncoder();
			if (!passencoder.matches(oldPassword, emp.getPassword())) {
				EntityDTO dto = new EntityDTO();
				dto.setName("Old password not matched");
				list.add(dto);
				return list;
			}
			emp.setPassword(encoder.encode(newPassword));
			emp.setIsLock(0);
			Employee e = loginRepository.save(emp);

			List<UserRequestDetails> findByUserName = userRequestDetailsRepo.findByUserName(loggedUser);
			logger.info("UserRequestDetails found based on UserName");
			for (UserRequestDetails userRequestDetails : findByUserName) {
				String userJwtToken = userRequestDetails.getUserJwtToken();
				JwtToken jwtToken = new JwtToken();
				jwtToken.setJwtToken(userJwtToken);
				blackListTockenRepo.save(jwtToken);
				logger.info("Tokens are added in to Black Listed token table");
			}
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getFirstName() + " " + e.getLastName());
			list.add(dto);
		} else {
			return list;
		}
		return list;
	}

	@Override
	public EntityDTO validatetTokenAndSavePassword(String token) {
		Optional<Employee> findByToken = loginRepository.findByToken(token);
		EntityDTO dto = new EntityDTO();
		if (findByToken.isPresent()) {
			Employee emp = findByToken.get();
			dto.setName("Token is valied..");
			dto.setId(emp.getId());
			dto.setName(emp.getFirstName() + " " + emp.getLastName());
		} else {
			dto.setName("Token is Invalied..");

		}
		return dto;
	}

	@Override
	public void isLockZero(String username) {
		loginRepository.isLockZero(username);

	}

}
