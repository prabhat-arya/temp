/*package com.hrms.admin.service.impl;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.OrgMasterDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.City;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Country;
import com.hrms.admin.entity.EmployeeRoles;
import com.hrms.admin.entity.Menu;
import com.hrms.admin.entity.RoleJson;
import com.hrms.admin.entity.State;
import com.hrms.admin.repository.CityRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.CountryRepository;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.repository.RoleJsonRepo;
import com.hrms.admin.repository.RolesRepository;
import com.hrms.admin.repository.StateRepository;
import com.hrms.admin.service.OrgMasterService;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.EmployeeServiceUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OrgMasterServiceImpl implements OrgMasterService {

	
	  @Autowired private OrgMasterRepository userRepo;
	 
	@Autowired
	private EmailServiceUtil emailUtil;

	@Autowired
	private EmployeeServiceUtil employeeUtil;

	@Autowired
	private CityRepository cityRepo;

	@Autowired
	private StateRepository stateRepo;

	@Autowired
	private CountryRepository countryRepo;

	@Autowired
	private MenuRepository menuRepo;

	@Autowired
	private RoleJsonRepo rjRepo;

	@Autowired
	private RolesRepository roleRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Value("${user.login.link}")
	private String loginUrl;

	@Override
	@Transactional
	public Map<String, String> save(OrgMasterDTO model) {
		Company entity = new Company();
		Company company = null;
		Map<String, String> listData = null;

		try {
			Address address = new Address();
			address.setAddress(model.getAddress());
			address.setLandmark("");
			address.setStreet("");
			address.setCity(1L);
			address.setDistrict("");
			address.setState(1L);
			address.setCountry(model.getCountryId());
			address.setPincode("000000");

			entity.setName(model.getCompanyName());
			entity.setContact(model.getMobileNo());
			entity.setEmail(model.getEmail().toLowerCase());
			entity.setWebsite("");
			entity.setBranch("");
			entity.setContactPerson(model.getFirstName() + model.getLastName());
			entity.setPanNumber("");
			entity.setGstNumber("");
			entity.setTanNumber("");
			entity.setLocation("");
			entity.setFirstName(model.getFirstName());
			entity.setLastName(model.getLastName());
			entity.setUserName(model.getUserName());
			entity.setAddress(address);
			entity.setIsDelete(Boolean.FALSE);
			entity.setIsActive(Boolean.TRUE);

			company = companyRepo.save(entity);

			String password = employeeUtil.saveUserToEmployeeDataSave(company);

			MailDTO request = new MailDTO();
			request.setTo(company.getEmail());
			request.setSubject("Welcome to O-Staff");
			request.setTemplate(Constants.SIGNUP_TEMPLATE_NAME);
			String url = loginUrl;
			Map<String, Object> mapModel = new HashMap<>();
			mapModel.put(Constants.URL, url);
			mapModel.put(Constants.TEMPPASS, password);
			mapModel.put(Constants.USERNAME, company.getUserName());
			emailUtil.sendUserSignUpMail(request, mapModel);

			
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (company != null) {
			listData = new HashedMap<>();
			String data = "User Signed In successfully/signup respective mail sent.";
			listData.put("data", data);
			log.info(data);
		}
		return listData;
	}//	@Override
//	public List<OrgMaster> getAll() {
//		return userRepo.findAll();
//	}

//	/**
//	 * @return employee exist or not in database
//	 */
//	@Override
//	public boolean validate(OrgMasterDTO model, boolean isSave) {
//		Long count = null;
//		if (isSave) {
//			count = userRepo.getUserSaveCount(model.getCompanyName(), model.getUserName());
//		}
//		return count > 0;
//	}
//
//	@Override
//	public boolean validateEmail(OrgMasterDTO model, boolean isSave) {
//		Long count = null;
//		if (isSave) {
//			count = userRepo.findByEmail(model.getEmail());
//		}
//		return count > 0;
//	}

	/*@PostConstruct
	public void init() throws Exception {
		InputStream is = null;
		ObjectMapper mapper = new ObjectMapper();
		ClassLoader classLoader = getClass().getClassLoader();
		final String countryFile = "Images/countryList.json";
		is = classLoader.getResourceAsStream(countryFile);
		List<Country> countryList = Arrays.asList(mapper.readValue(is, Country[].class));
		if (countryRepo.findAll().isEmpty() && countryList != null) {
			countryRepo.saveAll(countryList);
		}

		final String stateFile = "Images/stateList.json";
		is = classLoader.getResourceAsStream(stateFile);
		List<State> stateList = Arrays.asList(mapper.readValue(is, State[].class));
		if (stateRepo.findAll().isEmpty() && stateList != null) {
			stateRepo.saveAll(stateList);
		}

		final String cityFile = "Images/cityList.json";
		is = classLoader.getResourceAsStream(cityFile);
		List<City> cityList = Arrays.asList(mapper.readValue(is, City[].class));
		if (cityRepo.findAll().isEmpty() && cityList != null) {
			cityRepo.saveAll(cityList);
		}

		final String menuFile = "Images/menuList.json";
		is = classLoader.getResourceAsStream(menuFile);
		List<Menu> menuList = Arrays.asList(mapper.readValue(is, Menu[].class));
		if (menuRepo.findAll().isEmpty() && menuList != null) {
			menuRepo.saveAll(menuList);
		}

		final String roleJosnFile = "Images/roleJson.json";
		is = classLoader.getResourceAsStream(roleJosnFile);
		String accessList = new String(FileCopyUtils.copyToByteArray(is), StandardCharsets.UTF_8);
		RoleJson json = new RoleJson();
		json.setAccessList(accessList.replaceAll("\\s", ""));
		RoleJson roleJson = null;
		if (rjRepo.findAll().isEmpty() && !accessList.isEmpty()) {
			roleJson = rjRepo.save(json);
		}

		final String employeeRolesFile = "Images/employeeRoles.json";
		is = classLoader.getResourceAsStream(employeeRolesFile);
		EmployeeRoles employeeRoles = mapper.readValue(is, EmployeeRoles.class);
		if (roleRepo.findAll().isEmpty() && employeeRoles != null) {
			employeeRoles.setRoleJson(roleJson);
			roleRepo.save(employeeRoles);
		}
	}

}*/
