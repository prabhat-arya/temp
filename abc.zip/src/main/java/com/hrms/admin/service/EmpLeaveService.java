package com.hrms.admin.service;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.CancelLeaveDTO;
import com.hrms.admin.dto.EmpLeaveCountDTO;
import com.hrms.admin.dto.EmpLeaveDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.ManagerDTO;

public interface EmpLeaveService {
	public List<EntityDTO> addEmpLeave(EmpLeaveDTO empLeave, MultipartFile file, String companyId) throws IOException; // added

	public List<EmpLeaveDTO> findLeavesbyDate(Date date, String companyId);

	public List<EmpLeaveDTO> findLeavesbyEmpId(Long empId);

	List<ManagerDTO> findManager(Long id, String companyId);

	public List<ManagerDTO> allmangerList(String companyId);

	public EmpLeaveDTO getEmpLeaveByid(Long id);

	public List<EmpLeaveDTO> getAllEmpLeave(String companyId);

	public List<EntityDTO> updateEmpLeave(EmpLeaveDTO empLeave, Long id); // added

	public boolean deleteEmpLeave(Long id);

	public List<EntityDTO> approveOrReject(EmpLeaveDTO empLeave, Long id);

	public List<EmpLeaveDTO> getEmpLeavesByDate(Long id, Date date1, Date date2);

	public Map<String, Object> getAllEmpLeaves(Long empId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId);

	public Map<String, Object> getAllTeamLeaves(Long managerId, Integer pageIndex, Integer pageSize, String sortBy,
			String searchKey, String orderBy, String isActive, String companyId);

	public List<EntityDTO> softDeleteEmpLeave(Long id);

	// for validation
	public boolean validate(EmpLeaveDTO model, boolean isSave);

	public List<EntityDTO> updateEmpLeaveByStatus(Long id, String status);

	public List<EntityDTO> cancelLeaves(CancelLeaveDTO dto, Long id);

	public EmpLeaveCountDTO getEmployeeLeavesCountById(Long employeeId);

	public List<EntityDTO> getEmployeeCancellationofApprovedLeaves(EmpLeaveDTO dto);

	public List<EntityDTO> getEmployeeCancelAppliedRejectLeaves(EmpLeaveDTO dto);

	public List<EntityDTO> getEmployeeCancelApprovedLeaves(EmpLeaveDTO dto);

}
