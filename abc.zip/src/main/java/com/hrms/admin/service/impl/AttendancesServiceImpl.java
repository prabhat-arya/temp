package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AttendanceDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.entity.Attendance;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.entity.Shift;
import com.hrms.admin.repository.AttendancesRepository;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.repository.ShiftRepository;
import com.hrms.admin.service.AttendanceService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to perform DB operation on Attendances Record
 * 
 * @author {Chandu}
 *
 */
@Service
public class AttendancesServiceImpl implements AttendanceService {

	private static final Logger logger = LoggerFactory.getLogger(AttendancesServiceImpl.class);

	@Autowired
	private AttendancesRepository attRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private BranchRepository repo;

	@Autowired
	private ShiftRepository shiftRepository;

	/**
	 * Returns true when new Attendance is store in database
	 * 
	 * @param model - new Attendance data
	 * @return - boolean
	 */

	@Override
	public List<EntityDTO> save(AttendanceDTO model) {
		List<EntityDTO> list = new ArrayList<>();
		Optional<Company> findById = companyRepo.findById(model.getCompanyId());
		if (!findById.isPresent()) {
			return list;
		}
		Company company = findById.get();
		for (Long shiftId : model.getShiftIds()) {
			Attendance entity = new Attendance();
			Optional<Shift> findById2 = shiftRepository.findById(shiftId);
			if (!findById2.isPresent()) {
				return list;
			}
			Shift shift = findById2.get();
			entity.setCompanyId(model.getCompanyId());
			entity.setCompanyName(company.getName());
			entity.setBranchId(model.getBranchId());
			Optional<Branch> findById3 = repo.findById(model.getBranchId());
			if (!findById3.isPresent()) {
				return list;
			}
			Branch branch = findById3.get();
			entity.setBranchName(branch.getName());
			entity.setIsActive(Boolean.TRUE);
			entity.setIsDelete(Boolean.FALSE);
			if (shiftId.equals(model.getDefaultShiftId())) {
				entity.setIsDefault(Boolean.TRUE);
			} else {
				entity.setIsDefault(Boolean.FALSE);
			}
			entity.setShift(shift);
			attRepo.save(entity);
		}
		logger.info("Attendanc Added into database");
		EntityDTO dto = new EntityDTO();
		dto.setCompanyId(company.getId());
		dto.setName(company.getName());
		list.add(dto);
		return list;
	}

	/**
	 * @param pageIndex,
	 * @param pageSize,sortBy,
	 * @param searchKey,
	 * @param orderBy,
	 * @param status
	 * @return - page size
	 */

	@Override
	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String status, String companyId) {
		Pageable paging = PageRequest.of(pageIndex, pageSize);
		Page<Attendance> pagedResult = null;
		pagedResult = attRepo.allAttendancePage(searchKey,companyId, paging);
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Returns Attendance data when Attendance data is available in database by id
	 * @param id - Attendance Id
	 * @return - AttendanceModel
	 */
	@Override
	@Cacheable(value = "getById", unless = "#result == null", key = "#id")
	public AttendanceDTO getById(Long id) {
		Long branchId = attRepo.findBranchId(id);
		List<Attendance> attendance = attRepo.findByBranch(branchId);
		AttendanceDTO model = new AttendanceDTO();
		List<Long> shiftIds = new ArrayList<>();
		for (Attendance entity : attendance) {
			if (entity.getIsDefault()) {
				model.setDefaultShiftId(entity.getShift().getId());
			}
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchName(entity.getBranch().getName());
			model.setBranchId(entity.getBranchId());
			shiftIds.add(entity.getShift().getId());
		}
		model.setShiftIds(shiftIds);
		model.setId(id);
		return model;
	}
	/**
	 * @param id,
	 * @return - true when is deleted
	 */
	
	@Override
	public boolean deleteAttendnace(Long id) {
		attRepo.deleteById(id);
		logger.info("Attendnace record is deleted from database ");
		return true;
	}

	/**
	 * Returns true when existing Attendance data is store in database
	 * 
	 * @param model - AttendanceDTO
	 * @param id    - Attendance Id
	 * @return - boolean
	 */
	@Override
	public List<EntityDTO> updateAttendnace(AttendanceDTO model) {
		Long branchId = attRepo.findBranchId(model.getId());
		List<Attendance> attendanceList = attRepo.findByBranch(branchId);
		Optional<Company> findById = companyRepo.findById(model.getCompanyId());
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Company company = findById.get();
		for (Attendance entity : attendanceList) {
			entity.setIsActive(Boolean.FALSE);
			entity.setIsDefault(Boolean.FALSE);
			entity.setIsDelete(Boolean.TRUE);
			attRepo.save(entity);
		}
		for (Long shiftId : model.getShiftIds()) {
			Attendance entity = new Attendance();
			for (Attendance att : attendanceList) {
				entity.setCompanyId(model.getCompanyId());
				entity.setCompanyName(company.getName());
				entity.setBranchId(model.getBranchId());
				Optional<Branch> findById2 = repo.findById(model.getBranchId());
				if (!findById2.isPresent()) {
					return list;
				}
				Branch branch = findById2.get();
				entity.setBranchName(branch.getName());
				entity.setIsActive(Boolean.TRUE);
				entity.setIsDelete(Boolean.FALSE);
				if (shiftId.equals(model.getDefaultShiftId())) {
					entity.setIsDefault(Boolean.TRUE);
				} else {
					entity.setIsDefault(Boolean.FALSE);
				}
				Optional<Shift> findById3 = shiftRepository.findById(shiftId);
				if (!findById3.isPresent()) {
					return list;
				}
				Shift shift = findById3.get();
				entity.setShift(shift);
				attRepo.save(entity);
			}
		}
		logger.info("Attendanc is updated in to database with Id:{}",model.getId());
		EntityDTO dto = new EntityDTO();
		dto.setCompanyId(company.getId());
		dto.setName(company.getName());
		list.add(dto);
		return list;
	}
	
	/**
	 * @param Attendance Entity
	 * @return - page size
	 */

	public static Map<String, Object> mapData(Page<Attendance> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<AttendanceDTO> attendenceModels = pagedResult.stream().map(entity -> {
			AttendanceDTO model = new AttendanceDTO();
			model.setId(entity.getId());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompanyName());
			model.setBranchId(entity.getBranchId());
			model.setBranchName(entity.getBranchName());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setIsDefault(entity.getIsDefault());
			model.setShiftName(entity.getShift().getShiftName());
			model.setShiftId(entity.getShift().getId());
			model.setInTime(entity.getShift().getInTime());
			model.setOutTime(entity.getShift().getOutTime());
			return model;
		}).collect(Collectors.toList());
		response.put(Constants.DATA, attendenceModels);
		response.put(Constants.PAGEINDEX, pagedResult.getNumber());
		response.put(Constants.TOTALRECORDS, pagedResult.getTotalElements());
		response.put(Constants.TOTALPAGES, pagedResult.getTotalPages());
		return response;
	}
	
	/**
	 * @param id,
	 * @return - List of Attendance based on Company
	 */

	@Override
	@Cacheable(value = "getCompanyId", unless = "#result == null", key = "#id")
	public List<AttendanceDTO> getCompanyId(String id) {
		List<AttendanceDTO> models =null;
		List<Attendance> a = attRepo.findByCompanyId(id);
		 models = a.stream().map(entity -> {
			AttendanceDTO model = new AttendanceDTO();
			model.setId(entity.getId());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchName(entity.getBranch().getName());
			model.setBranchId(entity.getBranchId());
			model.setIsDelete(entity.getIsDelete());
			model.setIsActive(entity.getIsActive());
			model.setShiftName(entity.getShift().getShiftName());
			model.setIsDefault(entity.getIsDefault());
			return model;
		}).collect(Collectors.toList());

		return models;
	}
	
	/**
	 * @param id -Attendance,
	 * @return -  change value from database isDisable is true
	 */
	
	public List<EntityDTO> softDeleteAttendance(Long id) {
		Optional<Attendance> findById = attRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Attendance attendance = findById.get();
		if (attendance.getIsDefault().equals(Boolean.TRUE)) {
			List<Attendance> attendancelist = attRepo.findByBranch(attendance.getBranch().getId());
			for (Attendance entity : attendancelist) {
				entity.setIsActive(Boolean.FALSE);
				entity.setIsDelete(Boolean.TRUE);
				attRepo.save(entity);
			}
		} else {
			attendance.setIsActive(Boolean.FALSE);
			attendance.setIsDelete(Boolean.TRUE);
			attRepo.save(attendance);
		}
		logger.info("Attendance is SoftDeleted in to database Id:{}",id);
		EntityDTO dto = new EntityDTO();
		dto.setId(attendance.getId());
		dto.setName(attendance.getCompany().getName());
		list.add(dto);
		return list;
	}

	/**
	 * @param AttendanceDto,
	 *  @param boolean value,
	 * @return -  if record exit return true or if record not exit  return false
	 */
	@Override
	public boolean validate(AttendanceDTO model, boolean isSave) {
		Long count;
		if (isSave)
			count = attRepo.getAttendanceCount(model.getCompanyId(), model.getBranchId());
		else
			// pending
			count = attRepo.getUpdateAttendanceCount(model.getCompanyId(), model.getBranchId(), model.getId());
		return count > 0;
	}
	
	/**
	 * @param Attendance id,
	 *  @param String,
	 * @return -  if record is updateAttendanceByStatus based on Attendance id
	 */
	public List<EntityDTO> updateAttendanceByStatus(Long id, String status) {
		Optional<Attendance> findById = attRepo.findById(id);
		List<EntityDTO> list = new ArrayList<>();
		if (!findById.isPresent()) {
			return list;
		}
		Attendance a = findById.get();
		if (status.equalsIgnoreCase(Constants.ACTIVATE)) {
			a.setIsActive(Boolean.TRUE);
			Attendance e = attRepo.save(a);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getBranchName());
			list.add(dto);
			logger.info("Attendance is activated in database Id:{}",id);
			return list;
		} else if (status.equalsIgnoreCase(Constants.DEACTIVATE)) {
			a.setIsActive(Boolean.FALSE);
			Attendance e = attRepo.save(a);
			EntityDTO dto = new EntityDTO();
			dto.setId(e.getId());
			dto.setName(e.getBranchName());
			list.add(dto);
			logger.info("Attendance is deactivated in database Id:{}",id);
			return list;
		}
		return list;
	}
}
