package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.BellIconNotificationsDTO;
import com.hrms.admin.dto.EntityDTO;
import com.hrms.admin.dto.NotificationDTO;
import com.hrms.admin.dto.WishesDTO;
import com.hrms.admin.entity.BellIconNotifications;

public interface NotificationService {

	public List<EntityDTO> save(NotificationDTO model);

	public List<EntityDTO> sendNotifications(Long id, String fromMail) throws Exception;

	public List<EntityDTO> updateNotification(NotificationDTO model, Long id);

	public NotificationDTO getById(Long id, String companyId);

	public boolean deleteNotification(Long id);

	public List<EntityDTO> updateNotificationByStatus(Long id, String status);

	// paging

	public Map<String, Object> getAllNotification(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy, String isActive, String companyId);

	/**
	 * Returns All Notification data when notification data is available in database
	 * 
	 * @return - List of NotificationModel
	 */
	List<NotificationDTO> getAllNotificationList();

	/**
	 * Returns true when existing notification data is store in database
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - boolean
	 */

	public List<EntityDTO> softDeleteNotification(Long id);

	public boolean validate(NotificationDTO leaveType, boolean isSave);

	public List<EntityDTO> wishesList(WishesDTO w, String companyId);

	public Boolean welcomeMail(Long empId, String companyId);

	// public BellIconNotificationsDTO getBellIconNotifications(String companyId);

	public Map<String, Object> getBellIconNotificationsTomanager(Long approverId, String companyId);

	public Map<String, Object> getBellIconNotificationsToemployee(Long empId, String companyId);

	public BellIconNotifications getBellIconNotificationById(BellIconNotificationsDTO notification);

	public boolean deleteBellIconNotificationById(Long notificationId);

	public List<BellIconNotifications> getBellNotificationsListTomanager(Long approverId, String companyId);

	public List<BellIconNotifications> getBellNotificationsListToemployee(Long empId, String companyId);

}
