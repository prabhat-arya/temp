package com.hrms.admin.service;

import java.util.List;
import java.util.Set;

import com.hrms.admin.entity.Menu;
import com.hrms.admin.role.dto.MenuSortingDTO;

public interface MenuService {

	//public List<MenuSortingDTO> getByMenu(EmployeeGroups menuId);
	
	public MenuSortingDTO getByMenu(Long menuId);
	public List<MenuSortingDTO> getMenusByGroup(Set<Menu> menuSet);
	public List<MenuSortingDTO> removeDuplicates(List<MenuSortingDTO> menuDtoList);
}
