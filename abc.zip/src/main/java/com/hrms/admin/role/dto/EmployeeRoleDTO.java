package com.hrms.admin.role.dto;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.hrms.admin.payroll.dto.PayrollEmpListDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class EmployeeRoleDTO {
	
	private Long roleId;
	private String roleName;
	private Long empId;
	private Set<Long> menus;
	private List<MenuSortingDTO> menuSorting;
	private List<PayrollEmpListDTO> empList;
	private Boolean isActive;
	private Boolean isDelete;
	
}
