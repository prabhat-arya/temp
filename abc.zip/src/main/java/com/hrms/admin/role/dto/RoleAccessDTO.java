/*package com.hrms.admin.role.dto;

import java.util.HashSet;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleAccessDTO {
	
	private String roleName;
	private Set<AccessListDTO> menus = new HashSet<>();
	
}
*/