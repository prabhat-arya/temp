package com.hrms.admin.role.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class MenuSortingDTO implements Comparable<MenuSortingDTO>{
	
	private String menuTitle;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)	
	private String menuIcon;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String menuPath;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long id;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<MenuSortingDTO> childs;
	
//	@JsonInclude(JsonInclude.Include.NON_NULL)
//	private AccessListDTO accessList;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean create;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean delete;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean edit;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean view;
	
	@JsonIgnore
	private Long parentId;
	
	public MenuSortingDTO() {
		super();
	}

	public MenuSortingDTO(String menuTitle, String menuIcon, String menuPath, Long id) {
		super();
		this.menuTitle = menuTitle;
		this.menuIcon = menuIcon;
		this.menuPath = menuPath;
		this.id = id;
		
	}
	
	public MenuSortingDTO(String menuTitle, String menuIcon, String menuPath, Long id, Long parentId) {
		super();
		this.menuTitle = menuTitle;
		this.menuIcon = menuIcon;
		this.menuPath = menuPath;
		this.id = id;
		this.parentId = parentId;
	}

	public String getMenuTitle() {
		return menuTitle;
	}

	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

	public String getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public int compareTo(MenuSortingDTO menu) {
		// TODO Auto-generated method stub
		return this.id.intValue() - menu.id.intValue();
	}

	public List<MenuSortingDTO> getChilds() {
		return childs;
	}

	public void setChilds(List<MenuSortingDTO> childs) {
		this.childs = childs;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((menuTitle == null) ? 0 : menuTitle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuSortingDTO other = (MenuSortingDTO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (menuTitle == null) {
			if (other.menuTitle != null)
				return false;
		} else if (!menuTitle.equals(other.menuTitle))
			return false;
		return true;
	}

/*	public AccessListDTO getAccessList() {
		return accessList;
	}

	public void setAccessList(AccessListDTO accessList) {
		this.accessList = accessList;
	}
*/
	public Boolean getCreate() {
		return create;
	}

	public void setCreate(Boolean create) {
		this.create = create;
	}

	public Boolean getDelete() {
		return delete;
	}

	public void setDelete(Boolean delete) {
		this.delete = delete;
	}

	public Boolean getEdit() {
		return edit;
	}

	public void setEdit(Boolean edit) {
		this.edit = edit;
	}

	public Boolean getView() {
		return view;
	}

	public void setView(Boolean view) {
		this.view = view;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
}
