package com.hrms.admin.role.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuDTO {

	private Long menuId;
	private String menuTitle;
	private String menuPath;
	private String menuIcon;
	private Long isParent;
	private Long parentId;
}
