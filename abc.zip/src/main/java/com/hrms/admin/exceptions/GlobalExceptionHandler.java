package com.hrms.admin.exceptions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hrms.admin.dto.ResponseDTO;
import com.hrms.admin.dto.ResultDTO;
import com.hrms.admin.util.Constants;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ResponseDTO> validationExceptionHandling(MethodArgumentNotValidException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		BindingResult bindingResult = ex.getBindingResult();
		FieldError fieldError = bindingResult.getFieldError();
		if (fieldError != null) {
			String defaultMessage = fieldError.getDefaultMessage();
			ResultDTO result = new ResultDTO(new Date(), Constants.VALIDATE, defaultMessage);
			resultlist.add(result);
			return new ResponseEntity<>(new ResponseDTO(defaultMessage, Constants.FALSE, resultlist), HttpStatus.OK);
		}
		return null;

	}

	@ExceptionHandler(NotCreatedException.class)
	public ResponseEntity<ResponseDTO> creatingExceptionHandling(NotCreatedException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<ResponseDTO> findingExceptionHandling(NotFoundException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(NotUpdatedException.class)
	public ResponseEntity<ResponseDTO> updatingExceptionHandling(NotUpdatedException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(NotDeletedException.class)
	public ResponseEntity<ResponseDTO> deletingExceptionHandling(NotDeletedException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(FileUploadException.class)
	public ResponseEntity<ResponseDTO> fileUploadExceptionHandling(FileUploadException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ResponseDTO> userNotFoundExceptionHandling(UserNotFoundException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}

	@ExceptionHandler(LockedException.class)
	public ResponseEntity<ResponseDTO> lockedExceptionHandling(LockedException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}
	
	@ExceptionHandler(EmailNotFoundException.class)
	public ResponseEntity<ResponseDTO> EmailNotFoundExceptionHandling(EmailNotFoundException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}
	
	@ExceptionHandler(FileNotFoundException.class)
	public ResponseEntity<ResponseDTO> FileNotFoundExceptionHandling(FileNotFoundException ex) {
		List<ResultDTO> resultlist = new ArrayList<>();
		ResultDTO result = new ResultDTO(new Date(), Constants.EXCEPTION, ex.getMessage());
		resultlist.add(result);
		return new ResponseEntity<>(new ResponseDTO(ex.getMessage(), Constants.FALSE, resultlist), HttpStatus.OK);
	}
}