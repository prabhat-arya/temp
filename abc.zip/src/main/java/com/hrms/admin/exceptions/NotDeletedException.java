package com.hrms.admin.exceptions;

public class NotDeletedException extends RuntimeException{
	
	private static final long serialVersionUID = -6372089928086608733L;

	public NotDeletedException(String exception) {
		super(exception);
	}
	

}
