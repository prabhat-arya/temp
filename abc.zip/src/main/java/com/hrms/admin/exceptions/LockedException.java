package com.hrms.admin.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.LOCKED)
public class LockedException extends RuntimeException {

	private static final long serialVersionUID = 1300574240429604788L;

	public LockedException(String message) {
		super(message);
	}
}