package com.hrms.admin.exceptions;

public class NotCreatedException extends RuntimeException{
 
	
	private static final long serialVersionUID = 2967933691904572666L;

	public NotCreatedException(String exception) {
		super(exception);
	}
}
