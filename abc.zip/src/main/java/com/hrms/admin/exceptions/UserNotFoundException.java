package com.hrms.admin.exceptions;

public class UserNotFoundException  extends RuntimeException{

	private static final long serialVersionUID = 2215991230110212965L;

	public UserNotFoundException(String message) {
		super(message);
	}
	 

}
