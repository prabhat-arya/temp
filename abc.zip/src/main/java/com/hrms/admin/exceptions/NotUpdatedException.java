package com.hrms.admin.exceptions;

public class NotUpdatedException extends RuntimeException{
	
	private static final long serialVersionUID = -7398406376058328981L;

	public NotUpdatedException(String exception) {
		super(exception);
	}

}
