package com.hrms.admin.exceptions;

public class NotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1304895958987281035L;

	public NotFoundException(String exception) {
		super(exception);
	}
}
