package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EXIT_Feedback")
public class ExitFeedback implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FEEDBACK_ID")
	private Long feedbackId;

	@Column(name = "EMP_EXIT_ID")
	private Long employeeExitMgmtId;

	@Column(name = "SUBMIT_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date submitDate;

	@Column(name = "FEEDBACK", length = 2500)
	private String feedback;

	@Column(name = "SUBMISSIONS",length = 2500)
	private String submission;

	@Column(name = "SIGNATURE")
	private String signature;

	@Column(name = "DEPARTMENT")
	private String department;

	@Column(name = "DESIGNATION")
	private String designation;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "IS_SUBMIT")
	private Boolean isSubmit;

}
