package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "PROJECT")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Project extends AuditingEntity implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PROJECT_ID")
	private Long id;

	@Column(name = "PROJECT_NAME")
	private String name;

	@Column(name = "PROJECT_DESCRIPTION", length = 2500)
	private String description;

	@ManyToMany(targetEntity = Employee.class, mappedBy = "projects", cascade = { CascadeType.PERSIST })
	private List<Employee> employee;

	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "CLIENT_NAME")
	private String clientName;

	@Column(name = "START_DATE", columnDefinition = "DATE")
	@JsonFormat(pattern = "YYYY-MM-dd")
	private String startDate;

	@Column(name = "END_DATE", columnDefinition = "DATE")
	@JsonFormat(pattern = "YYYY-MM-dd")
	private String endDate;

	@Column(name = "ESTIMATION_HOURS")
	private Long estimatedHours;

	public Project(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Project(Long id, String name, String description) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;		
	}

	public Project(String name, String startDate, String endDate, Long estimatedHours) {

		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.estimatedHours = estimatedHours;
	}

}
