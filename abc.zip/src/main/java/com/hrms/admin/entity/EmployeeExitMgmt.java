package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMPLOYEE_EXIT_MGMT")
public class EmployeeExitMgmt implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EMPLOYEE_EXIT_ID")
	private Long employeeExitId;

	@Column(name = "HIRE_DATE")
	private Date hireDate;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;

	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;

	@Column(name = "LAST_WORKING_DATE")
	private Date lastWorkingDate;

	@Column(name = "STATUS")
	private String status;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "EMPLOYEE_EXIT_ID")
	private List<ExitMgmtQuestionAnswers> questionAnswers;
	
	@OneToOne
	@JoinColumn(name = "RESIGNATION_ID")
	private Resignation resignation;

	public EmployeeExitMgmt(Long employeeExitId, Date hireDate, Long employeeId, String employeeName,
			Date lastWorkingDate) {
		super();
		this.employeeExitId = employeeExitId;
		this.hireDate = hireDate;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.lastWorkingDate = lastWorkingDate;
	}

}
