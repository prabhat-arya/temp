package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author {RAMESH RENDLA }
 *
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "ATTENDANCE_INFO")
public class AttendanceInfo extends AuditingEntity implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ATTENDANCE_INFO_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long attendanceId;

	@Column(name = "INTIME", columnDefinition = "TIMESTAMP")
	private String inTime;

	@Column(name = "OUTTIME", columnDefinition = "TIMESTAMP")
	private String outTime;

	@Column(name = "DATE", columnDefinition = "DATE")
	private String date;

	@Column(name = "nohours")
	private String noOfHrs;

	@Column(name = "TOTAL_HOURS")
	private String totalHrs;

	@Column(name = "BREAK_HOURS")
	private String breakHrs;

	@Column(name = "REASON")
	private String reason;

	@Column(name = "AttendsPercentage")
	private Long attndsPercentage;

	@ManyToOne
	@JoinColumn(name = "empid")
	private Employee employee;

	@Column(name = "shift_Id")
	private Long shiftId;

	@OneToOne
	@JoinColumn(name = "shift_Id", insertable = false, updatable = false)
	private Shift shift;

}
