package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "ANNUALLEAVES")
public class AnnualLeaves extends AuditingEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3634280547646048458L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ANNUALLEAVES_ID")
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "LEAVETYPE_ID")
	private LeaveType leaveType;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;

	@Column(name = "TOTAL_TOOK_LEAVES")
	private Long totalTookLeaves;

	@Column(name = "ANNUALLEAVES")
	private Long yearlyLeaves;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "AVAILABLE_LEAVES")
	private Long availableLeaves;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;



	public AnnualLeaves(Long totalTookLeaves, Long availableLeaves) {
		super();
		this.totalTookLeaves = totalTookLeaves;
		this.availableLeaves = availableLeaves;
	}

}
