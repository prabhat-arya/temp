/*
 * package com.hrms.admin.entity;
 * 
 * import java.time.LocalDateTime;
 * 
 * import javax.persistence.Lob;
 * 
 * import org.hibernate.annotations.CreationTimestamp; import
 * org.springframework.data.annotation.Id; import
 * org.springframework.data.annotation.LastModifiedDate; import
 * org.springframework.data.mongodb.core.mapping.Document; import
 * org.springframework.data.mongodb.core.mapping.Field;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.NoArgsConstructor;
 * 
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor
 * 
 * @Document(collection = "FEEDBACK_FILES_UPLOAD") public class FileUpload {
 * 
 * @Id private String fileId;
 * 
 * @Field(name = "FILE_NAME") private String name;
 * 
 * @Field(name = "FILE_TYPE") private String type;
 * 
 * @Lob
 * 
 * @Field(name = "FILE_DATA") private byte[] data;
 * 
 * @Field(name = "FILE_URL") private String url;
 * 
 * @Field(name = "FEEDBACK_ID") private Long feedBackId;
 * 
 * @CreationTimestamp
 * 
 * @Field(value = "CREATED_TIME") private LocalDateTime createdTime;
 * 
 * 
 * @LastModifiedDate
 * 
 * @Field(value = "UPDATED_TIME") private LocalDateTime updatedTime;
 * 
 * 
 * public FileUpload(String name, String type, byte[] data, String url, Long
 * feedBackId,LocalDateTime createdTime,LocalDateTime updatedTime) { this.name =
 * name; this.type = type; this.data = data; this.feedBackId = feedBackId;
 * this.url = url; this.createdTime = createdTime; this.updatedTime =
 * updatedTime; }
 * 
 * 
 * 
 * }
 */