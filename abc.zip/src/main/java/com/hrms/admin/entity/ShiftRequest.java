package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SHIFT_REQUEST")
public class ShiftRequest extends AuditingEntity implements Serializable {
	
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SHIFT_REQUEST_ID")
	private Long id;

	@Column(name = "FROMDATE",columnDefinition = "DATE")
	private String fromdate;

	@Column(name = "TODATE",columnDefinition = "DATE")
	private String todate;

	/*
	 * @Column(name = "SHIFT_ID") private Long currentShiftId;
	 */
	
	@Column(name = "CURRENT_SHIFT_NAME")
	private String currentShiftName;

	@Column(name = "REQUEST_SHIFT_ID")
	private Long requestShiftID;
	
	@Column(name = "REQUEST_SHIFT_NAME")
	private String requestShiftName;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "REASON")
	private String reason;

	@ManyToOne
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;
	
	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;
}
