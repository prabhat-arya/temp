package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "BELL_ICON_NOTIFICATIONS")
public class BellIconNotifications {

	@Id
	@Column(name = "NOTIFICATION_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long notificationId;

	@Column(name = "NOTIFICATION_FLAG")
	private boolean notificationFlag;

	@Column(name = "EMPLOYEE_NOTIFICATION_FLAG")
	private boolean employeeNotificationFlag;

	@Column(name = "APPROVER_ID")
	private Long approverId;

	@Column(name = "NOTIFICATION_MENU_PATH")
	private String notificationMenuPath;

	@Column(name = "NOTIFICATION_TYPE")
	private String notificationType;

	@Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;

	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;

	@Column(name = "NOTIFICATION_MESSAGE")
	private String notificationMessage;

	@Column(name = "NOTIFICATION_DATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private String notificationDate;

	@Column(name = "LEAVE_STATUS")
	private String leaveStatus;

}
