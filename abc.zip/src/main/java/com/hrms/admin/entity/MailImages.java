/*
 * package com.hrms.admin.entity;
 * 
 * import java.io.Serializable;
 * 
 * import org.springframework.data.annotation.Id; import
 * org.springframework.data.mongodb.core.mapping.Document;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.NoArgsConstructor;
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor
 * 
 * @Document(collection = "MAIL_IMAGES") public class MailImages implements
 * Serializable{
 * 
 *//**
	* 
	*//*
		 * private static final long serialVersionUID = 1L; public static final String
		 * SEQUENCE_NAME = "FILE_sequence";
		 * 
		 * @Id private Long id; private byte[] image; private String contantType;
		 * private String fileName; private String fullFileName; }
		 */