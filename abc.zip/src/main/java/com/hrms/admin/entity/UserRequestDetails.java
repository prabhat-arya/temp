package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "USER_REQUEST_DETAILS") 
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRequestDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ACCESS_ID")
	private Long requestId;
	
	@Column(name = "USER_NAME")
	private String userName;
	
	@Column(name = "USER_JWT_TOKEN")
	private String userJwtToken;
	
	@Column(name = "USER_PORT_NO")
	private String userPortNumber;
	
	@Column(name = "USER_BROWSER_NAME")
	private String userBrowserName;

	
}
