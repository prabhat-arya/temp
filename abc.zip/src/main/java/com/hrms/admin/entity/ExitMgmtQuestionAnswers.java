package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EXIT_MGMT_QUESTION_ANSWERS")
public class ExitMgmtQuestionAnswers {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EXIT_QUESTION_ANSWERS_ID")
	private Long exitQuestionAnswersId;
	

	@Column(name = "QUESTION_ID")
	private Long questionId;
	
	
	@Column(name = "BOX_QUESTION", length = 2500)
	private String boxQuestion;
	
	@Column(name = "BOX_ANSWERS", length = 2500)
	private String boxAnswers;
	
	@Column(name = "RADIO_QUESTION")
	private String radioQuestion;
	
	@Column(name = "RADIO_ANSWERS", length = 2500)
	private Integer radioAnswers; //we are converting string to json and storing in DB  as list
	
	
	@Column(name = "RADIO_QUESTION_COMMENT", length = 2500)
	private String radioQuestionComment;
	
}
