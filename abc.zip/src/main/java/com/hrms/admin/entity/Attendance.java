package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ATTENDANCE")
public class Attendance extends AuditingEntity implements Serializable{


	 
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ATTENDANCE_ID")
	private Long id;
	
	@Column(name = "COMPANY_ID")
	private String companyId;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "COMPANY_ID", insertable = false, updatable = false)
	private Company company;

	@Column(name = "BRANCH_ID")
	private Long branchId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(unique = true, name = "BRANCH_ID", insertable = false, updatable = false)
	private Branch branch;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "BRANCH_NAME")
	private String branchName;

	@Column(name = "COMPANY_NAME")
	private String companyName;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "SHIFT_ID")
	private Shift shift;

	@Column(name = "IS_DEFAULT")
	private Boolean isDefault;

}
