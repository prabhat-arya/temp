package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "QUESTION_TABLE")
public class Questions implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "QUESTION_ID")
	private Long questionId;
	
	@Column(name = "BOX_QUESTION", length = 2500)
	private String subjectiveQuestion;
	
	@Column(name = "RADIO_QUESTION", length = 2500)
	private String objectiveQuestion;
	
	@Column(name = "RADIO_QUESTION_COMMENT", length = 2500)
	private String radioQuestionComment;
	
	@Column(name = "IS_DEFAULT")
	private Boolean isDefault;
	
	//@JsonIgnore
	@ManyToOne  (cascade = CascadeType.ALL) 
	@JoinColumn(name = "COMPANY_ID")
	private Company company;
	
}
