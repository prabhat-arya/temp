package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "LEAVE_TYPE")
public class LeaveType extends AuditingEntity implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LEAVE_TYPE_ID")
	private Long id;

	@Column(name = "LEAVE_TYPE_DESCRIPTION", length = 2500)
	private String description;

	@Column(name = "LEAVE_TYPE")
	private String leaveType;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;

	@Column(name = "ANNUALLEAVES")
	private Long annualLeaves;

	@Column(name = "MONTHLY_LEAVES")
	private Long monthlyLeaves;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "IS_CARRY_FORWARD")
	private Boolean isCarryForward;

	@Column(name = "IS_DOCUMENT_REQ")
	private Boolean isDocumentReq;
	
	public LeaveType(Long id,String leaveType) {
		this.id = id;
		this.leaveType = leaveType;
	}

	
	
	

	
}