package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PROFILEIMAGE")
public class ProfileImage implements Serializable{

	
	private static final long serialVersionUID = 4688979033260220596L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PROFILEIMAGE_ID")
	private Long id;
	@Column(name = "IMAGENAME")
	private String imageName;
	
	@Column(name = "IMAGEURL",length = 500)	
	private String imageurl;
	
	@Column(name = "FILETYPE")
	private String fileType;

	@OneToOne
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;
	
	@Column(name = "COMPANY_ID")
	private String companyId;
	
	@Column(name = "CONTENT_TYPE")
	private String contentType;
}
