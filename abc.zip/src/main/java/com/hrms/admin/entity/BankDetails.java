package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "BANK_DETAILS")
public class BankDetails implements Serializable{

	private static final long serialVersionUID = -5974372443371293836L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BANK_DETAILS_ID")
	private Long id;

	@Column(name = "BANKNAME")
	private String bankName;

	@Column(name = "ACCOUNTNO")
	private String accountNo;

	@Column(name = "ACCOUNTHOLDERNAME")
	private String accountHolderName;
	
	@Column(name = "IFSCCODE")
	private String ifscCode;
	
	@Column(name = "BRANCHNAME")
	private String branchName;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;
	
	@Column(name = "ESIC_NUMBER")
	private String esicNumber;
	
	@Column(name = "PF_NUMBER")
	private String pfNumber;

	@Column(name = "UAN_NUMBER")
	private String uanNumber;

}
