package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ADDRESS")
public class Address implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ADDRESS_ID")
	private Long id;
	@Column(name = "ADDRESS", length = 1000)
	private String address;
	@Column(name = "LANDMARK")
	private String landmark;
	@Column(name = "STREET")
	private String street;
	@Column(name = "CITY")
	private Long city;
	@Column(name = "DISTRICT")
	private String district;
	@Column(name = "STATE")
	private Long state;
	@Column(name = "COUNTRY")
	private Long country;
	@Column(name = "PIN_CODE")
	private String pincode;
	@Column(name = "TYPE")
	private String type;

}
