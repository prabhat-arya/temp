package com.hrms.admin.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMPLOYEEROLES"/*
								 * , uniqueConstraints = {
								 * 
								 * @UniqueConstraint(columnNames = "ROLE_NAME"), }
								 */)
public class EmployeeRoles {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ROLE_ID")
	private Long roleId;
	
	@Column(name = "ROLE_NAME")
	private String roleName;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(	name = "ROLE_MENU", 
				joinColumns = @JoinColumn(name = "ROLE_ID"), 
				inverseJoinColumns = @JoinColumn(name = "MENU_ID"))
	private Set<Menu> menus = new HashSet<>();
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(	name = "ROLE_ACCESS", 
				joinColumns = @JoinColumn(name = "ROLE_ID"), 
				inverseJoinColumns = @JoinColumn(name = "ACCESS_ID"))
	private Set<AccessList> accessList;
	
	@OneToOne
	@JoinColumn(name = "ACCESSID")
	private RoleJson roleJson;
	
	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;
	private Boolean isActive;
	
	private Boolean isDelete;

	public EmployeeRoles(Long roleId, String roleName, Boolean isActive, Boolean isDelete) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.isActive = isActive;
		this.isDelete = isDelete;
	}
	
	
}
