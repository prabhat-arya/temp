package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "DEDUCTIONS")
public class Deductions implements Serializable{

	private static final long serialVersionUID = 5464995442410897955L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DEDUCTION_ID")
	private Long id;

	@Column(name = "DEDUCTION_TYPE")
	private String deductionType;

	@Column(name = "DEDUCTION_NAME")
	private String deductionName;

	@Column(name = "NAME_IN_PAYSLIP")
	private String nameInPayslip;

	@Column(name = "CALCULATION_TYPE")
	private String calculationType;
	
	@Column(name = "FLAT_AMOUNT")
	private Double flatAmount;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;
	
	@Column(name = "PERCENTAGE_OF_BASIC")
	private Double percentageOfBasic;
	
	@Column(name = "STATUS")
	private Boolean status;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	public Deductions(Long id,String deductionType, String deductionName, String calculationType, Double flatAmount,
			Double percentageOfBasic, Boolean status) {
		super();
		this.id = id;
		this.deductionType = deductionType;
		this.deductionName = deductionName;
		this.calculationType = calculationType;
		this.flatAmount = flatAmount;
		this.percentageOfBasic = percentageOfBasic;
		this.status = status;
	}

	
	
	
	
}
