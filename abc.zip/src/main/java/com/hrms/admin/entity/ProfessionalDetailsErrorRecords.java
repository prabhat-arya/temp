package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PROFESSIONAL_DETAILS_ERROR_RECORDS")
public class ProfessionalDetailsErrorRecords extends AuditingEntity implements Serializable{

	
	private static final long serialVersionUID = 2357243101529134402L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "EMP_CONTACT_NO")
	private String empContactNO;
	
	@Column(name = "EMP_FIRST_NAME")
	private String empFirstName;

	@Column(name = "EMPLOYEE_ID")
	private String employeeId;
	
	@Column(name = "COMPANY_NAME")
	private String companyName;

	@Column(name = "JOINING_DATE")
	private Date joiningDate;

	@Column(name = "RELIEVING_DATE")
	private Date relievingDate;

	@Column(name = "EXPERIENCE")
	private String experience;

	@Column(name = "CLIENT")
	private String client;
	
	@Column(name = "IS_DEFAULT")
	private String isDefault;
	
}
