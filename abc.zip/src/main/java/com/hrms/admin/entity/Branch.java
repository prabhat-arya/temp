package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "BRANCH")
public class Branch extends AuditingEntity implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BRANCH_ID")
	private Long id;

	@Column(name = "BRANCH_NAME")
	private String name;

	/*
	 * @Column(name = "LOCATION") private String location;
	 */

	@Column(name = "CONTACT_NUMBER")
	private String contactNo;

	@Column(name = "EMAIL_ID")
	private String email;

	@Column(name = "FAX")
	private String fax;
	
	/*
	 * @Column(name = "WEEKEND") private String weekend;
	 */

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	/*
	 * @ManyToMany(targetEntity = Department.class, cascade = { CascadeType.ALL })
	 * private List<Department> department;
	 */
	
	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")  //this is bidirectional
	private Company company;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(unique = true, name = "ADDRESS_ID")
	private Address address;
	
	
	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

}
