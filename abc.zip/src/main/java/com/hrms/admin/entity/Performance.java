


package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PERFORMANCE")
public class Performance implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PERFOMANCE_ID")
	private Long perfomanceId;

	@Column(name = "DEPARTMENT_NAME")
	private String departmentName;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;

	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;

	@Column(name = "PERIOD")
	private Integer period;

	@Column(name = "REVIEW_START")
	private Date reviewStart;

	@Column(name = "REVIEW_END")
	private Date reviewEnd;

	@Column(name = "DUE_DATE")
	private Date dueDate;

	@Column(name = "REVIEW_MANAGER")
	private String reviewManager;

	@Column(name = "ASSIGN_DATE")
	private Date assignDate;

	@Column(name = "EMPLOYEE_STATUS")
	private String employeeStatus;

	@Column(name = "MANAGER_STATUS")
	private String managerStatus;

	@Column(name = "FINAL_COMMENT", length = 2500)
	private String finalComment;

	@Column(name = "FINAL_RATING")
	private String finalRating;

	@Column(name = "COMPLETED_DATE")
	private Date completedDate;

	@Column(name = "REVIWER_STATUS")
	private String reviwerStatus;

	/*
	 * @Column(name = "HR_REVIEWER") private String hrReviewer;
	 * 
	 * @Column(name = "HR_FINAL_COMMENT", length = 2500) private String
	 * hrFinalComment;
	 * 
	 * @Column(name = "HR_FINAL_RATING") private String hrFinalRating;
	 * 
	 * @Column(name = "HR_COMPLETE_DDATE") private Date HrCompletedDate;
	 */

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "PERFOMANCE_ID")
	private List<PerformanceQuesAnsReview> goalQuestionsAnsReview;
	
	@Column(name = "REVIWER_COMMENT")
	private String reviwerComment;
	
	@Column(name = "REVIWER_RATING")
	private String reviwerRating;
	
	@Column(name = "REVIWER_COMPLETED_DATE")
	private String reviwercompletedDate;
	
	@Column(name = "REVIEWER_NAME")
	private String reviewerName;
}
