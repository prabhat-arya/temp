package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SALARYCOMPONENTS")
public class SalaryComponents implements Serializable{

	private static final long serialVersionUID = 6655289973570922573L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SALARYCOMPONENTS_ID")
	private Long id;

	@NonNull
	@Column(columnDefinition = "JSON")
	private String earningJsonData;

	@NonNull
	@Column(columnDefinition = "JSON")
	private String deductionJsonData;

	@NonNull
	@Column(columnDefinition = "JSON")
	private String employeeJsonData;

	@OneToOne
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;

	private String paySlipOfMonth;


	public SalaryComponents(String earningJsonData, String deductionJsonData, String employeeJsonData) {
		super();
		this.earningJsonData = earningJsonData;
		this.deductionJsonData = deductionJsonData;
		this.employeeJsonData = employeeJsonData;
	}

}