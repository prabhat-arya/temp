package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "ASSETS")
public class Assets extends AuditingEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ASSET_ID")
	private Long id;

	@Column(name = "ASSET_NAME")
	private String name;

	@Column(name = "ASSET_DESCRIPTION", length=2500)
	private String description;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	public Assets(Long id, String name, String description, Boolean isDelete, Boolean isActive) {

		this.id = id;
		this.name = name;
		this.description = description;
		this.isDelete = isDelete;
		this.isActive = isActive;
	}

	public Assets(Long id, String name) {
		this.id = id;
		this.name = name;
	}

}
