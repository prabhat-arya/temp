package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMERGENCY_CONTACT_DETAILS")
public class EmergencyContactDetails implements Serializable{

	
	private static final long serialVersionUID = -6002847503380914107L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ECD_ID")
	private Long id;
	
	@Column(name = "ALT_CONTACT_NUMBER")
	private String altContactNumber;

	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;

	@Column(name = "CONTACT_PERSON")
	private String contactPerson;

	@Column(name = "RELATION")
	private String relation;
	
	@Column(name = "IS_DEFAULT")
	private Boolean isDefault;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;
}
