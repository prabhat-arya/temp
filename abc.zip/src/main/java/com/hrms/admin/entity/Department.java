package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "DEPARTMENT")
public class Department extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DEPARTMENT_ID")
	private Long id;

	@Column(name = "DEPARTMENT_NAME")
	private String name;

	@Column(name = "DEPARTMENT_DESCRIPTION", length = 2500)
	private String description;

	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "DEPARTMENT_ID")
	private List<Designation> designation;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@ManyToOne
	@JoinColumn(name = "BRANCH_ID")
//	@JsonIgnore
	private Branch branch;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

}
