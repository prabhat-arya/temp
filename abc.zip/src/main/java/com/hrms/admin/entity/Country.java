package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "COUNTRIES")
public class Country implements Serializable {

	private static final long serialVersionUID = 1L;
@Id
	@Column(name = "COUNTRIES_ID")
	private Long countryId;

	@Column(name = "COUNTRIES_NAME")
	private String countryName;

	@Column(name = "PHONECODE")
	private String phoneCode;

	@Column(name = "SORTNAME")
	private String sortName;

	@Column(name = "ISO3")
	private String iso3;

	@Column(name = "CAPITAL")
	private String capital;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "subregion")
	private String subregion;

}
