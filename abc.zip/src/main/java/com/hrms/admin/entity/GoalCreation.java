package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "GOAL_CREATION")
public class GoalCreation implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GOAL_ID")
	private Long goalId;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;

	@Column(name = "DEPARTMENT_NAME")
	private String departmentName;

	@Column(name = "REVIEW_START")
	private Date reviewStart;

	@Column(name = "PERIOD")
	private Integer period;

	@Column(name = "ASSIGN_DATE")
	private Date assignDate;

	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;

	@Column(name = "REVIEW_END")
	private Date reviewEnd;

	@Column(name = "DUE_DATE")
	private Date dueDate;

	@Column(name = "REVIEW_MANAGER")
	private String reviewManager;

	@Column(name = "STATUS")
	private String status;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "GOAL_ID")
	private List<GoalQuestions> goalQuestions;

	public GoalCreation(Long goalId, String departmentName, String employeeName, Date reviewStart, Date reviewEnd,
			Date dueDate, String status, Long employeeId) {
		super();
		this.goalId = goalId;
		this.departmentName = departmentName;
		this.employeeName = employeeName;
		this.reviewStart = reviewStart;
		this.reviewEnd = reviewEnd;
		this.dueDate = dueDate;
		this.status = status;
		this.employeeId = employeeId;
	}

}
