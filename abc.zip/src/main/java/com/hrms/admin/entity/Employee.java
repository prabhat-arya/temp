package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMPLOYEE")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Employee extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = -8143320141291934448L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "FIRST_NAME")
	private String firstName;
	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "EMAIL", unique = true)
	private String email;

	@Column(name = "OFFICAL_MAIL", unique = true)
	private String officalMail;

	@Column(name = "USER_NAME", unique = true)
	private String userName;
	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "DATE_OF_BIRTH")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date dateOfBirth;

	@Column(name = "MARRIAGE_DAY")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date marriageDay;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "MARITAL_STATUS")
	private String maritalStatus;

	@Column(name = "CONTACT_NO", unique = true)
	private String contactNo;

	@Column(name = "ALTERNATE_CONTACT_NO")
	private String alternateContactNo;

	@Column(name = "AADHAR_CARD")
	private String aadharCard;

	@Column(name = "pan_Card")
	private String panCard;

	@Column(name = "VOTERID")
	private String voterID;

	@Column(name = "JOINING_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date joiningDate;

	@Column(name = "BLOOD_GROUP")
	private String bloodGroup;

	@Column(name = "CTC")
	private Double ctc;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_APPROVE")
	private Boolean isApprove;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "MIDDLE_NAME")
	private String middleName;

	@Column(name = "PASSPORT")
	private String passport;
	
	@Column(name = "IS_EXIT")
	private Boolean isExit;

	@JsonIgnore
	private String token;

	@OneToMany(cascade = CascadeType.ALL) // one to many with Employee
	@JoinColumn(name = "employeeId")
	private List<Address> address;

//	@OneToMany(cascade = CascadeType.ALL) // one to many with Employee
//	@JoinColumn(name = "employeeId")
//	private List<PersonalDetails> personalDetails;

	/*
	 * @OneToMany(cascade = CascadeType.ALL) // one to many with Employee
	 * 
	 * @JoinColumn(name = "employeeId") private List<AcademicDetails>
	 * academicDetails;
	 * 
	 * @OneToMany(cascade = CascadeType.ALL) // one to many with Employee
	 * 
	 * @JoinColumn(name = "employeeId") private List<EmergencyContactDetails>
	 * emergency;
	 */

	@OneToOne // one to one with manager
	@JoinColumn(name = "MANAGER_ID")
	private Employee manager;

	@OneToOne
	@JoinColumn(name = "DEPARTMENT_ID")
	private Department department;

	@OneToOne
	@JoinColumn(name = "DESIGINATION_ID")
	private Designation designation;

	@OneToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@OneToOne
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;

	// many to many with project
	@ManyToMany(targetEntity = Project.class, cascade = { CascadeType.PERSIST })
	private List<Project> projects;

	// many to many with policies
	@ManyToMany(targetEntity = Policy.class, cascade = { CascadeType.PERSIST })
	private List<Policy> policies;

	// many to many with skills
//	@ManyToMany(targetEntity = Skill.class, cascade = { CascadeType.PERSIST })
//	private List<Skill> skills;

	@Column(name = "PRIMARY_SKILLS")
	private String primarySkills;

	@Column(name = "SECONDARY_SKILLS")
	private String secondarySkills;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;

	@Column(name = "PORT")
	private String port;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "emp_roles", joinColumns = @JoinColumn(name = "emp_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<EmployeeRoles> roles = new HashSet<>();

	@Column(name = "IS_LOCK", columnDefinition = "int default 0")
	private int isLock;

	private Date expiryDate;

	@Column(name = "IS_SAME_ADDRESS")
	private Boolean isSameAddress;

	@Column(name = "EMPLOYMENT_TYPE_ID")
	private Long employmentTypeId;

	@Column(name = "EMP_TYPE_STARTDATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date empTypeStartDate;

	@Column(name = "EMP_TYPE_ENDDATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date empTypeEndDate;

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public void setExpiryDate(int minutes) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, minutes);
		this.expiryDate = now.getTime();
	}

	public boolean isExpired() {
		return new Date().after(this.expiryDate);
	}

	public Employee(Long id, String firstName, String lastName, String email, String userName, String contactNo) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.userName = userName;
		this.contactNo = contactNo;
	}

	public Employee(Long id, String firstName, String lastName, String officalMail) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
	}

	public Employee(Long id, String firstName, String lastName, Double ctc) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ctc = ctc;
	}

	public Employee(Long id, String firstName, String lastName, String officalMail, Company company) {

		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.officalMail = officalMail;
		this.company = company;
	}

}
