package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ACADMIC_DETAILS_ERROR_RECORDS")
public class AcadmicDetailsErrorRecords extends AuditingEntity implements Serializable{
	private static final long serialVersionUID = 8729957697916865674L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "INSTITUTE")
	private String instituteName;

	@Column(name = "QUALIFICATION")
	private String qualification;

	@Column(name = "YEAR_OF_PASSING")
	private String yearOfPassing;

	@Column(name = "PERCANTAGE")
	private String percentage;

	@Column(name = "ACADEMICDETAILS_TYPE")
	private String type;
	
	@Column(name = "EMP_CONTACT_NO")
	private String empContactNO;
	
	@Column(name = "EMP_FIRST_NAME")
	private String empFirstName;
	
	@Column(name = "EMPLOYEE_ID")
	private String employeeId;
	
	@Column(name = "IS_DEFAULT")
	private String isDefault;

}
