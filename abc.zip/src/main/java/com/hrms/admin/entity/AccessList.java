package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ACCESS_LIST") 
public class AccessList {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ACCESS_ID")
	private Long accessId;
	
	@Column(name = "VIEW_ACCESS")
	private Boolean view;
	
	@Column(name = "CREATE_ACCESS")
	private Boolean create;
	
	@Column(name = "EDIT_ACCESS")
	private Boolean edit;
	
	@Column(name = "DELETE_ACCESS")
	private Boolean delete;
	
	@OneToOne
	@JoinColumn(name = "MENU_ID")
	private Menu menu;
	
	
	public AccessList(Boolean view, Boolean create, Boolean edit, Boolean delete) {
		super();
		this.view = view;
		this.create = create;
		this.edit = edit;
		this.delete = delete;
	}
}