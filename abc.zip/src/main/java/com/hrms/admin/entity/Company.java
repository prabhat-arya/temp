
package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "COMPANY")
public class Company extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "COMPANY_ID")
	private String id;

	@Column(name = "COMPANY_NAME", unique = true, nullable = false)
	private String name;

	@Column(name = "CONTACT_NUMBER", unique = true, nullable = false)
	private String contact;

	@Column(name = "EMAIL_ID", unique = true, nullable = false)
	private String email;

	@Column(name = "WEBSITE")
	private String website;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "COMPANY_ID")
	private List<Project> project;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(unique = true, name = "ADDRESS_ID")
	private Address address;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "BRANCH")
	private String branch;

	@Column(name = "LOCATION")
	private String location;

	@Column(name = "TAN_NUMBER")
	private String tanNumber;

	@Column(name = "PAN_NUMBER")
	private String panNumber;

	@Column(name = "GST_NUMBER")
	private String gstNumber;

	@Column(name = "CONTACT_PERSON")
	private String contactPerson;

	@Column(name = "USER_NAME", unique = true, length = 50)
	private String userName;

	@Column(name = "LAST_NAME", length = 50)
	private String lastName;

	@Column(name = "FIRST_NAME", length = 50)
	private String firstName;

}
