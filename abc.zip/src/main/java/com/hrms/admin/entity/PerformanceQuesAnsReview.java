package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PERFORMANCE_QUESANS_REVIEW")
public class PerformanceQuesAnsReview implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PRFMNCE_QUS_ANS_RVW_ID")
	private Long prfmnceQusAnsRvwId;

	@Column(name = "QUESTION_ID")
	private Long questionId;

	@Column(name = "QUESTION", length = 2500)
	private String question;

	@Column(name = "EMPLOYEE_ANSWER", length = 2500)
	private String employeeAnswer;

	@Column(name = "MANAGER_ANSWER", length = 2500)
	private String managerAnswer;

	@Column(name = "EMPLOYEE_REVIEW")
	private Double employeeReview;

	@Column(name = "MANAGER_REVIEW")
	private Double managerReview;
	
	@Column(name = "REVIWE_RANSWER", length = 2500)
	private String reviwerAnswer;
	
	@Column(name = "REVIWER_REVIEW")
	private Double reviwerReview;
}
