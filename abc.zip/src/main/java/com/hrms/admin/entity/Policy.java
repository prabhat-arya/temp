package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "POLICY")
public class Policy extends AuditingEntity implements Serializable {

	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "POLICY_ID")
	private Long id;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "POLICY_NAME")
	private String name;

	@ManyToMany(targetEntity = Employee.class, mappedBy = "policies", cascade = { CascadeType.PERSIST })
	private List<Employee> employee = new ArrayList<>();

	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@Column(name = "POLICY_DESCRIPTION", length = 2500)
	private String description;

	@Column(name = "VERSION")
	private String version;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	public Policy(String name, Company company, String version) {
		super();
		this.name = name;
		this.company = company;
		this.version = version;
	}

	public Policy(Long id, String name, String description, String attachmentLink, String fileType,
			List<Employee> employee, Company company, String version, Boolean isActive, Boolean isDelete) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.attachmentLink = attachmentLink;
		this.fileType = fileType;
		this.employee = employee;
		this.company = company;
		this.version = version;
		this.isActive = isActive;
		this.isDelete = isDelete;
	}

	@Column(name = "ATTACHMENT_LINK",length = 500)
	private String attachmentLink;

	public Policy(Long id, String name,Company company, Boolean isActive, Boolean isDelete,
			  String version, String attachmentLink,String fileType) {
		this.id = id;
		this.fileType = fileType;
		this.name = name;
		this.company = company;
		this.isActive = isActive;
		this.isDelete = isDelete;
		this.version = version;
		this.attachmentLink = attachmentLink;
	}
	
	

}