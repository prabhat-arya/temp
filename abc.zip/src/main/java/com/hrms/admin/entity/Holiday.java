package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
@Table(name = "HOLIDAY")
public class Holiday extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HOLIDAY_ID")
	private Long id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "DATE")
	@Temporal(TemporalType.DATE)

	private Date date;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "ATTECHEMENT_ID")
	private Long attechementId;
	
	public Holiday(Long id, String name, Date date, Company company, Branch branch, Boolean isActive,
			Boolean isDelete) {
		this.id = id;
		this.name = name;
		this.date = date;
		this.company = company;
		this.branch = branch;
		this.isActive = isActive;
		this.isDelete = isDelete;
	}

	public Holiday(Long id, String name, Date date, Company company, Branch branch,Long attechementId) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.company = company;
		this.branch = branch;
		this.attechementId=attechementId;
	}

	public Holiday(Long id, String name, Date date,Long attechementId) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.attechementId=attechementId;

	}

}
