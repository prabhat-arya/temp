package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "BANK_DETAIL_ERROR_RECORDS")
public class BankDetailsErrorRecords extends AuditingEntity implements Serializable{

	
	private static final long serialVersionUID = -1942742230925100335L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String employeeID;

	private String accountHolderName;

	private String accountNo;

	private String bankName;

	private String ifscCode;

	private String branchName;

	private String ctc;
	
	private String esicNumber;
	
	private String pfNumber;

	private String uanNumber;

}
