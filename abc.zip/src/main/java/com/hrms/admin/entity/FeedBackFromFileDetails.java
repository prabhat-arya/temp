package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "FEED_BACK_FROM_FILE_DETAILS")
public class FeedBackFromFileDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FILE_ID")
	private Long id;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "FILE_PATH")
	private String filePath;

	@Column(name = "FILE_NAME")
	private String name;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EXITFEEDBACK_ID")
	private ExitFeedback exitFeedback;

	@Column(name = "CONTANT_TYPE")
	private String contantType;

	public FeedBackFromFileDetails(Long id, String name, String filePath, String fileType) {
		super();
		this.id = id;
		this.fileType = fileType;
		this.filePath = filePath;
		this.name = name;
	}

}
