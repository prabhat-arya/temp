/*
 * package com.hrms.admin.entity;
 * 
 * import java.io.Serializable;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.GeneratedValue; import javax.persistence.GenerationType;
 * import javax.persistence.Id; import javax.persistence.Table;
 * 
 * import lombok.AllArgsConstructor; import lombok.Data; import
 * lombok.NoArgsConstructor;
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor
 * 
 * @Entity
 * 
 * @Table(name = "OSTAFF_ORG_MASTER") public class OrgMaster extends
 * AuditingEntity implements Serializable {
 * 
 * private static final long serialVersionUID = 1L;
 * 
 * @Id
 * 
 * @GeneratedValue(strategy = GenerationType.IDENTITY)
 * 
 * @Column(name = "ORG_ID") private Long orgId;
 * 
 * @Column(name = "ORG_NAME") private String orgName;
 * 
 * @Column(name = "ORG_TYPE") private String orgType;
 * 
 * @Column(name = "ORG_NO_EMPLOYEE") private String orgNoOfEmployees;
 * 
 * @Column(name = "ORG_COUNTRY_ID") private int orgCountryId;
 * 
 * @Column(name = "ORG_COUNTRY_NAME") private String orgCountryName;
 * 
 * @Column(name = "ORG_REGION") private String orgRegion;
 * 
 * @Column(name = "ORG_COMMENTS") private String orgComments;
 * 
 * @Column(name = "COMPANY_NAME") private String companyName;
 * 
 * @Column(name = "DB_HOST_NAME") private String dbHostName;
 * 
 * @Column(name = "DB_NAME") private String dbName;
 * 
 * @Column(name = "DB_PORT_NO") private String dbPortNo;
 * 
 * @Column(name = "DB_USER_NAME") private String dbUserName;
 * 
 * @Column(name = "DB_USER_PASSWORD") private String dbUserPassword;
 * 
 * @Column(name = "USER_FIRST_NAME") private String userFirstName;
 * 
 * @Column(name = "USER_LAST_NAME") private String userLastName;
 * 
 * @Column(name = "USER_EMAIL_ID") private String userEmailId;
 * 
 * @Column(name = "USER_NAME") private String userName;
 * 
 * @Column(name = "USER_CONTACT_NO") private String userContactNo;
 * 
 * @Column(name = "USER_ADDRESS") private String userAddress;
 * 
 * @Column(name = "IS_DELETE") private Boolean isDelete;
 * 
 * @Column(name = "IS_ACTIVE") private Boolean isActive;
 * 
 * }
 */