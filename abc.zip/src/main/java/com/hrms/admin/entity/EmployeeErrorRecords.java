package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMP_ERROR_RECORDS")
public class EmployeeErrorRecords extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = 6401778565470920095L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(length = 50)
	private String firstName;
	@Column(length = 50)
	private String middleName;
	@Column(length = 50)
	private String lastName;
	@Column(length = 50)
	private String email;
	@Column(length = 50)
	private String userName;
	@Column(length = 50)
	private Date dateOfBirth;
	@Column(length = 50)
	private String maritalStatus;
	@Column(length = 50)
	private Date marriageDay;
	@Column(length = 50)
	private String gender;
	@Column(length = 50)
	private String contactNo;
	@Column(length = 50)
	private String alternateContactNo;
	@Column(length = 50)
	private String aadharCard;
	@Column(length = 50)
	private String panCard;
	@Column(length = 50)
	private String voterID;
	@Column(length = 50)
	private String passportNo;
	@Column(length = 50)
	private Date joiningDate;
	@Column(length = 50)
	private String bloodGroup;
	@Column(length = 50)
	private String permanantAddress;
	@Column(length = 50)
	private String permanantLandmark;
	@Column(length = 50)
	private String permanantStreet;
	@Column(length = 50)
	private String permanantCity;
	@Column(length = 50)
	private String permanantDistrict;
	@Column(length = 50)
	private String permanantState;
	@Column(length = 50)
	private String permanantCountry;
	@Column(length = 50)
	private String permanantPincode;
	@Column(length = 50)
	private String temporaryAddress;
	@Column(length = 50)
	private String temporaryLandmark;
	@Column(length = 50)
	private String temporaryStreet;
	@Column(length = 50)
	private String temporaryCity;
	@Column(length = 50)
	private String temporaryDistrict;
	@Column(length = 50)
	private String temporaryState;
	@Column(length = 50)
	private String temporaryCountry;
	@Column(length = 50)
	private String temporaryPincode;
	@Column(length = 50)
	private String companyName;
	@Column(length = 50)
	private String branchName;
	@Column(length = 50)
	private String departmentName;
	@Column(length = 50)
	private String designationName;
	@Column(length = 500)
	private String skillsList;
	/*
	 * @Column(length = 50) private String personDetails1;
	 * 
	 * @Column(length = 50) private String pd1Relation;
	 * 
	 * @Column(length = 50) private String pd1ContactNumber;
	 * 
	 * @Column(length = 50) private String pd1AaltContactNumber;
	 * 
	 * @Column(length = 50) private String personDetails2;
	 * 
	 * @Column(length = 50) private String pd2Relation;
	 * 
	 * @Column(length = 50) private String pd2ContactNumber;
	 * 
	 * @Column(length = 50) private String pd2AaltContactNumber;
	 */
	@Column(length = 50)
	private String managar;
	@Column(length = 50)
	private String roles;
	@Column(length = 50)
	private String employmentType;
	@Column(length = 50)
	private Date empTypeStartDate;
	@Column(length = 50)
	private Date empTypeEndDate;
	@Column(length = 500)
	private String secondarySkillsList;
}
