package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMP_RESIGNATION")
public class Resignation extends AuditingEntity implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5483312259009112201L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESIGNATION_ID")
	private Long id;

	@Column(name = "EMPLOYEE_ID")
	private Long employee;
		
	@Column(name = "RESIGNATION_SUBMITTED_ON")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date resignationSubmittedOn;
	
	@Column(name = "TENTATIVE_LEAVING_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date tentativeLeavingDate;
	
	@Column(name = "REASON")
	private String reason;
	
	@Column(name = "DESCRIPTION",length = 2500)
	private String description;
	
		
	@Column(name = "NOTICE_PERIOD")
	private Integer noticePeriod;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "REASON_FOR_REJECT")
	private String reasonForReject;
	
	@Column(name = "IS_CHECKED")
	private Boolean isChecked;

	@Column(name = "REASON_FOR_EMP_REVOKE")
	private String reasonForEmpRevoke;
	
	@Column(name = "RESIGNATION_APPROVED_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date resignationApprovedDate;
	
	@Column(name = "REVOKE_APPLIED_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date revokeAppliedDate;
	
	@Column(name = "REASON_FOR_MANAGER_REVOKE")
	private String reasonForManagerRevoke;
	
	@Column(name = "REVOKE_APPROVED_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "YYYY-MM-dd")
	private Date revokeApprovedDate;
}
