package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "DESIGNATION")
public class Designation extends AuditingEntity implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DESIGNATION_ID")
	private Long id;

	@Column(name = "DESIGNATION")
	private String designation;

	@Column(name = "SKILLS")
	private String skills;

	@Column(name = "EXPERIANCE")
	private String experiance;

	@ManyToOne
	@JoinColumn(name = "DEPARTMENT_ID")
	@JsonIgnore
	private Department department;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@Column(name = "BAND")
	private String band;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	/*
	 * @ManyToMany(fetch = FetchType.LAZY)
	 * 
	 * @JoinTable(name = "DESIGNATION_ROLES", joinColumns = @JoinColumn(name =
	 * "ID"), inverseJoinColumns = @JoinColumn(name = "ROLE_ID")) private
	 * Set<EmployeeRoles> roles;
	 */
	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@ManyToOne
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;
}
