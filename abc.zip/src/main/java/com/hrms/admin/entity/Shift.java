package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SHIFT")
public class Shift extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SHIFT_ID")
	private Long id;

	@Column(name = "IN_TIME", columnDefinition = "TIMESTAMP")
	private String inTime;

	@Column(name = "OUT_TIME", columnDefinition = "TIMESTAMP")
	private String outTime;

	@Column(name = "SHIFT_NAME")
	private String shiftName;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "WEEKEND")
	private String weekend;

	@Column(name = "TYPE")
	private Boolean type;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COMPANY_ID", insertable = true, updatable = true)
	private Company company;

	@Column(name = "ALLOWANCE_APPLICABLE")
	private Boolean allowanceApplicable;

	@Column(name = "ALLOWANCE_AMOUNT")
	private Double allowanceAmount;
}
