package com.hrms.admin.entity;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
//@Document(collection = "EMAILTEMPLATE")
@Entity
@Table(name = "EMAIL_TEMPLATE")
public class EmailTemplate extends AuditingEntity implements Serializable {

	private static final long serialVersionUID = -5622734335458512390L;

//	public static final String SEQUENCE_NAME = "EmailTemplate_sequence";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TEMPLATE_ID")
	private Long id;
	
	@Column(name = "FROM_MAIL")
	private String from;
	
	@Column(name = "SUBJECT")
	private String subject;
	
	@Column(name = "PLAIN_TEXT")
	@Lob
	private Blob plainText;
	
	@Column(name = "TEMPLATE_NAME")
	private String templateName;
	
	@Column(name = "EMPLOYEE_ID")
	private Long empId;

}
