package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Table(name = "NOTIFICATION")
public class Notification extends AuditingEntity implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "NOTIFICATION_ID")
	private Long id;

	@Column(name = "SUBJECT")
	private String subject;

	@Column(name = "NOTIFICATION_DESCRIPTION", length = 2500)
	private String description;

	@Column(name = "EVENT_DATE")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date eventDate;

	@ManyToOne
	@JoinColumn(name = "COMPANY_ID")
	private Company company;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;
	
	@Column(name = "FROM_MAIL")
	private String fromMail;

	public Notification(Long id, String subject, Company company) {
		super();
		this.id = id;
		this.subject = subject;
		this.company = company;
	}

}