package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ASSIGN_SHIFT")
public class AssignShift extends AuditingEntity implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ASSIGN_SHIFT_ID")
	private Long id;

	@Column(name = "FROM_DATE", columnDefinition = "DATE")
	private String fromDate;

	@Column(name = "TO_DATE", columnDefinition = "DATE")
	private String toDate;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "SHIFT_ID")
	private Shift shift;

	@Column(name = "SHIFT_NAME")
	private String shiftName;
	
	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;

	@Column(name = "DAY_STATUS")
	private String dayStatus;

	@Column(name = "PROJECT_NAME")
	private String projectName;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@Column(name = "PROJECT_ID")
	private Long projectId;

	@Column(name = "MANAGER_ID")
	private Long managerId;

	
}
