package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="MENU")
public class Menu {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MENU_ID")
	private Long menuId;
	
	@Column(name = "MENU_TITLE")
	private String menuTitle;
	
	@Column(name = "MENU_PATH")
	private String menuPath;
	
	@Column(name = "MENU_ICON")
	private String menuIcon;
	
	@Column(name = "IS_PARENT")
	private Long isParent;
	
	@Column(name = "PARENT_ID")
	private Long parentId;

	public Menu() {
		super();
	}

	public Menu(Long menuId, String menuTitle, String menuPath, String menuIcon, Long isParent, Long parentId) {
		super();
		this.menuId = menuId;
		this.menuTitle = menuTitle;
		this.menuPath = menuPath;
		this.menuIcon = menuIcon;
		this.isParent = isParent;
		this.parentId = parentId;
	}
	
	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getMenuTitle() {
		return menuTitle;
	}

	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public String getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}

	public Long getIsParent() {
		return isParent;
	}

	public void setIsParent(Long isParent) {
		this.isParent = isParent;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	
	@Override
	public String toString() {
		return "Menu [menuId=" + menuId + ", menuTitle=" + menuTitle + ", menuPath=" + menuPath + ", menuIcon="
				+ menuIcon + ", isParent=" + isParent + ", parentId=" + parentId + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuId == null) ? 0 : menuId.hashCode());
		result = prime * result + ((menuTitle == null) ? 0 : menuTitle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Menu other = (Menu) obj;
		if (menuId == null) {
			if (other.menuId != null)
				return false;
		} else if (!menuId.equals(other.menuId))
			return false;
		if (menuTitle == null) {
			if (other.menuTitle != null)
				return false;
		} else if (!menuTitle.equals(other.menuTitle))
			return false;
		return true;
	}
}
