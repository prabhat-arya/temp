package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "RESOURCE_ITEMS")
public class ResourceItems extends AuditingEntity implements Serializable{


	
	private static final long serialVersionUID = -8289783639767091010L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESOURCE_ITEMS_ID")
	private long id;

	@OneToOne(fetch = FetchType.EAGER) //one to one with assets
	@JoinColumn(name = "ASSET_ID")
	private Assets asset;

	@Column(name = "RESOURCE_VALUE")
	private String value;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "EMPLOYEE_ID")
    private Employee employee;
	
	@Column(name = "IS_DELETE")
	private Boolean isDelete;

}
