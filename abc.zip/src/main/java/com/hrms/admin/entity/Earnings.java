package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EARNINGS")
public class Earnings implements Serializable{

	private static final long serialVersionUID = -3444027857840194885L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EARNING_ID")
	private Long id;

	@Column(name = "EARNING_TYPE")
	private String earningType;

	@Column(name = "EARNING_NAME")
	private String earningName;

	@Column(name = "NAME_IN_PAYSLIP")
	private String nameInPayslip;

	@Column(name = "CALCULATION_TYPE")
	private String calculationType;

	@Column(name = "FLAT_AMOUNT")
	private Double flatAmount;

	@Column(name = "PERCENTAGE_OF_GROSS_SALARY")
	private Double percentageOfGrossSalary;

	@Column(name = "PERCENTAGE_OF_BASIC")
	private Double percentageOfBasic;

	@Column(name = "STATUS")
	private Boolean status;

	@Column(name = "IS_DELETE")
	private Boolean isDelete;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "BRANCH_ID")
	private Branch branch;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "COMPANY_ID")
	private Company company;
	@Column(name = "INCLUSIVE_OF_NET_SALARY")
	private Boolean inclusiveOfNetSalary;

	@Column(name = "EXCLUSIVE_OF_NET_SALARY")
	private Boolean exclusiveOfNetSalary;


	public Earnings(Long id, String earningType, String earningName, String calculationType, Double flatAmount,
			Double percentageOfGrossSalary, Double percentageOfBasic, Boolean status, Boolean inclusiveOfNetSalary,
			Boolean exclusiveOfNetSalary) {
		this.id = id;
		this.earningType = earningType;
		this.earningName = earningName;
		this.calculationType = calculationType;
		this.flatAmount = flatAmount;
		this.percentageOfGrossSalary = percentageOfGrossSalary;
		this.percentageOfBasic = percentageOfBasic;
		this.status = status;
		this.inclusiveOfNetSalary = inclusiveOfNetSalary;
		this.exclusiveOfNetSalary = exclusiveOfNetSalary;
	}

	
	
}
