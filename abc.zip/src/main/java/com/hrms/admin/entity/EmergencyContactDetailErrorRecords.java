package com.hrms.admin.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMERGENCY_CONTACT_DETAIL_ERROR_RECORDS")
public class EmergencyContactDetailErrorRecords extends AuditingEntity implements Serializable {


	private static final long serialVersionUID = -6002847503380914107L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "ALT_CONTACT_NUMBER")
	private String altContactNumber;

	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;

	@Column(name = "CONTACT_PERSON")
	private String contactPerson;

	@Column(name = "RELATION")
	private String relation;
	
	@Column(name = "EMP_CONTACT_NO")
	private String empContactNO;
	
	@Column(name = "EMP_FIRST_NAME")
	private String empFirstName;
	
	@Column(name = "EMPLOYEE_ID")
	private String employeeId;
	
	@Column(name = "IS_DEFAULT")
	private String isDefault;

}
