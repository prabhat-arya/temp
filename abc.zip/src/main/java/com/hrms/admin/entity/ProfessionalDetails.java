package com.hrms.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PROFESSIONAL_DETAILS")
public class ProfessionalDetails implements Serializable{


	
	private static final long serialVersionUID = -5717714224713865778L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PROFESSIONAL_DETAILS_ID")
	private Long id;

	@Column(name = "COMPANYNAME")
	private String companyName;

	@Column(name = "JOINING_DATE", columnDefinition = "DATE")
	private Date joiningDate;

	@Column(name = "RELIEVING_DATE", columnDefinition = "DATE")
	private Date relievingDate;

	@Column(name = "EXPERIENCE")
	private String experience;

	@Column(name = "CLIENT")
	private String client;
	
	@Column(name = "IS_DEFAULT")
	private Boolean isDefault;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employee employee;
	
}
