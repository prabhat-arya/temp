package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.dto.JobDTO;
import com.hrms.admin.entity.Job;

@Repository
public interface Jobrepository extends JpaRepository<Job, Long> {

	// validation
	@Query(value = "SELECT count(*) FROM Job j WHERE   j.name=:name AND   j.company.id=:companyId   AND   j.branch.id=:branchId AND j.isDelete=false")
	public Long getJobCountForSave(String name, String companyId, Long branchId);

	@Query(value = "SELECT count(*) FROM Job j WHERE   j.name=:name AND   j.company.id=:companyId   AND   j.branch.id=:branchId AND j.id <> :jobId AND j.isDelete=false")
	public Long getJobCountForUpdate(String name, String companyId, Long branchId, Long jobId);

	public Optional<Job> findByName(String name);

	@Query("select new com.hrms.admin.dto.JobDTO(j.id,j.name,j.description,j.experience,j.company.id,j.company.name,j.branch.id,j.branch.name) from Job j WHERE  (j.name LIKE %?1% OR j.company.name LIKE %?1% OR j.branch.name LIKE %?1%  OR j.experience LIKE %?1%) AND j.company.id=?2 and j.isActive=?3 AND j.isDelete=false")
	Page<JobDTO> jobPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query("select new com.hrms.admin.dto.JobDTO(j.id,j.name,j.description,j.experience,j.company.id,j.company.name,j.branch.id,j.branch.name) from Job j WHERE  (j.name LIKE %?1% OR j.company.name LIKE %?1% OR j.branch.name LIKE %?1%  OR j.experience LIKE %?1%) AND j.company.id=?2 AND (j.isActive=true OR j.isActive=false) AND j.isDelete=false")
	Page<JobDTO> allJobPage(String searchKey,String companyId, Pageable pageable);
	
	@Query("select j from Job j where j.id=:id and j.company.id=:companyId and j.isActive=true and j.isDelete=false")
	public Optional<Job> findJobByCompanyId(Long id,String companyId);
}
