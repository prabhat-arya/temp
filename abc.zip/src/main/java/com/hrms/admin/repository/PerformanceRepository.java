package com.hrms.admin.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.PerfomanceResponceDTO;
import com.hrms.admin.entity.Performance;

public interface PerformanceRepository extends JpaRepository<Performance, Long> {

	public Performance findByEmployeeId(Long employeeId);

	@Query("SELECT new com.hrms.admin.dto.PerfomanceResponceDTO(p.employeeId,p.reviewStart,p.reviewEnd,p.assignDate,p.managerStatus,p.completedDate,e.designation.designation,e.firstName,e.lastName) FROM Performance p INNER JOIN Employee e ON p.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% )  AND  p.reviewStart>=:startDate1    AND    p.reviewEnd<=:endDate1 and e.company.id=:companyId AND e.isDelete=false")
	Page<PerfomanceResponceDTO> performanceReportByDates(String searchKey, String companyId, Pageable pageable,
			Date startDate1, Date endDate1);

	@Query("SELECT new com.hrms.admin.dto.PerfomanceResponceDTO(p.employeeId,p.reviewStart,p.reviewEnd,p.assignDate,p.managerStatus,p.completedDate,e.designation.designation,e.firstName,e.lastName) FROM Performance p INNER JOIN Employee e ON p.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% ) and e.company.id=:companyId AND e.isDelete=false")
	Page<PerfomanceResponceDTO> performanceReport(String searchKey, String companyId, Pageable pageable);

	@Query("SELECT new com.hrms.admin.dto.PerfomanceResponceDTO(p.employeeId,p.reviewStart,p.reviewEnd,p.assignDate,p.managerStatus,p.completedDate,e.designation.designation,e.firstName,e.lastName) FROM Performance p INNER JOIN Employee e ON p.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% )  AND  p.reviewStart>=:startDate1    AND    p.reviewEnd<=:endDate1 and e.company.id=:companyId  AND e.isDelete=false")
	public List<PerfomanceResponceDTO> findperformanceReportByDates(Date startDate1, Date endDate1, String searchKey,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PerfomanceResponceDTO(p.employeeId,p.reviewStart,p.reviewEnd,p.assignDate,p.managerStatus,p.completedDate,e.designation.designation,e.firstName,e.lastName) FROM Performance p INNER JOIN Employee e ON p.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% ) and e.company.id=:companyId  AND  e.isDelete=false")
	public List<PerfomanceResponceDTO> findperformanceReports(String searchKey, String companyId);
}
