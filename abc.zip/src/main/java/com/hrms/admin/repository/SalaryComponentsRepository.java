package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.SalaryComponents;

public interface SalaryComponentsRepository extends JpaRepository<SalaryComponents, Long> {
	
	

//	@Query(value = "SELECT * FROM SalaryComponents sc WHERE sc.employee_id=:employeeId",nativeQuery = true)
//	SalaryComponents getAllFields(Long employeeId);
//	
//	@Query(value = "SELECT * FROM SalaryComponents sc WHERE sc.employee_id=:employeeId",nativeQuery = true)
//	SalaryComponents getComponents(Long employeeId);
//
//	Optional<SalaryComponents> findByEmployeeId(Long empId);
	
	@Query(value = "SELECT new com.hrms.admin.entity.SalaryComponents(sc.earningJsonData,sc.deductionJsonData,sc.employeeJsonData) FROM SalaryComponents sc WHERE sc.employee.id=:employeeId and sc.paySlipOfMonth=:paySlipOfMonth")
	SalaryComponents findByPaySlipOfMonth(Long employeeId, String paySlipOfMonth);
	
	@Query(value = "SELECT new com.hrms.admin.entity.SalaryComponents(sc.earningJsonData,sc.deductionJsonData,sc.employeeJsonData) FROM SalaryComponents sc WHERE sc.employee.id=:employeeId and sc.paySlipOfMonth=:paySlipOfMonth")
	List<SalaryComponents> findByPaySlipOfMonth2(Long employeeId, String paySlipOfMonth);
	
	
	
}
