package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Policy;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {


	public Optional<Policy> findByName(String name);

	// validation
	@Query(value = "SELECT count(*) FROM Policy p WHERE   p.company.id=:companyId AND p.name=:name AND p.version=:version AND p.isDelete=false")
	public Long getPolicyCountForSave(String companyId,String name,String version);

	@Query(value = "SELECT count(*) FROM Policy p WHERE  p.company.id=:companyId AND  p.name=:name AND p.id <> :policyId AND p.version=:version AND p.isDelete=false")
	public Long getPolicyCountForUpdate(String companyId, String name, Long policyId,String version);

	@Query("SELECT a FROM Policy a WHERE a.isActive=true AND a.isDelete=false")
	public List<Policy> findAll();

	@Query("SELECT a FROM Policy a WHERE a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public List<Policy> findByCompany(String  companyId);
	
	// page indicate these methods are use to get the data as Pageable
	//@Query("select p from Policy p WHERE  (p.name LIKE %?1% OR p.company.name LIKE %?1%) AND p.isActive=?2 AND p.isDelete=false")
	@Query("from Policy p WHERE  (p.name LIKE %?1% OR p.company.name LIKE %?1% OR p.company.id LIKE %?1% OR p.version LIKE %?1% OR p.attachmentLink LIKE %?1% OR p.fileType LIKE %?1%)and p.company.id=?2 AND p.isActive=?3 AND p.isDelete=false")
	Page<Policy> policyPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query(" from Policy p WHERE  (p.name LIKE %?1% OR p.company.name LIKE %?1% OR p.company.id LIKE %?1% OR p.version LIKE %?1% OR p.attachmentLink LIKE %?1% OR p.fileType LIKE %?1%)and p.company.id=?2 AND (p.isActive=true OR p.isActive=false) AND p.isDelete=false")
	Page<Policy> allpolicyPage(String searchKey,String companyId, Pageable pageable);

	//@Query("SELECT new com.hrms.admin.entity.Policy(a.id,a.name,a.description,a.attachmentLink,a.fileType,a.employee,a.company,a.version,a.isActive,a.isDelete) FROM Policy a WHERE a.name=:name AND a.isActive=true AND a.isDelete=false")
	@Query("SELECT a FROM Policy a WHERE a.name=:name AND a.isActive=true AND a.isDelete=false and a.company.id=:companyId")
	public List<Policy> findAllPolicies(String name,String companyId);
	
	@Query("select p from Policy p where p.id=:id and p.company.id=:companyId AND p.isActive=true AND p.isDelete=false ")
	public Optional<Policy> findPolicyByCompanyId(Long id, String companyId);

}
