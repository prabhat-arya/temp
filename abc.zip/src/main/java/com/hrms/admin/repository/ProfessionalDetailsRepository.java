package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.ProfessionalDetails;

public interface ProfessionalDetailsRepository extends JpaRepository<ProfessionalDetails, Long> {

	@Query(value = "SELECT p FROM ProfessionalDetails p WHERE  p.employee.id=:employeeId")
	public List<ProfessionalDetails> findByEmployee(Long employeeId);

	@Query(value = "SELECT p FROM ProfessionalDetails p WHERE  p.employee.id=:employeeId and p.isDefault=true")
	public ProfessionalDetails basedOnEmployee(Long employeeId);
}
