package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.EmployeeExitMgmt;

public interface EmployeeExitMgmtRepository extends JpaRepository<EmployeeExitMgmt, Long> {

	public EmployeeExitMgmt findByEmployeeId(Long employeeId);
	/*
	 * // page indicate these methods are use to get the data as Pageable
	 * 
	 * @Query("select new com.hrms.admin.entity.EmployeeExitMgmt(e.employeeExitId,e.hireDate,e.employeeId,e.employeeName,e.lastWorkingDate) from EmployeeExitMgmt e"
	 * ) Page<EmployeeExitMgmt> exitFormPage(Pageable pageable);
	 */

	@Query("select em from EmployeeExitMgmt em inner join Employee e on e.id=em.employeeId where e.company.id=?1")
	Page<EmployeeExitMgmt> exitFormPage(String companyId, Pageable pageable);

	@Query("select em from EmployeeExitMgmt em inner join Employee e on e.id=em.employeeId where e.company.id=?1")
	List<EmployeeExitMgmt> exitFormPage(String companyId);
}
