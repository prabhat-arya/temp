/*
 * package com.hrms.admin.repository;
 * 
 * import org.springframework.data.mongodb.repository.MongoRepository; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.hrms.admin.entity.EmployeeProfileImage;
 * 
 * @Repository public interface EmployeeProfileImageRepository extends
 * MongoRepository<EmployeeProfileImage, Long> {
 * 
 * }
 */