package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.AttendanceInfoBreaksHistory;

public interface AttendanceInfoBreaksHistoryRepository extends JpaRepository<AttendanceInfoBreaksHistory, Long> {

	@Query("select min(inTime) from AttendanceInfoBreaksHistory where employee.id=:empid and date=:date")
	public String getIntime(Long empid, String date);

	@Query("select max(outTime) from AttendanceInfoBreaksHistory where employee.id=:empid and date=:date")
	public String getOutTime(Long empid, String date);

	@Query("select timediff(timediff(max(a.outTime),min(a.inTime)) ,SEC_TO_TIME( SUM( TIME_TO_SEC( timediff(a.outTime,a.inTime) ) ) )) from AttendanceInfoBreaksHistory  a where employee.id=:empid and date=:date")
	public String getBreakHrs(Long empid, String date);

	@Query("select SEC_TO_TIME( SUM( TIME_TO_SEC( timediff(outTime,inTime) ) ) ) from AttendanceInfoBreaksHistory where employee.id=:empid and date=:date")
	public String getNoOfhrs(Long empid, String date);
}
