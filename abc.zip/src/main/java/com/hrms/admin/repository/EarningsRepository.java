package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Earnings;

public interface EarningsRepository extends JpaRepository<Earnings, Long> {

	
	@Query(value = "SELECT count(e.id) FROM Earnings e WHERE e.earningName=:name and  e.company.id=:companyId AND e.isDelete=false")
	Long getEarningsCountSave(String name,String companyId);

	@Query(value = "SELECT count(e.id) FROM Earnings e WHERE e.earningName=:name AND e.id=:id AND e.isDelete=false and e.company.id=:companyId")
	Long getEarningsCountUpdate(String name, Long id,String companyId);

//	@Query(value = "SELECT new com.hrms.admin.entity.Earnings(e.id,e.earningType,e.earningName,e.calculationType,e.flatAmount,e.percentageOfGrossSalary,e.percentageOfBasic,e.status,e.inclusiveOfNetSalary,e.exclusiveOfNetSalary) FROM Earnings e WHERE e.branch.id=:branchId AND e.isDelete=false order by e.id")
//	List<Earnings> getAllFields(Long branchId);

	@Query(value = "SELECT new com.hrms.admin.entity.Earnings(e.id,e.earningType,e.earningName,e.calculationType,e.flatAmount,e.percentageOfGrossSalary,e.percentageOfBasic,e.status,e.inclusiveOfNetSalary,e.exclusiveOfNetSalary) FROM Earnings e WHERE e.company.id=:companyId AND e.isDelete=false order by e.id")
	List<Earnings> getAllFields(String companyId);

	@Query("select new com.hrms.admin.entity.Earnings(e.id,e.earningType,e.earningName,e.calculationType,e.flatAmount,e.percentageOfGrossSalary,e.percentageOfBasic,e.status,e.inclusiveOfNetSalary,e.exclusiveOfNetSalary) from Earnings e WHERE  (e.earningName LIKE %?1% OR e.earningType LIKE %?1% OR e.nameInPayslip LIKE %?1% OR e.percentageOfGrossSalary LIKE %?1% OR e.flatAmount LIKE %?1% OR e.percentageOfBasic LIKE %?1%) AND (e.status=true OR e.status=false) AND e.isDelete=false and e.company.id=?2")
	Page<Earnings> allEarningsPage(String searchKey,String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.entity.Earnings(e.id,e.earningType,e.earningName,e.calculationType,e.flatAmount,e.percentageOfGrossSalary,e.percentageOfBasic,e.status,e.inclusiveOfNetSalary,e.exclusiveOfNetSalary) from Earnings e WHERE  (e.earningName LIKE %?1% OR e.earningType LIKE %?1% OR e.nameInPayslip LIKE %?1% OR e.percentageOfGrossSalary LIKE %?1% OR e.flatAmount LIKE %?1% OR e.percentageOfBasic LIKE %?1%) AND e.status=?2 AND e.isDelete=false and e.company.id=?3")
	Page<Earnings> earningsPage(String searchKey, Boolean status,String companyId, Pageable pageable);

//	
//	@Query(value = "SELECT e FROM Earnings e WHERE e.isDelete=false")
//	List<Earnings> getComponents();
	@Query(value = " FROM Earnings e WHERE e.company.id=:companyId AND e.isDelete=false")
	public List<Earnings> getAllEarnings(String companyId);
}
