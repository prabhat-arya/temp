package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {

	@Query("select p from Project p where p.name=:name AND p.company.id=:companyId AND p.isActive=true AND p.isDelete=false")
	public Optional<Project> getProjectsList(String name, String companyId);

	// for duplicate checks

	@Query(value = "SELECT count(*) FROM Project p WHERE p.company.id=:companyId AND p.name=:projectName AND p.isDelete=false")
	public Long getProjectCount(String companyId, String projectName);

	@Query(value = "SELECT count(*) FROM Project p WHERE p.company.id=:companyId  AND p.name=:projectName AND p.id <> :projectId AND p.isDelete=false")
	public Long getProjectCountForUpdate(String companyId, String projectName, Long projectId);

	/*
	 * 
	 * 
	 * @Query("SELECT a FROM Project a WHERE a.branch.id=:branchId AND a.isActive=true AND a.isDelete=false AND a.company.isActive=false     "
	 * ) //@
	 * Query("SELECT new com.hrms.admin.entity.Project(a.id,a.name,a.description,a.employee.id,a.company.id,a.branch.id,a.clientName,a.startDate,a.endDate,a.estimatedHours) FROM Project a WHERE a.branch.id=:branchId AND a.isActive=true AND a.isDelete=false AND a.company.isActive=false     "
	 * ) public List<Project> findByBranchId(Long branchId);
	 */
	@Query("SELECT a FROM Project a WHERE a.isActive=true AND a.isDelete=false")
	public List<Project> findAll();

	// changed
	// @Query("select a from Project a where a.company.id=:id AND a.isActive=true
	// AND a.isDelete=false")
	// @Query("select new
	// com.hrms.admin.dto.ProjectDTO(a.id,a.name,a.description,a.employee,a.company,a.branch,a.isDelete,a.isActive,a.status,a.remarks,a.clientName,a.startDate,a.endDate,a.estimatedHours)
	// from Project a where a.company.id=:id AND a.isActive=true AND
	// a.isDelete=false")
	@Query("select new com.hrms.admin.entity.Project(a.id,a.name,a.description) from Project a where a.company.id=:id AND a.isActive=true AND a.isDelete=false")
	public List<Project> findByCompany(String id);

	@Query("select a from Project a where a.company.id=:id AND a.isActive=true AND a.isDelete=false")
	public List<Project> findByCompanyEmployees(Long id);

	// changed
	@Query("select new com.hrms.admin.entity.Project(a.id,a.name) from Project a where a.id=:managerId AND a.isActive=true AND a.isDelete=false")
	public List<Project> projectsListBasedOnManager(Long managerId);

	@Query("select a from Project a where a.id=:managerId AND a.isActive=true AND a.isDelete=false")
	public List<Project> projectsListBasedOnManagerEmployee(Long managerId);

	@Query("select a.name from Project a WHERE a.company.id=:companyId AND isActive=true AND isDelete=false")
	public List<String> projectNameInPiechart(Long companyId);

	@Query("SELECT a.name FROM Project a WHERE a.id=:id")
	public String getProjectName(Long id);

	// page indicate these methods are use to get the data as Pageable

	// @Query("select new
	// com.hrms.admin.entity.Project(p.name,p.startDate,p.endDate,p.estimatedHours)
	// from Project p WHERE (p.name LIKE %?1% OR p.company.name LIKE %?1% OR
	// p.startDate LIKE %?1% OR p.endDate LIKE %?1% OR p.estimatedHours LIKE %?1%)
	// AND p.isActive=?2 AND p.isDelete=false")
	
	@Query("select new com.hrms.admin.dto.ProjectDTO(p.id,p.name,p.company.id,p.company.name,p.startDate,p.endDate,p.estimatedHours) from Project p WHERE  (p.name LIKE %?1%  OR  p.company.name LIKE %?1%   OR  p.startDate LIKE %?1%  OR  p.endDate LIKE %?1%  OR p.estimatedHours LIKE %?1%) and p.company.id=?2 AND p.isActive=?3 AND p.isDelete=false")
	Page<ProjectDTO> projectPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query("select new com.hrms.admin.dto.ProjectDTO(p.id,p.name,p.company.id,p.company.name,p.startDate,p.endDate,p.estimatedHours) from Project p WHERE  (p.name LIKE %?1%  OR  p.company.name LIKE %?1%   OR  p.startDate LIKE %?1%  OR  p.endDate LIKE %?1%  OR p.estimatedHours LIKE %?1%) and p.company.id=?2 AND (p.isActive=true OR p.isActive=false) AND p.isDelete=false")
	Page<ProjectDTO> allProjectPage(String searchKey,String companyId, Pageable pageable);

	/*
	 * 
	 * 
	 * @Query(value = "select p.project_name  \r\n" +
	 * "from project p, employee e ,employee_projects ep where p.project_id=ep.projects_project_id and e.id= ep.employee_id\r\n"
	 * + "and e.id= :id ;", nativeQuery = true) public List<String>
	 * getProjectNameByEmpId(Long id);
	 */
	@Query(value = "select * from project p, employee e ,employee_projects ep where p.project_id=ep.projects_project_id and e.id= ep.employee_id and e.id= :id and p.company_id=:companyId ;", nativeQuery = true)
	public List<Project> getProjectListByEmpId(Long id, String companyId);

	@Query(value = "select id from employee e where e.department_Id=:id inner join ", nativeQuery = true)
	public List<Long> findDeptCount(Long id);
	
	@Query("select p from Project p where p.id=:id and p.company.id=:companyId AND p.isActive=true AND p.isDelete=false ")
	public Optional<Project> findProjectByCompanyId(Long id , String companyId);
	

	@Query(value = "select p from Project p where p.id=id and p.company.id=companyId")
	public Optional<Project> projects(Long id, String companyId);
}
