package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.WeekDays;

public interface WeekDaysRepository extends JpaRepository<WeekDays, Long>{

}
