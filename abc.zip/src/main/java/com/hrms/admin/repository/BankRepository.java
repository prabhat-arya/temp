package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.BankDetails;

public interface BankRepository extends JpaRepository<BankDetails, Long>{

	@Query(value = "FROM BankDetails WHERE employee.id=:employeeId" )
	public BankDetails findByEmployee(Long employeeId);

}
