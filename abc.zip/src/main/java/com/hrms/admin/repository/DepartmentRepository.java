package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.DepartmentDTO;
import com.hrms.admin.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

//	public Department findByname(String name);

//	@Query(value = "SELECT a FROM Department a WHERE  a.name LIKE %?1%  AND a.isDelete=false")
//	Page<Department> findAllSearchWithPagination(String searchKey, Pageable paging); // not using any where

	@Query(value = "FROM Department d WHERE d.name=:name AND d.company.id=:companyId and d.isActive=true AND d.isDelete=false")
	public Optional<Department> findByName(String name, String companyId);

	@Query(value = "FROM Department d WHERE d.branch.id=:branchId and d.company.id=:companyId AND d.isActive=true AND d.isDelete=false")
	public List<Department> findByBranchId(Long branchId,String companyId); 

	@Query(value = "SELECT count(*) FROM Department d WHERE   d.name=:name AND d.company.id=:companyId AND d.branch.id=:branchId AND d.isDelete=false")
	Long getDepartmentCountSave(String name, String companyId, Long branchId);

	@Query(value = "SELECT count(*) FROM Department d WHERE   d.name=:name AND d.company.id=:companyId AND d.id <>:id AND d.branch.id=:branchId AND d.isDelete=false")
	Long getDepartmentCountUpdate(String name, String companyId, Long id, Long branchId);

//	@Query(value = "SELECT d FROM Department d WHERE d.name=:departmentName AND d.company.id=:companyId AND d.branch.id=:branchId AND d.isActive=true AND d.isDelete=false")
//	public Department findBydeptname(String departmentName, String companyId, Long branchId);
	@Query(value = "SELECT * FROM department where department_name=:departmentName and company_id=:companyId and branch_id=:branchId and is_active=1 and is_delete=0",nativeQuery = true)
//	@Query(value = "FROM Department d WHERE d.name=:departmentName AND d.company.id=:companyId AND d.branch.id=:branchId AND d.isActive=true AND d.isDelete=false")
	public Optional<Department> findByName(String departmentName, String companyId, Long branchId);

	// page indicate these methods are use to get the data as Pageable

	@Query("select new com.hrms.admin.dto.DepartmentDTO (d.id,d.name,d.description,d.branch.id,d.company.id,d.branch.name,d.company.name,d.isDelete,d.isActive) from Department d WHERE  (d.name LIKE %?1% OR d.company.name LIKE %?1% OR d.branch.name LIKE %?1%) AND d.company.id=?2 AND d.isActive=?3 AND d.isDelete=false")
	Page<DepartmentDTO> departmentPage(String searchKey, String companyId, Boolean status, Pageable pageable);

	@Query("select new com.hrms.admin.dto.DepartmentDTO (d.id,d.name,d.description,d.branch.id,d.company.id,d.branch.name,d.company.name,d.isDelete,d.isActive) from Department d WHERE  (d.name LIKE %?1% OR d.company.name LIKE %?1% OR d.branch.name LIKE %?1%) AND d.company.id=?2 AND (d.isActive=true OR d.isActive=false) AND d.isDelete=false")
	Page<DepartmentDTO> allDepartmentPage(String searchKey, String companyId, Pageable pageable);

	@Query("select d From Department d where d.id=:id and d.company.id=:companyId and d.isActive=true AND d.isDelete=false")
	public Optional<Department> findDepartmentIdByCompanyId(Long id, String companyId);

	@Query("select d from Department d where d.company.id=:companyId and d.isActive=true AND d.isDelete=false")
	public List<Department> findAllDepartmentByCompanyId(String companyId);
}
