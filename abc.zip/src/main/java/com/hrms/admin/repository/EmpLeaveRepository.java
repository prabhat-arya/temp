package com.hrms.admin.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.EmpLeave;

public interface EmpLeaveRepository extends JpaRepository<EmpLeave, Long> {

	public List<EmpLeave> findByEmployeeId(Long empId);

	@Query("select a from EmpLeave a where a.startDate=:date and a.employee.company.id=:companyId")
	public List<EmpLeave> findByStartDate(Date date, String companyId);

	// for validation save Method
	@Query(value = "SELECT count(e.id) FROM EmpLeave e WHERE e.employeeId=:employeeId AND (e.startDate=:startDate or e.endDate=:endDate) AND e.isDelete=false")
	public Long getLeaveTypeCount(Long employeeId, Date startDate, Date endDate);

	// for validation update Method
	@Query(value = "SELECT count(e.id) FROM EmpLeave e WHERE e.employeeId=:employeeId AND (e.startDate=:startDate or e.endDate=:endDate) and e.id <> :leaveTypeId AND e.isDelete=false")
	public Long getCompanyCountForUpdate(Long employeeId, Date startDate, Date endDate, Long leaveTypeId);

	@Query("select case when sum(e.totalDays) is not null THEN sum(e.totalDays) ELSE 0 END from  EmpLeave e where status='Approved' AND e.employeeId=:employeeId")
	public Long getEmpAprovedLeaves(Long employeeId);

	@Query("select case when sum(e.totalDays) is not null  THEN sum(e.totalDays) ELSE 0 END from  EmpLeave e where status='Rejected' AND e.employeeId=:employeeId")
	public Long getEmpRejectedLeaves(Long employeeId);

	@Query("select case when sum(e.totalDays) is not null  THEN sum(e.totalDays) ELSE 0 END from  EmpLeave e where status='cancelled' AND e.employeeId=:employeeId")
	public Long getEmpCancelledLeaves(Long employeeId);

	@Query("select case when sum(e.totalDays) is not null  THEN sum(e.totalDays) ELSE 0 END from  EmpLeave e where status='Applied' AND e.employeeId=:employeeId")
	public Long getEmpPendingLeaves(Long employeeId);

	// page indicate these methods are use to get the data as Pageable
	@Query(value = "SELECT e FROM EmpLeave e WHERE (e.employee.firstName LIKE %?1% OR e.employee.lastName LIKE %?1% OR e.leaveType1.leaveType LIKE %?1% OR e.startDate LIKE %?1% OR e.endDate LIKE %?1%	OR e.leaveApplyDate LIKE %?1% OR e.totalDays LIKE %?1% OR e.reason LIKE %?1% OR e.status LIKE %?1%)  and e.employee.company.id=?2 AND  e.status=?3 And e.employeeId=?4  AND e.isDelete=false")
	Page<EmpLeave> empLeavePage(String searchKey, String companyId, String status, Long empId, Pageable paging);

	@Query("select e from EmpLeave e WHERE (e.employee.firstName LIKE %?1% OR e.employee.lastName LIKE %?1% OR e.leaveType1.leaveType LIKE %?1% OR e.startDate LIKE %?1% OR e.endDate LIKE %?1%	OR e.leaveApplyDate LIKE %?1% OR e.totalDays LIKE %?1% OR e.reason LIKE %?1% OR e.status LIKE %?1%) and e.employee.company.id=?2   AND   e.employeeId=?3  AND  e.isDelete=false")
	Page<EmpLeave> allEmpLeavePage(String searchKey, String companyId, Long empId, Pageable pageable);

	@Query("SELECT e FROM EmpLeave e WHERE  (e.employee.firstName LIKE %?1% OR e.employee.lastName LIKE %?1% OR e.leaveType1.leaveType LIKE %?1% OR e.startDate LIKE %?1% OR e.endDate LIKE %?1% OR e.leaveApplyDate LIKE %?1% OR e.totalDays LIKE %?1% OR e.reason LIKE %?1% OR e.status LIKE %?1%) and e.employee.company.id=?2  AND  e.status=?3 AND e.managerId=?4 AND  e.isDelete=false")
	Page<EmpLeave> empLeaveManagerPage(String searchKey, String companyId, String status, Long managerId,
			Pageable paging);

	@Query("select e from EmpLeave e WHERE (e.employee.firstName LIKE %?1% OR e.employee.lastName LIKE %?1% OR e.leaveType1.leaveType LIKE %?1% OR e.startDate LIKE %?1% OR e.endDate LIKE %?1%	OR e.leaveApplyDate LIKE %?1% OR e.totalDays LIKE %?1% OR e.reason LIKE %?1% OR e.status LIKE %?1%) and e.employee.company.id=?2 AND e.managerId=?3  AND e.isDelete=false")
	Page<EmpLeave> allEmpLeaveManagerPage(String searchKey, String companyId, Long managerId, Pageable pageable);

	@Query("select e from EmpLeave e WHERE (e.employee.firstName LIKE %:searchKey% OR e.employee.lastName LIKE %:searchKey% OR e.leaveType1.leaveType LIKE %:searchKey% OR e.startDate LIKE %:searchKey% OR e.endDate LIKE %:searchKey% 	OR e.leaveApplyDate LIKE %:searchKey%  OR e.totalDays LIKE %:searchKey%  OR e.reason LIKE %:searchKey%) AND (e.isActive=true AND e.isDelete=false AND e.status=:status) AND e.startDate>=:fromDate AND  e.endDate<=:toDate and e.employee.company.id=:companyId")
	Page<EmpLeave> allEmpLeaveReport(String searchKey, String companyId, Pageable pageable, Date fromDate, Date toDate,
			String status);

	@Query("select e from EmpLeave e WHERE (e.employee.firstName LIKE %:searchKey%  OR e.employee.lastName LIKE %:searchKey% OR e.leaveType1.leaveType LIKE %:searchKey% OR e.startDate LIKE %:searchKey% OR e.endDate LIKE %:searchKey% 	OR e.leaveApplyDate LIKE %:searchKey%  OR e.totalDays LIKE %:searchKey% )  AND  e.isActive=true AND e.isDelete=false AND e.status=:status   AND e.startDate>=:fromDate AND  e.endDate<=:toDate and e.employee.company.id=:companyId")
	public List<EmpLeave> allEmpLeaveReportsDateBased(Date fromDate, Date toDate, String status, String searchKey,
			String companyId);

	@Query("select e from EmpLeave e WHERE (e.employee.firstName LIKE %:searchKey%  OR e.employee.lastName LIKE %:searchKey% OR e.leaveType1.leaveType LIKE %:searchKey% OR e.startDate LIKE %:searchKey% OR e.endDate LIKE %:searchKey% 	OR e.leaveApplyDate LIKE %:searchKey%  OR e.totalDays LIKE %:searchKey% )  AND e.employee.company.id=:companyId and  e.isActive=true AND e.isDelete=false AND e.status=:status ")
	public List<EmpLeave> allEmpLeaveReports(String status, String searchKey, String companyId);

	@Query(value = "SELECT e FROM EmpLeave e WHERE (e.employee.firstName LIKE %:searchKey% OR e.employee.lastName LIKE %:searchKey% OR e.leaveType1.leaveType LIKE %:searchKey% OR e.startDate LIKE %:searchKey% OR e.endDate LIKE %:searchKey%	OR e.leaveApplyDate LIKE %:searchKey% OR e.totalDays LIKE %:searchKey% OR e.reason LIKE %:searchKey% ) and e.employee.company.id=:companyId  AND  e.status=:status AND e.isDelete=false")
	Page<EmpLeave> empLeaveReport(String searchKey, String status, String companyId, Pageable paging);

	@Query("select a from EmpLeave a where a.status like %?2% AND a.employeeId=?1 and  ADDDATE(a.startDate, -1) >=ADDDATE(current_date(), -30) and DATE_FORMAT(a.endDate,'%Y-%m-%d') <= ADDDATE(current_date(), -1)")
	public Page<EmpLeave> getEmployeeLeavesListInMonthPaging(Long employeeId, String searchKey, Pageable pageable);

	@Query("select a from EmpLeave a where  a.employeeId=:employeeId and  ADDDATE(a.startDate, -1) >=ADDDATE(current_date(), -30) and DATE_FORMAT(a.endDate,'%Y-%m-%d') <= ADDDATE(current_date(), -1)")
	public List<EmpLeave> getEmployeeLeavesListInMonth(Long employeeId);

	@Query("select a from EmpLeave a where a.employee.company.id=?1")
	public List<EmpLeave> findAll(String companyId);

	@Query("select a from EmpLeave a where a.leavePasscode=?1")
	public EmpLeave getEmpLeaveByPassCode(String passCode);

	@Query("select el from EmpLeave el where el.employee.id=:empId  and el.status=:status and el.leaveApplyDate=:applayDate")
	public Optional<EmpLeave> findByEmpApprovedLeaves(Long empId, String status, Date applayDate);

	@Query("select el from EmpLeave el where el.managerId=:managerId and el.status=:status and el.leaveApplyDate=:leaveApplyDate")
	public Optional<EmpLeave> findByEmpCancelApprovedLeaves(Long managerId, String status, Date leaveApplyDate);
}
