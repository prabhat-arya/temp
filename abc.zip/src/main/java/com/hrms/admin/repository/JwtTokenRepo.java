package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.JwtToken;

public interface JwtTokenRepo extends JpaRepository<JwtToken, Long> {

	public List<JwtToken> findByJwtToken(String name);

}
