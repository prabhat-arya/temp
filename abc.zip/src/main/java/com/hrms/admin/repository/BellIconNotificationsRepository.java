package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.BellIconNotifications;

/**
 * Contains method to perform DB operation on Bell icon Notifications Record
 * 
 * @author {Ramesh Rendla}
 *
 */
public interface BellIconNotificationsRepository extends JpaRepository<BellIconNotifications, Long> {

	@Query("select b from BellIconNotifications b where b.notificationFlag='false' and b.approverId=:approverId and b.companyId=:companyId")
	public List<BellIconNotifications> getNotificationsForManager(Long approverId, String companyId);

	@Query("select b from BellIconNotifications b where b.employeeNotificationFlag='false' and b.leaveStatus !='Pending' and b.employeeId=:empId and b.companyId=:companyId ")
	public List<BellIconNotifications> getNotificationsForEmployee(Long empId, String companyId);

	@Query("select b from BellIconNotifications b where b.notificationId=:notificationId ")
	public Optional<BellIconNotifications> findNotificationBymanagerAndEmployee(Long notificationId);

	@Query("select b from BellIconNotifications b where b.notificationFlag=true and b.approverId=:approverId and b.companyId=:companyId")
	public List<BellIconNotifications> getBellNotificationListOfManager(Long approverId, String companyId);

	@Query("select b from BellIconNotifications b where b.employeeNotificationFlag=true and b.leaveStatus !='Pending' and b.employeeId=:empId and b.companyId=:companyId ")
	public List<BellIconNotifications> getBellNotificationListOfEmployee(Long empId, String companyId);
}
