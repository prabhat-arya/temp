package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.PaySchedule;

public interface PayScheduleRepository extends JpaRepository<PaySchedule, Long> {

	@Query(value = "SELECT count(e.id) FROM PaySchedule e WHERE   e.payDaySelected=:paysalOnDate and e.company.id=:companyId")
	Long getPayScheduleCountSave(Integer paysalOnDate,String companyId);

	@Query(value = "SELECT count(e.id) FROM PaySchedule e WHERE   e.payDaySelected=:paysalOnDate AND e.id=:id and e.company.id=:companyId")
	Long getPayScheduleCountUpdate(Integer paysalOnDate, Long id,String companyId);

	Optional<PaySchedule> findByBranchId(Long branchId);

	Optional<PaySchedule> findByCompanyId(String id);

}
