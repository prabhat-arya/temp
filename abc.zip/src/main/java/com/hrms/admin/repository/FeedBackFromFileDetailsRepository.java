package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.FeedBackFromFileDetails;

@Repository
public interface FeedBackFromFileDetailsRepository extends JpaRepository<FeedBackFromFileDetails, Long> {

	public FeedBackFromFileDetails findByFilePath(String filePath);

	@Query(value = " FROM FeedBackFromFileDetails s WHERE exitFeedback.feedbackId=:feedbackId")
	public List<FeedBackFromFileDetails> findByExitFeedback(Long feedbackId);
}
