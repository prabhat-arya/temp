package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.EmployeeRolesDTO;
import com.hrms.admin.entity.EmployeeRoles;

public interface RolesRepository extends JpaRepository<EmployeeRoles, Long> {
	@Query("FROM EmployeeRoles r WHERE r.roleName=:roleName AND r.isActive=true AND r.isDelete=false")
	Optional<EmployeeRoles> findByRoleName(String roleName);

	@Query(value = "SELECT a FROM EmployeeRoles a WHERE  a.roleName LIKE %?1%  AND a.isDelete=false AND a.company.id=?2")
	Page<EmployeeRoles> findAllSearchWithPagination(String searchKey,String companyId, Pageable paging);

	@Query(value = "SELECT d FROM EmployeeRoles d WHERE  d.roleName LIKE %?1% AND d.isActive=true AND d.isDelete=false AND d.company.id=?2")
	Page<EmployeeRoles> findAllSearchWithPaginationActiveRecords(String searchKey, String companyId, Pageable paging);

	@Query(value = "SELECT d FROM EmployeeRoles d WHERE  d.roleName LIKE %?1% AND d.isActive=false AND d.isDelete=false AND d.company.id=?2")
	Page<EmployeeRoles> findAllSearchWithPaginationInActiveRecord(String searchKey, String companyId, Pageable paging);
	
	@Query("FROM EmployeeRoles r WHERE r.roleId=:roleId AND r.isActive=true AND r.isDelete=false")
	Optional<EmployeeRoles>  findByRoleId(Long roleId);
	
	@Query("SELECT new com.hrms.admin.dto.EmployeeRolesDTO(r.roleId,r.roleName) FROM EmployeeRoles r WHERE r.isActive=true AND r.isDelete=false and r.company.id=:companyId")
	public List<EmployeeRolesDTO> getAllRoles(String companyId); 
	
//	@Query("FROM EmployeeRoles r WHERE r.roleName=:roleName")
//	public EmployeeRoles findByName(String roleName);

	@Query("FROM EmployeeRoles r WHERE r.roleName=:roleName AND r.company.id=:companyId")
	public EmployeeRoles findRoleByCompany(String roleName, String companyId);
	
	@Query("SELECT r FROM EmployeeRoles r WHERE r.isActive=true AND r.isDelete=false and r.company.id=:companyId")
	public List<EmployeeRoles> getAllRolesByCompany(String companyId);
	
	@Query("FROM EmployeeRoles r WHERE r.roleName=:roleName and r.isActive=true AND r.isDelete=false")
	public List<EmployeeRoles> findByName(String roleName);
	

}
