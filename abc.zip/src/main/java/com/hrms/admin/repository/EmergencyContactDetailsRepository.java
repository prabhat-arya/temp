package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.EmergencyContactDetails;

public interface EmergencyContactDetailsRepository extends JpaRepository<EmergencyContactDetails, Long> {

	@Query(value = "SELECT p FROM EmergencyContactDetails p WHERE  p.employee.id=:employeeId")
	public List<EmergencyContactDetails> findByEmployee(Long employeeId);

	@Query(value = "SELECT p FROM EmergencyContactDetails p WHERE  p.employee.id=:employeeId and p.isDefault=true")
	public EmergencyContactDetails basedOnEmployee(Long employeeId);

}
