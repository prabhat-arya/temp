package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.EmailTemplate;

@Repository
//public interface EmailTemplateRepository extends MongoRepository<EmailTemplate, Long> {
public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {

	EmailTemplate findByEmpIdAndTemplateName(Long empId,String templateName);
	
}
