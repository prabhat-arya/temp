package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.hrms.admin.entity.Employee;
import com.hrms.admin.util.Constants;

public interface EmployeeLoginRepository extends JpaRepository<Employee, Integer> {

	@Query(value = "select e from Employee e where e.userName=:username and e.isExit=false")
	public Optional<Employee> findByUserName(String username);
	

	// @Query(value="select * from EMPLOYEE where token=:token",nativeQuery=true)
	@Query(value = "select e from Employee e where e.token=:token")
	public Optional<Employee> findByToken(String token);

	@Modifying
	@Transactional
	@Query(value = " update Employee e set e.isLock=" + Constants.DEFAULT_FAILED_ATTEMPTS + " where e.isLock >="
			+ Constants.MAX_FAILED_ATTEMPTS + " and e.isActive=true and e.isDelete=false")
	public void unlockEmployeeEveryDay();

	@Modifying
	@Transactional
	@Query(value = " update Employee e set e.isLock=" + Constants.DEFAULT_FAILED_ATTEMPTS
			+ " where  e.id=:id and e.isActive=true and e.isDelete=false ")
	public void unlockEmployee(Long id);
	
	@Query(value = "select e from Employee e where e.officalMail=:email or e.email=:email")
	public Optional<Employee> findByUserByEmail(String email);

	@Query(value = "select e from Employee e where e.userName= :loogedUser or e.officalMail= :loogedUser ")
	public Optional<Employee> employeePassword(String loogedUser);
	
	@Query(value = "select e from Employee e where e.token=:token")
	public Optional<Employee> findByTokenvalidate(String token);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE Employee e set e.isLock =" + Constants.DEFAULT_FAILED_ATTEMPTS +" WHERE e.userName=:username and e.isActive=true and e.isDelete=false")
	public void isLockZero(String username); 

}
