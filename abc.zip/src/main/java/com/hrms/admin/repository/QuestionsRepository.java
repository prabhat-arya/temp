package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.QuestionsDTO;
import com.hrms.admin.entity.Questions;

public interface QuestionsRepository extends JpaRepository<Questions, Long> {

	@Query(value = "SELECT q FROM Questions q WHERE  q.company.id=:companyId")
	public List<Questions> findByCompanyId(String companyId);

	@Query(value = "SELECT count(*) FROM Questions q WHERE  (q.subjectiveQuestion=:question or q.objectiveQuestion=:question) AND q.company.id=:companyId ")
	public Long getQuestionCount(String question, String companyId);

	@Query(value = "SELECT count(*) FROM Questions q WHERE ( q.subjectiveQuestion=:question or q.objectiveQuestion=:question) AND q.questionId=:qId AND q.company.id=:companyId ")
	public Long getQuestionCountWhileUpdate(String question, String companyId, Long qId);
	
	@Query(value = "from Questions q where q.isDefault=true" )
	public  List<Questions> getAllDeafultQuestionList();
	
	@Query(value = "from Questions q where q.company.id=:companyId and q.isDefault=false")
	public List<Questions> getAllcustomizeQuestionList( String companyId) ;

	
	
}
