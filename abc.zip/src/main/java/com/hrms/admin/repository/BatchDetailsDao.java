package com.hrms.admin.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.hrms.admin.dto.DataCountDTO;

/**
 * Contains method to provide APIs for ValidationProcessor
 * 
 * @author {Sachin}
 *
 */
@Repository
public class BatchDetailsDao {
 
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	EntityManager entityManager;
	@Autowired
	EntityManagerFactory entityManagerFactory; 
	@Value("${cloud.dbname}")
	private String dbName;

	public DataCountDTO getBatchStatus(String fileName){
		String SQL_QUERY = "SELECT WRITE_COUNT, FILTER_COUNT FROM "+dbName+".BATCH_STEP_EXECUTION where step_name = ?";
		//String SQL_QUERY = "SELECT WRITE_COUNT, FILTER_COUNT FROM "+dbName+".hrmsqa.BATCH_JOB_EXECUTION where step_name = ?";

		return jdbcTemplate.queryForObject(SQL_QUERY, new Object[]{fileName}, (rs, rowNum) -> {
			DataCountDTO data = new DataCountDTO();
		    data.setFailureCount(rs.getLong("FILTER_COUNT"));
		    data.setSuccessCount(rs.getLong("WRITE_COUNT"));
		    return data;
		});
	}
	
}
