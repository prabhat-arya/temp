package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.ExitFeedback;

@Repository
public interface ExitFeedbackRepository extends JpaRepository<ExitFeedback, Long> {

	@Query("select new com.hrms.admin.entity.ExitFeedback(e.feedbackId,e.employeeExitMgmtId,e.submitDate,e.feedback,e.submission,e.signature,e.department,e.designation,e.status,e.isSubmit) FROM ExitFeedback e WHERE feedbackId=:exitId")
	public ExitFeedback findByFeedbackId(Long exitId);

	public List<ExitFeedback> findByEmployeeExitMgmtId(Long employeeExitMgmtId);

	@Query("select ef from ExitFeedback ef inner join EmployeeExitMgmt em on ef.employeeExitMgmtId=em.employeeExitId inner join Employee e on e.id=em.employeeId and e.company.id=?1")
	public List<ExitFeedback> findAllExitFeedBack(String companyId);

}
