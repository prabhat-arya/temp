package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Resignation;

public interface ResignationRepository extends JpaRepository<Resignation, Long> {

	@Query(value = "from Resignation r where r.employee=:employeeId")
	public Resignation getByEmployee(Long employeeId);
		

	@Query("select r from Resignation r inner join Employee e on e.id=r.employee where e.company.id=?1")
	Page<Resignation> resignationFormPage(String companyId, Pageable pageable);
	
	@Query(value = " select r.status from Resignation r where r.employee=:empId ")
	public String findStatusByEmpId(Long empId);

	@Query("select r from Resignation r inner join Employee e on e.id=r.employee where e.company.id=?1 AND e.manager.id=?2")
	Page<Resignation> resignationFormPage(String companyId, Long managerId, Pageable pageable);

	@Query(value = "from Resignation r where r.status=:completed")
	public List<Resignation> findAllByStatus(String completed);

//	@Query(value = "from Resignation r where r.employee=:empId AND r.status=:submitted")
//	public Resignation findResignationSubmitByEmpId(Long empId, String submitted);

}
