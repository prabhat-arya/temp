package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.AttendanceInfoDTO;
import com.hrms.admin.entity.AttendanceInfo;

/**
 * Contains method to perform DB operation on AttendanceInfo Record
 * 
 * @author {Ramesh Rendla}
 *
 */
public interface AttendanceInfoRepository extends JpaRepository<AttendanceInfo, Long> {

	@Query("select a from AttendanceInfo a where a.employee.company.id=:companyId")
	public List<AttendanceInfo> findAllEmployeeAttendance(String companyId);

	@Query("select a from AttendanceInfo a where a.employee.id=:empId and a.date=:date")
	public Optional<AttendanceInfo> getEmployeeAttendanceOnDate(Long empId, String date);

	@Query("SELECT a FROM AttendanceInfo a where (a.employee.firstName LIKE %?1%  OR  a.employee.lastName  LIKE %?1%  OR a.shift.shiftName LIKE %?1%) and a.employee.company.id=?2")
	public List<AttendanceInfo> findAllReports(String searchKey, String companyId);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) and a.employee.company.id=?2 ")
	Page<AttendanceInfoDTO> allAttendancePage(String searchKey, String companyId, Pageable pageable);

	@Query("select a from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) and a.employee.company.id=?2")
	Page<AttendanceInfo> allAttendancePageReports(String searchKey, String companyId, Pageable pageable);

	@Query("select count(a.noOfHrs) from AttendanceInfo a where a.employee.id=:empId and DATE_FORMAT(a.date,'%Y-%m')=:date")
	public Integer findByEmpIdAndMonth(Long empId, String date);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a where a.employee.id=?1 AND (concat(a.employee.firstName , ' ',a.employee.lastName) LIKE %?2% OR a.shift.shiftName LIKE %?2% OR a.date LIKE %?2% OR a.inTime LIKE %?2% OR a.outTime LIKE %?2%) and a.employee.company.id=?3")
	public Page<AttendanceInfoDTO> findByEmpIds(Long empid, String searchKey, String companyId, Pageable pageable);

	@Query("select count(employee.id) from AttendanceInfo where date= ADDDATE(current_date(), -1) and employee.company.id=?1  ")
	public Long getAllEmployeecountPerDay(String companyId);

	@Query("select count(employee.id) from AttendanceInfo  where attndsPercentage<>0 and noOfHrs<>0 and date= ADDDATE(current_date(), -1) and employee.company.id=?1")
	public Long attendancePresentPercentagePieChart(String companyId);

	@Query("select count(employee.id) from AttendanceInfo where attndsPercentage=0 and noOfHrs=0 and date= ADDDATE(current_date(), -1) and employee.company.id=?1")
	public Long attendanceAbsentPercentagePieChart(String companyId);

	@Query("SELECT a FROM AttendanceInfo a where a.date>=:fromDate AND a.date <=:toDate and a.employee.company.id=:companyId order by date  ")
	public List<AttendanceInfo> getEmpAttDetailsBetweenDays(String fromDate, String toDate, String companyId);

	@Query("SELECT a FROM AttendanceInfo a where a.date>=?1 AND a.date <=?2  AND (a.employee.firstName LIKE %?3%  OR  a.employee.lastName  LIKE %?3%  OR a.shift.shiftName LIKE %?3%) and a.employee.company.id=?4")
	public List<AttendanceInfo> getEmpAttDetailsBetweenDaysReports(String fromDate, String toDate, String searchKey,
			String companyId);

	@Query("SELECT a FROM AttendanceInfo a where a.date>=?1 and a.date <=?2 AND (concat(a.employee.firstName , ' ',a.employee.lastName) LIKE %?3% OR a.shift.shiftName LIKE %?3% OR a.date LIKE %?3% OR a.inTime LIKE %?3% OR a.outTime LIKE %?3%) and a.employee.company.id=?4")
	public Page<AttendanceInfo> getEmpAttDetailsBetweenDaysPaging(String fromDate, String toDate, String searchKey,
			String companyId, Pageable pageable);

	@Query("SELECT a FROM AttendanceInfo a where a.employee.id = :empid and a.date>=:fromDate and a.date <=:toDate order by date")
	public List<AttendanceInfo> getEmpAttDetailsBetweenDaysEmpid(Long empid, String fromDate, String toDate);

	// changed
	@Query("SELECT new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) FROM AttendanceInfo a where a.employee.id =?1 and a.date>=?2 and a.date <=?3 AND (concat(a.employee.firstName , ' ',a.employee.lastName) LIKE %?4% OR a.shift.shiftName LIKE %?4% OR a.date LIKE %?4% OR a.inTime LIKE %?4% OR a.outTime LIKE %?4%) and a.employee.company.id=?5")
	public Page<AttendanceInfoDTO> getEmpAttDetailsBetweenDaysEmpidpaging(Long empid, String fromDate, String toDate,
			String searchKey, String companyId, Pageable pageable);

	@Query("SELECT a FROM AttendanceInfo a where a.shift.id =?1 and a.date>=?2 and a.date <=?3 AND (concat(a.employee.firstName , ' ',a.employee.lastName) LIKE %?4% OR a.shift.shiftName LIKE %?4% OR a.date LIKE %?4% OR a.inTime LIKE %?4% OR a.outTime LIKE %?4%) and a.employee.company.id=?5")
	public Page<AttendanceInfo> getEmpAttDetailsBetweenDaysShiftPaging(Long shiftId, String fromDate, String toDate,
			String searchKey, String companyId, Pageable pageable);

	@Query("select a FROM AttendanceInfo a where a.employee.id=:empid and a.date=:date and a.employee.company.id=:companyId ")
	public AttendanceInfo getNoOfHrsPerEmpInProject(Long empid, String date, String companyId);

	@Query("select count(employee.id)  from AttendanceInfo  where attndsPercentage<>0 and noOfHrs<>0  and date=:date and employee.company.id=:companyId ")
	public Long getAllPresentEmpByBranchWithDate(String date, String companyId);

	@Query("select count(employee.id) from AttendanceInfo where attndsPercentage=0 and noOfHrs=0  and date=:date and employee.company.id=:companyId")
	public Long getAllAbsentEmpByBranchWithDate(String date, String companyId);

	// for duplicate check
	// save
	@Query(value = "SELECT count(employee.id) FROM AttendanceInfo a WHERE a.employee.id = :empId AND a.date=:date")
	public Long getAttendanceCount(Long empId, String date);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage<>0 and a.noOfHrs<>0 and DATE_FORMAT(a.date,'%Y-%m-%d')= ADDDATE(current_date(), -1) and a.employee.company.id=?2 ")
	public Page<AttendanceInfoDTO> getEmpAttPresentListPieChart(String searchKey, String companyId, Pageable paging);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage=0 and a.noOfHrs=0 and DATE_FORMAT(a.date,'%Y-%m-%d')= ADDDATE(current_date(), -1) and a.employee.company.id=?2 ")
	public Page<AttendanceInfoDTO> getEmpAttAbsentListPieChart(String searchKey, String companyId, Pageable paging);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage<>0 and a.noOfHrs<>0 and ADDDATE(a.date, -1) >=ADDDATE(current_date(), -7) and DATE_FORMAT(a.date,'%Y-%m-%d')  <=ADDDATE(current_date(), -1) and a.employee.company.id=?2")
	public Page<AttendanceInfoDTO> getEmpAttPresentListBarChart(String searchKey, String companyId, Pageable paging);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage=0 and a.noOfHrs=0 and ADDDATE(a.date, -1) >=ADDDATE(current_date(), -7) and DATE_FORMAT(a.date,'%Y-%m-%d')  <=ADDDATE(current_date(), -1) and a.employee.company.id=?2 ")
	public Page<AttendanceInfoDTO> getEmpAttAbsentListBarChart(String searchKey, String companyId, Pageable paging);

	@Query("select count(a.employee.id) from  AttendanceInfo a where a.employee.id=:empid and DATE_FORMAT(a.date, '%m-%y' ) = DATE_FORMAT(curdate(), '%m-%y') and a.employee.company.id=:companyId")
	public Long getAllEmployeecountInMonthByEmpid(Long empid, String companyId);

	@Query("select count(a.employee.id) from AttendanceInfo a where a.employee.id=:empid and a.attndsPercentage<>0 and a.noOfHrs<>0 and DATE_FORMAT(a.date, '%m-%y' ) = DATE_FORMAT(curdate(), '%m-%y') and a.employee.company.id=:companyId")
	public Long attendancePresentPercentagePieChartByEmpid(Long empid, String companyId);

	@Query("select count(a.employee.id) from AttendanceInfo a where a.employee.id=:empid and a.attndsPercentage=0 and a.noOfHrs=0 and DATE_FORMAT(a.date, '%m-%y' ) = DATE_FORMAT(curdate(), '%m-%y') and a.employee.company.id=:companyId")
	public Long attendanceAbsentPercentagePieChartByEmpid(Long empid, String companyId);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a where (a.date like %?2% OR a.inTime like %?2% OR a.outTime like %?2%) AND a.employee.id=?1 AND a.attndsPercentage<>0 and DATE_FORMAT(a.date, '%m-%y' ) = DATE_FORMAT(curdate(), '%m-%y') and a.employee.company.id=?3")
	public Page<AttendanceInfoDTO> getPresentAttendenceByEmpIdInPieChart(Long empid, String searchKey, String companyId,
			Pageable paging);

	// changed
	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a where  (a.date like %?2% OR a.inTime like %?2% OR a.outTime like %?2%) AND a.employee.id=?1 and a.attndsPercentage=0 and a.noOfHrs=0 and DATE_FORMAT(a.date, '%m-%y' ) = DATE_FORMAT(curdate(), '%m-%y') and a.employee.company.id=?3")
	public Page<AttendanceInfoDTO> getAbsentAttendenceListByEmpIdInPieChart(Long empid, String searchKey,
			String companyId, Pageable paging);

	@Query(value = "select com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs) from attendance_info a inner join employee_projects ep on a.empid=ep.employee_id inner join employee e on e.id=ep.employee_id where (concat(e.first_name , ' ',e.last_name) like %?1% OR a.date like %?1% OR a.intime like %?1% OR a.outtime like %?1%) and ep.projects_project_id=?4 and e.company_id=?3 and a.date=?2", nativeQuery = true)
	public Page<AttendanceInfoDTO> getEmpAttPresentListProjectBarChartOnDate(String searchKey, String date,
			String companyId, Long projectId, Pageable paging);

	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND  a.attndsPercentage<>0 and a.noOfHrs<>0 and a.date=?2  and a.employee.company.id=?3")
	public Page<AttendanceInfoDTO> getEmpAttPresentListBarChartOnDate(String searchKey, String date, String companyId,
			Pageable paging);

	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage=0 and a.noOfHrs=0 and date=?2  and a.employee.company.id=?3 AND a.employee.id=?4")
	public Page<AttendanceInfoDTO> getEmpAttAbsentListProjectBarChartOnDate(String searchKey, String date,
			String companyId, Long empid, Pageable paging);

	@Query("select new com.hrms.admin.dto.AttendanceInfoDTO(a.employee.id,a.employee.firstName,a.employee.lastName,a.date,a.inTime,a.outTime,a.noOfHrs,a.shift.shiftName,a.breakHrs) from AttendanceInfo a WHERE  (concat(a.employee.firstName , ' ',a.employee.lastName) like %?1% OR  a.shift.shiftName LIKE %?1% OR a.date like %?1% OR a.inTime like %?1% OR a.outTime like %?1%) AND a.attndsPercentage=0 and a.noOfHrs=0 and date=?2  and a.employee.company.id=?3")
	public Page<AttendanceInfoDTO> getEmpAttAbsentListBarChartOnDate(String searchKey, String date, String companyId,
			Pageable paging);
}
