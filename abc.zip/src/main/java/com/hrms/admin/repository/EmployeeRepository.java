package com.hrms.admin.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.dto.EmployeeBranchDTO;
import com.hrms.admin.dto.EmployeeInfoDTO;
import com.hrms.admin.dto.EmployeeManagerDTO;
import com.hrms.admin.dto.EmployeePageDTO;
import com.hrms.admin.dto.PayrollReportResponseDTO;
import com.hrms.admin.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Query(value = "FROM Employee e WHERE e.id=:id and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public Optional<Employee> findByIdByCompany(Long id, String companyId);

//	@Query(value = "select e FROM Employee e WHERE e.id=:id AND e.userName=:userName AND e.joiningDate=:joiningDate AND e.isActive=true AND e.isDelete=false AND e.isApprove=true")
	// public Optional<Employee> findByIdAttr(Long id, String userName, Date
	// joiningDate);

	// deactive and approval
	// public List<Employee> findAllByIsApprove(Boolean boolean1);

	@Query(value = "FROM Employee e WHERE e.userName=:userName AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public Optional<Employee> findByUserName(String userName);

	@Query(value = "FROM Employee e WHERE e.userName=:userName AND e.isActive=true AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public Optional<Employee> getByUserName(String userName, String companyId);

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.company.id=:companyId AND e.userName=:userName"
			+ "  AND e.email=:email AND e.contactNo=:contactNo AND e.isDelete=false AND e.isExit=false")
	public Long getEmployeeSaveCount(String companyId, String email, String userName, String contactNo);

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.company.id=:companyId AND e.userName=:userName "
			+ " AND e.email=:email AND e.contactNo=:contactNo AND e.id<>:id AND e.isDelete=false AND e.isExit=false")
	public Long getEmployeeUpdadateCount(String companyId, String email, String userName, String contactNo, Long id);

	@Query(value = "select new com.hrms.admin.dto.EmployeeManagerDTO(e.id,e.firstName,e.officalMail,e.designation.designation,e.designation.band) FROM Employee e WHERE e.department.id=:id AND e.isActive=true AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeeManagerDTO> findByDepartmentId(Long id, String companyId);

	@Query(value = "SELECT * FROM employee e join emp_roles r on e.id=r.emp_id where r.role_id=:roleId", nativeQuery = true)
	public List<Employee> allManagers(Long roleId);

	@Query(value = "select new com.hrms.admin.dto.EmployeeBranchDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.designation.designation,e.joiningDate,e.isActive,e.isDelete) FROM Employee e WHERE e.branch.id=:branchId AND e.isActive=true AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeeBranchDTO> findByBranchId(Long branchId, String companyId);

	@Query("select count(e.id) from Employee e where branch.id=:branchId AND e.isActive=true AND e.isDelete=false AND e.isExit=false and company.id=:companyId")
	public Long getAllEmpCountBasedOnBranch(Long branchId, String companyId);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.dateOfBirth) = day(:date2) and month(e.dateOfBirth) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<Employee> findBirthday(Date date2, String companyId);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.marriageDay) = day(:date2) and month(e.marriageDay) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<Employee> findMarraigeDay(Date date2, String companyId);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.joiningDate) = day(:date2) and month(e.joiningDate) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<Employee> findJoiningDay(Date date2, String companyId);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.dateOfBirth) = day(:date2) and month(e.dateOfBirth) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false")
	public List<Employee> findBirthday1(Date date2);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.marriageDay) = day(:date2) and month(e.marriageDay) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false")
	public List<Employee> findMarraigeDay1(Date date2);

	@Query(value = "SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.officalMail,e.company) from Employee e where day(e.joiningDate) = day(:date2) and month(e.joiningDate) = month(CURRENT_DATE) and e.isActive=true and e.isDelete=false AND e.isExit=false")
	public List<Employee> findJoiningDay1(Date date2);

	// @Query("SELECT new
	// com.hrms.admin.dto.EmployeeInfoDTO(e.id,e.firstName,e.lastName,e.officalMail,e.userName,e.dateOfBirth,e.gender,e.maritalStatus,e.contactNo,e.alternateContactNo,e.aadharCard,e.panCard,e.voterID,e.joiningDate,e.bloodGroup,e.designation.designation)
	// FROM Employee e WHERE e.isActive=true AND e.isDelete=false")
//	public List<EmployeeInfoDTO> find();

//	@Query(value = "SELECT customEmployeeId FROM Employee e  WHERE id = (select max(e.id) from Employee e)")
//	public String getLastEmployeeIdForCustomeIdGeneration();

	/*
	 * @Query("SELECT CONCAT(e.firstName ,' ',e.lastName) as Employeename FROM Employee e WHERE e.id=:i"
	 * ) public String getAllEmplaoyeeNames(Long i);
	 */

	@Query(value = "SELECT  new com.hrms.admin.entity.Employee(a.id,a.firstName,a.lastName,a.ctc) FROM Employee a WHERE (a.firstName LIKE %?1%  OR a.lastName LIKE %?1%OR a.ctc LIKE %?1%) AND a.isActive=true AND a.isDelete=false AND a.isExit=false and a.company.id=?2")
	Page<Employee> findAllEmployeeBankDetails(String searchKey, String companyId, Pageable paging);

	/*
	 * @Query("SELECT CONCAT(e.firstName ,' ',e.lastName) as Employeename FROM Employee e WHERE e.id=:id AND e.isDelete=false"
	 * ) public String getEmployeeNames(Long id);
	 */

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.email=:email")
	public Long getEmployeeEmail(String email);

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.contactNo=:contactNo")
	public Long getEmployeeContact(String contactNo);

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.userName=:userName")
	public Long getEmployeeUserName(String userName);

	@Query("SELECT new com.hrms.admin.entity.Employee(e.id,e.firstName,e.lastName,e.email,e.userName,e.contactNo) FROM Employee e where DATE_FORMAT(e.createdDate,'%Y-%m-%d')=current_date() and e.createdBy=:user and e.company.id=:companyId")
	public List<Employee> getTodayaddedEmployess(String user, String companyId);

	@Query(value = "SELECT e.id FROM Employee e WHERE e.company.id=:companyId AND e.userName=:userName"
			+ "  AND e.email=:email AND e.contactNo=:contactNo AND e.isDelete=false")
	public List<Long> getEmployeeSaveCountList(String companyId, String email, String userName, String contactNo);

	// Tabular
	// page indicate these methods are use to get the data as Pageable
	@Query("select e from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND e.isActive=?2 AND e.isDelete=false AND e.isExit=false and e.company.id=?3")
	Page<Employee> employeePageList(String searchKey, Boolean status, String companyId, Pageable pageable);

	// tabular
	@Query("select e from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND (e.isActive=true OR e.isActive=false) AND e.isDelete=false AND e.isExit=false and e.company.id=?2")
	Page<Employee> allEmployeePageList(String searchKey, String companyId, Pageable pageable);

	// page indicate these methods are use to get the data as Pageable
	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND e.isActive=?2 AND e.isDelete=false AND e.isExit=false and e.company.id=?3")
	Page<EmployeePageDTO> employeePage(String searchKey, Boolean status, String companyId, Pageable pageable);

	@Query("select e from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND e.isExit=?2 AND e.isDelete=false and e.company.id=?3")
	Page<Employee> employeePageIfIsExit(String searchKey, Boolean status, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND e.isActive=?2 AND e.isDelete=false AND e.isExit=false  and e.company.id=?3")
	List<EmployeePageDTO> employeeListReport(String searchKey, Boolean status, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND (e.isActive=true OR e.isActive=false) AND e.isDelete=false AND e.isExit=false and e.company.id=?2")
	Page<EmployeePageDTO> allEmployeePage(String searchKey, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND (e.isActive=true OR e.isActive=false) AND e.isDelete=false AND e.isExit=false and e.company.id=?2")
	List<EmployeePageDTO> allEmployeeListReport(String searchKey, String companyId);

	@Query(value = "FROM Employee e WHERE e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<Employee> findByCompany(String companyId);

	// Report start
	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReports(String searchKey, Boolean status, Date startDate, Date endDate,
			String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReports(String searchKey, Boolean status, Date startDate, Date endDate,
			String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND (e.isActive=true OR e.isActive=false) AND e.joiningDate between :startDate AND :endDate AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> allEmployeeReports(String searchKey, Date startDate, Date endDate, String companyId,
			Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND (e.isActive=true OR e.isActive=false) AND e.joiningDate between :startDate AND :endDate AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> allEmployeeListReports(String searchKey, Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND (e.joiningDate between :startDate AND :endDate OR e.gender=:gender OR e.department.id=:departmentId OR e.designation.id=:designationId) AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeePageDTO> allReportsDateBased(Date startDate, Date endDate, Boolean status, String gender,
			Long departmentId, Long designationId, String searchKey, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND (e.joiningDate between :startDate AND :endDate OR e.gender=:gender OR e.department.id=:departmentId OR e.designation.id=:designationId) AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeePageDTO> allReportDateBased(Date startDate, Date endDate, String gender, Long departmentId,
			Long designationId, String searchKey, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND (e.gender=:gender OR e.department.id=:departmentId OR e.designation.id=:designationId) AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeePageDTO> allReport(String gender, Long departmentId, Long designationId, String searchKey,
			String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR e.gender LIKE %:searchKey% OR e.department.name LIKE %:searchKey%) AND e.gender=:gender AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<EmployeePageDTO> allReport(Boolean status, String gender, Long departmentId, Long designationId,
			String searchKey, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByGender(String searchKey, Boolean status, String gender, Date startDate,
			Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByGender(String searchKey, Boolean status, String gender, Date startDate,
			Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByGenderDept(String searchKey, Boolean status, String gender, Long departmentId,
			Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByGenderDept(String searchKey, Boolean status, String gender,
			Long departmentId, Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByGenderDesg(String searchKey, Boolean status, String gender,
			Long designationId, Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByGenderDesg(String searchKey, Boolean status, String gender,
			Long designationId, Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByDepartment(String searchKey, Boolean status, Long departmentId,
			Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByDepartment(String searchKey, Boolean status, Long departmentId,
			Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByDepartmentDesg(String searchKey, Boolean status, Long departmentId,
			Long designationId, Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByDepartmentDesg(String searchKey, Boolean status, Long departmentId,
			Long designationId, Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByDesignation(String searchKey, Boolean status, Long designationId,
			Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByDesignation(String searchKey, Boolean status, Long designationId,
			Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByGender(String searchKey, Boolean status, String gender, String companyId,
			Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByGenderReport(String searchKey, Boolean status, String gender, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByGenderDept(String searchKey, Boolean status, String gender, Long departmentId,
			String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByGenderDeptReport(String searchKey, Boolean status, String gender,
			Long departmentId, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByGenderDesg(String searchKey, Boolean status, String gender, Long designationId,
			String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByGenderDesgReport(String searchKey, Boolean status, String gender,
			Long designationId, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByDepartment(String searchKey, Boolean status, Long departmentId,
			String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.department.id=:departmentId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByDepartmentReport(String searchKey, Boolean status, Long departmentId,
			String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByDepartmentDesg(String searchKey, Boolean status, Long departmentId,
			Long designationId, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByDepartmentDesgReport(String searchKey, Boolean status, Long departmentId,
			Long designationId, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByDesignation(String searchKey, Boolean status, Long designationId,
			String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByDesignationReport(String searchKey, Boolean status, Long designationId,
			String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeeReportByGenderDeptDesig(String searchKey, Boolean status, String gender,
			Long departmentId, Long designationId, Date startDate, Date endDate, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.joiningDate between :startDate and :endDate AND e.gender=:gender AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListReportByGenderDeptDesig(String searchKey, Boolean status, String gender,
			Long departmentId, Long designationId, Date startDate, Date endDate, String companyId);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	Page<EmployeePageDTO> employeePageByGenderDeptDesig(String searchKey, Boolean status, String gender,
			Long departmentId, Long designationId, String companyId, Pageable pageable);

	@Query("select new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.officalMail,e.contactNo,e.isActive,e.isApprove,e.isDelete,e.designation.designation,e.joiningDate,e.department.name,e.gender) from Employee e WHERE (e.firstName LIKE %:searchKey% OR e.lastName LIKE %:searchKey% OR e.officalMail LIKE %:searchKey% OR e.contactNo LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey%) AND e.gender=:gender AND e.department.id=:departmentId AND e.designation.id=:designationId AND e.isActive=:status AND e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	List<EmployeePageDTO> employeeListByGenderDeptDesigReport(String searchKey, Boolean status, String gender,
			Long departmentId, Long designationId, String companyId);
	// Report end

	@Query(value = "FROM Employee e WHERE e.firstName=:name AND e.isActive=true AND e.isDelete=false and e.company.id=:companyId AND e.isExit=false")
	public Optional<Employee> findByName(String name, String companyId);

	/*
	 * @Query(value =
	 * "select e from Employee e where e.manager.id=:managerId and e.isActive=true  AND e.isDelete=false"
	 * ) public List<Employee> getManagerSubordinate(Long managerId);
	 */

	@Query(value = "select e from Employee e where e.id=:id and e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public Optional<Employee> findByEmployeeId(Long id);

	// @Query(value = "SELECT e FROM Employee e WHERE e.officalMail=:email AND
	// e.isDelete=false")
	// public Employee getEmployeeOfficialEmail(String email);

	@Query(value = "select * from employee e where e.report_to= :empId AND e.isExit=false;", nativeQuery = true)
	public List<Employee> getEmpByReportToNo(Long empId);

	@Query(value = "select e.report_to from employee e where e.report_to=0 AND e.isExit=false;", nativeQuery = true)
	public Long getFirstRepoter();

	@Query("select userName from Employee e where e.company.id=:companyId AND e.isExit=false")
	public List<String> getAllUserNames(String companyId);

	@Query(value = "SELECT new com.hrms.admin.dto.EmployeeManagerDTO(e.id,e.firstName,e.lastName,e.officalMail,e.manager.id,e.manager.firstName,e.manager.lastName,e.manager.officalMail,e.company.id) FROM Employee e WHERE e.id=:id and e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public EmployeeManagerDTO findByEmpId(Long id);

	// payroll report
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% )   AND (p.ctc between :startSalary AND :endSalary      OR  p.joiningDate between :startDate AND :endDate   OR       p.department.id=:departmentId   OR   p.designation.id=:designationId) And p.isActive=true AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryRange(String key, Pageable paging, Double startSalary,
			Double endSalary, Date startDate, Date endDate, Long departmentId, Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc) FROM Employee p where p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportBySalary(String searchKey, Pageable pageable);

	// for excel, pdf and csv for all
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc) FROM Employee p where p.isExit=false") // new
	public List<PayrollReportResponseDTO> payrollReportBySalary(String searchKey);

	// for excel, pdf and csv with filter
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% )   AND (p.ctc between :startSalary AND :endSalary      OR  p.joiningDate between :startDate AND :endDate   OR       p.department.id=:departmentId   OR   p.designation.id=:designationId) And p.isActive=true AND p.isDelete=false AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportBySalaryRangeExcel(String key, Double startSalary,
			Double endSalary, Date startDate, Date endDate, Long departmentId, Long designationId);

	// new payroll query
	// for active and deactive
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(e.id, e.firstName, e.lastName, e.ctc, e.joiningDate) FROM Employee e where   (e.firstName LIKE %:key% OR e.lastName LIKE %:key%  OR e.designation.designation LIKE %:key%    OR e.department.name LIKE %:key%   )  AND  e.joiningDate between :startDate AND :endDate   And  e.isActive=:isActive  AND  e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportByDate(String key, Boolean isActive, Pageable paging,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND  p.joiningDate between :startDate AND :endDate   And p.isActive=:isActive AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%                  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId  And p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDeptDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Pageable paging, Date startDate, Date endDate,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId   And p.isActive=:isActive AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDesigDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long designationId, Pageable paging, Date startDate, Date endDate,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND  p.joiningDate between :startDate AND :endDate   AND   p.department.id=:departmentId   And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDeptDate(String key, Boolean isActive, Long departmentId,
			Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId  AND   p.department.id=:departmentId  And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDepDesigDate(String key, Boolean isActive, Long departmentId,
			Long designationId, Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId   And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDesigDate(String key, Boolean isActive, Long designationId,
			Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId   AND   p.designation.id=:designationId  AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportSalDeptDesigDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Long designationId, Pageable paging,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   ) AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportNoDate(String key, Boolean isActive, String companyId,
			Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportSalaryNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalDeptNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Long departmentId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND  p.ctc between :startSalary AND :endSalary  AND     p.designation.id=:designationId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportSalDesigNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Long designationId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDeptNoDate(String key, Boolean isActive, Long departmentId,
			String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDeptDesigNoDate(String key, Boolean isActive, Long departmentId,
			Long designationId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND     p.designation.id=:designationId  AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportDesigNoDate(String key, Boolean isActive, Long designationId,
			String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )  AND    p.ctc between :startSalary AND :endSalary      AND     p.department.id=:departmentId   AND   p.designation.id=:designationId   AND   p.isActive=:isActive  AND  p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportSalDeptDesigNodate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Long designationId, String companyId,
			Pageable paging);

	// for all
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(e.id, e.firstName, e.lastName, e.ctc, e.joiningDate) FROM Employee e where   (e.firstName LIKE %:key% OR e.lastName LIKE %:key%   OR e.designation.designation LIKE %:key%    OR e.department.name LIKE %:key%   )  AND  e.joiningDate between :startDate AND :endDate AND e.isExit=false and e.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportByDateAll(String key, Pageable paging, Date startDate,
			Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND  p.joiningDate between :startDate AND :endDate AND p.isExit=false and p.company.id=:companyId")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDateAll(String key, Double startSalary, Double endSalary,
			Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId  and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDeptDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportBySalaryDesigDateAll(String key, Double startSalary,
			Double endSalary, Long designationId, Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.joiningDate between :startDate AND :endDate   AND   p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDeptDateAll(String key, Long departmentId, Pageable paging,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId  AND   p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDepDesigDateAll(String key, Long departmentId,
			Long designationId, Pageable paging, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDesigDateAll(String key, Long designationId, Pageable paging,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportSalDeptDesigDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Long designationId, Pageable paging, Date startDate, Date endDate,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   ) and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportNoDateAll(String key, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportSalaryNoDateAll(String key, Double startSalary, Double endSalary,
			String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportBySalDeptNoDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportSalDesigNoDateAll(String key, Double startSalary,
			Double endSalary, Long designationId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDeptNoDateAll(String key, Long departmentId, String companyId,
			Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDeptDesigNoDateAll(String key, Long departmentId,
			Long designationId, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportDesigNoDateAll(String key, Long designationId, String companyId,
			Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )  AND    p.ctc between :startSalary AND :endSalary      AND     p.department.id=:departmentId   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public Page<PayrollReportResponseDTO> payrollReportSalDeptDesigNodateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Long designationId, String companyId, Pageable paging);

	// payroll pdf,excel and csv
	// for active and deactive
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(e.id, e.firstName, e.lastName, e.ctc, e.joiningDate) FROM Employee e where   (e.firstName LIKE %:key% OR e.lastName LIKE %:key%  OR e.designation.designation LIKE %:key%    OR e.department.name LIKE %:key%   )  AND  e.joiningDate between :startDate AND :endDate   And  e.isActive=:isActive  AND  e.isDelete=false AND e.isExit=false and e.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportByDate(String key, Boolean isActive, Date startDate,
			Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND  p.joiningDate between :startDate AND :endDate   And p.isActive=:isActive AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%                  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId    And p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDeptDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId   And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDesigDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long designationId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND  p.joiningDate between :startDate AND :endDate   AND   p.department.id=:departmentId   And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDeptDate(String key, Boolean isActive, Long departmentId,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId  AND   p.department.id=:departmentId  And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDepDesigDate(String key, Boolean isActive, Long departmentId,
			Long designationId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId   And p.isActive=:isActive   AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDesigDate(String key, Boolean isActive, Long designationId,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId   AND   p.designation.id=:designationId  AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportSalDeptDesigDate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Long designationId, Date startDate, Date endDate,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   ) AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportNoDate(String key, Boolean isActive, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key% OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportSalaryNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportBySalDeptNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Long departmentId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND  p.ctc between :startSalary AND :endSalary  AND     p.designation.id=:designationId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportSalDesigNoDate(String key, Boolean isActive, Double startSalary,
			Double endSalary, Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDeptNoDate(String key, Boolean isActive, Long departmentId,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId AND     p.department.id=:departmentId   AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDeptDesigNoDate(String key, Boolean isActive, Long departmentId,
			Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND     p.designation.id=:designationId  AND  p.isActive=:isActive  AND p.isDelete=false AND p.isExit=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportDesigNoDate(String key, Boolean isActive, Long designationId,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )  AND    p.ctc between :startSalary AND :endSalary      AND     p.department.id=:departmentId   AND   p.designation.id=:designationId   AND   p.isActive=:isActive  AND  p.isDelete=false and p.company.id=:companyId")
	public List<PayrollReportResponseDTO> payrollReportSalDeptDesigNodate(String key, Boolean isActive,
			Double startSalary, Double endSalary, Long departmentId, Long designationId, String companyId);

	// for all
	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(e.id, e.firstName, e.lastName, e.ctc, e.joiningDate) FROM Employee e where   (e.firstName LIKE %:key% OR e.lastName LIKE %:key%   OR e.designation.designation LIKE %:key%    OR e.department.name LIKE %:key%   )  AND  e.joiningDate between :startDate AND :endDate and e.company.id=:companyId AND e.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportByDateAll(String key, Date startDate, Date endDate,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND  p.joiningDate between :startDate AND :endDate and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDateAll(String key, Double startSalary, Double endSalary,
			Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDeptDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportBySalaryDesigDateAll(String key, Double startSalary,
			Double endSalary, Long designationId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.joiningDate between :startDate AND :endDate   AND   p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDeptDateAll(String key, Long departmentId, Date startDate,
			Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId  AND   p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDepDesigDateAll(String key, Long departmentId,
			Long designationId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )  AND  p.joiningDate between :startDate AND :endDate   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDesigDateAll(String key, Long designationId, Date startDate,
			Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary   AND  p.joiningDate between :startDate AND :endDate   AND     p.department.id=:departmentId   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportSalDeptDesigDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Long designationId, Date startDate, Date endDate, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   ) and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportNoDateAll(String key, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportSalaryNoDateAll(String key, Double startSalary, Double endSalary,
			String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportBySalDeptNoDateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND  p.ctc between :startSalary AND :endSalary  AND     p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportSalDesigNoDateAll(String key, Double startSalary,
			Double endSalary, Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )   AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDeptNoDateAll(String key, Long departmentId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%   OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId AND     p.department.id=:departmentId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDeptDesigNoDateAll(String key, Long departmentId,
			Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%   )   AND     p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportDesigNoDateAll(String key, Long designationId, String companyId);

	@Query("SELECT new com.hrms.admin.dto.PayrollReportResponseDTO(p.id, p.firstName, p.lastName, p.ctc, p.joiningDate) FROM Employee p where   (p.firstName LIKE %:key% OR p.lastName LIKE %:key%  OR p.designation.designation LIKE %:key%    OR p.department.name LIKE %:key%    )  AND    p.ctc between :startSalary AND :endSalary      AND     p.department.id=:departmentId   AND   p.designation.id=:designationId and p.company.id=:companyId AND p.isExit=false")
	public List<PayrollReportResponseDTO> payrollReportSalDeptDesigNodateAll(String key, Double startSalary,
			Double endSalary, Long departmentId, Long designationId, String companyId);

	@Query(value = "FROM Employee e WHERE e.designation.designation=:name AND e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<Employee> findByDesignation(String name, String companyId);

	@Query("SELECT new com.hrms.admin.dto.EmployeeInfoDTO(e.id,e.firstName,e.lastName,e.officalMail,e.userName,e.dateOfBirth,e.gender,e.maritalStatus,e.contactNo,e.alternateContactNo,e.aadharCard,e.panCard,e.voterID,e.joiningDate,e.bloodGroup,e.designation.designation,e.isActive) FROM Employee e WHERE e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<EmployeeInfoDTO> findEmp(String companyId);

	@Query("SELECT e FROM Employee e where e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<Employee> getAllActiveEmployees();

	@Query("SELECT e FROM Employee e where e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.company.id=:companyId")
	public List<Employee> getAllEmpPaySlipByCompId(String companyId);

	@Query("select e.officalMail from Employee e where e.company.id=:companyId and e.isActive=true AND e.isDelete=false AND e.isExit=false ")
	public List<Employee> findAllEmployeeEmailsByCompanyId(String companyId);

	@Query(value = "SELECT count(e.id) FROM Employee e WHERE e.officalMail=:email AND e.isExit=false")
	public Long getEmployeeOfficalEmail(String email);

	@Query(value = "FROM Employee e WHERE e.contactNo=:contactNo AND e.isExit=false") // need to add other conditions
	public Employee getEmployeeContactNo(String contactNo);

	@Query("SELECT e FROM Employee e where e.isDelete=false AND e.isApprove=false AND e.isActive=false AND e.isExit=false AND e.company.id=:companyId")
	public List<Employee> findAllByStatus(String companyId);

	@Query("SELECT e FROM Employee e where e.isExit=false AND e.isDelete=false AND e.isApprove=false")
	public List<Employee> findAllByStatusThroughMail();

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate>=:startDate AND e.empTypeEndDate<=:endDate and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public Page<EmployeePageDTO> employmentTypeReportByDates(String searchKey, String companyId, Date startDate,
			Date endDate, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate>=:startDate AND e.empTypeEndDate<=:endDate and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public Page<EmployeePageDTO> employmentTypeReportByDatesAndEmpType(String searchKey, String companyId,
			Date startDate, Date endDate, Long employmentTypeId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public Page<EmployeePageDTO> employmentTypeReportByEmpType(String searchKey, String companyId,
			Long employmentTypeId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate=:startDate  and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public Page<EmployeePageDTO> employmentTypeReportByStartDatesAndEmpType(String searchKey, String companyId,
			Date startDate, Long employmentTypeId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public Page<EmployeePageDTO> employmentTypeReport(String searchKey, String companyId, Pageable paging);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate>=:startDate AND e.empTypeEndDate<=:endDate and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<EmployeePageDTO> employmentTypeReportByDates(String searchKey, String companyId, Date startDate,
			Date endDate);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate>=:startDate AND e.empTypeEndDate<=:endDate and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public List<EmployeePageDTO> employmentTypeReportByDatesAndEmpType(String searchKey, String companyId,
			Date startDate, Date endDate, Long employmentTypeId);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public List<EmployeePageDTO> employmentTypeReportByEmpType(String searchKey, String companyId,
			Long employmentTypeId);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.empTypeStartDate=:startDate and e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false AND e.employmentTypeId=:employmentTypeId")
	public List<EmployeePageDTO> employmentTypeReportByStartDatesAndEmpType(String searchKey, String companyId,
			Date startDate, Long employmentTypeId);

	@Query("SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.isActive,e.designation.designation,et.employmentTypeName,e.empTypeStartDate,e.empTypeEndDate) FROM Employee e INNER JOIN EmploymentType et ON e.employmentTypeId=et.employmentTypeId WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% OR et.employmentTypeName LIKE %:searchKey%)  AND  e.company.id=:companyId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<EmployeePageDTO> employmentTypeReport(String searchKey, String companyId);

	@Query(value = "select new com.hrms.admin.dto.EmployeeManagerDTO(e.id,e.firstName,e.officalMail,e.designation.designation,e.designation.band) FROM Employee e WHERE e.isActive=true AND e.isDelete=false and e.company.id=:companyId  AND e.isExit=false")
	public List<EmployeeManagerDTO> findBycompanyId(String companyId);

	/*
	 * @Query(value =
	 * "SELECT count(e.id) FROM Employee e WHERE e.officalMail=:email and e.id=id  AND e.isExit=false"
	 * ) public Long getEmployeeOfficalEmail(String email,Long id);
	 */
	@Query(value = "SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.designation.designation,e.joiningDate,eem.lastWorkingDate) FROM Employee e INNER JOIN EmployeeExitMgmt eem ON eem.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% )  AND  e.joiningDate>=:startDate AND eem.lastWorkingDate<=:endDate and e.company.id=:companyId AND e.isDelete=false")
	public Page<EmployeePageDTO> allEmployeeExitReport(String searchKey, String companyId, Date startDate, Date endDate,
			Pageable paging);

	@Query(value = "SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.designation.designation,e.joiningDate,eem.lastWorkingDate) FROM Employee e INNER JOIN EmployeeExitMgmt eem ON eem.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% )  AND  e.joiningDate>=:startDate AND eem.lastWorkingDate<=:endDate and e.company.id=:companyId AND e.isDelete=false")
	public List<EmployeePageDTO> allEmployeeExitReport(String searchKey, String companyId, Date startDate,
			Date endDate);

	@Query(value = "SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.designation.designation,e.joiningDate,eem.lastWorkingDate) FROM Employee e INNER JOIN EmployeeExitMgmt eem ON eem.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% ) and e.company.id=:companyId AND e.isDelete=false")
	public Page<EmployeePageDTO> allEmployeeExitReport(String searchKey, String companyId, Pageable paging);

	@Query(value = "SELECT new com.hrms.admin.dto.EmployeePageDTO(e.id,e.firstName,e.lastName,e.designation.designation,e.joiningDate,eem.lastWorkingDate) FROM Employee e INNER JOIN EmployeeExitMgmt eem ON eem.employeeId=e.id WHERE (concat(e.firstName , ' ',e.lastName)LIKE %:searchKey% OR e.designation.designation LIKE %:searchKey% ) and e.company.id=:companyId AND e.isDelete=false")
	public List<EmployeePageDTO> allEmployeeExitReport(String searchKey, String companyId);

	@Query("SELECT new com.hrms.admin.dto.EmployeeInfoDTO(e.id,e.firstName,e.lastName,e.officalMail,e.userName,e.dateOfBirth,e.gender,e.maritalStatus,e.contactNo,e.alternateContactNo,e.aadharCard,e.panCard,e.voterID,e.joiningDate,e.bloodGroup,e.designation.designation,e.isActive) FROM Employee e WHERE e.manager.id=:managerId AND e.isActive=true AND e.isDelete=false AND e.isExit=false")
	public List<EmployeeInfoDTO> findByMangerId(Long managerId);

	@Query("select e from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND (e.isActive=true OR e.isActive=false) AND e.isDelete=false AND e.isExit=false and e.company.id=?2 and e.employmentTypeId=?3")
	public Page<Employee> allEmployeePageWithEmploymentType(String searchKey, String companyId, Long employmentTypeId,
			Pageable paging);

	@Query("select e from Employee e WHERE (e.firstName LIKE %?1% OR e.lastName LIKE %?1% OR e.officalMail LIKE %?1% OR e.contactNo LIKE %?1% OR e.designation.designation LIKE %?1%) AND e.isActive=?2 AND e.isDelete=false AND e.isExit=false and e.company.id=?3 and e.employmentTypeId=?4")
	public Page<Employee> employeePageWithEmploymentType(String searchKey, Boolean status, String companyId,
			Long employmentTypeId, Pageable paging);
}
