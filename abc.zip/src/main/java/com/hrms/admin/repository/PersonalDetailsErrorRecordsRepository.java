package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.PersonalDetailsErrorRecords;

public interface PersonalDetailsErrorRecordsRepository extends JpaRepository<PersonalDetailsErrorRecords, Long> {
	
	@Query("SELECT e FROM PersonalDetailsErrorRecords e where DATE_FORMAT(e.createdDate,'%Y-%m-%d')=current_date() and e.createdBy=:username")
	public List<PersonalDetailsErrorRecords> getTodayaddedEmployeeecdErrorRecords(String username);

}
