package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long> {

	Menu findByMenuId(Long menuId);
	
	Menu findByMenuTitle(String menuTitle);
}
