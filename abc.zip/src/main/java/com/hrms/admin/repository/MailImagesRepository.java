/*
 * package com.hrms.admin.repository;
 * 
 * import org.springframework.data.mongodb.repository.MongoRepository; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.hrms.admin.entity.MailImages;
 * 
 * @Repository public interface MailImagesRepository extends
 * MongoRepository<MailImages, Long> {
 * 
 * public MailImages findByFileName(String fileName);
 * 
 * }
 */