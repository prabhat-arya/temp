package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.AnnualLeaves;

public interface AnnualLeavesRepository extends JpaRepository<AnnualLeaves, Long> {

	@Query(value = "SELECT a FROM AnnualLeaves a WHERE  a.employee.id=:employeeId AND a.leaveType.id=:leavetypeId")
	public AnnualLeaves findByEmployeeId(Long employeeId, Long leavetypeId);

	@Query(value = "SELECT a FROM AnnualLeaves a WHERE   a.leaveType.id=:leaveTypeId")
	public List<AnnualLeaves> findByLeaveTypeId(Long leaveTypeId);

	@Query("select sum(availableLeaves) from AnnualLeaves a where a.employee.id=:employeeId ")
	public Long getEmpAnualLeaves(Long employeeId);

	@Query("select sum(availableLeaves) from AnnualLeaves a where a.employee.id=:employeeId")
	public Long getEmpAvailableLeaves(Long employeeId);

	public List<AnnualLeaves> findByEmployeeId(Long employeeId);
	
	@Query(value = "SELECT a FROM AnnualLeaves a WHERE  a.employee.id=:employeeId AND a.leaveType.id=:leavetypeId")
	public AnnualLeaves findByEmpId(Long employeeId, Long leavetypeId);
	
	
	@Query(value = "SELECT a FROM AnnualLeaves a WHERE a.leaveType.id=:leaveTypeId AND a.employee.id=:empId")
	public List<AnnualLeaves> findByLeaveTypeIdAndEmpId(Long leaveTypeId,Long empId);

}