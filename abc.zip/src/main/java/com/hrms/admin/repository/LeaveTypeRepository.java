package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.LeaveType;

@Repository
public interface LeaveTypeRepository  extends JpaRepository<LeaveType, Long>{
	
	/*
	 * String leaveList =
	 * "SELECT l.id,l.leaveType,l.isActive,l.company.id,l.isDelete,c.name,l.branch.id, b.name \r\n"
	 * +
	 * "FROM LeaveType l INNER JOIN Company c ON l.company.id =c.id INNER JOIN Branch b ON l.branch.id =b.id"
	 * ;
	 * 
	 * @Query(leaveList) Page<LeaveType> findAll(Pageable paging);
	 */

//	public Optional<LeaveType> findByLeaveType(String leaveType);
	
	@Query(value = "SELECT count(*) FROM LeaveType l WHERE l.leaveType=:leaveType AND l.company.id=:companyId AND l.isDelete=false")
	Long getLeaveTypeCountSave( String leaveType, String companyId);

	@Query(value = "SELECT count(*) FROM LeaveType l WHERE   l.leaveType=:leaveType AND l.company.id=:companyId AND l.id <> :id AND l.isDelete=false")
	Long getLeaveTypeCountUpdate(String companyId,  String leaveType, Long id);

	/*
	 * @Query("SELECT a FROM LeaveType a WHERE a.isActive=true AND a.isDelete=false"
	 * ) public List<LeaveType> findAll();
	 */
//	@Query("SELECT a FROM LeaveType a WHERE a.id=:id AND a.isActive=true AND a.isDelete=false")
//	public Optional<LeaveType> findById(Long id);
	
	@Query("select l from LeaveType l WHERE  (l.leaveType LIKE %?1% OR l.company.name LIKE %?1% OR l.branch.name LIKE %?1%) and l.company.id=?2 AND l.isActive=?3 AND l.isDelete=false")
	Page<LeaveType> leaveTypePage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query("select l from LeaveType l WHERE  (l.leaveType LIKE %?1% OR l.company.name LIKE %?1% OR l.branch.name LIKE %?1%) and l.company.id=?2 AND (l.isActive=true OR l.isActive=false) AND l.isDelete=false")
	Page<LeaveType> allLeaveTypePage(String searchKey,String companyId, Pageable pageable);
	
	@Query("SELECT a FROM LeaveType a WHERE a.company.id=:companyId AND a.branch.id=:branchId AND a.isActive=true AND a.isDelete=false")
	public List<LeaveType> findByCompanyId(String companyId,Long branchId);
	
	@Query("SELECT a FROM LeaveType a WHERE a.id=:id AND a.isDelete=false")
	public Optional<LeaveType> findByLeave(Long id);
	
	@Query("SELECT new com.hrms.admin.entity.LeaveType(a.id,a.leaveType) FROM LeaveType a WHERE a.id=:id AND a.isActive=true AND a.isDelete=false")
	public LeaveType findByLeaveTypeId(Long id);
	
	@Query("select l from LeaveType l where l.id=:id and l.company.id=:companyId AND l.isActive=true AND l.isDelete=false")
	public Optional<LeaveType> findLeaveByCompanyId(Long id , String companyId);
	
	@Query("select l from LeaveType l where l.company.id=:companyId AND l.isActive=true AND l.isDelete=false ")
	public List<LeaveType> findAllLeaveTypeByCompanyId(String companyId);
	

}
