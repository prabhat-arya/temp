package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Shift;

public interface ShiftRepository extends JpaRepository<Shift, Long> {

	@Query(value = "SELECT count(*) FROM Shift a WHERE a.shiftName = :shiftName  AND  a.isDelete=false and a.company.id=:companyId")
	public Long getShiftCount(String shiftName,String companyId);

	@Query(value = "SELECT count(*) FROM Shift a WHERE a.shiftName = :shiftName   AND  a.id <> :shiftId AND a.isDelete=false and a.company.id=:companyId")
	public Long getUpdateShiftCount(String shiftName, Long shiftId,String companyId);

	@Query(value = "SELECT a FROM Shift a WHERE  a.isActive=true AND a.isDelete=false")
	public List<Shift> findAll();

	@Query(value = "SELECT s FROM Shift s WHERE s.id=:id AND s.isActive=true AND s.isDelete=false")
	public Optional<Shift> findById(Long id);

	@Query(value = "SELECT s FROM Shift s WHERE s.id=:id and s.company.id=:companyId AND s.isActive=true AND s.isDelete=false")
	public Optional<Shift> findShiftById(Long id, String companyId);

	@Query(value = "SELECT s.shiftName FROM Shift s WHERE s.id=:id AND s.isActive=true AND s.isDelete=false")
	public Shift getShiftNames(Long id);

	@Query(value = "SELECT a FROM Shift a WHERE a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public List<Shift> findByCompany(String companyId);

	// page indicate these methods are use to get the data as Pageable
	@Query("select s from Shift s WHERE  (s.shiftName LIKE %?1% OR s.company.name LIKE %?1% OR s.inTime LIKE %?1%  OR s.outTime LIKE %?1%)and s.company.id=?2 AND s.isActive=?3 AND s.isDelete=false")
	Page<Shift> shiftPage(String searchKey, String companyId, Boolean status, Pageable pageable);

	@Query("select s from Shift s WHERE  (s.shiftName LIKE %?1% OR s.company.name LIKE %?1% OR s.inTime LIKE %?1%  OR s.outTime LIKE %?1%) and s.company.id=?2 AND (s.isActive=true OR s.isActive=false) AND s.isDelete=false")
	Page<Shift> allShiftPage(String searchKey, String companyId, Pageable pageable);

	@Query(value = "SELECT s.shiftName FROM Shift s WHERE s.id=:id AND s.isActive=true AND s.isDelete=false")
	public String findById1(Long id);

	@Query(value = "FROM Shift s WHERE s.shiftName=:shiftName AND s.isActive=true AND s.isDelete=false and s.company.id=:companyId")
	public Shift findByShiftName(String shiftName,String companyId);
}
