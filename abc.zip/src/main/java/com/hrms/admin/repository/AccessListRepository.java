package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.AccessList;
import com.hrms.admin.entity.Menu;

public interface AccessListRepository extends JpaRepository<AccessList, Long> {

	List<AccessList> findByMenu(Menu menu);
}
