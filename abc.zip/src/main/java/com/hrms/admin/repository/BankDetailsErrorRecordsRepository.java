package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.BankDetailsErrorRecords;

public interface BankDetailsErrorRecordsRepository extends JpaRepository<BankDetailsErrorRecords, Long>{

	@Query("SELECT e FROM BankDetailsErrorRecords e where DATE_FORMAT(e.createdDate,'%Y-%m-%d')=current_date() and e.createdBy=:user")
	public List<BankDetailsErrorRecords> getTodayaddedEmployeeBankErrorRecords(String user);
}
