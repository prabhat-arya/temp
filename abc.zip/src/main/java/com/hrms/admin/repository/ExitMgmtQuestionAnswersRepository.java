package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.ExitMgmtQuestionAnswers;

public interface ExitMgmtQuestionAnswersRepository extends JpaRepository<ExitMgmtQuestionAnswers, Long> {

}
