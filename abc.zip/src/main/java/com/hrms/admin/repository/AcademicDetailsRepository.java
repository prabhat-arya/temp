package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.AcademicDetails;

public interface AcademicDetailsRepository extends JpaRepository<AcademicDetails,Long> {

	@Query(value = "SELECT p FROM AcademicDetails p WHERE  p.employee.id=:employeeId")
	public List<AcademicDetails> findByEmployee(Long employeeId);
}
