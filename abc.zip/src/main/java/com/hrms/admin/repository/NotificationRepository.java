package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

	public Notification findBysubject(String subject);

	/*
	 * String notificationlist =
	 * "SELECT n.id,n.subject,n.isActive,n.isDelete,n.company.id,c.name\r\n" +
	 * "FROM Notification n INNER JOIN Company c ON n.company.id =c.id ";
	 * 
	 * @Query(notificationlist) Page<Notification> findAll(Pageable paging);
	 */

	public Optional<Notification> findBySubject(String name);

	@Query(value = "SELECT count(*) FROM Notification n WHERE   n.subject=:subject AND n.company.id=:companyId AND n.isDelete=false")
	Long getJobCountSave(String subject, Long companyId);

	@Query(value = "SELECT count(*) FROM Notification n WHERE   n.subject=:subject AND n.company.id=:companyId AND n.id <> :id AND n.isDelete=false")
	Long getJobCountUpdate(Long companyId, String subject, Long id);

	@Query(value = "SELECT count(*) FROM Notification n WHERE   n.subject=:subject AND n.company.id=:companyId AND n.isDelete=false")
	public Long getNotificationCountSave(String subject, String companyId);

	@Query(value = "SELECT count(*) FROM Notification n WHERE   n.subject=:subject AND n.company.id=:companyId AND n.id <> :id AND n.isDelete=false")
	public Long getNotificationCountUpdate(String subject, String companyId, Long id);

	@Query("select new com.hrms.admin.entity.Notification(n.id,n.subject,n.company) from Notification n WHERE  (n.subject LIKE %?1% OR n.company.name LIKE %?1%) and n.company.id=?2 AND n.isActive=?3 AND n.isDelete=false")
	Page<Notification> notificationPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query("select new com.hrms.admin.entity.Notification (n.id,n.subject,n.company) from Notification n WHERE  (n.subject LIKE %?1% OR n.company.name LIKE %?1%)and n.company.id=?2 AND (n.isActive=true OR n.isActive=false) AND n.isDelete=false")
	Page<Notification> allNotificationPage(String searchKey,String companyId, Pageable pageable);
	
	@Query("select n from Notification n where n.id=:id and n.company.id=:companyId AND n.isActive=true AND n.isDelete=false")
	public Optional<Notification> findNotificationByCompanyId(Long id, String companyId);
}
