package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.State;

@Repository
public interface StateRepository extends JpaRepository<State, Long> {

	List<State> findAllBycountryId(Long countryId);

	@Query(value = "FROM State c WHERE c.stateName=:stateName")
	public State findByStateName(String stateName);

	@Query(value = "select max(states_id) from states", nativeQuery = true)
	public Long getLastStateId();
}
