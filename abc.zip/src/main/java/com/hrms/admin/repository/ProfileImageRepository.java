package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.ProfileImage;

public interface ProfileImageRepository extends JpaRepository<ProfileImage, Long>{

//public ProfileImage findByEmployeeId(Long employeeId);

@Query(value = "FROM ProfileImage b WHERE b.employee.id=:employeeId" )
public ProfileImage findByEmployee(Long employeeId);

@Query(value = "FROM ProfileImage b WHERE b.employee.id=:employeeId" )
public List<ProfileImage> getEmployeeImages(Long employeeId);

List<ProfileImage> findByCompanyId(String companyId);
}
