package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Long> {

	@Query(value = "FROM Branch b WHERE b.company.id=:companyId AND b.isActive=true AND b.isDelete=false")
	List<Branch> findByCompanyId(String companyId);

//	@Query(value = "FROM Branch b WHERE b.name=:name AND b.isActive=true AND b.isDelete=false")
//	public Optional<Branch> findByName(String name);

//	@Query(value = "FROM Branch b WHERE b.company.id=:companyId AND b.isActive=true AND b.isDelete=false")
//	public List<Branch> getCompanyById(Long companyId);

	@Query(value = "SELECT count(*) FROM Branch b WHERE b.company.id=:companyId AND b.name=:branchName AND b.isDelete=false")
	public Long getBranchCount(String companyId, String branchName);

	@Query(value = "SELECT count(*) FROM Branch b WHERE b.company.id=:companyId  AND b.name=:branchName AND b.id <> :branchId AND b.isDelete=false")
	public Long getBranchCountForUpdate(String companyId, String branchName, Long branchId);

	@Query(value = "FROM Branch b WHERE b.name=:name AND b.company.id=:companyId AND b.isActive=true AND b.isDelete=false")
	public Branch findByBranchName(String name, String companyId);

	@Query("select b from Branch b WHERE  (b.name LIKE %?1%  OR b.contactNo LIKE %?1%  OR b.email LIKE %?1%) AND b.company.id=?2 and b.isActive=?3 AND b.isDelete=false")
	Page<Branch> branchPage(String searchKey, String companyId,Boolean status, Pageable pageable);

	@Query("select b from Branch b WHERE  (b.name LIKE %?1% OR b.contactNo LIKE %?1% OR b.email LIKE %?1%) AND b.company.id=?2 and (b.isActive=true OR b.isActive=false) AND b.isDelete=false")
	Page<Branch> allBranchPage(String searchKey,String companyId, Pageable pageable);
	
	@Query("select b from Branch b where b.id=:id and b.company.id=:companyId AND b.isActive=true AND b.isDelete=false")
	public Optional<Branch> findBranchByCompanyId(Long id,String companyId);
	
}
