package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.City;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

	List<City> findAllBystateId(Long stateId);

	@Query(value = "FROM City c WHERE c.cityName=:cityName AND c.stateId=:stateId")
	public City findByCityName(String cityName,Long stateId);
	
	@Query(value = "select max(cities_id) from cities",nativeQuery = true)
	public Long getLastCityId();
}
