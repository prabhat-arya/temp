package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Long> {

	Page<Company> findAll(Pageable paging);

	/*
	 * @Query(value = "SELECT a FROM Company a WHERE  a.name LIKE %?1%")
	 * Page<Company> findAllSearchWithPagination(String searchKey,Pageable paging);
	 */

	public Optional<Company> findByEmail(String email);

	public Optional<Company> findByWebsite(String website);

	// for validation save Method

	@Query(value = "SELECT count(*) FROM Company c WHERE c.name=:companyName AND c.isDelete=false")
	public Long getCompanyCount(String companyName);

	// for validation update Method

	@Query(value = "SELECT count(*) FROM Company c WHERE c.name=:companyName AND c.id <> :companyId AND c.isDelete=false")
	public Long getCompanyCountForUpdate(String companyName, String companyId);

	@Query(value = "SELECT a FROM Company a WHERE  a.name LIKE %?1% AND a.isActive=true AND a.isDelete=false")
	Page<Company> findAllSearchWithPaginationActiveRecord(String searchKey, Pageable paging);

	@Query(value = "SELECT a FROM Company a WHERE  a.name LIKE %?1% AND a.isActive=false AND a.isDelete=false")
	Page<Company> findAllSearchWithPaginationInActiveRecord(String searchKey, Pageable paging);

	@Query(value = "SELECT a FROM Company a WHERE  a.name LIKE %?1% AND a.isDelete=false")
	Page<Company> findAllSearchWithPaginationAll(String searchKey, Pageable paging);

//	@Query(value = "FROM Company c WHERE c.isActive=true AND c.isDelete=false")
//	public List<Company> findAllCommpany();

	@Query(value = "FROM Company c WHERE c.name=:companyName AND c.isActive=true AND c.isDelete=false")
	public Company findByName(String companyName);

	@Query(value = "FROM Company c WHERE c.id=:id AND c.isActive=true AND c.isDelete=false")
	public Optional<Company> findById(String id);

	// page indicate these methods are use to get the data as Pageable

	@Query("select c from Company c WHERE  (c.name LIKE %?1% OR c.email LIKE %?1% OR c.contact LIKE %?1% OR c.website LIKE %?1%) AND c.isActive=?2 AND c.isDelete=false and c.id=?3")
	Page<Company> companyPage(String searchKey, Boolean status,String companyId, Pageable pageable);

	@Query("select c from Company c WHERE  (c.name LIKE %?1% OR c.email LIKE %?1% OR c.contact LIKE %?1% OR c.website LIKE %?1%) AND (c.isActive=true OR c.isActive=false) AND c.isDelete=false and c.id=?2")
	Page<Company> allCompanyPage(String searchKey,String companyId, Pageable pageable);

	@Query(value = "FROM Company c WHERE c.id=:id AND c.isDelete=false")
	public Optional<Company> findByCompany(Long id);

	@Query(value = "SELECT count(c.id) FROM Company c WHERE c.name=:companyName AND c.userName=:userName AND c.contact=:mobileNo AND c.email=:emailId")
	public Long getCompanySaveCount(String companyName, String userName, String mobileNo, String emailId);

	@Query(value = "SELECT count(c.id) FROM Company c WHERE c.userName=:userName")
	public Long getCompanySaveCountByUserName(String userName);

	@Query(value = "SELECT count(c.id) FROM Company c WHERE c.email=:emailId")
	public Long getCompanySaveCountByEmail(String emailId);

	@Query(value = "SELECT count(c.id) FROM Company c WHERE  c.contact=:mobileNo")
	public Long getCompanySaveCountByContact(String mobileNo);

	@Query(value = "SELECT count(c.id) FROM Company c WHERE c.name=:companyName")
	public Long getCompanySaveCountByName(String companyName);

	@Query(value = "select company_id from company order by created_date desc limit 1",nativeQuery = true)
	public String getLostInsertedCompany();
}
