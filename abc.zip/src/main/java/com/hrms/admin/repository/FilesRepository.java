package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.FileDetails;

public interface FilesRepository extends JpaRepository<FileDetails, Long> {

	@Query(value = "FROM FileDetails  WHERE employee.id=:employeeId")
	public List<FileDetails> findByemployee(Long employeeId);

}
