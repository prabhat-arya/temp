package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.AttendanceInfoErrorRecords;

public interface AttendanceInfoErrorRecordsRepository extends JpaRepository<AttendanceInfoErrorRecords, Long> {

	@Query("SELECT e FROM AttendanceInfoErrorRecords e where DATE_FORMAT(e.createdDate,'%Y-%m-%d')=current_date() and e.createdBy=:user")
	public List<AttendanceInfoErrorRecords> getTodayaddedAttendanceInfoErrorRecords(String user);
}
