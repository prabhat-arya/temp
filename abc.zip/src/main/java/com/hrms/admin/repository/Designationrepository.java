package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.dto.DesignationDTO;
//manikantakottakota@bitbucket.org/cloudopsonpassive/hrmsapi.git
import com.hrms.admin.entity.Designation;

@Repository
public interface Designationrepository extends JpaRepository<Designation, Long> {

//	public Optional<Designation> findByDesignation(String designation);

//	public Optional<Designation> findBydesignation(String designation);

	@Query(value = "FROM Designation d WHERE d.department.id=:departmentid AND d.company.id=:companyId AND d.isActive=true AND d.isDelete=false")
	public List<Designation> findDepartmentByCompanyId(Long departmentid,String companyId);

	// validation for save
	@Query(value = "SELECT count(*) FROM Designation d WHERE d.designation=:designation AND d.department.id=:departmentid AND d.company.id=:companyId AND d.branch.id=:branchId AND d.isDelete=false")
	public Long getDesignationCountForSave(String designation, Long departmentid, String companyId, Long branchId);

	@Query(value = "SELECT count(*) FROM Designation d WHERE d.designation=:designation AND d.department.id=:departmentid AND d.company.id=:companyId AND d.branch.id=:branchId AND d.id <> :designationId AND d.isDelete=false")
	public Long getDesignationCountForUpdate(String designation, Long departmentid, String companyId, Long branchId,
			Long designationId);

	@Query(value = "FROM Designation d WHERE d.designation=:name AND d.company.id=:companyId AND d.branch.id=:branchId  AND d.department.id=:departmentId AND d.isActive=true AND d.isDelete=false")
	public Designation findBydesignationName(String name, String companyId, Long branchId, Long departmentId);

	// page indicate these methods are use to get the data as Pageable
	@Query("select new com.hrms.admin.dto.DesignationDTO(d.id,d.designation,d.skills,d.experiance,d.company.name,d.branch.name,d.department.name,d.department.id,d.branch.id,d.company.id,d.isDelete,d.isActive) from Designation d WHERE (d.company.name LIKE %?1% OR d.branch.name LIKE %?1% OR d.designation LIKE %?1% OR d.skills LIKE %?1% OR d.experiance LIKE %?1%) AND d.company.id=?2 AND d.isActive=?3 AND d.isDelete=false")
	Page<DesignationDTO> designationPage(String searchKey,  String companyId,Boolean status, Pageable pageable);

	//@Query("select d from Designation d WHERE (d.company.name LIKE %?1% OR d.branch.name LIKE %?1%  OR d.designation LIKE %?1% OR d.skills LIKE %?1% OR d.experiance LIKE %?1%) AND (d.isActive=true OR d.isActive=false) AND d.isDelete=false")
	@Query("select new com.hrms.admin.dto.DesignationDTO(d.id,d.designation,d.skills,d.experiance,d.company.name,d.branch.name,d.department.name,d.department.id,d.branch.id,d.company.id,d.isDelete,d.isActive) from Designation d WHERE (d.company.name LIKE %?1% OR d.branch.name LIKE %?1% OR d.designation LIKE %?1% OR d.skills LIKE %?1% OR d.experiance LIKE %?1%) AND d.company.id=?2 AND d.isActive=?3 AND d.isDelete=false")
	Page<DesignationDTO> allDesignationPage(String searchKey, String companyId,Boolean status,Pageable pageable);

	@Query(value = "FROM Designation d WHERE d.id=:id AND d.company.id=:companyId AND d.isActive=true AND d.isDelete=false")
	public Optional<Designation> findById(Long id,String companyId);

}
