package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.CertificateTypeDTO;
import com.hrms.admin.entity.CertificateType;

public interface CertificateTypeRepository extends JpaRepository<CertificateType, Long> {

	@Query(value = "select new com.hrms.admin.dto.CertificateTypeDTO(c.certificateId,c.certificateName) from CertificateType c ")
	List<CertificateTypeDTO> getAllCertificateTypeList();

	@Query(value = "select count(c.certificateId) from CertificateType c where c.certificateName=:certificateName")
	public Long getCertificateName(String certificateName);

}
