package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.GoalCreation;

public interface GoalCreationRepository extends JpaRepository<GoalCreation, Long> {

	public GoalCreation findByEmployeeId(Long employeeId);

	// page indicate these methods are use to get the data as Pageable
	/*
	 * @Query("select new com.hrms.admin.entity.GoalCreation(g.goalId,g.departmentName,g.employeeName,g.reviewStart,g.reviewEnd,g.dueDate,g.status,g.employeeId) from GoalCreation g WHERE reviewManager=:manager and "
	 * ) Page<GoalCreation> goalPage(Pageable pageable, String manager,String
	 * companyId);
	 */

	// page indicate these methods are use to get the data as Pageable
	@Query("select gc from Company c inner join Employee e on c.id=e.company.id inner join GoalCreation gc on e.id=gc.employeeId and c.id=?1")
	Page<GoalCreation> goalPage(String companyId, String manager, Pageable pageable);

}
