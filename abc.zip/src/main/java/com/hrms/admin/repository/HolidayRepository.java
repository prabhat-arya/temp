package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Holiday;

public interface HolidayRepository extends JpaRepository<Holiday, Long> {

	String holidayList = "SELECT h.id,h.name,h.date,h.isActive,h.company.id, h.isDelete,c.name,h.branch.id,b.name\r\n"
			+ "FROM Holiday h INNER JOIN Company c ON h.company.id =c.id\r\n"
			+ "INNER JOIN Branch b ON h.branch.id =b.id";

	@Query(holidayList)
	Page<Holiday> findAll(Pageable paging);

//	@Query(value = "SELECT a FROM Holiday a WHERE  (a.name LIKE %?1%  OR a.date LIKE %?1%) AND a.isDelete=false")
//	Page<Holiday> findAllSearchWithPaginationAll(String searchKey, Pageable paging);

//	public Optional<Holiday> findByName(String name);

	@Query(value = "SELECT count(*) FROM Holiday h WHERE  h.branch.id=:branchId  AND h.name=:name AND h.company.id=:companyId AND h.isDelete=false")
	public Long getHolidayCountSave(Long branchId, String name, String companyId);

	@Query(value = "SELECT count(*) FROM Holiday h WHERE  h.branch.id=:branchId  AND h.name=:name AND h.company.id=:companyId AND h.id <> :holidayId AND h.isDelete=false")
	public Long getHolidayCountUpdate(String companyId, Long branchId, String name, Long holidayId);

//	@Query(value = "SELECT a FROM Holiday a WHERE  (a.name LIKE %?1%  OR a.date LIKE %?1%) AND a.isActive=true AND a.isDelete=false")
//	Page<Holiday> findAllSearchWithPaginationActiveRecord(String searchKey, Pageable paging);
//
//	@Query(value = "SELECT a FROM Holiday a WHERE  (a.name LIKE %?1%  OR a.date LIKE %?1%)AND a.isActive=false AND a.isDelete=false")
//	Page<Holiday> findAllSearchWithPaginationInActiveRecord(String searchKey, Pageable paging);

	// changed
	// @Query(value = "FROM Holiday h WHERE h.branch.id=:branchId AND
	// h.isActive=true AND h.isDelete=false")
	// @Query(value = "select new com.hrms.admin.entity.Holiday
	// (h.id,h.name,h.date,h.company,h.branch,h.isActive,h.isDelete) FROM Holiday h
	// WHERE h.branch.id=:branchId AND h.isActive=true AND h.isDelete=false")
	@Query("select new com.hrms.admin.entity.Holiday(h.id,h.name,h.date,h.attechementId) FROM Holiday h WHERE h.branch.id=:branchId AND h.isActive=true AND date_format(date,'%Y')=YEAR(CURDATE()) and h.isDelete=false order by date")
	public List<Holiday> getAllHolidayListBasedOnBranch(Long branchId);
	
	@Query("select new com.hrms.admin.entity.Holiday(h.id,h.name,h.date,h.attechementId) FROM Holiday h WHERE h.branch.id=:branchId and h.company.id=:companyId AND h.isActive=true AND date_format(date,'%Y')=YEAR(CURDATE()) and h.isDelete=false order by date")
	public List<Holiday> getAllHolidayListByBranch(Long branchId, String companyId);

	// page indicate these methods are use to get the data as Pageable
	// @Query("select h from Holiday h WHERE (h.name LIKE %?1% OR h.date LIKE %?1%
	// OR h.company.name LIKE %?1% OR h.branch.name LIKE %?1%) AND h.isActive=?2 AND
	// h.isDelete=false")
	@Query("select new com.hrms.admin.entity.Holiday(h.id,h.name,h.date,h.company,h.branch,h.attechementId) from Holiday h WHERE  (h.name LIKE %?1% OR  h.date LIKE %?1% OR h.company.name LIKE %?1% OR h.branch.name LIKE %?1%) and h.company.id=?2 AND h.isActive=?3 AND h.isDelete=false")
	Page<Holiday> holidayPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	// @Query("select h from Holiday h WHERE (h.name LIKE %?1% OR h.date LIKE %?1%
	// OR h.company.name LIKE %?1% OR h.branch.name LIKE %?1%) AND (h.isActive=true
	// OR h.isActive=false) AND h.isDelete=false")
	@Query("select new com.hrms.admin.entity.Holiday(h.id,h.name,h.date,h.company,h.branch,h.attechementId) from Holiday h WHERE  (h.name LIKE %?1% OR  h.date LIKE %?1% OR h.company.name LIKE %?1% OR h.branch.name LIKE %?1%)and h.company.id=?2 AND (h.isActive=true OR h.isActive=false) AND h.isDelete=false")
	Page<Holiday> allHolidayPage(String searchKey,String companyId, Pageable pageable);
	
	@Query("select h from Holiday h where h.id=:id and h.company.id=:companyId AND h.isActive=true AND h.isDelete=false ")
	public Optional<Holiday> findHolidaysByCompanyId(Long id, String companyId);
	
}