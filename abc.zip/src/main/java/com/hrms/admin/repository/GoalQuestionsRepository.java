package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.GoalQuestions;

public interface GoalQuestionsRepository extends JpaRepository<GoalQuestions, Long> {



}
