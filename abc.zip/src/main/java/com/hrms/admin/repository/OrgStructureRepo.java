package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.DegLevelEntity;

@Repository
public interface OrgStructureRepo extends JpaRepository<DegLevelEntity, Long> {
	
	DegLevelEntity findByLevelNo(String LevelNo);
	
	@Query(value = "SELECT level_id FROM test4.deg_level;",nativeQuery = true)
	public List<Long> getAllLevelId();

}
