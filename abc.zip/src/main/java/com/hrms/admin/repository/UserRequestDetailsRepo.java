package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.UserRequestDetails;

public interface UserRequestDetailsRepo extends JpaRepository<UserRequestDetails, Long> {
	
	//user_request_details user_jwt_token
	@Query(value = "SELECT * FROM user_request_details WHERE USER_JWT_TOKEN =:jwtToken", nativeQuery = true)
	public UserRequestDetails findByUserJwtToken(String jwtToken);
	
	List<UserRequestDetails> findByUserName(String userName);
}
