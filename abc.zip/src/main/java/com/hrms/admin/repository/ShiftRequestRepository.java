package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.ShiftRequest;

public interface ShiftRequestRepository extends JpaRepository<ShiftRequest, Long> {

//	@Query(value = "FROM ShiftRequest s WHERE  s.employee.id=:employeeId")
//	public ShiftRequest findByDateAndId(Long employeeId);

//	@Query(value = "SELECT a FROM ShiftRequest a WHERE      a.status  LIKE %?1%  OR  a.employeeName LIKE %?1%")
//	Page<ShiftRequest> findAllSearchWithPaginationAll(String searchKey, Pageable paging,Long employeeId);

//	@Query(value = "SELECT s FROM ShiftRequest s WHERE  s.id=:id")
//	public Optional<ShiftRequest> findById(Long id);

//	@Query(value = "SELECT s FROM ShiftRequest s WHERE s.status LIKE %?1%  OR s.employeeName LIKE %?1% ")
//	Page<ShiftRequest> findAllManagerSearchWithPaginationAll(String searchKey, Pageable paging);

	// page indicate these methods are use to get the data as Pageable

	@Query("select s from ShiftRequest s WHERE  (s.todate LIKE %?1%    OR  s.fromdate LIKE %?1%   OR   s.employeeName  LIKE %?1%   OR  s.currentShiftName  LIKE %?1%  OR  s.requestShiftName  LIKE %?1%  OR  s.status   LIKE %?1%) AND  s.employee.id=?2 AND s.status=?3 and s.employee.company.id=?4")
	Page<ShiftRequest> shiftRequestPage(String searchKey, Long empId, String status,String companyId, Pageable pageable);

	@Query("select s from ShiftRequest s WHERE (s.todate LIKE %?1%    OR  s.fromdate LIKE %?1%   OR   s.employeeName  LIKE %?1%   OR  s.currentShiftName  LIKE %?1%  OR  s.requestShiftName  LIKE %?1%   OR  s.status   LIKE %?1%) AND  s.employee.id=?2 and s.employee.company.id=?3")
	Page<ShiftRequest> allShiftRequestPage(String searchKey, Long empId,String companyId, Pageable pageable);

	@Query("select s from ShiftRequest s WHERE  (s.todate LIKE %?1%    OR  s.fromdate LIKE %?1%   OR   s.employeeName  LIKE %?1%   OR  s.currentShiftName  LIKE %?1%  OR  s.requestShiftName  LIKE %?1%  OR  s.status   LIKE %?1%) AND  s.status=?2 and s.employee.company.id=?3")
	Page<ShiftRequest> shiftRequestManagerPage(String searchKey, String status, String companyId, Pageable pageable);

	@Query("select s from ShiftRequest s WHERE (s.todate LIKE %?1%    OR  s.fromdate LIKE %?1%   OR   s.employeeName  LIKE %?1%   OR  s.currentShiftName  LIKE %?1%  OR  s.requestShiftName  LIKE %?1%  OR  s.status   LIKE %?1%) and s.employee.company.id=?2")
	Page<ShiftRequest> allShiftRequestManagerPage(String searchKey,String companyId, Pageable pageable);

}
