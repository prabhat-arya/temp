package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Attendance;

public interface AttendancesRepository extends JpaRepository<Attendance, Long> {

	/*
	 * String attendanceList =
	 * "SELECT a.id,a.isDelete,a.companyId,c.name,a.branchId,b.name\r\n" +
	 * "FROM Attendance a INNER JOIN Company c ON a.companyId =c.id\r\n" +
	 * "INNER JOIN Branch b ON a.branchId =b.id";
	 * 
	 * @Query(attendanceList) Page<Attendance> findAll(Pageable paging);
	 */
//	@Query(value = "SELECT a FROM Attendance a WHERE  (a.branchName LIKE %?1%    OR a.companyName LIKE %?1%) AND a.isDelete=false")
//	Page<Attendance> findAllSearchWithPagination(String searchKey, Pageable paging);

//	public Optional<Attendance> findByCompany(String company);

//	public Optional<Attendance> findByBranch(String branch);

	@Query(value = "FROM Attendance a WHERE a.companyId=:companyId AND a.isActive=true AND a.isDelete=false")
	public List<Attendance> findByCompanyId(String companyId);

	// for duplicate check
	// save
	@Query(value = "SELECT count(*) FROM Attendance a WHERE a.companyId = :companyId AND a.branchId=:branchId AND a.isDelete=false")
	public Long getAttendanceCount(String companyId, Long branchId);

	// update
	@Query(value = "SELECT count(*) FROM Attendance a WHERE a.companyId = :companyId AND a.branchId=:branchId AND a.id <> :attendanceId AND a.isDelete=false")
	public Long getUpdateAttendanceCount(String companyId, Long branchId, Long attendanceId);

//	@Query(value = "SELECT a FROM Attendance a WHERE  (a.branchName LIKE %?1%    OR a.companyName LIKE %?1%) AND a.isActive=true AND a.isDelete=false")
//	Page<Attendance> findAllSearchWithPaginationActiveRecord(String searchKey, Pageable paging);
//
//	@Query(value = "SELECT a FROM Attendance a WHERE  (a.branchName LIKE %?1%    OR a.companyName LIKE %?1%) AND a.isActive=false AND a.isDelete=false")
//	Page<Attendance> findAllSearchWithPaginationInActiveRecord(String searchKey, Pageable paging);

//	@Query(value = "FROM Attendance a WHERE a.branchId=:branchId AND a.isActive=true AND a.isDelete=false")
//	public Attendance findByBranchId(Long branchId);

	@Query(value = "SELECT a.branchId FROM Attendance a WHERE a.id=:id")
	public Long findBranchId(Long id);

	@Query(value = "SELECT a FROM Attendance a WHERE a.branchId=:branchId AND a.isDefault=true AND a.isActive=true AND a.isDelete=false")
	public Attendance findDefaultShiftByBranch(Long branchId);

	@Query(value = "FROM Attendance a WHERE a.branchId=:branchId AND a.isActive=true AND a.isDelete=false")
	public List<Attendance> findByBranch(Long branchId);

	// setting Default shift to employee
	@Query(value = "FROM Attendance a WHERE a.branchId=:branchId AND a.isDefault=true  AND a.isActive=true AND a.isDelete=false")
	public Attendance getShiftIdBasedOnBranchId(Long branchId);

	// page indicate these methods are use to get the data as Pageable
	@Query("select a from Attendance a WHERE  (a.shift.shiftName LIKE %?1% OR a.shift.inTime LIKE %?1% OR  a.shift.outTime LIKE %?1% OR  a.company.name LIKE %?1% OR a.branch.name LIKE %?1%) AND a.isActive=?2 AND a.isDelete=false")
	Page<Attendance> attendancePage(String searchKey, Boolean status, Pageable pageable);

	@Query("select a from Attendance a WHERE  (a.shift.shiftName LIKE %?1% OR a.shift.inTime LIKE %?1% OR   a.shift.outTime LIKE %?1% OR a.company.name LIKE %?1% OR a.branch.name LIKE %?1%) and a.company.id=?2 AND (a.isActive=true OR a.isActive=false) AND a.isDelete=false")
	Page<Attendance> allAttendancePage(String searchKey, String companyId, Pageable pageable);

}
