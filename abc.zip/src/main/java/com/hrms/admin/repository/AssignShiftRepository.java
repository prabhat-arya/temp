
package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.AssignShiftDTO;
import com.hrms.admin.entity.AssignShift;

public interface AssignShiftRepository extends JpaRepository<AssignShift, Long> {

	@Query(value = "SELECT a FROM AssignShift a  WHERE a.employee.id=:employeeId AND a.isDelete=false")
	public List<AssignShift> findByEmployeeId(Long employeeId);

	@Query("SELECT a FROM AssignShift a WHERE  (a.employeeName LIKE %?1%  OR a.projectName LIKE %?1%) and a.employee.company.id=?2")
	Page<AssignShift> assignShiftPage(String searchKey, String companyId, Boolean status, Pageable pageable);

//	@Query("SELECT a FROM AssignShift a WHERE  a.employeeName LIKE %?1%  OR a.projectName LIKE %?1%")
//	Page<AssignShift> allAssignShiftPage(String searchKey, Pageable pageable);

//	@Query(value = "SELECT a FROM AssignShift a  WHERE a.employee.id=:employeeId  AND  a.shift.id=:shiftId AND a.isDelete=false")
//	public AssignShift findByEmplolyeeIdAndShiftId(Long employeeId, Long shiftId);

	@Query(value = "SELECT a FROM AssignShift a  WHERE a.employee.id=:employeeId  AND  a.projectId=:projectId AND a.isDelete=false")
	public List<AssignShift> findByEmplolyeeIdAndProjectId(Long employeeId, Long projectId);

//	@Query(value = "SELECT a FROM AssignShift a  WHERE a.employee.id=:employeeId  AND  a.projectId=:projectId  AND  a.shift.id=:shiftId AND a.isDelete=false")
//	public AssignShift findByEmplolyeeIdAndShiftIdAndProjectId(Long employeeId, Long projectId, Long shiftId);

	@Query("select count(a.employee.id) From AssignShift a where a.employee.id =:empId and DATE_FORMAT(:date,'%Y-%m-%d')>=a.fromDate and DATE_FORMAT(:date,'%Y-%m-%d')<=a.toDate and a.employee.company.id=:companyId")
	public Long findShiftIdCount(Long empId, String date, String companyId);

	@Query("select a From AssignShift a where a.employee.id =:empId and DATE_FORMAT(:date,'%Y-%m-%d')>=a.fromDate and DATE_FORMAT(:date,'%Y-%m-%d')<=a.toDate and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftId(Long empId, String date, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE  (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND   a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> allAssignShiftAllReports(String searchKey, Boolean status, String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND  (a.projectId= :projectId AND a.shift.id= :shiftId) AND a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReport(String searchKey, Long projectId, Long shiftId, Boolean status,
			String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND  (a.projectId= :projectId)  AND a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReportProjectbased(String searchKey, Long projectId, Boolean status, String companyId,
			Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND  (a.shift.id= :shiftId) AND a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReportShiftbased(String searchKey, Long shiftId, Boolean status, String companyId,
			Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND  (a.projectId= :projectId AND a.shift.id= :shiftId AND DATE_FORMAT(:startDate,'%Y-%m-%d')<=a.fromDate AND DATE_FORMAT(:endDate,'%Y-%m-%d')>=a.toDate)   AND  a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReport(String searchKey, Long projectId, Long shiftId, Boolean status,
			String startDate, String endDate, String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND  (a.projectId= :projectId AND DATE_FORMAT(:startDate,'%Y-%m-%d')<=a.fromDate AND DATE_FORMAT(:endDate,'%Y-%m-%d')>=a.toDate)  AND a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReportProjectDatebased(String searchKey, Long projectId, Boolean status,
			String startDate, String endDate, String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)    AND  (a.shift.id= :shiftId AND  DATE_FORMAT(:startDate,'%Y-%m-%d')<=a.fromDate AND DATE_FORMAT(:endDate,'%Y-%m-%d')>=a.toDate) AND  a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReportShiftDatebased(String searchKey, Long shiftId, Boolean status, String startDate,
			String endDate, String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)    AND   (DATE_FORMAT(:startDate,'%Y-%m-%d')<=a.fromDate AND DATE_FORMAT(:endDate,'%Y-%m-%d')>=a.toDate)  AND a.isDelete= :status and a.employee.company.id=:companyId")
	Page<AssignShift> assignShiftReportDatebased(String searchKey, Boolean status, String startDate, String endDate,
			String companyId, Pageable pageable);

	@Query("SELECT a FROM AssignShift a WHERE  (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND (a.projectId= :projectId AND a.shift.id= :shiftId) AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportSPbased(Long projectId, Long shiftId, String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND  (a.projectId= :projectId ) AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportPbased(Long projectId, String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND (a.shift.id= :shiftId) AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportSbased(Long shiftId, String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND  a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftAllReport(String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)  AND  a.projectId= :projectId AND a.shift.id= :shiftId  AND   DATE_FORMAT(:startDate,'%Y-%m-%d')>=a.fromDate   AND   DATE_FORMAT(:endDate,'%Y-%m-%d')<=a.toDate AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportSPDatebased(Long projectId, Long shiftId, String startDate, String endDate,
			String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND   DATE_FORMAT(:startDate,'%Y-%m-%d')>=a.fromDate   AND   DATE_FORMAT(:endDate,'%Y-%m-%d')<=a.toDate  AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportDatebased(String startDate, String endDate, String searchKey,
			String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND  a.projectId= :projectId  AND  DATE_FORMAT(:startDate,'%Y-%m-%d')>=a.fromDate AND DATE_FORMAT(:endDate,'%Y-%m-%d')<=a.toDate AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportDateProjectbased(Long projectId, String startDate, String endDate,
			String searchKey, String companyId);

	@Query("SELECT a FROM AssignShift a WHERE (a.employee.firstName LIKE %:searchKey% OR a.employee.lastName LIKE %:searchKey% OR a.employee.manager.firstName LIKE %:searchKey% OR a.employee.manager.lastName LIKE %:searchKey% OR a.employee.designation.designation LIKE %:searchKey% OR a.shift.shiftName LIKE %:searchKey%  OR a.projectName  LIKE %:searchKey% OR a.fromDate LIKE %:searchKey% OR a.toDate LIKE %:searchKey%)   AND  a.shift.id= :shiftId  AND  DATE_FORMAT(:startDate,'%Y-%m-%d')>=a.fromDate  AND  DATE_FORMAT(:endDate,'%Y-%m-%d')<=a.toDate   AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShift> findShiftReportDateShiftbased(Long shiftId, String startDate, String endDate,
			String searchKey, String companyId);

	@Query(value = "SELECT new com.hrms.admin.dto.AssignShiftDTO(a.id,a.fromDate,a.toDate,a.managerId,a.shift.id,a.shift.shiftName) FROM AssignShift a  WHERE a.employee.id=:employeeId AND a.isDelete=false and a.employee.company.id=:companyId")
	public List<AssignShiftDTO> findByEmpId(Long employeeId, String companyId);

	@Query(value = "SELECT a FROM AssignShift a  WHERE a.employee.company.id=?1 AND a.isDelete=false")
	public List<AssignShift> findAll(String comapnyId);

}
