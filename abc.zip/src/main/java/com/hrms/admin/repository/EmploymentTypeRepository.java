package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.EmploymentTypeDTO;
import com.hrms.admin.entity.EmploymentType;

public interface EmploymentTypeRepository extends JpaRepository<EmploymentType, Long>{

	@Query(value = "select new com.hrms.admin.dto.EmploymentTypeDTO(c.employmentTypeId,c.employmentTypeName) from EmploymentType c ")
	List<EmploymentTypeDTO> getAllEmploymentTypeList();
	
	@Query(value = "from EmploymentType where employmentTypeName=:employmentTypeName")
	public EmploymentType findByEmploymentTypeName(String employmentTypeName);
}
