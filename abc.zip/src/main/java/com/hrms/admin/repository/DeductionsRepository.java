package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Deductions;

public interface DeductionsRepository extends JpaRepository<Deductions, Long> {

	@Query(value = "SELECT count(d.id) FROM Deductions d WHERE   d.deductionName=:name AND d.isDelete=false and d.company.id=:companyId")
	Long getDeductionsCountSave(String name,String companyId);

	@Query(value = "SELECT count(d.id) FROM Deductions d WHERE   d.deductionName=:name AND d.id=:id AND d.isDelete=false and d.company.id=:companyId")
	Long getDeductionsCountUpdate(String name, Long id,String companyId);

//	@Query(value = "SELECT new com.hrms.admin.entity.Deductions(e.id,e.deductionType,e.deductionName,e.calculationType,e.flatAmount,e.percentageOfBasic,e.status) FROM Deductions e WHERE e.branch.id=:branchId AND e.isDelete=false")
	@Query(value = "SELECT new com.hrms.admin.entity.Deductions(e.id,e.deductionType,e.deductionName,e.calculationType,e.flatAmount,e.percentageOfBasic,e.status) FROM Deductions e WHERE e.company.id=:companyId AND e.isDelete=false")
	//	List<Deductions> getAllFields(Long branchId);
	List<Deductions> getAllFields(String companyId);

	
	@Query("select new com.hrms.admin.entity.Deductions(e.id,e.deductionType,e.deductionName,e.calculationType,e.flatAmount,e.percentageOfBasic,e.status) from Deductions e WHERE  (e.deductionName LIKE %?1% OR e.deductionType LIKE %?1% OR e.nameInPayslip LIKE %?1% OR e.percentageOfBasic LIKE %?1% OR e.flatAmount LIKE %?1%) AND (e.status=true OR e.status=false) AND e.isDelete=false and e.company.id=?2")
	Page<Deductions> allDeductionsPage(String searchKey,String companyId, Pageable paging);

	@Query("select new com.hrms.admin.entity.Deductions(e.id,e.deductionType,e.deductionName,e.calculationType,e.flatAmount,e.percentageOfBasic,e.status) from Deductions e WHERE  (e.deductionName LIKE %?1% OR e.deductionType LIKE %?1% OR e.nameInPayslip LIKE %?1% OR e.percentageOfBasic LIKE %?1% OR e.flatAmount LIKE %?1%) AND e.status=?2 AND e.isDelete=false and e.company.id=?3")
	Page<Deductions> DeductionsPage(String searchKey, Boolean status,String companyId, Pageable paging);

//	
//	@Query(value = "SELECT e FROM Deductions e WHERE e.isDelete=false")
//	List<Deductions> getComponents();
	@Query(value = " FROM Deductions d WHERE d.company.id=:companyId AND d.isDelete=false")
	public List<Deductions> findByCompany(String  companyId);

}
