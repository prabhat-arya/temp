package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.SkillDTO;
import com.hrms.admin.entity.Skill;

public interface SkillRepository extends JpaRepository<Skill, Long> {
	
	public Skill findByskillSet(String skilset);
	
	@Query("SELECT a FROM Skill a WHERE a.skillSet=:skillSet AND a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public Skill findBySkillSet(String skillSet,String companyId);
	
	@Query(value = "SELECT count(*) FROM Skill s WHERE   s.skillSet=:skillSet AND s.company.id=:companyId AND s.isDelete=false")
	Long getSkillCountSave(String skillSet, String companyId);

	@Query(value = "SELECT count(*) FROM Skill s WHERE   s.skillSet=:skillSet AND s.company.id=:companyId AND s.id <> :id AND s.isDelete=false")
	Long getSkillCountUpdate(String companyId, String skillSet, Long id);
	
	@Query("FROM Skill a WHERE a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public List<Skill> findByCompany(String companyId);

	// page indicate these methods are use to get the data as Pageable
	@Query("select new com.hrms.admin.dto.SkillDTO(s.id,s.skillSet,s.description,s.company.id,s.company.name) from Skill s WHERE  (s.skillSet  LIKE %?1% OR  s.company.name  LIKE %?1%) AND  s.company.id=?2 and s.isActive=?3 AND s.isDelete=false")
	Page<SkillDTO> skillPage(String searchKey, String companyId,Boolean status, Pageable pageable);

	@Query("select new com.hrms.admin.dto.SkillDTO(s.id,s.skillSet,s.description,s.company.id,s.company.name) from Skill s  WHERE  (s.skillSet  LIKE %?1%   OR  s.company.name  LIKE %?1%) AND s.company.id=?2 and (s.isActive=true OR s.isActive=false) AND s.isDelete=false")
	Page<SkillDTO> allSkillPage(String searchKey, String companyId,Pageable pageable);
	
	@Query("select s from Skill s where s.id=:id and s.company.id=:companyId AND s.isActive=true AND s.isDelete=false")
	public Optional<Skill> findSkillByCompanyId(Long id,String companyId);




}
