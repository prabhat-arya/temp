package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.EmployeeErrorRecords;

@Repository
public interface EmployeeErrorRecordsRepository extends JpaRepository<EmployeeErrorRecords, Long> {
	
	@Query("SELECT e FROM EmployeeErrorRecords e where DATE_FORMAT(e.createdDate,'%Y-%m-%d')=current_date() and e.createdBy=:user")
	public List<EmployeeErrorRecords> getTodayaddedEmployeeErrorRecords(String user);


}
