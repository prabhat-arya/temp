/*
 * package com.hrms.admin.repository;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository; import
 * org.springframework.data.jpa.repository.Query;
 * 
 * import com.hrms.admin.entity.OrgMaster;
 * 
 * public interface OrgMasterRepository extends JpaRepository<OrgMaster, Long> {
 * 
 * @Query(value =
 * "SELECT count(e.id) FROM OrgMaster e WHERE e.orgName=:companyName AND e.userName=:userName"
 * ) public Long getUserSaveCount(String companyName, String userName);
 * 
 * @Query(value =
 * "SELECT count(e.id) FROM OrgMaster e WHERE e.userEmailId=:email") public Long
 * findByEmail(String email);
 * 
 * }
 */