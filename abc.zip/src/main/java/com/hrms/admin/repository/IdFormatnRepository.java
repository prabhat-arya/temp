package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.IdFormat;

public interface IdFormatnRepository extends JpaRepository<IdFormat, Long> {

}
