package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.dto.AssetsDTO;
import com.hrms.admin.entity.Assets;

public interface AssetsRepository extends JpaRepository<Assets, Long> {

//	public Optional<Assets> findByName(String name);

	@Query("SELECT new com.hrms.admin.dto.AssetsDTO(a.id,a.company.name,a.isDelete,a.isActive,a.name,a.description,a.company.id) FROM Assets a WHERE  (a.name LIKE %?1% OR a.company.name LIKE %?1% ) and a.company.id=?2 AND a.isActive=?3 AND a.isDelete=false")
	Page<AssetsDTO> assetsPage(String searchKey,String companyId, Boolean status, Pageable pageable);

	@Query("SELECT new com.hrms.admin.dto.AssetsDTO(a.id,a.company.name,a.isDelete,a.isActive,a.name,a.description,a.company.id) FROM Assets a WHERE  (a.name LIKE %?1% OR a.company.name LIKE %?1%) and a.company.id=?2 AND (a.isActive=true OR a.isActive=false) AND a.isDelete=false")
	Page<AssetsDTO> allAssetsPage(String searchKey,String companyId, Pageable pageable);

	@Query(value = "SELECT count(*) FROM Assets a WHERE   a.name=:name AND a.company.id=:companyId AND a.isDelete=false")
	Long getSkillCountSave(String name, String companyId);

	@Query(value = "SELECT count(*) FROM Assets a WHERE   a.name=:name AND a.company.id=:companyId AND a.id <> :id AND a.isDelete=false")
	Long getSkillCountUpdate(String companyId, String name, Long id);

//	@Query(value = "SELECT a FROM Assets a WHERE  a.name LIKE %?1% AND a.isActive=true AND a.isDelete=false")
//	Page<Assets> findAllSearchWithPaginationActiveRecord(String searchKey, Pageable paging);
//
//	@Query(value = "SELECT a FROM Assets a WHERE  a.name LIKE %?1% AND a.isActive=false AND a.isDelete=false")
//	Page<Assets> findAllSearchWithPaginationInActiveRecord(String searchKey, Pageable paging);

//	@Query("SELECT a FROM Assets a WHERE a.isActive=true AND a.isDelete=false")
//	public List<Assets> findAll();

	//@Query("FROM Assets a WHERE a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	@Query("SELECT new com.hrms.admin.entity.Assets(a.id,a.name,a.description,a.isActive,a.isDelete) FROM Assets a WHERE a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public List<Assets> findByCompany(String companyId);

	@Query("FROM Assets a WHERE a.id=:id and a.company.id=:companyId AND a.isActive=true AND a.isDelete=false")
	public Optional<Assets> findById(Long id, String companyId);
	//@Query("FROM Assets a WHERE a.id=:id AND a.isDelete=false")
	
	@Query("select new com.hrms.admin.entity.Assets(a.id,a.name)FROM Assets a WHERE a.id=:id AND a.isDelete=false")
	public Optional<Assets> findByAsset(Long id);

}
