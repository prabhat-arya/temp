package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.PersonalDetails;

public interface PersonalDetailsRepository extends JpaRepository<PersonalDetails, Long> {

	@Query(value = "SELECT p FROM PersonalDetails p WHERE  p.employee.id=:employeeId")
	List<PersonalDetails> findByEmployee(Long employeeId);


}
