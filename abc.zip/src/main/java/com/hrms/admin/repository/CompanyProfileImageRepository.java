/*
 * package com.hrms.admin.repository;
 * 
 * import org.springframework.data.mongodb.repository.MongoRepository; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.hrms.admin.entity.CompanyProfileImage;
 * 
 * @Repository public interface CompanyProfileImageRepository extends
 * MongoRepository<CompanyProfileImage, Long > {
 * 
 * }
 */