package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.EmployeePromotional;

public interface EmployeePromotionalRepository extends JpaRepository<EmployeePromotional, Long> {

	@Query(value = "SELECT p FROM EmployeePromotional p WHERE  p.employee.id=:employeeId")
	public List<EmployeePromotional> findByEmployee(Long employeeId);

	@Query(value = "SELECT p FROM EmployeePromotional p WHERE  p.employee.id=:employeeId and p.promotionEndDate=null")
	public EmployeePromotional basedOnEmployee(Long employeeId);
}
