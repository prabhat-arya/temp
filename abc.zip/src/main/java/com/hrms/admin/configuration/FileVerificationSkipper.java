/*
 * package com.hrms.admin.configuration;
 * 
 * import java.io.FileNotFoundException; import java.util.ArrayList; import
 * java.util.List;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.batch.core.step.skip.SkipLimitExceededException; import
 * org.springframework.batch.core.step.skip.SkipPolicy; import
 * org.springframework.batch.item.file.FlatFileParseException; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Component;
 * 
 * import com.hrms.admin.entity.AttendanceInfoErrorRecords; import
 * com.hrms.admin.repository.AttendanceInfoErrorRecordsRepository;
 * 
 *//**
	 * Contains method to provide APIs for FileVerificationSkipper
	 * 
	 * @author {Benarji}
	 *
	 *//*
		 * //@Component public class FileVerificationSkipper implements SkipPolicy {
		 * 
		 * @Autowired private AttendanceInfoErrorRecordsRepository
		 * errorRecordsRepository;
		 * 
		 * private static final Logger logger =
		 * LoggerFactory.getLogger("badRecordLogger");
		 * 
		 * @Override public boolean shouldSkip(Throwable exception, int skipCount)
		 * throws SkipLimitExceededException {
		 * 
		 * if (exception instanceof FileNotFoundException) { return false; } else if
		 * (exception instanceof FlatFileParseException) {
		 * 
		 * FlatFileParseException ffpe = (FlatFileParseException) exception;
		 * StringBuilder errorMessage = new StringBuilder();
		 * 
		 * errorMessage.append("An error occured while processing the " +
		 * ffpe.getLineNumber() + " line of the file. Below was the faulty " +
		 * "input.\n");
		 * 
		 * errorMessage.append(ffpe.getInput() + "\n");
		 * errorMessage.append("======================="+ffpe.toString());
		 * 
		 * logger.error("{}", errorMessage.toString());
		 * 
		 * String record = ffpe.getInput(); String [] records = record.split(",");
		 * List<String> recordList = new ArrayList<>();
		 * 
		 * for (String itemFields : records) {
		 * 
		 * recordList.add(itemFields); }
		 * 
		 * if(recordList.size() == 6 && recordList.size() > 5) { String dummyDate =
		 * "0000-00-00"; recordList.add(dummyDate); }
		 * 
		 * AttendanceInfoErrorRecords attandenInfo = new AttendanceInfoErrorRecords();
		 * 
		 * //attandenInfo.setEmpId(Long.parseLong(recordList.get(0)));
		 * //attandenInfo.setEmpName(recordList.get(1));
		 * //attandenInfo.setCompanyName(recordList.get(2));
		 * //attandenInfo.setBranchName(recordList.get(3));
		 * attandenInfo.setInTime(recordList.get(1));
		 * attandenInfo.setOutTime(recordList.get(2));
		 * attandenInfo.setDate(recordList.get(3));
		 * 
		 * System.out.println("===============================");
		 * System.out.println("AttendanceInfoErrorRecordRepository"+attandenInfo.
		 * toString()); errorRecordsRepository.save(attandenInfo);
		 * 
		 * logger.error("{}", errorMessage.toString()); return true; } else { return
		 * false; } } }
		 */