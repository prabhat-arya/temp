/*
 * package com.hrms.admin.configuration;
 * 
 * import java.io.File;
 * 
 * import org.springframework.batch.core.StepContribution; import
 * org.springframework.batch.core.scope.context.ChunkContext; import
 * org.springframework.batch.core.step.tasklet.Tasklet; import
 * org.springframework.batch.repeat.RepeatStatus; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.stereotype.Component;
 * 
 * 
 *//**
	 * Contains method to provide APIs for TaskletStep
	 * 
	 * @author {Benarji}
	 *
	 *//*
		 * //@Component public class TaskletStep implements Tasklet{
		 * 
		 * @Value("${file.upload-dir}") private String filePath;
		 * 
		 * @Override public RepeatStatus execute(StepContribution contribution,
		 * ChunkContext chunkContext) throws Exception { try{ File file = new
		 * File(filePath+"/Attendance.csv"); if(file.delete()){
		 * System.out.println("### TaskletStep:" + file.getName() + " is deleted!");
		 * }else{ System.out.println("Delete operation is failed."); } }catch(Exception
		 * e){ e.printStackTrace(); } return null; }
		 * 
		 * }
		 */