package com.hrms.admin.configuration;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnection;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hrms.admin.util.Constants;


//@Configuration
//@Lazy
public class LoggerConnectionSource {
	private static final Logger log = LoggerFactory.getLogger(LoggerConnectionSource.class);
	private static class Singleton {
		static final LoggerConnectionSource INSTANCE = new LoggerConnectionSource();
	}

//	@Autowired
	private DataSource dataSource;

	public LoggerConnectionSource() {
		Properties properties= new Properties();
		String user = null;
		String password = null;
		String url = null;
		String validationQuery = null;
		
		try (FileReader reader = new FileReader("src/main/resources/application.properties");) { // no need to name intermediate resources if you don't want to
			properties.load(reader);
			user = properties.getProperty("spring.datasource.username");
			password = properties.getProperty("spring.datasource.password");
			url = properties.getProperty("spring.datasource.url");
			validationQuery = properties.getProperty("spring.datasource.validation-query");
		}
		catch (Exception e) {
			log.info("properties file not found Define Db info as src/main/resources/loggerDB.properties",e);
		}
	
		properties.setProperty(Constants.USER, user);
		properties.setProperty(Constants.PASSWORD, password);
		GenericObjectPool<PoolableConnection> pool = new GenericObjectPool<>();
		DriverManagerConnectionFactory connectionFactory = new DriverManagerConnectionFactory(url, properties);
		new PoolableConnectionFactory(connectionFactory, pool, null, validationQuery, 3, false, false,
				Connection.TRANSACTION_READ_COMMITTED);
		this.dataSource = new PoolingDataSource(pool);
	}

	public static Connection getDatabaseConnection() throws SQLException {
		return Singleton.INSTANCE.dataSource.getConnection();
	}
}
