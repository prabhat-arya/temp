/*
 * package com.hrms.admin.configuration;
 * 
 * import org.springframework.batch.core.Job; import
 * org.springframework.batch.core.Step; import
 * org.springframework.batch.core.configuration.annotation.
 * EnableBatchProcessing; import
 * org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
 * import
 * org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
 * import org.springframework.batch.core.launch.support.RunIdIncrementer; import
 * org.springframework.batch.item.ItemProcessor; import
 * org.springframework.batch.item.file.FlatFileItemReader; import
 * org.springframework.batch.item.file.LineMapper; import
 * org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper; import
 * org.springframework.batch.item.file.mapping.DefaultLineMapper; import
 * org.springframework.batch.item.file.transform.DelimitedLineTokenizer; import
 * org.springframework.batch.item.validator.BeanValidatingItemProcessor; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.core.io.FileSystemResource;
 * 
 * import com.hrms.admin.batch.CustomJpaItemWriter; import
 * com.hrms.admin.batch.ValidationProcessor; import
 * com.hrms.admin.entity.AttendanceInfo;
 * 
 * 
 *//**
	 * Contains method to provide APIs for BatchConfiguration
	 * 
	 * @author {Benarji}
	 *
	 *//*
		 * //@Configuration //@EnableBatchProcessing public class BatchConfiguration {
		 * 
		 * @Autowired private JobBuilderFactory jobBuilderFactory;
		 * 
		 * @Autowired private StepBuilderFactory stepBuilderFactory;
		 * 
		 * @Autowired private TaskletStep taskletStep;
		 * 
		 * @Autowired private FileVerificationSkipper fileVerificationSkipper;
		 * 
		 * @Value("${file.upload-dir}") private String filePath;
		 * 
		 * 
		 * @Bean public Job readCSVFilesJob() throws Exception { return
		 * jobBuilderFactory .get("ATTENDANCE-Load") .incrementer(new
		 * RunIdIncrementer()) .start(step1()) .next(step2()) .build(); }
		 * 
		 * @Bean public Step step1() throws Exception { return stepBuilderFactory
		 * .get("ATTENDANCE-file-load") .<AttendanceInfo, AttendanceInfo>chunk(100)
		 * .reader(itemReader()) .faultTolerant() .skipPolicy(fileVerificationSkipper)
		 * .processor(processor()) .writer(writer()) .build(); }
		 * 
		 * @Bean public Step step2() { return stepBuilderFactory.get("step2")
		 * .tasklet(taskletStep) .build(); }
		 * 
		 * @Bean public ItemProcessor<AttendanceInfo, AttendanceInfo> processor() throws
		 * Exception { BeanValidatingItemProcessor<AttendanceInfo> validator = new
		 * BeanValidatingItemProcessor<>(); validator.setFilter(true);
		 * validator.afterPropertiesSet(); return new ValidationProcessor();
		 * 
		 * }
		 * 
		 * @Bean public CustomJpaItemWriter writer() { return new CustomJpaItemWriter();
		 * }
		 * 
		 * @Bean public FlatFileItemReader<AttendanceInfo> itemReader() {
		 * FlatFileItemReader<AttendanceInfo> flatFileItemReader = new
		 * FlatFileItemReader<>(); flatFileItemReader.setResource(new
		 * FileSystemResource(filePath+"/Attendance.csv"));
		 * 
		 * flatFileItemReader.setName("CSV-Reader");
		 * flatFileItemReader.setLinesToSkip(1);
		 * flatFileItemReader.setLineMapper(lineMapper()); return flatFileItemReader; }
		 * 
		 * @Bean public LineMapper<AttendanceInfo> lineMapper() {
		 * DefaultLineMapper<AttendanceInfo> lineMapper = new
		 * DefaultLineMapper<AttendanceInfo>(); DelimitedLineTokenizer lineTokenizer =
		 * new DelimitedLineTokenizer(); lineTokenizer.setNames(new String[] {
		 * "empId","inTime", "outTime", "date" }); lineTokenizer.setIncludedFields(new
		 * int[] { 0, 1, 2, 3}); BeanWrapperFieldSetMapper<AttendanceInfo>
		 * fieldSetMapper = new BeanWrapperFieldSetMapper<AttendanceInfo>();
		 * fieldSetMapper.setTargetType(AttendanceInfo.class);
		 * lineMapper.setLineTokenizer(lineTokenizer);
		 * lineMapper.setFieldSetMapper(fieldSetMapper); return lineMapper; } }
		 */