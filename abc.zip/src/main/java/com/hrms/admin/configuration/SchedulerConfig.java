package com.hrms.admin.configuration;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import com.hrms.admin.entity.PaySchedule;
import com.hrms.admin.repository.PayScheduleRepository;
import com.hrms.admin.service.PayrollService;

@Configuration
public class SchedulerConfig implements SchedulingConfigurer {

	private static final Logger log = LoggerFactory.getLogger(SchedulerConfig.class);
	@Autowired
	private PayrollService payrollService;

	@Autowired
	private PayScheduleRepository payScheduleRepository;

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
//		int day = getNewExecutionTime();
//		String dayString = String.valueOf(day);
//		String s = "0 25 13 " + dayString + " * *";	
//		String s = "0 30 10 01 * *", zone="IST";
//		System.out.println(s);		
		String s = getNewExecutionTime();
		if (s != null) {
			taskRegistrar.addTriggerTask(new Runnable() {
				@Override
				public void run() {
					payrollService.generatePayslipOnEveryMonth();
				}
			}, new Trigger() {
				@Override
				public Date nextExecutionTime(TriggerContext triggerContext) {

					CronTrigger crontrigger = new CronTrigger(s);
					log.info("+++++++++++++" + crontrigger.nextExecutionTime(triggerContext));
					return crontrigger.nextExecutionTime(triggerContext);
				}
			});
		}

	}

//	private int getNewExecutionTime() {
//		int i = 0;
//		List<PaySchedule> findAll = payScheduleRepository.findAll();
//		for (PaySchedule paySchedule : findAll) {
//			i = paySchedule.getPayDaySelected();
//		}
//		return i;
//	}

	private String getNewExecutionTime() {
		String cronexp = null;
		List<PaySchedule> findAll = payScheduleRepository.findAll();
		for (PaySchedule paySchedule : findAll) {
			cronexp = paySchedule.getCronExp();
		}
		return cronexp;
	}

}
