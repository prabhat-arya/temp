/*
 * package com.hrms.admin.batch;
 * 
 * import java.util.List; import java.util.Optional;
 * 
 * import javax.persistence.EntityManagerFactory;
 * 
 * import org.springframework.batch.item.ItemWriter; import
 * org.springframework.batch.item.database.JpaItemWriter; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Component;
 * 
 * import com.hrms.admin.entity.AttendanceInfo; import
 * com.hrms.admin.entity.Employee; import
 * com.hrms.admin.repository.AssignShiftRepository; import
 * com.hrms.admin.repository.EmployeeRepository;
 * 
 *//**
	 * Contains method to provide APIs for CustomJpaItemWriter
	 * 
	 * @author {Benarji}
	 *
	 *//*
		 * //@Component public class CustomJpaItemWriter implements
		 * ItemWriter<AttendanceInfo> {
		 * 
		 * @Autowired private EntityManagerFactory emf;
		 * 
		 * @Autowired private EmployeeRepository empRepo;
		 * 
		 * @Autowired private AssignShiftRepository assignShiftRepository;
		 * 
		 * 
		 * 
		 * @Override public void write(List<? extends AttendanceInfo> items) throws
		 * Exception { for (AttendanceInfo attendanceInfo : items) {
		 * System.out.println("==========================");
		 * System.out.println(attendanceInfo.getEmpId()); Optional<Employee> employee =
		 * empRepo.findById(attendanceInfo.getEmpId());
		 * attendanceInfo.setBranch(employee.get().getBranch()); //Optional<AssignShift>
		 * findByShiftId =
		 * assignShiftRepository.findByShiftId(attendanceInfo.getEmpId());
		 * attendanceInfo.setEmployee(employee.get());
		 * //attendanceInfo.setAssignShift(findByShiftId.get());
		 * 
		 * 
		 * //AttendanceInfo entity = new AttendanceInfo(); //Attendance findById =
		 * attendancesRepository.findByBranchId(items.getBranchId()); //Long NoOfHrs =
		 * items.setNoOfHrs(util.calculateWorkingHours(items.getInTime(),
		 * items.getOutTime())); //attendanceInfo.setBranch(employee.get().getBranch());
		 * //attendanceInfo.setCompanyId(employee.get().getCompanyId());
		 * //attendanceInfo.setAttndsPercentage(util.attendsPersentage(findById.
		 * getInTime(), findById.getOutTime(), NoOfHrs)); }
		 * 
		 * JpaItemWriter<AttendanceInfo> writer = new JpaItemWriter<>();
		 * writer.setEntityManagerFactory(emf); writer.write(items);
		 * 
		 * } }
		 * 
		 * 
		 */