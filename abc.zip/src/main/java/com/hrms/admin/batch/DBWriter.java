package com.hrms.admin.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.repository.AttendanceInfoRepository;

//@Component
public class DBWriter implements ItemWriter<AttendanceInfo> {

	@Autowired
	private AttendanceInfoRepository attRepository;

	@Override
	public void write(List<? extends AttendanceInfo> items) throws Exception {
		attRepository.saveAll(items);
	}
}
