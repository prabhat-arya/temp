/*
 * package com.hrms.admin.batch;
 * 
 * import java.util.HashSet; import java.util.Set;
 * 
 * import org.springframework.batch.item.ItemProcessor; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Component;
 * 
 * import com.hrms.admin.entity.AttendanceInfo; import
 * com.hrms.admin.entity.AttendanceInfoErrorRecords; import
 * com.hrms.admin.entity.Shift; import
 * com.hrms.admin.repository.AssignShiftRepository; import
 * com.hrms.admin.repository.AttendanceInfoErrorRecordsRepository; import
 * com.hrms.admin.repository.EmployeeRepository; import
 * com.hrms.admin.repository.ShiftRepository; import
 * com.hrms.admin.util.StringToDateUtility;
 * 
 *//**
	 * Contains method to provide APIs for ValidationProcessor
	 * 
	 * @author {Benarji}
	 *
	 *//*
		 * //@Component public class ValidationProcessor implements
		 * ItemProcessor<AttendanceInfo, AttendanceInfo> {
		 * 
		 * @Autowired private StringToDateUtility util;
		 * 
		 * @Autowired private AttendanceInfoErrorRecordsRepository attErrorRecord;
		 * 
		 * @Autowired private ShiftRepository shiftRepo;
		 * 
		 * @Autowired private AssignShiftRepository assignShiftRepository;
		 * 
		 * @Autowired private EmployeeRepository empRepo;
		 * 
		 * private Set<AttendanceInfo> seenAttendanceInfo = new HashSet<>();
		 * 
		 * 
		 * @Override public AttendanceInfo process(AttendanceInfo item) throws Exception
		 * { AttendanceInfoErrorRecords attErrorEntity = new
		 * AttendanceInfoErrorRecords(); boolean flag =
		 * empRepo.findById(item.getEmpId()).isEmpty();
		 * 
		 * //System.out.println("========findById======="+findByid.getId()); if
		 * (item.getEmpId() == null || item.getInTime().equals("") ||
		 * item.getOutTime().equals("") || item.getDate().equals("") || flag == true ){
		 * 
		 * attErrorEntity.setEmpId(item.getEmpId());
		 * 
		 * if(item.getInTime().equals("")) { attErrorEntity.setInTime(null); }else {
		 * attErrorEntity.setInTime(item.getInTime()); }
		 * if(item.getOutTime().equals("")) { attErrorEntity.setOutTime(null); }else {
		 * 
		 * attErrorEntity.setOutTime(item.getOutTime()); } if
		 * (item.getDate().equals("")) {
		 * 
		 * attErrorEntity.setDate(null); }else { attErrorEntity.setDate(item.getDate());
		 * } attErrorRecord.save(attErrorEntity); return null; } try { if
		 * (Long.valueOf(item.getEmpId()) <= 0) {
		 * System.out.println("Invalid employee id : " + item.getEmpId()); return null;
		 * } } catch (NumberFormatException e) {
		 * System.out.println("Invalid employee id : " + item.getEmpId()); return null;
		 * } System.out.println(String.format("Converted from [%s] ", item)); if
		 * (item.getInTime().equals("") || item.getOutTime().equals("")) { return null;
		 * } else { item.setNoOfHrs(util.calculateWorkingHours(item.getInTime(),
		 * item.getOutTime())); Long noOfHrs =
		 * util.calculateWorkingHours(item.getInTime(), item.getOutTime()); Shift shift
		 * = new Shift(); Shift actlHrs = shiftRepo.findById(shift.getId()).get();
		 * item.setAttndsPercentage(util.attendsPersentage(actlHrs.getInTime(),
		 * actlHrs.getOutTime(), noOfHrs)); } if(seenAttendanceInfo.contains(item) &&
		 * !item.isProcessed()) {
		 * 
		 * return null; } else { seenAttendanceInfo.add(item); item.setProcessed(true);
		 * return item;
		 * 
		 * } } }
		 */