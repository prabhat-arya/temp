package com.hrms.admin.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.util.StringToDateUtility;

//@Component
public class Processor implements ItemProcessor<AttendanceInfo, AttendanceInfo> {

	@Autowired
	private StringToDateUtility util;

//	private Set<AttendanceInfo> seenAttendance = new HashSet<AttendanceInfo>();
	@Override
	public AttendanceInfo process(AttendanceInfo item) throws Exception {
		item.getEmployee().getId();
		//item.getBranch();
		item.getInTime();
		item.getInTime(); 
		item.getDate(); 
		item.setNoOfHrs(util.calculateWorkingHours(item.getInTime(), item.getOutTime()));
		return item;
	}

	
	
}
