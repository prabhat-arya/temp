package com.hrms.admin.schedulingtasks;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.repository.AnnualLeavesRepository;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.SalaryComponentsRepository;
import com.hrms.admin.util.AnnualLeavesUtil;
import com.hrms.admin.util.Constants;
import com.hrms.admin.util.EmailServiceUtil;

@Component
public class ScheduledTasks {

	@Autowired
	private EmployeeRepository repo;

	@Autowired
	private EmailServiceUtil emailService;
	@Autowired
	private AnnualLeavesUtil annualLeavesUtil;

	@Autowired
	SalaryComponentsRepository salaryComponentsRepository;

//	@Autowired
//	MonthlySalaryDetailsRepository monthlySalaryDetailsRepository;

	@Autowired
	AnnualLeavesRepository annualLeavesRepository;

	@Autowired
	EmpLeaveRepository empLeaveRepository;

	private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

	private static final long MILLIS_IN_A_DAY = 1000 * 60 * 60 * 24L;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("MMM-dd");

	@Scheduled(cron = "0 0 6 * * *", zone="IST")
	public void sendWishes() {
		log.info("early morning scheduler start running");
		try {
			Date today = new Date();
			ZoneId z = ZoneId.systemDefault();
			Calendar c = Calendar.getInstance(TimeZone.getTimeZone(z));
			log.info("time Zone:{}"+c);
			c.setTime(today);
			int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
			// Friday is 6
			if (dayOfWeek == 6) {

				// Today's Occasion
				findEmpMarriageDay(today, Constants.HAPPY_MARRIAGEDAY);
				findEmployeeBirthday(today, Constants.HAPPY_BIRTHDAY);
				findEmpJoinningDay(today, Constants.HAPPY_JOINNINGDAY);

				// Saturday Occasion
				Date saturday = new Date(today.getTime() + MILLIS_IN_A_DAY);
				findEmployeeBirthday(saturday, Constants.ADVANCE_BIRTHDAY_WISHES);
				findEmpMarriageDay(saturday, Constants.ADVANCE_MARRIAGEDAY_ANNIVERSARY_WISHES);
				findEmpJoinningDay(saturday, Constants.ADVANCE_JOINNINGDAY_WISHES);

				// Sunday Occasion
				Date sunday = new Date(saturday.getTime() + MILLIS_IN_A_DAY);
				findEmployeeBirthday(sunday, Constants.ADVANCE_BIRTHDAY_WISHES);
				findEmpMarriageDay(sunday, Constants.ADVANCE_MARRIAGEDAY_ANNIVERSARY_WISHES);
				findEmpJoinningDay(sunday, Constants.ADVANCE_JOINNINGDAY_WISHES);
				log.info("time Zone:{}"+c);
			} else {
				// Today's Occasion
				findEmployeeBirthday(today, Constants.HAPPY_BIRTHDAY);
				findEmpMarriageDay(today, Constants.HAPPY_MARRIAGEDAY);
				findEmpJoinningDay(today, Constants.HAPPY_JOINNINGDAY);
			}
		} catch (Exception e) {
			log.info("mid night scheduler stop running" + e);
		}
	}

	/* find employee birthday based on date */
	void findEmployeeBirthday(Date date2, String msg) {
		List<Employee> findByBirthday = repo.findBirthday1(date2);
		log.info("employee birthday found");
		for (Employee employee : findByBirthday) {
			sendNotificationMail(employee, msg, date2);
		}
	}

	void findEmpMarriageDay(Date date2, String msg) {
		List<Employee> findEmpMarriageDay = repo.findMarraigeDay1(date2);
		log.info("employee MarriageDay found");
		for (Employee employee : findEmpMarriageDay) {
			sendNotificationMail(employee, msg, date2);
		}
	}

	void findEmpJoinningDay(Date date2, String msg) {
		List<Employee> findEmpJoinningDay = repo.findJoiningDay1(date2);
		log.info("employee JoinningDay found");
		for (Employee employee : findEmpJoinningDay) {
			sendNotificationMail(employee, msg, date2);
		}
	}

	/* send wish massage to employee through mail */
	private void sendNotificationMail(Employee employee, String msg, Date date2) {
		List<Employee> findAll = repo.findByCompany(employee.getCompany().getId());
		log.info("all employee found for sending mail");
		for (Employee employee2 : findAll) {
			if (employee2.getOfficalMail() != null) {
				MailDTO request = new MailDTO();
				request.setTo(employee2.getOfficalMail());
				request.setSubject("***** " + msg + " " + employee.getFirstName() + " " + employee.getLastName() + " "
						+ dateFormat.format(date2) + " ******");
				request.setCompanyId(employee.getCompany().getId());
				Map<String, Object> model = new HashMap<>();
				model.put("Name", employee.getFirstName() + " " + employee.getLastName());
				model.put("msg", msg);
				emailService.sendOccationEmail(request, model);
				log.info("Occasion mail send to::{} ", employee2.getOfficalMail());
			}
		}
	}

	@Scheduled(cron = "00 00 01 01 * *", zone="IST")
	public void addIntialLeaves() {
		annualLeavesUtil.addIntialLeaves();
	}

	@Scheduled(cron = "01 00 00 01 01 *", zone="IST")
	public void deleteAnnualLeaves() {
		annualLeavesUtil.deleteAnnualLeaves();
	}

}
