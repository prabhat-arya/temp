set @msg = '0';
call sp_pulldefault_project_data(@msg);
select @msg;